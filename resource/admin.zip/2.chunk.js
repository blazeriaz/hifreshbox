webpackJsonp([2],{

/***/ "../../../../../src/admin/layouts/empty-layout.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/@angular/core.es5.js");
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return emptyLayoutComponent; });
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var emptyLayoutComponent = (function () {
    function emptyLayoutComponent() {
    }
    emptyLayoutComponent.prototype.ngOnInit = function () { };
    return emptyLayoutComponent;
}());
emptyLayoutComponent = __decorate([
    __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
        selector: 'empty-layout',
        template: '<router-outlet></router-outlet>'
    }),
    __metadata("design:paramtypes", [])
], emptyLayoutComponent);

//# sourceMappingURL=empty-layout.component.js.map

/***/ }),

/***/ "../../../../../src/admin/users/form.component.html":
/***/ (function(module, exports) {

module.exports = "<form [formGroup]=\"userForm\" (submit)=\"saveUser()\" novalidate>\r\n<div class=\"animated fadeIn\">\r\n  <div class=\"row\">\r\n    <div class=\"col-md-12\">\r\n      <div class=\"card mb-0 border-bottom-0\">\r\n        <div class=\"card-header bg-primary\">\r\n          <i class=\"fa fa-user\"></i> Account Information\r\n        </div>\r\n        <div class=\"card-block\">\r\n          <div class=\"form-group row\">\r\n            <label for=\"user_first_name\" class=\"col-md-2 col-sm-4 form-control-label\">First Name</label>\r\n            <div class=\"col-md-4 col-sm-8\" [ngClass]=\"setContainerErrorClass('firstname')\">\r\n              <input type=\"text\" class=\"form-control\" id=\"user_first_name\" formControlName=\"firstname\" \r\n                [ngClass]=\"setInputErrorClass('firstname')\" />\r\n            </div>\r\n            \r\n            <label for=\"user_last_name\" class=\"col-md-2 col-sm-4 form-control-label\">Last Name</label>\r\n            <div class=\"col-md-4 col-sm-8\" [ngClass]=\"setContainerErrorClass('lastname')\">\r\n              <input type=\"text\" class=\"form-control\" id=\"user_last_name\" formControlName=\"lastname\" \r\n                [ngClass]=\"setInputErrorClass('lastname')\" />\r\n            </div>\r\n          </div>\r\n          <div class=\"form-group row\">\r\n            <label for=\"user_email\" class=\"col-md-2 col-sm-4 form-control-label\">Email</label>\r\n            <div class=\"col-md-10 col-sm-8\" [ngClass]=\"setContainerErrorClass('email')\">\r\n              <input type=\"email\" class=\"form-control\" id=\"user_email\" formControlName=\"email\" \r\n                [ngClass]=\"setInputErrorClass('email')\" />\r\n            </div>\r\n          </div>\r\n          <div class=\"form-group row\">\r\n            <label class=\"col-md-2 col-sm-4 form-control-label\">Gender</label>\r\n            <div class=\"col-md-10 col-sm-8\">\r\n              <div class=\"btn-group\">\r\n                <button type=\"button\" class=\"btn\" (click)=\"setGender(1)\" [ngClass]=\"setGenderClass(1)\">\r\n                  <i class=\"fa fa-male\"></i> Male</button>\r\n                <button type=\"button\" class=\"btn\" (click)=\"setGender(2)\" [ngClass]=\"setGenderClass(2)\">\r\n                  <i class=\"fa fa-female\"></i> Female</button>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n  <div class=\"row\">\r\n    <div class=\"col-md-12\">\r\n      <div class=\"card mb-0 border-bottom-0\">\r\n        <div class=\"card-header bg-primary\">\r\n          <i class=\"fa fa-list\"></i> Address\r\n          <button type=\"button\" class=\"btn btn-warning text-white pull-right\" (click)=\"addNewAddress()\">Add New Address</button>\r\n        </div>\r\n        <div class=\"card-block\">\r\n          <div class=\"row\">\r\n            <div class=\"col-md-4\" *ngFor=\"let address of userForm.get('addresses').value; let index = index;\">\r\n              <div class=\"card card-faded\">\r\n                <div class=\"card-block\" [ngClass]=\"setAddressClass(index)\">\r\n                  <address>\r\n                    <strong>{{address.firstname}} {{address.lastname}}</strong><br>\r\n                    <span *ngFor=\"let str of address.street\">{{str}}<br *ngIf=\"str\" /></span>\r\n                    <span *ngIf=\"address.city\">{{address.city}}, </span>\r\n                    <span *ngIf=\"address.region.region\">{{address.region.region}}, </span>\r\n                    <span>{{address.country_id}} {{address.postcode}}</span><br />\r\n                    <abbr title=\"Phone\" *ngIf=\"address.telephone\">P:</abbr> {{address.telephone}}\r\n                  </address>\r\n                </div>\r\n                <div class=\"card-footer p-0\">\r\n                  <div class=\"btn-group\">\r\n                    <button type=\"button\" class=\"btn btn-secondary border-0\" \r\n                        (click)=\"doEditAddress(index)\">\r\n                      <i class=\"fa fa-edit\"></i> Edit</button>\r\n                    <button type=\"button\" class=\"btn btn-secondary border-0\" \r\n                        (click)=\"deleteAddress(index)\">\r\n                      <i class=\"fa fa-remove\"></i> Delete</button>\r\n                    <button type=\"button\" class=\"btn btn-secondary border-0\" \r\n                        *ngIf=\"!address.default_shipping\" \r\n                        (click)=\"setDefaultAddress(index)\">\r\n                      <i class=\"fa fa-star\"></i> Default</button>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </div>\r\n          <div class=\"row\">\r\n            <div class=\"col-md-12\" formArrayName=\"addresses\">\r\n              <div *ngFor=\"let address of userForm.get('addresses').controls; let index = index;\">\r\n                <div class=\"card\" [formGroupName]=\"index\" *ngIf=\"index == indexEditAddress\">\r\n                  <div class=\"card-header bg-primary\">\r\n                    <i class=\"fa fa-edit\"></i> Edit Address\r\n                  </div>\r\n                  <div class=\"card-block\">\r\n                    <div class=\"form-group row\">\r\n                      <label for=\"address_first_name\" class=\"col-md-2 col-sm-4 form-control-label\">First Name</label>\r\n                      <div class=\"col-md-4 col-sm-8\" [ngClass]=\"setAddressDivClass('firstname')\">\r\n                        <input type=\"text\" class=\"form-control\" id=\"address_first_name\" formControlName=\"firstname\" \r\n                           [ngClass]=\"setAddressInputClass('firstname')\" /></div>\r\n                      <label for=\"address_last_name\" class=\"col-md-2 col-sm-4 form-control-label\">Last Name</label>\r\n                      <div class=\"col-md-4 col-sm-8\" [ngClass]=\"setAddressDivClass('firstname')\">\r\n                        <input type=\"text\" class=\"form-control\" id=\"address_last_name\" formControlName=\"lastname\" \r\n                           [ngClass]=\"setAddressInputClass('lastname')\" /></div>\r\n                    </div>\r\n                    <div class=\"form-group row\" formArrayName=\"street\">\r\n                      <label for=\"address_street_0\" class=\"col-md-2 form-control-label\">Street Address</label>\r\n                      <div class=\"col-md-5\" [ngClass]=\"setAddressDivClass('street')\">\r\n                        <input type=\"text\" class=\"form-control\" id=\"address_street_0\" formControlName=\"0\" \r\n                           [ngClass]=\"setAddressInputClass('street')\" /></div>\r\n                      <div class=\"col-md-5\">\r\n                        <input type=\"text\" class=\"form-control\" id=\"address_street_1\" formControlName=\"1\" /></div>\r\n                    </div>\r\n                    <div class=\"form-group row\">\r\n                      <label for=\"address_city\" class=\"col-md-2 form-control-label\">City</label>\r\n                      <div class=\"col-md-10\" [ngClass]=\"setAddressDivClass('city')\">\r\n                        <input type=\"text\" class=\"form-control\" id=\"address_city\" formControlName=\"city\" \r\n                           [ngClass]=\"setAddressInputClass('city')\" /></div>\r\n                    </div>\r\n                    <div class=\"form-group row\">\r\n                      <label for=\"address_postcode\" class=\"col-md-2 form-control-label\">Post Code</label>\r\n                      <div class=\"col-md-10\" [ngClass]=\"setAddressDivClass('postcode')\">\r\n                        <input type=\"text\" class=\"form-control\" id=\"address_postcode\" formControlName=\"postcode\" \r\n                           [ngClass]=\"setAddressInputClass('postcode')\" /></div>\r\n                    </div>\r\n                    <div class=\"form-group row\" [ngClass]=\"setAddressDivClass('telephone')\">\r\n                      <label for=\"address_telephone\" class=\"col-md-2 form-control-label\">Phone</label>\r\n                      <div class=\"col-md-10\">\r\n                        <input type=\"text\" class=\"form-control\" id=\"address_telephone\" formControlName=\"telephone\" \r\n                           [ngClass]=\"setAddressInputClass('telephone')\" /></div>\r\n                    </div>\r\n                    <div class=\"form-group row\">\r\n                      <label for=\"address_country\" class=\"col-md-2 form-control-label\">Country</label>\r\n                      <div class=\"col-md-10\" *ngIf=\"countries.length > 0\">\r\n                        <ng-select [allowClear]=\"true\" [multiple]=\"false\"\r\n                          [items]=\"countries\" \r\n                          [active]=\"getActiveCountry()\" \r\n                          (data)=\"refreshCountryValue($event)\"\r\n                          placeholder=\"No country selected\">\r\n                        </ng-select>\r\n                      </div>\r\n                    </div>\r\n                    <div class=\"form-group row\">\r\n                      <label for=\"address_region\" class=\"col-md-2 form-control-label\">Region</label>\r\n                      <div class=\"col-md-10\" *ngIf=\"getActiveCountryRegions()\">\r\n                        <ng-select [allowClear]=\"true\" [multiple]=\"false\"\r\n                          [items]=\"getActiveCountryRegions()\" \r\n                          [active]=\"getActiveRegion()\" \r\n                          (data)=\"refreshRegionValue($event)\"\r\n                          placeholder=\"No region selected\">\r\n                        </ng-select>\r\n                      </div>\r\n                      <div class=\"col-md-10\" *ngIf=\"!getActiveCountryRegions()\" formGroupName=\"region\">\r\n                        <input type=\"text\" class=\"form-control\" id=\"address_region\" formControlName=\"region\" />\r\n                      </div>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n        <div class=\"card-footer bg-info\">\r\n          <div class=\"btn-group\">\r\n            <button type=\"submit\" class=\"btn btn-primary\">Submit</button>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div></form>\r\n"

/***/ }),

/***/ "../../../../../src/admin/users/form.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/@angular/core.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/@angular/router.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_services__ = __webpack_require__("../../../../../src/services/index.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_forms__ = __webpack_require__("../../../forms/@angular/forms.es5.js");
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return customerEditResolve; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return UserFormComponent; });
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var customerEditResolve = (function () {
    function customerEditResolve(usersService) {
        this.usersService = usersService;
    }
    customerEditResolve.prototype.resolve = function (route) {
        var userId = route.params['id'];
        return this.usersService.getUser(userId);
    };
    return customerEditResolve;
}());
customerEditResolve = __decorate([
    __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Injectable"])(),
    __metadata("design:paramtypes", [typeof (_a = typeof __WEBPACK_IMPORTED_MODULE_2_services__["e" /* UsersService */] !== "undefined" && __WEBPACK_IMPORTED_MODULE_2_services__["e" /* UsersService */]) === "function" && _a || Object])
], customerEditResolve);

var UserFormComponent = (function () {
    function UserFormComponent(usersService, alert, _fb, route, router) {
        var _this = this;
        this.usersService = usersService;
        this.alert = alert;
        this._fb = _fb;
        this.route = route;
        this.router = router;
        this.countries = [];
        this.regionsAll = [];
        this.available_regions = [];
        this.usersService.getCountries().subscribe(function (data) {
            data.filter(function (data) {
                _this.available_regions[data.id] = null;
                if (data.available_regions) {
                    _this.available_regions[data.id] = [];
                    data.available_regions.filter(function (region) {
                        _this.regionsAll.push(region);
                        _this.available_regions[data.id].push({ id: region.id, text: region.name });
                    });
                }
                _this.countries.push({ id: data.id, text: data.full_name_locale });
            });
        });
    }
    UserFormComponent.prototype.initUserForm = function (user) {
        var _this = this;
        this.userForm = this._fb.group({
            'id': this.user.id,
            'store_id': 1,
            'website_id': 1,
            'firstname': [this.user.firstname, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["Validators"].required],
            'lastname': [this.user.lastname, [__WEBPACK_IMPORTED_MODULE_3__angular_forms__["Validators"].required]],
            'email': [this.user.email, [__WEBPACK_IMPORTED_MODULE_3__angular_forms__["Validators"].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["Validators"].email]],
            'gender': this.user.gender,
            'addresses': this._fb.array([])
        });
        this.userForm.valueChanges.subscribe(function (data) {
            if (!_this.indexEditAddress)
                return;
            var region_id = data.addresses[_this.indexEditAddress].region_id;
            var region_name = data.addresses[_this.indexEditAddress].region.region;
            if (region_id == 0) {
                _this.patchAddressValue(_this.indexEditAddress, {
                    region_id: 0,
                    region: {
                        region_id: 0,
                        region_code: region_name,
                        region: region_name
                    }
                });
            }
        });
    };
    UserFormComponent.prototype.initAddressForm = function (address) {
        return this._fb.group({
            'id': address.id,
            'customer_id': address.customer_id,
            'firstname': [address.firstname, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["Validators"].required],
            'lastname': [address.lastname, [__WEBPACK_IMPORTED_MODULE_3__angular_forms__["Validators"].required]],
            'street': this._fb.array([
                new __WEBPACK_IMPORTED_MODULE_3__angular_forms__["FormControl"](address.street[0], __WEBPACK_IMPORTED_MODULE_3__angular_forms__["Validators"].required),
                new __WEBPACK_IMPORTED_MODULE_3__angular_forms__["FormControl"](address.street[1] ? address.street[1] : '')
            ]),
            'city': address.city,
            'country_id': [address.country_id, [__WEBPACK_IMPORTED_MODULE_3__angular_forms__["Validators"].required]],
            'region_id': address.region_id,
            'region': this._fb.group({
                'region_id': (address.region) ? address.region.region_id : '',
                'region_code': [(address.region) ? address.region.region_code : '', __WEBPACK_IMPORTED_MODULE_3__angular_forms__["Validators"].required],
                'region': [(address.region) ? address.region.region : '', __WEBPACK_IMPORTED_MODULE_3__angular_forms__["Validators"].required]
            }),
            'postcode': [address.postcode, [__WEBPACK_IMPORTED_MODULE_3__angular_forms__["Validators"].required]],
            'telephone': [address.telephone, [__WEBPACK_IMPORTED_MODULE_3__angular_forms__["Validators"].required]],
            'default_shipping': address.default_shipping,
            'default_billing': address.default_billing
        });
    };
    UserFormComponent.prototype.ngOnInit = function () {
        var _this = this;
        var userId = this.route.snapshot.params['id'];
        this.user = (userId) ? this.route.snapshot.data['user'] : {};
        this.initUserForm(this.user);
        if (userId) {
            this.user.addresses.map(function (address, i) {
                if (address.default_shipping) {
                    _this.indexDefaultAddress = i;
                }
                _this.userForm.controls['addresses'].push(_this.initAddressForm(address));
            });
            this.doEditAddress(0);
        }
        else {
            this.addNewAddress();
            this.setDefaultAddress(0, true);
        }
    };
    UserFormComponent.prototype.getActiveCountry = function () {
        var country_id = this.userForm.value.addresses[this.indexEditAddress].country_id;
        return this.countries.filter(function (x) { return x.id == country_id; });
    };
    UserFormComponent.prototype.getActiveCountryRegions = function () {
        var available_regions = this.available_regions[this.userForm.value.addresses[this.indexEditAddress].country_id];
        return available_regions;
    };
    UserFormComponent.prototype.getActiveRegion = function () {
        var regions = this.getActiveCountryRegions();
        if (!regions)
            return;
        var region_id = this.userForm.value.addresses[this.indexEditAddress].region_id;
        return regions.filter(function (x) { return x.id == region_id; });
    };
    UserFormComponent.prototype.refreshCountryValue = function (country) {
        this.patchAddressValue(this.indexEditAddress, { country_id: country.id });
    };
    UserFormComponent.prototype.refreshRegionValue = function (selectedRegion) {
        var region = this.regionsAll.find(function (x) { return x.id == selectedRegion.id; });
        this.patchAddressValue(this.indexEditAddress, {
            region_id: region.id,
            region: {
                region_id: region.id,
                region_code: region.code,
                region: region.name
            }
        });
    };
    UserFormComponent.prototype.setAddressClass = function (i) {
        return {
            'bg-primary text-white': this.indexDefaultAddress == i,
            'bg-warning text-white': this.indexEditAddress == i,
            'bg-danger text-white': this.submitted && this.userForm.controls.addresses.controls[i].invalid,
        };
    };
    UserFormComponent.prototype.setGender = function (gender) {
        this.userForm.patchValue({ gender: gender });
    };
    UserFormComponent.prototype.getGender = function () {
        return this.userForm.value.gender;
    };
    UserFormComponent.prototype.patchAddressValue = function (i, values) {
        if (this.userForm.controls['addresses'].controls[i])
            this.userForm.controls['addresses'].controls[i].patchValue(values);
    };
    UserFormComponent.prototype.setGenderClass = function (type) {
        if (this.getGender() == type) {
            return 'bg-primary';
        }
        else {
            return 'bg-secondary';
        }
    };
    UserFormComponent.prototype.setInputErrorClass = function (input) {
        var invalid = this.userForm.get(input).invalid && this.submitted;
        if (invalid)
            return 'form-control-danger';
    };
    UserFormComponent.prototype.setContainerErrorClass = function (input) {
        var invalid = this.userForm.get(input).invalid && this.submitted;
        if (invalid)
            return 'has-danger';
    };
    UserFormComponent.prototype.setAddressInputClass = function (input) {
        var invalid = this.userForm.controls['addresses'].controls[this.indexEditAddress].get(input).invalid;
        if (invalid && this.submitted)
            return 'form-control-danger';
    };
    UserFormComponent.prototype.setAddressDivClass = function (input) {
        var invalid = this.userForm.controls['addresses'].controls[this.indexEditAddress].get(input).invalid;
        if (invalid && this.submitted)
            return 'has-danger';
    };
    UserFormComponent.prototype.setDefaultAddress = function (i, first) {
        if (first || confirm('Are you sure want to change default Address?')) {
            if (!this.indexDefaultAddress) {
                this.patchAddressValue(this.indexDefaultAddress, {
                    default_shipping: null,
                    default_billing: null
                });
            }
            this.indexDefaultAddress = i;
            this.patchAddressValue(this.indexDefaultAddress, {
                default_shipping: true,
                default_billing: true
            });
        }
    };
    UserFormComponent.prototype.doEditAddress = function (i) {
        this.indexEditAddress = i;
    };
    UserFormComponent.prototype.deleteAddress = function (i) {
        if (i == this.indexDefaultAddress) {
            alert("You can't delete the default address");
            return;
        }
        if (confirm('Are you sure want to delete the address?')) {
            this.userForm.controls['addresses'].removeAt(i);
            this.doEditAddress(0);
        }
    };
    UserFormComponent.prototype.addNewAddress = function () {
        var newAddress = {
            id: 0,
            customer_id: this.user.id,
            firstname: this.user.firstname,
            lastname: this.user.lastname,
            street: ['', ''],
            city: "",
            region: {
                region_code: null,
                region: null,
                region_id: 0
            },
            region_id: 0,
            country_id: "US",
            postcode: "",
            telephone: ""
        };
        this.userForm.controls['addresses'].push(this.initAddressForm(newAddress));
        this.doEditAddress(this.userForm.controls['addresses'].controls.length - 1);
    };
    UserFormComponent.prototype.saveUser = function () {
        var _this = this;
        this.alert.clear();
        this.submitted = true;
        if (this.userForm.dirty && this.userForm.valid) {
            var userId = this.route.snapshot.params['id'];
            userId = (userId) ? userId : '';
            this.usersService.saveUser(userId, { customer: this.userForm.value }).subscribe(function (data) {
                _this.alert.success("The customer details are saved successfully!", true);
                _this.router.navigate(['users']);
            }, function (error) {
                if (error.status == 401) {
                    _this.alert.error("Access restricted!");
                }
                else {
                    _this.alert.error("Server Error");
                }
                window.scrollTo(0, 0);
            });
        }
        else {
            this.alert.error("Please check the form to enter all required details");
            window.scrollTo(0, 0);
        }
    };
    return UserFormComponent;
}());
UserFormComponent = __decorate([
    __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
        template: __webpack_require__("../../../../../src/admin/users/form.component.html")
    }),
    __metadata("design:paramtypes", [typeof (_b = typeof __WEBPACK_IMPORTED_MODULE_2_services__["e" /* UsersService */] !== "undefined" && __WEBPACK_IMPORTED_MODULE_2_services__["e" /* UsersService */]) === "function" && _b || Object, typeof (_c = typeof __WEBPACK_IMPORTED_MODULE_2_services__["b" /* AlertService */] !== "undefined" && __WEBPACK_IMPORTED_MODULE_2_services__["b" /* AlertService */]) === "function" && _c || Object, typeof (_d = typeof __WEBPACK_IMPORTED_MODULE_3__angular_forms__["FormBuilder"] !== "undefined" && __WEBPACK_IMPORTED_MODULE_3__angular_forms__["FormBuilder"]) === "function" && _d || Object, typeof (_e = typeof __WEBPACK_IMPORTED_MODULE_1__angular_router__["b" /* ActivatedRoute */] !== "undefined" && __WEBPACK_IMPORTED_MODULE_1__angular_router__["b" /* ActivatedRoute */]) === "function" && _e || Object, typeof (_f = typeof __WEBPACK_IMPORTED_MODULE_1__angular_router__["a" /* Router */] !== "undefined" && __WEBPACK_IMPORTED_MODULE_1__angular_router__["a" /* Router */]) === "function" && _f || Object])
], UserFormComponent);

var _a, _b, _c, _d, _e, _f;
//# sourceMappingURL=form.component.js.map

/***/ }),

/***/ "../../../../../src/admin/users/list.component.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"animated fadeIn\">\r\n  <div class=\"row\">\r\n    <div class=\"col-md-12\">\r\n      <div class=\"card\">\r\n        <div class=\"card-header\">\r\n          <i class=\"fa fa-users\"></i> Users\r\n          <div  class=\"pull-right\"><a [routerLink]=\"'add'\" class=\"btn btn-primary\">Add</a></div>\r\n        </div>\r\n        <div class=\"card-block\">\r\n          <div class=\"row py-2 bg-info\">\r\n            <div class=\"col-md-3\">Name</div>\r\n            <div class=\"col-md-3\">Email</div>\r\n            <div class=\"col-md-3\">Phone</div>\r\n            <div class=\"col-md-3\">Region</div>\r\n          </div>  \r\n\r\n          <div class=\"row py-2\" [ngClass]=\"{'bg-faded': odd}\" *ngFor=\"let user of users; let odd= odd;\">\r\n            <div class=\"col-md-3\">\r\n              <i class=\"fa fa-male\" *ngIf=\"user.gender == 1\"></i>\r\n              <i class=\"fa fa-female\" *ngIf=\"user.gender == 2\"></i>\r\n              {{user.firstname}} {{user.lastname}}\r\n            </div>\r\n            <div class=\"col-md-3\">\r\n              {{user.email}}</div>\r\n            <div class=\"col-md-3\">\r\n              <span *ngIf=\"user.default_shipping\">{{user.default_shipping.telephone}}</span></div>\r\n            <div class=\"col-md-3\">\r\n              <span *ngIf=\"user.default_shipping && user.default_shipping.region.region\">{{user.default_shipping.region.region}}, </span>\r\n              <span *ngIf=\"user.default_shipping\">{{user.default_shipping.country_id}}</span></div>\r\n            <div class=\"col-md-12\">              \r\n              <div class=\"btn-group btn-group-sm\">\r\n                <a [routerLink]=\"['edit', user.id]\" class=\"btn btn-link pl-0\">Edit</a>\r\n                <button type=\"button\" class=\"btn btn-link px-0\" (click)=\"deleteUser(user.id)\">Delete</button>\r\n              </div>\r\n            </div>\r\n          </div>\r\n\r\n          <div class=\"row mt-2\"><div class=\"col-md-12\">\r\n            <ul class=\"pagination pull-right\">\r\n              <li class=\"page-item\" [ngClass]=\"{disabled:pager.currentPage === 1}\">\r\n                <a class=\"page-link\" href=\"javascript:void(0);\" (click)=\"setPage(1);\">First</a></li>\r\n              <li class=\"page-item\" [ngClass]=\"{disabled:pager.currentPage === 1}\">\r\n                <a class=\"page-link\" href=\"javascript:void(0);\" (click)=\"setPage(pager.currentPage - 1);\">Prev</a></li>\r\n              <li class=\"page-item active\" *ngFor=\"let page of pager.pages\" [ngClass]=\"{active:pager.currentPage === page}\">\r\n                <a class=\"page-link\" href=\"javascript:void(0);\" (click)=\"setPage(page);\">{{page}}</a>\r\n              </li>\r\n              <li class=\"page-item\" [ngClass]=\"{disabled:pager.currentPage === pager.totalPages}\">\r\n                <a class=\"page-link\" href=\"javascript:void(0);\" (click)=\"setPage(pager.currentPage + 1);\">Next</a></li>\r\n            </ul>\r\n          </div></div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n"

/***/ }),

/***/ "../../../../../src/admin/users/list.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/@angular/core.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/@angular/router.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_services__ = __webpack_require__("../../../../../src/services/index.ts");
/* unused harmony export pageSize */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return customerListResolve; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return UsersListComponent; });
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var pageSize = 10;
var customerListResolve = (function () {
    function customerListResolve(usersService) {
        this.usersService = usersService;
    }
    customerListResolve.prototype.resolve = function (route) {
        return this.usersService.getUsers(1, [], pageSize);
    };
    return customerListResolve;
}());
customerListResolve = __decorate([
    __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Injectable"])(),
    __metadata("design:paramtypes", [typeof (_a = typeof __WEBPACK_IMPORTED_MODULE_2_services__["e" /* UsersService */] !== "undefined" && __WEBPACK_IMPORTED_MODULE_2_services__["e" /* UsersService */]) === "function" && _a || Object])
], customerListResolve);

var UsersListComponent = (function () {
    function UsersListComponent(usersService, alert, pagerService, route, router) {
        this.usersService = usersService;
        this.alert = alert;
        this.pagerService = pagerService;
        this.route = route;
        this.router = router;
    }
    UsersListComponent.prototype.ngOnInit = function () {
        var users = this.route.snapshot.data['users'];
        this.initUsersList(users);
    };
    UsersListComponent.prototype.initUsersList = function (users, page) {
        this.users = users.items;
        for (var _i = 0, _a = this.users; _i < _a.length; _i++) {
            var user = _a[_i];
            user.default_shipping = user.addresses.find(function (x) { return x.default_shipping == 1; });
            user.default_billing = user.addresses.find(function (x) { return x.default_shipping == 1; });
        }
        // get pager object from service
        page = page ? page : 1;
        this.pager = this.pagerService.getPager(users.total_count, page, pageSize);
    };
    UsersListComponent.prototype.setPage = function (page) {
        var _this = this;
        this.usersService.getUsers(page, [], pageSize).subscribe(function (users) {
            _this.initUsersList(users, page);
        });
    };
    UsersListComponent.prototype.deleteUser = function (userId) {
        var _this = this;
        if (!confirm("Are you sure to delete the customer?")) {
            return;
        }
        this.alert.clear();
        this.usersService.deleteUser(userId).subscribe(function (data) {
            if (data) {
                _this.alert.success("The customer deleted successfully!", true);
                var page_1 = 1;
                _this.usersService.getUsers(page_1, [], pageSize).subscribe(function (users) {
                    _this.initUsersList(users, page_1);
                });
            }
            else {
                _this.alert.error("The customer can't be deleted!", true);
            }
        });
    };
    return UsersListComponent;
}());
UsersListComponent = __decorate([
    __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
        template: __webpack_require__("../../../../../src/admin/users/list.component.html")
    }),
    __metadata("design:paramtypes", [typeof (_b = typeof __WEBPACK_IMPORTED_MODULE_2_services__["e" /* UsersService */] !== "undefined" && __WEBPACK_IMPORTED_MODULE_2_services__["e" /* UsersService */]) === "function" && _b || Object, typeof (_c = typeof __WEBPACK_IMPORTED_MODULE_2_services__["b" /* AlertService */] !== "undefined" && __WEBPACK_IMPORTED_MODULE_2_services__["b" /* AlertService */]) === "function" && _c || Object, typeof (_d = typeof __WEBPACK_IMPORTED_MODULE_2_services__["d" /* PagerService */] !== "undefined" && __WEBPACK_IMPORTED_MODULE_2_services__["d" /* PagerService */]) === "function" && _d || Object, typeof (_e = typeof __WEBPACK_IMPORTED_MODULE_1__angular_router__["b" /* ActivatedRoute */] !== "undefined" && __WEBPACK_IMPORTED_MODULE_1__angular_router__["b" /* ActivatedRoute */]) === "function" && _e || Object, typeof (_f = typeof __WEBPACK_IMPORTED_MODULE_1__angular_router__["a" /* Router */] !== "undefined" && __WEBPACK_IMPORTED_MODULE_1__angular_router__["a" /* Router */]) === "function" && _f || Object])
], UsersListComponent);

var _a, _b, _c, _d, _e, _f;
//# sourceMappingURL=list.component.js.map

/***/ }),

/***/ "../../../../../src/admin/users/users-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/@angular/core.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/@angular/router.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__list_component__ = __webpack_require__("../../../../../src/admin/users/list.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__form_component__ = __webpack_require__("../../../../../src/admin/users/form.component.ts");
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return UsersRoutingModule; });
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};




var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__list_component__["a" /* UsersListComponent */],
        resolve: {
            users: __WEBPACK_IMPORTED_MODULE_2__list_component__["b" /* customerListResolve */]
        },
        data: {
            title: 'Users'
        }
    },
    {
        path: 'add',
        component: __WEBPACK_IMPORTED_MODULE_3__form_component__["a" /* UserFormComponent */],
        data: {
            title: 'Add'
        }
    },
    {
        path: 'edit/:id',
        component: __WEBPACK_IMPORTED_MODULE_3__form_component__["a" /* UserFormComponent */],
        resolve: {
            user: __WEBPACK_IMPORTED_MODULE_3__form_component__["b" /* customerEditResolve */]
        },
        data: {
            title: 'Edit'
        }
    }
];
var UsersRoutingModule = (function () {
    function UsersRoutingModule() {
    }
    return UsersRoutingModule;
}());
UsersRoutingModule = __decorate([
    __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
        imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */].forChild(routes)],
        exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */]]
    })
], UsersRoutingModule);

//# sourceMappingURL=users-routing.module.js.map

/***/ }),

/***/ "../../../../../src/admin/users/users.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/@angular/core.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_common__ = __webpack_require__("../../../common/@angular/common.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__list_component__ = __webpack_require__("../../../../../src/admin/users/list.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__users_routing_module__ = __webpack_require__("../../../../../src/admin/users/users-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_services__ = __webpack_require__("../../../../../src/services/index.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__form_component__ = __webpack_require__("../../../../../src/admin/users/form.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__angular_forms__ = __webpack_require__("../../../forms/@angular/forms.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__layouts_empty_layout_component__ = __webpack_require__("../../../../../src/admin/layouts/empty-layout.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8_ng2_select__ = __webpack_require__("../../../../ng2-select/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8_ng2_select___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_8_ng2_select__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsersModule", function() { return UsersModule; });
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};









var UsersModule = (function () {
    function UsersModule() {
    }
    return UsersModule;
}());
UsersModule = __decorate([
    __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
        imports: [
            __WEBPACK_IMPORTED_MODULE_8_ng2_select__["SelectModule"], __WEBPACK_IMPORTED_MODULE_3__users_routing_module__["a" /* UsersRoutingModule */], __WEBPACK_IMPORTED_MODULE_1__angular_common__["CommonModule"], __WEBPACK_IMPORTED_MODULE_6__angular_forms__["FormsModule"], __WEBPACK_IMPORTED_MODULE_6__angular_forms__["ReactiveFormsModule"]
        ],
        declarations: [__WEBPACK_IMPORTED_MODULE_2__list_component__["a" /* UsersListComponent */], __WEBPACK_IMPORTED_MODULE_5__form_component__["a" /* UserFormComponent */], __WEBPACK_IMPORTED_MODULE_7__layouts_empty_layout_component__["a" /* emptyLayoutComponent */]],
        providers: [__WEBPACK_IMPORTED_MODULE_4_services__["e" /* UsersService */], __WEBPACK_IMPORTED_MODULE_5__form_component__["b" /* customerEditResolve */], __WEBPACK_IMPORTED_MODULE_2__list_component__["b" /* customerListResolve */], __WEBPACK_IMPORTED_MODULE_4_services__["d" /* PagerService */]]
    })
], UsersModule);

//# sourceMappingURL=users.module.js.map

/***/ })

});
//# sourceMappingURL=2.chunk.js.map