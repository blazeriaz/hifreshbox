webpackJsonp([1],{

/***/ "../../../../../src/admin/recipes/form.component.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"animated fadeIn\">\r\n  <form [formGroup]=\"recipeForm\" (submit)=\"saveRecipe()\">\r\n  <div class=\"row\">\r\n    <div class=\"col-md-12\">\r\n      <div class=\"card\">\r\n        <div class=\"card-header\">\r\n          <i class=\"fa fa-list\"></i> Add Recipe\r\n        </div>\r\n        <div class=\"card-block\">\r\n          <div class=\"form-group row\">\r\n            <label for=\"recipe_name\" class=\"col-md-2 form-control-label\">Recipe Name</label>\r\n            <div class=\"col-md-10\" [ngClass]=\"setContainerErrorClass('name')\">\r\n              <input tooltip=\"dsdsf dsf dsf ds\" type=\"text\" class=\"form-control\" id=\"recipe_name\" formControlName=\"name\" [ngClass]=\"setInputErrorClass('name')\" />\r\n            </div>\r\n          </div>\r\n          <div class=\"form-group row\">\r\n            <label for=\"recipe_name\" class=\"col-md-2 form-control-label\">Image</label>\r\n            <div class=\"col-md-5\">\r\n              <input type=\"file\" accept=\"image/*\" (change)=\"changeListener($event)\" />\r\n            </div>\r\n            <div class=\"col-md-5\" ng-if=\"recipe.sku\">\r\n              <div class=\"avatar\">\r\n                <img class=\"img-avatar\" \r\n                  [src]=\"recipe.custom_attributes | mgCatalogAttribute:'thumbnail'\"\r\n                  (error)=\"recipe.imageHide=1\" *ngIf=\"!recipe.imageHide\" />\r\n                <span class=\"avatar-status badge-success\"></span>\r\n              </div>\r\n            </div>\r\n          </div>\r\n          <div class=\"form-group row\" formArrayName=\"custom_attributes\" \r\n              *ngIf=\"getCustomAttributeIndex('description') >= 0\">\r\n            <label for=\"recipe_desc\" class=\"col-md-2 form-control-label\">Description</label>\r\n            <div class=\"col-md-10\" [ngClass]=\"setAttrContainerErrorClass('description')\" [formGroupName]=\"getCustomAttributeIndex('description')\">\r\n              <textarea class=\"form-control\" rows=\"5\" id=\"recipe_desc\" [ngClass]=\"setAttrInputErrorClass('description')\" formControlName=\"value\"></textarea>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n  <div class=\"row\">\r\n    <div class=\"col-md-12\">\r\n      <div class=\"card\">\r\n        <div class=\"card-block\" formArrayName=\"custom_attributes\">\r\n          <div class=\"form-group row\">\r\n            <label for=\"recipe_chef\" class=\"col-md-2 form-control-label\">Created By</label>\r\n            <div class=\"col-md-10\" [ngClass]=\"setAttrContainerErrorClass('chef_name')\" [formGroupName]=\"getCustomAttributeIndex('chef_name')\">\r\n              <input type=\"text\" class=\"form-control\" id=\"recipe_chef\" [ngClass]=\"setAttrInputErrorClass('chef_name')\" formControlName=\"value\" />\r\n            </div>\r\n          </div>\r\n          <div class=\"form-group row\">\r\n            <label for=\"recipe_serving\" class=\"col-md-2 form-control-label\">Serving Size</label>\r\n            <div class=\"col-md-4\" [ngClass]=\"setAttrContainerErrorClass('servings')\" [formGroupName]=\"getCustomAttributeIndex('servings')\">\r\n              <input type=\"text\" class=\"form-control\" id=\"recipe_serving\" [ngClass]=\"setAttrInputErrorClass('servings')\" formControlName=\"value\" /> \r\n            </div>\r\n            <label for=\"recipe_prep\" class=\"col-md-2 form-control-label\">Prep. Time</label>\r\n            <div class=\"col-md-4\" [ngClass]=\"setAttrContainerErrorClass('cooking_time')\" [formGroupName]=\"getCustomAttributeIndex('cooking_time')\">\r\n              <input type=\"text\" class=\"form-control\" id=\"recipe_prep\" [ngClass]=\"setAttrInputErrorClass('cooking_time')\"formControlName=\"value\" />\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n  <div class=\"row\">\r\n    <div class=\"col-md-6\">\r\n      <div class=\"card\">\r\n        <div class=\"card-header\">\r\n          Food Nutrition\r\n        </div>\r\n        <div class=\"card-block\" formArrayName=\"custom_attributes\">\r\n          <div class=\"form-group row\">\r\n            <label for=\"recipe_calories\" class=\"col-md-4 form-control-label\">Calories</label>\r\n            <div class=\"input-group col-md-8\" [ngClass]=\"setAttrContainerErrorClass('calories')\" [formGroupName]=\"getCustomAttributeIndex('calories')\">\r\n              <input type=\"text\" class=\"form-control\" id=\"recipe_calories\" [ngClass]=\"setAttrInputErrorClass('calories')\" formControlName=\"value\" />\r\n            </div>\r\n          </div>\r\n          <div class=\"form-group row\">\r\n            <label for=\"recipe_protein\" class=\"col-md-4 form-control-label\">Protein</label>\r\n            <div class=\"input-group col-md-8\" [ngClass]=\"setAttrContainerErrorClass('protein')\" [formGroupName]=\"getCustomAttributeIndex('protein')\">\r\n              <input type=\"text\" class=\"form-control\" id=\"recipe_protein\" [ngClass]=\"setAttrInputErrorClass('protein')\" formControlName=\"value\" />\r\n              <span class=\"input-group-addon\">g</span>\r\n            </div>\r\n          </div>\r\n          <div class=\"form-group row\">\r\n            <label for=\"recipe_carb\" class=\"col-md-4 form-control-label\">Carb</label>\r\n            <div class=\"input-group col-md-8\" [ngClass]=\"setAttrContainerErrorClass('carb')\" [formGroupName]=\"getCustomAttributeIndex('carb')\">\r\n              <input type=\"text\" class=\"form-control\" id=\"recipe_carb\" [ngClass]=\"setAttrInputErrorClass('carb')\" formControlName=\"value\" />\r\n              <span class=\"input-group-addon\">g</span>\r\n            </div>\r\n          </div>\r\n          <div class=\"form-group row\">\r\n            <label for=\"recipe_fat\" class=\"col-md-4 form-control-label\">Fat</label>\r\n            <div class=\"input-group col-md-8\" [ngClass]=\"setAttrContainerErrorClass('fat')\" [formGroupName]=\"getCustomAttributeIndex('fat')\">\r\n              <input type=\"text\" class=\"form-control\" id=\"recipe_fat\" [ngClass]=\"setAttrInputErrorClass('fat')\" formControlName=\"value\" />\r\n              <span class=\"input-group-addon\">g</span>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n    <div class=\"col-md-6\">\r\n      <div class=\"card\">\r\n        <div class=\"card-header\">\r\n          Ingredients\r\n        </div>\r\n        <div class=\"card-block\">\r\n          <div class=\"form-group row mb-1\" *ngIf=\"ingredientsOptions\">\r\n            <div class=\"col-md-12\">\r\n              <ng-select [allowClear]=\"true\" [multiple]=\"false\"\r\n                [items]=\"ingredientsOptions.ingredients\" \r\n                (data)=\"refreshIngredientOptionValue($event)\"\r\n                placeholder=\"No Integredient selected\">\r\n              </ng-select>\r\n              <div class=\"input-group\">                \r\n                <input class=\"form-control\" type=\"number\" [(ngModel)]=\"newIngredient.qty\" [ngModelOptions]=\"{standalone: true}\" />\r\n                <select class=\"form-control\" [(ngModel)]=\"newIngredient.portion\" [ngModelOptions]=\"{standalone: true}\">\r\n                  <option></option>\r\n                  <option *ngFor=\"let portion of ingredientsOptions.portions\" [ngValue]=\"portion\">{{portion.text}}</option>\r\n                </select>\r\n                <span>\r\n                  <button class=\"btn btn-primary\" type=\"button\" [disabled]=\"ingredientDisable()\" (click)=\"addIngredient()\">Add</button>\r\n                </span>\r\n              </div>\r\n            </div>\r\n          </div>\r\n          <ul class=\"list-group\" *ngFor=\"let ingredient of ingredients; let index = index;\">\r\n            <li class=\"list-group-item p-1\">\r\n              <span>{{ingredient.ingredient.text}}</span> \r\n              <span>{{ingredient.qty}}</span> \r\n              <span *ngIf=\"ingredient.portion\">{{ingredient.portion.text}}</span>\r\n              <span class=\"px-1\">\r\n                <button class=\"btn btn-link p-0\" type=\"button\" (click)=\"removeIngredient(index)\">\r\n                  <i class=\"fa fa-remove\"></i> Remove\r\n                </button>\r\n              </span>\r\n            </li>\r\n          </ul>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n  <div class=\"row\">\r\n    <div class=\"col-md-12\">\r\n      <div class=\"card\">\r\n        <div class=\"card-header\">\r\n          Steps\r\n        </div>\r\n        <div class=\"card-block\">         \r\n          <div class=\"form-group row mb-1\">\r\n            <div class=\"col-md-12\">\r\n              <div class=\"input-group\">\r\n                <textarea type=\"text\" class=\"form-control\" rows=\"5\" \r\n                    [(ngModel)]=\"newRecipeStep\" [ngModelOptions]=\"{standalone: true}\"></textarea>\r\n                <span class=\"input-group-btn\">\r\n                  <button class=\"btn btn-primary\" type=\"button\" (click)=\"addRecipeStep()\">Add</button>\r\n                </span>\r\n              </div>\r\n            </div>\r\n          </div>\r\n          <ul class=\"list-group\" *ngFor=\"let step of recipeSteps; let index = index;\">\r\n            <li class=\"list-group-item p-1\">\r\n              {{step}}\r\n              <span class=\"px-1\">\r\n                <button class=\"btn btn-link p-0\" type=\"button\" (click)=\"removeRecipeStep(index)\">\r\n                  <i class=\"fa fa-remove\"></i> Remove\r\n                </button>\r\n              </span>\r\n            </li>\r\n          </ul> \r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n  <div class=\"row\">\r\n    <div class=\"col-md-6\">\r\n      <div class=\"card\">\r\n        <div class=\"card-header\">\r\n          what customer will need\r\n        </div>\r\n        <div class=\"card-block\">\r\n          <div class=\"form-group row\">\r\n            <div class=\"col-md-12\">\r\n              <div class=\"input-group\">\r\n                <input type=\"text\" class=\"form-control\" />\r\n                <span class=\"input-group-btn\">\r\n                  <button class=\"btn btn-primary\" type=\"button\">Add</button>\r\n                </span>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n    <div class=\"col-md-6\">\r\n      <div class=\"card\">\r\n        <div class=\"card-header\">\r\n          Allergies\r\n        </div>\r\n        <div class=\"card-block\">\r\n          <div class=\"form-group row\">\r\n            <div class=\"col-md-12\">\r\n              <div class=\"input-group\">\r\n                <input type=\"text\" class=\"form-control\" />\r\n                <span class=\"input-group-btn\">\r\n                  <button class=\"btn btn-primary\" type=\"button\">Add</button>\r\n                </span>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n  <div class=\"row\">\r\n    <div class=\"col-md-12\">\r\n      <div class=\"card\">\r\n        <div class=\"card-footer bg-info\">\r\n          <div class=\"btn-group\">\r\n            <button type=\"button\" class=\"btn btn-secondary\" (click)=\"goToList()\">Cancel</button>\r\n            <button type=\"submit\" class=\"btn btn-primary\">Submit</button>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n  </form>\r\n</div>\r\n"

/***/ }),

/***/ "../../../../../src/admin/recipes/form.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/@angular/core.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/@angular/router.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_services__ = __webpack_require__("../../../../../src/services/index.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__angular_forms__ = __webpack_require__("../../../forms/@angular/forms.es5.js");
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return recipeEditResolve; });
/* unused harmony export getRandomInt */
/* unused harmony export checkAllChildrenValid */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return RecipeFormComponent; });
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var recipeEditResolve = (function () {
    function recipeEditResolve(recipesService) {
        this.recipesService = recipesService;
    }
    recipeEditResolve.prototype.resolve = function (route) {
        var recipeSku = route.params['sku'];
        return this.recipesService.getProduct(recipeSku);
    };
    return recipeEditResolve;
}());
recipeEditResolve = __decorate([
    __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Injectable"])(),
    __metadata("design:paramtypes", [typeof (_a = typeof __WEBPACK_IMPORTED_MODULE_2_services__["c" /* ProductsService */] !== "undefined" && __WEBPACK_IMPORTED_MODULE_2_services__["c" /* ProductsService */]) === "function" && _a || Object])
], recipeEditResolve);

function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}
function checkAllChildrenValid(c) {
    if (c.controls.length == 0) {
        return {
            checkAllChildrenValid: true
        };
    }
    for (var i = 0; i < c.controls.length - 1; i++) {
        if (!c.controls[i].valid) {
            return {
                checkAllChildrenValid: true
            };
        }
    }
    return {
        checkAllChildrenValid: false
    };
}
var RecipeFormComponent = (function () {
    function RecipeFormComponent(recipesService, alert, route, router, _fb) {
        this.recipesService = recipesService;
        this.alert = alert;
        this.route = route;
        this.router = router;
        this._fb = _fb;
    }
    RecipeFormComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.ingredients = [];
        this.newIngredient = {};
        this.recipeSteps = [];
        this.ingredientsOptions = null;
        this.image = {};
        this.recipesService.getIngredienOptions().subscribe(function (data) {
            _this.ingredientsOptions = {};
            var options = data[0];
            _this.ingredientsOptions.ingredients = options.ingredients.map(function (ingredient) {
                return { id: ingredient.ingredient_id, text: ingredient.title };
            });
            _this.ingredientsOptions.portions = options.portions.map(function (portion) {
                return { id: portion.portion_id, text: portion.title };
            });
        });
        ;
        var recipeSku = this.route.snapshot.params['sku'];
        this.recipe = (recipeSku) ? this.route.snapshot.data['recipe'] : {};
        this.customAttributes = [];
        var customAttributesArray = [];
        ["description", "chef_name", "servings", "cooking_time", "calories", "protein", "carb", "fat"].map(function (attribute_code) {
            var value = '';
            if (_this.recipe && _this.recipe.custom_attributes) {
                var attribute = _this.recipe.custom_attributes.find(function (x) { return x.attribute_code == attribute_code; });
                value = attribute ? attribute.value : '';
            }
            ;
            _this.customAttributes.push(attribute_code);
            customAttributesArray.push(_this.addCustomArrtibute(attribute_code, value, true));
        });
        ["ingredients", "steps"].map(function (attribute_code) {
            var value = [];
            if (_this.recipe && _this.recipe.custom_attributes) {
                var attribute = _this.recipe.custom_attributes.find(function (x) { return x.attribute_code == attribute_code; });
                value = attribute.value;
            }
            ;
            try {
                value = JSON.parse(value);
            }
            catch (e) {
                value = [];
            }
            if (attribute_code == "ingredients") {
                _this.ingredients = value;
            }
            if (attribute_code == "steps") {
                _this.recipeSteps = value;
            }
        });
        customAttributesArray.push(this.addCustomArrtibute("category_ids", ['41'], false));
        this.recipeForm = this._fb.group({
            name: [this.recipe.name, [__WEBPACK_IMPORTED_MODULE_3__angular_forms__["Validators"].required, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["Validators"].minLength(5)]],
            visibility: 1,
            type_id: 'simple',
            price: 0,
            status: 1,
            attribute_set_id: 16,
            extension_attributes: this._fb.group({
                stock_item: this._fb.group({
                    manage_stock: 0,
                    is_in_stock: 1,
                    qty: 0
                })
            }),
            custom_attributes: this._fb.array(customAttributesArray)
        });
    };
    RecipeFormComponent.prototype.addCustomArrtibute = function (attribute_code, value, required) {
        if (attribute_code == "category_ids") {
            value = this._fb.array(value);
        }
        if (required) {
            value = [value, __WEBPACK_IMPORTED_MODULE_3__angular_forms__["Validators"].required];
        }
        return this._fb.group({
            attribute_code: attribute_code,
            value: value
        });
    };
    RecipeFormComponent.prototype.getCustomAttributeIndex = function (attribute_code) {
        return this.customAttributes.indexOf(attribute_code);
    };
    RecipeFormComponent.prototype.getCustomAttributeValue = function (attribute_code) {
        var index = this.getCustomAttributeIndex(attribute_code);
        if (index >= 0) {
            var controls = this.recipeForm.controls['custom_attributes'].controls;
            return controls[index].get('value').value;
        }
        return '';
    };
    RecipeFormComponent.prototype.ingredientDisable = function () {
        return !(this.newIngredient.ingredient && this.newIngredient.qty);
    };
    RecipeFormComponent.prototype.refreshIngredientOptionValue = function (ingredient) {
        this.newIngredient.ingredient = ingredient;
    };
    RecipeFormComponent.prototype.addIngredient = function () {
        this.ingredients.push(this.newIngredient);
        this.newIngredient = {};
    };
    RecipeFormComponent.prototype.removeIngredient = function (i) {
        this.ingredients.splice(i, 1);
    };
    RecipeFormComponent.prototype.addRecipeStep = function () {
        this.recipeSteps.push(this.newRecipeStep);
        this.newRecipeStep = "";
    };
    RecipeFormComponent.prototype.removeRecipeStep = function (i) {
        this.recipeSteps.splice(i, 1);
    };
    RecipeFormComponent.prototype.setInputErrorClass = function (input) {
        var invalid = this.recipeForm.get(input).invalid && this.submitted;
        if (invalid)
            return 'form-control-danger';
    };
    RecipeFormComponent.prototype.setContainerErrorClass = function (input) {
        var invalid = this.recipeForm.get(input).invalid && this.submitted;
        if (invalid)
            return 'has-danger';
    };
    RecipeFormComponent.prototype.setAttrInputErrorClass = function (attribute_code) {
        var index = this.getCustomAttributeIndex(attribute_code);
        var invalid = false;
        if (index >= 0) {
            invalid = this.recipeForm.controls['custom_attributes'].controls[index].invalid && this.submitted;
        }
        if (invalid)
            return 'form-control-danger';
    };
    RecipeFormComponent.prototype.setAttrContainerErrorClass = function (attribute_code) {
        var index = this.getCustomAttributeIndex(attribute_code);
        var invalid = false;
        if (index >= 0) {
            invalid = this.recipeForm.controls['custom_attributes'].controls[index].invalid && this.submitted;
        }
        if (invalid)
            return 'has-danger';
    };
    RecipeFormComponent.prototype.changeListener = function ($event) {
        this.readThis($event.target);
    };
    RecipeFormComponent.prototype.readThis = function (inputValue) {
        var _this = this;
        var file = inputValue.files[0];
        var myReader = new FileReader();
        this.image.filetype = file.type;
        this.image.filename = file.name;
        this.image.filesize = file.size;
        myReader.onloadend = function (e) {
            _this.image.base64 = myReader.result;
            console.log(_this.image);
        };
        myReader.readAsDataURL(file);
    };
    RecipeFormComponent.prototype.saveRecipe = function () {
        var _this = this;
        this.alert.clear();
        this.submitted = true;
        if (this.recipeForm.dirty && this.recipeForm.valid) {
            var recipeSku = this.route.snapshot.params['sku'];
            var sendData = this.recipeForm.value;
            sendData.custom_attributes.push({
                attribute_code: "ingredients",
                value: JSON.stringify(this.ingredients)
            });
            sendData.custom_attributes.push({
                attribute_code: "steps",
                value: JSON.stringify(this.recipeSteps)
            });
            if (!recipeSku) {
                recipeSku = '';
                sendData.sku = getRandomInt(10000, 99999);
            }
            this.recipesService.saveProduct(recipeSku, { product: sendData }).subscribe(function (data) {
                if (_this.image.base64) {
                    var base64 = _this.image.base64.split('base64,');
                    var image_upload = {
                        media_type: 'image',
                        label: 'Product Image',
                        position: 0,
                        disabled: 0,
                        types: ['image', 'small_image', 'thumbnail', 'swatch_image'],
                        file: _this.image.filename,
                        content: {
                            base64_encoded_data: base64[1],
                            type: _this.image.filetype,
                            name: _this.image.filename
                        }
                    };
                    _this.recipesService.saveProductImage(data.sku, image_upload).subscribe(function (data) {
                        _this.alert.success("The recipe details are saved successfully!", true);
                        _this.router.navigate(['recipes']);
                    });
                }
                else {
                    _this.alert.success("The recipe details are saved successfully!", true);
                    _this.router.navigate(['recipes']);
                }
            }, function (error) {
                if (error.status == 401) {
                    _this.alert.error("Access restricted!");
                }
                else {
                    _this.alert.error("Server Error");
                }
                window.scrollTo(0, 0);
            });
        }
        else {
            this.alert.error("Please check the form to enter all required details");
            window.scrollTo(0, 0);
        }
    };
    RecipeFormComponent.prototype.goToList = function () {
        this.router.navigate(['recipes']);
    };
    return RecipeFormComponent;
}());
RecipeFormComponent = __decorate([
    __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
        template: __webpack_require__("../../../../../src/admin/recipes/form.component.html")
    }),
    __metadata("design:paramtypes", [typeof (_b = typeof __WEBPACK_IMPORTED_MODULE_2_services__["c" /* ProductsService */] !== "undefined" && __WEBPACK_IMPORTED_MODULE_2_services__["c" /* ProductsService */]) === "function" && _b || Object, typeof (_c = typeof __WEBPACK_IMPORTED_MODULE_2_services__["b" /* AlertService */] !== "undefined" && __WEBPACK_IMPORTED_MODULE_2_services__["b" /* AlertService */]) === "function" && _c || Object, typeof (_d = typeof __WEBPACK_IMPORTED_MODULE_1__angular_router__["b" /* ActivatedRoute */] !== "undefined" && __WEBPACK_IMPORTED_MODULE_1__angular_router__["b" /* ActivatedRoute */]) === "function" && _d || Object, typeof (_e = typeof __WEBPACK_IMPORTED_MODULE_1__angular_router__["a" /* Router */] !== "undefined" && __WEBPACK_IMPORTED_MODULE_1__angular_router__["a" /* Router */]) === "function" && _e || Object, typeof (_f = typeof __WEBPACK_IMPORTED_MODULE_3__angular_forms__["FormBuilder"] !== "undefined" && __WEBPACK_IMPORTED_MODULE_3__angular_forms__["FormBuilder"]) === "function" && _f || Object])
], RecipeFormComponent);

var _a, _b, _c, _d, _e, _f;
//# sourceMappingURL=form.component.js.map

/***/ }),

/***/ "../../../../../src/admin/recipes/list.component.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"animated fadeIn\">\r\n  <div class=\"row\">\r\n    <div class=\"col-md-12\">\r\n      <div class=\"card\">\r\n        <div class=\"card-header\">\r\n          <i class=\"fa fa-list\"></i> Recipes\r\n          <div  class=\"pull-right\"><a [routerLink]=\"'add'\" class=\"btn btn-primary\">Add</a></div>\r\n        </div>\r\n        <div class=\"card-block\">\r\n          <div class=\"row py-2 bg-primary\">\r\n            <div class=\"col-md-3\">Receipe</div>\r\n            <div class=\"col-md-3\">Serving Size</div>\r\n            <div class=\"col-md-3\">Cook Time</div>\r\n            <div class=\"col-md-3\">Created By</div>\r\n          </div>\r\n\r\n          <div class=\"row py-2\" *ngFor=\"let recipe of recipes;let odd=odd;\" [ngClass]=\"{'bg-faded': odd}\">\r\n            <div class=\"col-md-1\">\r\n              <div class=\"avatar\">\r\n                <img class=\"img-avatar\" \r\n                  [src]=\"recipe.custom_attributes | mgCatalogAttribute:'thumbnail'\"\r\n                  (error)=\"recipe.imageHide=1\" *ngIf=\"!recipe.imageHide\" />\r\n                <span class=\"avatar-status badge-success\"></span>\r\n              </div>\r\n            </div>\r\n            <div class=\"col-md-2\">\r\n              {{recipe.name}}\r\n              <div class=\"btn-group btn-group-sm\">\r\n                <a [routerLink]=\"['edit', recipe.sku]\" class=\"btn btn-link pl-0\">Edit</a>\r\n                <button type=\"button\" class=\"btn btn-link px-0\" (click)=\"deleteReceipe(recipe.sku)\">Delete</button>\r\n              </div>\r\n            </div>\r\n            <div class=\"col-md-3\">{{recipe.custom_attributes | mgCatalogAttribute: 'servings'}}</div>\r\n            <div class=\"col-md-3\">{{recipe.custom_attributes | mgCatalogAttribute: 'cooking_time'}}</div>\r\n            <div class=\"col-md-3\">{{recipe.custom_attributes | mgCatalogAttribute: 'chef_name'}}</div>\r\n          </div>\r\n\r\n          <div class=\"row mt-2\"><div class=\"col-md-12\">\r\n            <ul class=\"pagination pull-right\">\r\n              <li class=\"page-item\" [ngClass]=\"{disabled:pager.currentPage === 1}\">\r\n                <a class=\"page-link\" href=\"javascript:void(0);\" (click)=\"setPage(1);\">First</a></li>\r\n              <li class=\"page-item\" [ngClass]=\"{disabled:pager.currentPage === 1}\">\r\n                <a class=\"page-link\" href=\"javascript:void(0);\" (click)=\"setPage(pager.currentPage - 1);\">Prev</a></li>\r\n              <li class=\"page-item active\" *ngFor=\"let page of pager.pages\" [ngClass]=\"{active:pager.currentPage === page}\">\r\n                <a class=\"page-link\" href=\"javascript:void(0);\" (click)=\"setPage(page);\">{{page}}</a>\r\n              </li>\r\n              <li class=\"page-item\" [ngClass]=\"{disabled:pager.currentPage === pager.totalPages}\">\r\n                <a class=\"page-link\" href=\"javascript:void(0);\" (click)=\"setPage(pager.currentPage + 1);\">Next</a></li>\r\n            </ul>\r\n          </div></div>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n"

/***/ }),

/***/ "../../../../../src/admin/recipes/list.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/@angular/core.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/@angular/router.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_services__ = __webpack_require__("../../../../../src/services/index.ts");
/* unused harmony export pageSize */
/* unused harmony export filterGroups */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return recipesListResolve; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return RecipesListComponent; });
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var pageSize = 10;
var filterGroups = [{
        filters: [{
                field: "attribute_set_id",
                value: 16,
                condition_type: 'eq'
            }]
    }];
var recipesListResolve = (function () {
    function recipesListResolve(recipesService) {
        this.recipesService = recipesService;
    }
    recipesListResolve.prototype.resolve = function (route) {
        return this.recipesService.getProducts(1, filterGroups, pageSize);
    };
    return recipesListResolve;
}());
recipesListResolve = __decorate([
    __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Injectable"])(),
    __metadata("design:paramtypes", [typeof (_a = typeof __WEBPACK_IMPORTED_MODULE_2_services__["c" /* ProductsService */] !== "undefined" && __WEBPACK_IMPORTED_MODULE_2_services__["c" /* ProductsService */]) === "function" && _a || Object])
], recipesListResolve);

var RecipesListComponent = (function () {
    function RecipesListComponent(recipesService, alert, pagerService, route, router) {
        this.recipesService = recipesService;
        this.alert = alert;
        this.pagerService = pagerService;
        this.route = route;
        this.router = router;
    }
    RecipesListComponent.prototype.ngOnInit = function () {
        var recipes = this.route.snapshot.data['recipes'];
        this.initRecipesList(recipes);
    };
    RecipesListComponent.prototype.initRecipesList = function (recipes, page) {
        this.recipes = recipes.items;
        // get pager object from service
        page = page ? page : 1;
        this.pager = this.pagerService.getPager(recipes.total_count, page, pageSize);
    };
    RecipesListComponent.prototype.setPage = function (page) {
        var _this = this;
        this.recipesService.getProducts(page, filterGroups, pageSize).subscribe(function (recipes) {
            _this.initRecipesList(recipes, page);
        });
    };
    RecipesListComponent.prototype.deleteReceipe = function (recipeSku) {
        var _this = this;
        if (!confirm("Are you sure to delete the recipe?")) {
            return;
        }
        this.alert.clear();
        this.recipesService.deleteProduct(recipeSku).subscribe(function (data) {
            if (data) {
                _this.alert.success("The recipe deleted successfully!", true);
                _this.recipesService.getProducts(1, filterGroups, pageSize).subscribe(function (recipes) {
                    _this.initRecipesList(recipes);
                });
            }
            else {
                _this.alert.error("The recipe can't be deleted!", true);
            }
        });
    };
    return RecipesListComponent;
}());
RecipesListComponent = __decorate([
    __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Component"])({
        template: __webpack_require__("../../../../../src/admin/recipes/list.component.html")
    }),
    __metadata("design:paramtypes", [typeof (_b = typeof __WEBPACK_IMPORTED_MODULE_2_services__["c" /* ProductsService */] !== "undefined" && __WEBPACK_IMPORTED_MODULE_2_services__["c" /* ProductsService */]) === "function" && _b || Object, typeof (_c = typeof __WEBPACK_IMPORTED_MODULE_2_services__["b" /* AlertService */] !== "undefined" && __WEBPACK_IMPORTED_MODULE_2_services__["b" /* AlertService */]) === "function" && _c || Object, typeof (_d = typeof __WEBPACK_IMPORTED_MODULE_2_services__["d" /* PagerService */] !== "undefined" && __WEBPACK_IMPORTED_MODULE_2_services__["d" /* PagerService */]) === "function" && _d || Object, typeof (_e = typeof __WEBPACK_IMPORTED_MODULE_1__angular_router__["b" /* ActivatedRoute */] !== "undefined" && __WEBPACK_IMPORTED_MODULE_1__angular_router__["b" /* ActivatedRoute */]) === "function" && _e || Object, typeof (_f = typeof __WEBPACK_IMPORTED_MODULE_1__angular_router__["a" /* Router */] !== "undefined" && __WEBPACK_IMPORTED_MODULE_1__angular_router__["a" /* Router */]) === "function" && _f || Object])
], RecipesListComponent);

var _a, _b, _c, _d, _e, _f;
//# sourceMappingURL=list.component.js.map

/***/ }),

/***/ "../../../../../src/admin/recipes/recipes-routing.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/@angular/core.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__angular_router__ = __webpack_require__("../../../router/@angular/router.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__list_component__ = __webpack_require__("../../../../../src/admin/recipes/list.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__form_component__ = __webpack_require__("../../../../../src/admin/recipes/form.component.ts");
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return RecipesRoutingModule; });
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};




var routes = [
    {
        path: '',
        component: __WEBPACK_IMPORTED_MODULE_2__list_component__["a" /* RecipesListComponent */],
        resolve: {
            recipes: __WEBPACK_IMPORTED_MODULE_2__list_component__["b" /* recipesListResolve */]
        },
        data: {
            title: 'Recipes'
        }
    },
    {
        path: 'add',
        component: __WEBPACK_IMPORTED_MODULE_3__form_component__["a" /* RecipeFormComponent */],
        data: {
            title: 'Add'
        }
    },
    {
        path: 'edit/:sku',
        component: __WEBPACK_IMPORTED_MODULE_3__form_component__["a" /* RecipeFormComponent */],
        resolve: {
            recipe: __WEBPACK_IMPORTED_MODULE_3__form_component__["b" /* recipeEditResolve */]
        },
        data: {
            title: 'Edit'
        }
    }
];
var RecipesRoutingModule = (function () {
    function RecipesRoutingModule() {
    }
    return RecipesRoutingModule;
}());
RecipesRoutingModule = __decorate([
    __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
        imports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */].forChild(routes)],
        exports: [__WEBPACK_IMPORTED_MODULE_1__angular_router__["c" /* RouterModule */]]
    })
], RecipesRoutingModule);

//# sourceMappingURL=recipes-routing.module.js.map

/***/ }),

/***/ "../../../../../src/admin/recipes/recipes.module.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/@angular/core.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__list_component__ = __webpack_require__("../../../../../src/admin/recipes/list.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__recipes_routing_module__ = __webpack_require__("../../../../../src/admin/recipes/recipes-routing.module.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_services__ = __webpack_require__("../../../../../src/services/index.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__angular_common__ = __webpack_require__("../../../common/@angular/common.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_pipes__ = __webpack_require__("../../../../../src/pipes.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__form_component__ = __webpack_require__("../../../../../src/admin/recipes/form.component.ts");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__angular_forms__ = __webpack_require__("../../../forms/@angular/forms.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8_ng2_select__ = __webpack_require__("../../../../ng2-select/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8_ng2_select___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_8_ng2_select__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9_services_index__ = __webpack_require__("../../../../../src/services/index.ts");
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RecipesModule", function() { return RecipesModule; });
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};










var RecipesModule = (function () {
    function RecipesModule() {
    }
    return RecipesModule;
}());
RecipesModule = __decorate([
    __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_0__angular_core__["NgModule"])({
        imports: [
            __WEBPACK_IMPORTED_MODULE_8_ng2_select__["SelectModule"], __WEBPACK_IMPORTED_MODULE_2__recipes_routing_module__["a" /* RecipesRoutingModule */], __WEBPACK_IMPORTED_MODULE_4__angular_common__["CommonModule"], __WEBPACK_IMPORTED_MODULE_7__angular_forms__["FormsModule"], __WEBPACK_IMPORTED_MODULE_7__angular_forms__["ReactiveFormsModule"]
        ],
        declarations: [__WEBPACK_IMPORTED_MODULE_1__list_component__["a" /* RecipesListComponent */], __WEBPACK_IMPORTED_MODULE_6__form_component__["a" /* RecipeFormComponent */], __WEBPACK_IMPORTED_MODULE_5_pipes__["a" /* mgCatalogAttribute */]],
        providers: [__WEBPACK_IMPORTED_MODULE_3_services__["c" /* ProductsService */], __WEBPACK_IMPORTED_MODULE_1__list_component__["b" /* recipesListResolve */], __WEBPACK_IMPORTED_MODULE_6__form_component__["b" /* recipeEditResolve */], __WEBPACK_IMPORTED_MODULE_9_services_index__["d" /* PagerService */]]
    })
], RecipesModule);

//# sourceMappingURL=recipes.module.js.map

/***/ }),

/***/ "../../../../../src/pipes.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__angular_core__ = __webpack_require__("../../../core/@angular/core.es5.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__global__ = __webpack_require__("../../../../../src/global.ts");
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return mgCatalogAttribute; });
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};


var mgCatalogAttribute = (function () {
    function mgCatalogAttribute() {
    }
    mgCatalogAttribute.prototype.transform = function (productAtts, attribute_code) {
        if (!productAtts)
            return productAtts;
        var attr = productAtts.find(function (x) { return x.attribute_code === attribute_code; });
        var attr_vlue = (attr) ? attr.value : '';
        if (attribute_code == 'image' || attribute_code == 'small_image' || attribute_code == 'thumbnail') {
            attr_vlue = __WEBPACK_IMPORTED_MODULE_1__global__["b" /* BASE_MEDIA_URL */] + attr_vlue;
        }
        return attr_vlue;
    };
    return mgCatalogAttribute;
}());
mgCatalogAttribute = __decorate([
    __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_0__angular_core__["Pipe"])({ name: 'mgCatalogAttribute' })
], mgCatalogAttribute);

//# sourceMappingURL=pipes.js.map

/***/ })

});
//# sourceMappingURL=1.chunk.js.map