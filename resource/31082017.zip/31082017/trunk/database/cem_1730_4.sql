ALTER TABLE `tb_contexts_items` ADD COLUMN `context_item_mandatory` INT(1) DEFAULT '0';
ALTER TABLE `tb_contexts_items` ADD COLUMN `context_item_type` ENUM('TEXT','LIST','MULTI') COLLATE utf8_bin DEFAULT 'TEXT';
CREATE TABLE `tb_contexts_items_values` (
  `context_item_value_id` INT(11) NOT NULL AUTO_INCREMENT,
  `context_item_id_fk` INT(11) NOT NULL,
  `context_item_value_fr` VARCHAR(50) COLLATE utf8_bin DEFAULT NULL,
  `context_item_value_en` VARCHAR(50) COLLATE utf8_bin DEFAULT NULL,
  `context_item_value_status` ENUM('ACT','INACT') COLLATE utf8_bin DEFAULT 'INACT',
  PRIMARY KEY (`context_item_value_id`)
) ENGINE=INNODB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
CREATE TABLE `tb_instances_contexts_values` (
  `context_item_value_id_fk` INT(11) NOT NULL,
  `context_item_id_fk` INT(11) NOT NULL,
  `instance_id_fk` INT(11) NOT NULL
) ENGINE=INNODB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

ALTER TABLE `tb_instances_milestones` ADD COLUMN `is_deleted` TINYINT(2) DEFAULT '0';
ALTER TABLE `tb_repositories` ADD COLUMN `repository_allow_tdb_creation` TINYINT(4) NOT NULL DEFAULT '1';