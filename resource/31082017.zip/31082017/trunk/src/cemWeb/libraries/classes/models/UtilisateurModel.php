<?php
class UtilisateurModel extends coreModel {
    public $ipn;
    public $acl;
    public $owners = array();
    
    public function __construct($ipn) {
        parent::__construct();
        $this->ipn = $ipn;
        $this->acl = array();
        $this->getUserAccess();
    }
    
    public function getUserAccess() {
        $query = "SELECT * FROM (SELECT up.universe_id_fk AS universe_id, ai.keyword, api.params, up.acl_profile_id_fk AS acl_profile_id "
                . "FROM tb_user_profiles AS up "
                . "JOIN tb_acl_profile_items AS api ON up.acl_profile_id_fk = api.acl_profile_id_fk "
                . "JOIN tb_acl_items AS ai ON ai.acl_item_id = api.acl_item_id_fk WHERE up.ipn = '".$this->ipn."' "
                . "UNION ALL "
                . "SELECT 0, ai.keyword, api.params, api.acl_profile_id_fk AS acl_profile_id "
                . "FROM tb_acl_profile_items AS api "
                . "JOIN tb_acl_items AS ai ON ai.acl_item_id = api.acl_item_id_fk WHERE api.acl_profile_id_fk = '".CONTRIBUTOR."' ) as t "
                . "ORDER BY keyword ASC ";
        $this->request->envoi($query);
        $access_infos = $this->request->recup_array_champ();
        $this->acl["acl_profiles"] = array();
        
        foreach($access_infos as $access_info) {
            $keyword = $access_info['keyword'];
            
            if(!isset($this->acl[$keyword])) {
                $this->acl[$keyword] = array();
                $this->acl[$keyword]["universe"] = array();
            }
            
            if(!in_array($access_info['acl_profile_id'], $this->acl["acl_profiles"])) {
                $this->acl["acl_profiles"][] = $access_info['acl_profile_id'];
            }
            
            if(!in_array($access_info['universe_id'], $this->acl[$keyword]["universe"])) {
                $this->acl[$keyword]["universe"][] = $access_info['universe_id'];
            }
            
            $access_info['params'] = json_decode($access_info['params']);
            
            foreach($access_info['params'] as $paramKey => $params) {
                if(empty($params)) {
                    continue;
                }
                if(!isset($this->acl[$keyword][$paramKey])) {
                    $this->acl[$keyword][$paramKey] = array();
                }
                if(!is_array($params)) {
                    $params = array($params);
                }
                foreach($params as $param) {
                    if(!isset($this->acl[$keyword][$paramKey][$param])) {
                        $this->acl[$keyword][$paramKey][$param] = array();
                    }
                    if(!in_array($access_info['universe_id'], $this->acl[$keyword][$paramKey][$param])) {
                        $this->acl[$keyword][$paramKey][$param][] = $access_info['universe_id'];
                    }
                }
            }
        }
        return $this->acl;
    }
    
    public function getOwnedDashboards() {
        $query = "SELECT i.instance_id, `ish`.`type`, r.repository_id, r.universe_id_fk AS universe_id "
                . "FROM tb_instances_stakeholders AS ish "
                . "JOIN tb_instances AS i ON i.instance_id = ish.instance_id_fk "
                . "JOIN tb_repositories_versions AS rv ON i.repository_revision_id_fk = rv.repository_revision_id "
                . "JOIN tb_repositories AS r ON r.repository_id = rv.repository_id_fk "                
                . "WHERE stakeholder_ipn = '" . $this->ipn . "'";
        return $this->getDetailsFromQuery('getOwnerDashboards', $query);
    }
    
    public function getAclProfiles() {
        return isset($this->acl["acl_profiles"])?$this->acl["acl_profiles"]:array();
    }
    
    public function haveAccess($params = array()) {
        return !empty($this->acl);
    }
    
    public function getUserAccessParam($keyword, $param) {
        if(!isset($this->acl[$keyword]) || !isset($this->acl[$keyword][$param])) {
            return false;
        }
        return $this->acl[$keyword][$param];
    }
            
    public function checkAccess($keyword, $params = array()) {
        if(!isset($this->acl[$keyword])) {
            return false;
        }
        $access_info = $this->acl[$keyword];
        $return = true;
        
        $accessParams = array("dashboard", "repository", "user_profiles");
        foreach($accessParams as $accessParam) {
            if(isset($params[$accessParam]) && !empty($access_info[$accessParam])) {
                if(!is_array($params[$accessParam])) {
                    $params[$accessParam] = array($params[$accessParam]);
                }
                $types = array_keys($access_info[$accessParam]);
                $access_types = array_intersect($types, $params[$accessParam]);
                if(count($access_types) == 0) {
                    $return = false;
                }
            }
        }
        return $return;
    }
    
    public function getAccessUniverse($keyword, $params = array()) {
        if(!isset($this->acl[$keyword])) {
            return false;
        }
        $access_info = $this->acl[$keyword];
        $return_universe = array();
        if(empty($params)) {
            $return_universe = $access_info['universe'];
        }
        
        $accessParams = array("dashboard", "repository", "user_profiles");
        foreach($accessParams as $accessParam) {
            if(isset($params[$accessParam])) {
                if(!is_array($params[$accessParam])) {
                    $params[$accessParam] = array($params[$accessParam]);
                }
                foreach($params[$accessParam] as $tdb_user_type) {
                    if(isset($access_info[$accessParam][$tdb_user_type])) {
                        $return_universe = array_merge($return_universe, $access_info[$accessParam][$tdb_user_type]);
                    }
                }            
            }
        }
        
        $return_universe = array_unique($return_universe);
        if(in_array(0, $return_universe)) {
            $return_universe = array('all');
        } 
        
        return $return_universe;
    }
    
    public function setOwner($param, $object_id, $type = 'O') {
        if(!isset($this->acl['owner'])) {
            $this->acl['owner'] = array();            
        }
        if(!isset($this->acl['owner'][$param])) {
            $this->acl['owner'][$param] = array();            
        }
        if(!isset($this->acl['owner'][$param][$type])) {
            $this->acl['owner'][$param][$type] = array();            
        }
        $this->acl['owner'][$param][$type][] = $object_id;
    }
    
    public function isOwner($param, $object_id, $type = 'O') {
        return isset($this->acl['owner'])
                && isset($this->acl['owner'][$param]) 
                    && isset($this->acl['owner'][$param][$type]) 
                        && in_array($object_id, $this->acl['owner'][$param][$type]);
    }
    
    public function setOwnerType($param, $object_id) {
        if(isset($this->owners[$param]) && isset($this->owners[$param][$object_id])) {
            return;
        }
        if(!isset($this->owners[$param])) {
            $this->owners[$param] = array();
        }
        
        if($param == "dashboard") {
            $query = "SELECT `type` FROM tb_instances_stakeholders "
                    . "WHERE instance_id_fk = " . $object_id . " AND stakeholder_ipn = '" . $this->ipn . "' ORDER BY FIELD(`type`, 'O', 'D', 'DR', 'C3', 'C2')";
        } else if($param == "repository") {
            $query = "SELECT CASE WHEN (repository_manager = '" . $this->ipn . "') THEN 'M' ELSE 'BM' END AS `type` FROM tb_repositories "
                    . "WHERE '" . $this->ipn . "' IN (repository_creator, repository_manager, repository_manager_backup) "
                    . "AND repository_id = " . $object_id;
        }
        $this->request->envoi($query);
        
        $tdb_owner_type = $this->request->recup_row();
        $this->owners[$param][$object_id] = false;
        if($tdb_owner_type && isset($tdb_owner_type[0])) {
            $this->owners[$param][$object_id] = $tdb_owner_type[0];
            $this->setOwner($param, $object_id, $tdb_owner_type[0]);
        }
    }
    
    public function getUniverseId($param = "dashboard", $object_id) {
        if($param == "dashboard") {
            $query = "SELECT universe_id_fk FROM tb_repositories AS r "
                    . "JOIN tb_repositories_versions AS rv ON r.repository_id = rv.repository_id_fk "
                    . "JOIN tb_instances AS i ON i.repository_revision_id_fk = rv.repository_revision_id "
                    . "WHERE i.instance_id = " . $object_id;
            $this->request->envoi($query);
            $temp = $this->request->recup_row();
            return $temp[0];
        }
        
        if($param == "repository") {
            $query = "SELECT universe_id_fk FROM tb_repositories WHERE repository_id = " . $object_id;
            $this->request->envoi($query);
            $temp = $this->request->recup_row();
            return $temp[0];
        }
    }
    
    public function canAccess($param, $keyword, $object_id, $universe_id = false, $accessParams = array()) {
        if(!$universe_id) {
            $universe_id = $this->getUniverseId($param, $object_id);
        }
        if(!$param || !$keyword || !$object_id || !$universe_id) {
            return false;
        }
        if(!isset($this->acl[$keyword])) {
            return false;
        }
        $cond = false;
        $allPermssion = array_search("A", $accessParams);
        if($allPermssion !== false) {
            $accessUniverse = $this->getAccessUniverse($keyword, array($param=>array("A")));
            $cond = $this->checkAccess($keyword, array($param => array("A")));
            
            if($cond && $accessUniverse[0] == 'all') {
                return true;
            }            
            
            $cond = $cond && ($accessUniverse[0] == 'all' || in_array($universe_id, $accessUniverse));
            unset($accessParams[$allPermssion]);
        }
        
        if(!$cond && !empty($accessParams)) {
            $this->setOwnerType($param, $object_id);
        }
        foreach($accessParams as $accessParam) {
            if($cond) {
                break;
            }            
            $cond = $this->checkAccess($keyword, array($param=>array($accessParam)));
            $cond = $cond && $this->isOwner($param, $object_id, $accessParam);
        }
        return $cond;
    }
    
    public function canAccessDashboard($keyword, $instance_id, $universe_id = false, $accessParams = array("A", "O", "D", "DR", "C3", "C2")) {
        return $this->canAccess("dashboard", $keyword, $instance_id, $universe_id, $accessParams);
    }
    
    public function canDeleteDashboard($instance_id, $universe_id = false, $accessParams = array("A", "O", "D", "DR", "C3", "C2")) {        
        return $this->canAccessDashboard("delete_dashboard", $instance_id, $universe_id, $accessParams);
    }
    
    public function canReadDashboard($instance_id, $universe_id = false, $accessParams = array("A", "O", "D", "DR", "C3", "C2")) {
        return $this->canAccessDashboard("read_dashboard", $instance_id, $universe_id, $accessParams);
    }
    
    public function canModifyDashboard($instance_id, $universe_id = false, $accessParams = array("A", "O", "D", "DR", "C3", "C2")) {
        return $this->canAccessDashboard("modify_dashboard", $instance_id, $universe_id, $accessParams);
    }
    
    public function canEvaluateDashboard($instance_id, $universe_id = false, $accessParams = array("A", "O", "D", "DR", "C3", "C2")) {
        return $this->canAccessDashboard("evaluate_dashboard", $instance_id, $universe_id, $accessParams);
    }
    
    public function canAccessRepository($keyword, $rep_id, $universe_id = false, $accessParams = array("A", "M", "BM")) {                
        return $this->canAccess("repository", $keyword, $rep_id, $universe_id, $accessParams);
    }
    
    public function canDeleteRepository($rep_id, $universe_id = false, $accessParams = array("A", "M", "BM")) {        
        return $this->canAccessRepository("delete_repository", $rep_id, $universe_id, $accessParams);
    }
    
    public function canReadRepository($rep_id, $universe_id = false, $accessParams = array("A", "M", "BM")) {
        return $this->canAccessRepository("read_repository", $rep_id, $universe_id, $accessParams);
    }
    
    public function canModifyRepository($rep_id, $universe_id = false, $accessParams = array("A", "M", "BM")) {
        return $this->canAccessRepository("modify_repository", $rep_id, $universe_id, $accessParams);
    }
    
    public function canActivateRepository($rep_id, $universe_id = false, $accessParams = array("A", "M", "BM")) {
        return $this->canAccessRepository("activate_repository", $rep_id, $universe_id, $accessParams);
    }
}