<?php
class ExchangeFOrmModel extends coreModel {    
    protected $exchange_form_id = array();

    public function __construct($exchange_form_id) {
        parent::__construct();
        $this->exchange_form_id = $exchange_form_id;
        $this->lang = !empty($_SESSION['language']) ? $_SESSION['language'] : 'fr';
    }
}
