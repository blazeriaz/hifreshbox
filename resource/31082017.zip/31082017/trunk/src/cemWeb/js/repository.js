var app = angular.module('agCem', ['ngRoute', 'ngPagination', 'angular.filter','clem.filters','ui.bootstrap','ngFileUpload','angular.vertilize']);

//constant
app.constant('config', {  
    baseUrl: '../../scripts',
    enableDebug: true
});

//filter
app.filter('cemTranslate', function(languageService) {
    return function(string, args) {
        return languageService.get(string, args);
    }
});

app.filter('isEmptyObject', function () {
    var bar;
    return function (obj) {
        for (bar in obj) {
            if (obj.hasOwnProperty(bar)) {
                return false;
            }
        }
        return true;
    };
});
app.filter('notInArray', function($filter) {
    return function(list, arrayFilter) {
        if(arrayFilter.length > 0) {
            return $filter("filter")(list, function(listItem) {
                return arrayFilter.indexOf(listItem) == -1;
            });
        } else {
            return list;
        }
    };
});

// Router
app.config(function($routeProvider,$locationProvider) {    
    $routeProvider.when('/', {
        template : '<repositories-list repositories="$resolve.repositories"></repositories-list>',
        resolve :{
            repositories: function($route, repositoryService) {
                return repositoryService.getRepositories();
            }
        }
    }).when('/repository/:repID/:revId', {
        template : '<repositories-view repository="$resolve.repository" milestones="$resolve.milestones" milestonedata="$resolve.milestonedata"></repositories-view>',
        resolve :{
            repository: function($route, repositoryService,$filter) {
                return repositoryService.getRepositoryVersion($route.current.params.repID,$route.current.params.revId).then(function(res){
                    return res.data.repositoryVersion;
                }, function(error){
                    });
            },
            milestones: function($route, repositoryMileService,$sce,$filter) {
                return repositoryMileService.getAllMilestones($route.current.params.repID,$route.current.params.revId).then(function(res){
                    angular.forEach(res.data.repMilestones, function(milestone){
                        milestone.showActivities = 0;
                        var milestone_title = (milestone.milestone_title)?(milestone.milestone_title):'-';
                        var milestone_definition = (milestone.milestone_definition)?(milestone.milestone_definition):'-';
                        var milestone_aer_reference = (milestone.milestone_aer_reference)?(milestone.milestone_aer_reference):'-';
                        var milestone_rpif_reference = (milestone.milestone_rpif_reference)?(milestone.milestone_rpif_reference):'-';
                        var popoverHtml = '<b>'+$filter('cemTranslate')('text_std_milestone')+'</b> : '                    
                        + milestone_title + "<br/>"
                        +'<b>'+$filter('cemTranslate')('text_definition')+'</b> : '
                        + (milestone_definition) + "<br/>"
                        +'<b>'+$filter('cemTranslate')('text_overall_result')+'</b> : '
                        + (milestone_aer_reference) + "<br/>"
                        +'<b>'+$filter('cemTranslate')('text_RPIF')+'</b> : '
                        + (milestone_rpif_reference);
                        milestone.htmlPopover = $sce.trustAsHtml(popoverHtml);
                    });
                    return res.data.repMilestones;
                });
            },
            milestonedata:function($route,repositoryMileService){
                return repositoryMileService.getMilestoneDatas($route.current.params.repID,$route.current.params.revId).then(function(res){
                    return res.data.miledata;
                });
            }
        }
    }).when('/add', {
        template : '<form-add></form-add>'
    });
        
}).run(function(languageService){
    languageService.setLang('fr');
    languageService.putlanguages('repository_designer','alertes_js','repository_milestone_designer');
});



//Common services
app.service('languageService', function($http,config){
    var ls = this;
    ls.lang = 'fr';
    ls.languages = {};
    ls.setLang = function(lang) {
        ls.lang = lang;
    }
    ls.set = function(key, value) {
        ls.languages[key] = value;
    }
    ls.get = function(key, args) {        
        if(!args) {
            args = [];
        }
        if(!ls.languages[key]) {
            return key;
        }
        var rt = ls.languages[key];
        for(i=0;i<args.length;i++) {
            rt = rt[args[i]]?rt[args[i]]:rt;
        }
        return rt;
    }
    ls.putlanguages = function(languages) {
        $http.post(config.baseUrl+'/xmlhttprequest/ajax_get_languages.php',
        {
            languages : languages, 
            lang : ls.lang
        }
        ).then(function(res){
            angular.extend(ls.languages, res.data);
        });
    }
});

app.service('arcaUserService', function($http, $filter,config){
    var arca = this;
    arca.ipnUsers = {};
    arca.getIpnUsers = function(ipnLists,ajax){
        if(ajax || $filter('isEmptyObject')(arca.ipnUsers)){
            $http.post(config.baseUrl+'/admin_template/ajax/common.php',{
                users : ipnLists
            }).then(function(res){
                arca.ipnUsers = res.data.usersIpns
                return arca.ipnUsers;
            });
        }else{
            return arca.ipnUsers;
        }
            
    }
});

app.service('arcaUserService', function($timeout, $q, $http, $filter,config){
    var arca = this;
    arca.searchTimeOut = null;
    arca.searchInputTimeOut = null;
    arca.addFavTimeOut = null;
    arca.addFavUsers = [];
    arca.removeFavTimeOut = null;
    arca.removeFavUsers = [];
    arca.savedUsers = [];
    arca.needToSearchIpns = [];
    
    arca.saveUserCache = function(user) {
        if(arca.savedUsers.indexOf(user) < 0) {
            arca.savedUsers.push(user);
        } 
    }
    
    arca.getFavUsers = function() {
        return $http.post(config.baseUrl+'/admin_template/ajax/arca.php',{
            action : 'favourite'
        });
    }
    
    arca.addFavUser = function(ipn) {
        if(arca.addFavUsers.indexOf(ipn) !== -1) {
            var defer = $q.defer();
            $timeout(function(){
                defer.resolve(ipn);
            }, 100);
            return defer.promise;
        }
        
        arca.addFavUsers.push(ipn);
        
        if(arca.addFavTimeOut) {
            $timeout.cancel(arca.addFavTimeOut);
        }
        
        arca.addFavTimeOut = $timeout(function(){
            var request = $http.post(
                './ajax/arca.php',
                {
                    action : 'add_favourite', 
                    ipns : arca.addFavUsers
                }
                );
            arca.addFavUsers = [];
            return request;
        }, 600);
        return arca.addFavTimeOut;
    }
    
    arca.removeFavUser = function(ipn) {
        if(arca.removeFavUsers.indexOf(ipn) !== -1) {
            var defer = $q.defer();
            $timeout(function(){
                defer.resolve(ipn);
            }, 100);
            return defer.promise;
        }
        
        arca.removeFavUsers.push(ipn);
        
        if(arca.removeFavTimeOut) {
            $timeout.cancel(arca.addFavTimeOut);
        }
        
        arca.removeFavTimeOut = $timeout(function(){
            var request = $http.post(
                './ajax/arca.php',
                {
                    action : 'remove_favourite', 
                    ipns : arca.removeFavUsers
                }
                );
            arca.removeFavUsers = [];
            return request;
        }, 600);
        return arca.removeFavTimeOut;
    }
    
    arca.searchIpn = function(ipn) {
        var user = $filter('filter')(arca.savedUsers, {
            ipn: ipn
        });
        if(arca.needToSearchIpns.indexOf(ipn) !== -1 || user.length > 0) {
            var defer = $q.defer();
            $timeout(function(){
                defer.resolve(ipn);
            }, 100);
            return defer.promise;
        }
        
        arca.needToSearchIpns.push(ipn);
        
        if(arca.searchTimeOut) {
            $timeout.cancel(arca.searchTimeOut);
        }
        
        arca.searchTimeOut = $timeout(function(){            
            var request = $http.post(
                './ajax/arca.php',
                {
                    ipns : arca.needToSearchIpns
                }
                ).then(function(res){
                angular.forEach(res.data.arcaUsers, function(user) {
                    if(arca.savedUsers.indexOf(user) < 0) {
                        arca.savedUsers.push(user);
                    }                    
                });
            });
            arca.needToSearchIpns = [];
            return request;
        }, 300);
        return arca.searchTimeOut;
    }
    
    arca.getUserInfo = function(ipn) {
        arca.searchIpn(ipn).then(angular.noop,angular.noop);
        var user = $filter('filter')(arca.savedUsers, {
            'ipn': ipn
        });
        if(user.length > 0) {
            var defer = $q.defer();
            defer.resolve(user[0]);
            return defer.promise;
        }
        return $timeout(function(){
            return arca.getUserInfo(ipn);
        }, 1000);
    }
    
    arca.searchInput = function(input) {
        if(arca.searchInputTimeOut) {
            $timeout.cancel(arca.searchInputTimeOut);
        }
        arca.searchInputTimeOut = $timeout(function(){ 
            return $http.post(
                config.baseUrl+'/admin_template/ajax/arca.php',
                {
                    action: 'search', 
                    input : input
                }
                );
        }, 600)
        return arca.searchInputTimeOut;
    }
});

//Services
app.service('repositoryService', function($http, $filter,config){
    var rep = this;
    rep.universe ={};
    rep.repositories =[];
    rep.getRepositories = function() {
        if(rep.repositories.length==0){
            return $http.post(config.baseUrl+'/admin_template/ajax/repositories/list.php').then(function(res){
                rep.universe = res.data.universeList;
                rep.repositories =res.data.repositories;
                return rep.repositories;
                       
            });
        }else{
            return rep.repositories 
        }
    }
    rep.getItem = function(repId) {
        return $http.post(config.baseUrl+'/admin_template/ajax/repositories/actions.php', {
            action : 'getItem', 
            repository_id : repId
        })
    }
    rep.getRepositoryVersion = function(repId,revId) {
        return $http.post(config.baseUrl+'/admin_template/ajax/repositories/actions.php', {
            action : 'getRepositoryVersion', 
            repository_id : repId, 
            revision_id : revId
        });
    }
    rep.deleteRep = function(repId) {
        return $http.post(config.baseUrl+'/admin_template/ajax/repositories/actions.php', {
            action : 'delete', 
            repository_id : repId
        })
    }
    rep.checkAffectedTdb = function(repId) {
        return $http.post(config.baseUrl+'/admin_template/ajax/repositories/affected_tdb.php', {
            repository_id : repId
        })
    }
    rep.activateRep=function(action,datas){
        datas.action = action;
        return $http.post(config.baseUrl+'/admin_template/ajax/repositories/actions.php', datas)
    }
    rep.deleteFile=function(repId){
        return $http.post(config.baseUrl+'/admin_template/ajax/repositories/actions.php', {
            action : 'deletefile', 
            repository_id : repId
        })
    }
        
    rep.saveData = function(datas){
        var repForm = new FormData();
        repForm.append('action', 'save');
        angular.forEach(datas, function(value, key) {
            repForm.append(key, value);
        });
        return $http.post(config.baseUrl+'/admin_template/ajax/repositories/actions.php',repForm, {
            transformRequest: angular.identity,
            headers: {
                'Content-Type': undefined
            }
        });
    }
    rep.updateManager=function(datas){
        datas.action='update_manger';
        return $http.post(config.baseUrl+'/admin_template/ajax/repositories/actions.php',datas)
    }
    rep.getGesperTypolgy = function(repid){
        var datas={};
        datas.action='gesper';
        datas.repository_id=repid;
        return $http.post(config.baseUrl+'/admin_template/ajax/typology.php',datas)
    }
    rep.saveSetting=function(datas){
        datas.action='save_setting';
        return $http.post(config.baseUrl+'/admin_template/ajax/repositories/actions.php',datas)
    }
   
});

app.service('repositoryMileService', function($http, $q,config){
    var serviceData = this;
    serviceData.Allitems ={};
    this.getAllMilestones = function(repId,revid) {        
        return $http.post(config.baseUrl+'/admin_template/ajax/repository_milestone', {
            action : 'list', 
            repository_id : repId,
            revision_id:revid
        });
    }
    this.getMilestoneDatas = function(repId,revid){
        return $http.post(config.baseUrl+'/admin_template/ajax/repository_milestone', {
            action : 'miledata', 
            repository_id : repId,
            revision_id:revid
        });
    }
    this.getItem = function(mileId,force) {
        return $http.post(config.baseUrl+'/admin_template/ajax/repository_milestone', {
            action : 'getItem', 
            milestone_id : mileId
        }).then(function(res){
            return res.data.repositoryMile;
        });
    }

    this.saveItem = function(mileDatas) {
        mileDatas.action = 'saveItem';
        return $http.post(config.baseUrl+'/admin_template/ajax/repository_milestone', mileDatas);
    }

    this.deleteItem = function(mileDatas) {
        mileDatas.action = 'deleteMilestone';
        return $http.post(config.baseUrl+'/admin_template/ajax/repository_milestone', mileDatas);
    }
    this.updateOrderMilestones = function($action,mileDatas){
        mileDatas.action="updateOrder";
        mileDatas.move= $action;
        return $http.post(config.baseUrl+'/admin_template/ajax/repository_milestone', mileDatas);
    }
    this.updateOrderAll = function($action,mileDatas){
        mileDatas.action= $action;
        return $http.post(config.baseUrl+'/admin_template/ajax/repository_milestone', mileDatas);
    }   
    this.copyData = function(datas){
        datas.action="copy";
        return $http.post(config.baseUrl+'/admin_template/ajax/repository_milestone',datas);
    }
    this.deleteRepMilestone =function(revId,mileId) {        
        return $http.post(config.baseUrl+'/admin_template/ajax/repository_milestone', {
            action : 'deleteMilestone', 
            revision_id : revId,
            milestone_id:mileId
        });
    }
});

// Common component
app.component('sortBy', {
    bindings: {
        orderby:'=',
        orderfield:'=',
        field:'@',
        onClick: '&'
    },
    template: '<button class="btn btn-sm" ng-if="$ctrl.field != $ctrl.orderfield">\n\
                <img src="../../images/pictos/table_sorticon.gif" ng-click="$ctrl.setOrderField($ctrl.field)" />\n\
    </button><button class="btn btn-sm" ng-click="$ctrl.setOrderField($ctrl.field)" ng-if="$ctrl.field == $ctrl.orderfield && !$ctrl.orderby">\n\
<img src="../../images/pictos/table_sortedupicon.gif" /></button>\n\
<button class="btn btn-sm" ng-click="$ctrl.setOrderField($ctrl.field)" ng-if="$ctrl.field == $ctrl.orderfield && $ctrl.orderby">\n\
<img src="../../images/pictos/table_sorteddownicon.gif" /></button>',   

    transclude: true,
    controller:function(){
        $ctrl =this;
        $ctrl.setOrderField=function(ele){
            $ctrl.onClick({
                'orderElement':ele
            }); 
        }
    }
});

app.component('multiselect', {
    templateUrl: '../../js/angular/components/multiselect/template.html',   
    bindings: {
        leftitems: '=',
        model: '=',
        size: '@',
        optionid: '@',
        optionvalue: '@',
        optiongroup: '@'
    },
    controllerAs: "vm",
    controller: function(){
        var vm = this;
        vm.boxStyle = {};        
        vm.rightitems = [];
        
        vm.$onInit = function(){
            if(!vm.size) {
                vm.size = 18;
            }
            if(vm.size > 15) {
                vm.boxStyle = {
                    'margin-top':'110px'
                };
            }
        }
        
        vm.moveRight = function($event){
            if(typeof $event != 'undefined' && $event.type == 'dblclick' && $event.target.nodeName.toLowerCase() == 'optgroup') {
            //vm.sfamilies = $filter('filter')(vm.families, vm.pjtFilter, function(families){});
            }          
            for (var i = 0; i < vm.leftBox.length; i++) {
                vm.rightitems.push(vm.leftBox[i]);
            }
            vm.model = vm.rightitems;
            vm.leftBox = [];
        }
        
        vm.moveLeft = function($event){
            if(typeof $event != 'undefined' && $event.type == 'dblclick' && $event.target.nodeName.toLowerCase() == 'optgroup') {
            //vm.sfamilies = $filter('filter')(vm.families, vm.pjtFilter, function(families){});
            }
            for (var i = 0; i < vm.rightBox.length; i++) {
                var removeIndex = vm.rightitems.map(function(item) {
                    return item[vm.optionid];
                })
                .indexOf(vm.rightBox[i][vm.optionid]);
                if(removeIndex == -1) {
                    continue;
                }
                vm.rightitems.splice(removeIndex, 1);
            }
            vm.model = vm.rightitems;
            vm.rightBox = [];
        }
        vm.moveRightAll = function() {
            vm.rightitems = [];
            for (var i = 0; i < vm.leftitems.length; i++) {
                vm.rightitems.push(vm.leftitems[i]);
            }
            vm.model = vm.rightitems;
            vm.leftBox = [];
            vm.rightBox = [];
            vm.leftFilter = '';
            vm.rightFilter = '';
        }
        vm.moveLeftAll = function() {
            vm.rightitems = [];
            vm.leftBox = [];
            vm.rightBox = [];
            vm.leftFilter = '';
            vm.rightFilter = '';
            vm.model = vm.rightitems;
        }
    }
});
    
app.component('arcaSearch', {
    templateUrl: '../admin_template/views/common/arca_search.html',   
    bindings: {
        resolve: '<',
        close: '&',
        dismiss: '&'
    },
    controllerAs: "arca",
    transclude: true,
    controller: function(arcaUserService) {
        var arca = this;  
        arca.selectedIpn = '';
        arca.users = [];
        arca.input = "";
        arca.searching = false;
        arca.favUsers = [];
        arca.$onInit = function() {
            arcaUserService.getFavUsers().then(function(res){
                arca.favUsers = res.data.favUsers;
            });
            if(arca.resolve.input) {
                arca.input = arca.resolve.input;
                arca.search(arca.input);
            }
            arca.selectedIpn = arca.resolve.ipn;
        }
        
        arca.inFavUsers = function(ipn) {
            return arca.favUsers.indexOf(ipn) !== -1;
        }
        
        arca.addFavUser = function(ipn) {
            arca.favUsers.push(ipn);
            arcaUserService.addFavUser(ipn).then(function(res){
                if(res && res.favUsers) {
                    arca.favUsers = res.favUsers;
                }
            },angular.noop);
        }
        
        arca.removeFavUser = function(ipn) {
            var i = arca.favUsers.indexOf(ipn);
            if(i >= 0) {
                arca.favUsers.splice(i, 1);
            }
            arcaUserService.removeFavUser(ipn).then(function(res){
                if(res && res.favUsers) {
                    arca.favUsers = res.favUsers;
                }
            },angular.noop);
        }
        
        arca.search = function() {
            arca.searching = true;
            arcaUserService.searchInput(arca.input).then(function(res){
                arca.users = res.data.arcaUsers;
                arca.searching = false;
            },angular.noop);
        }
        
        arca.selectIPN = function(user) {
            if(typeof user == 'string') {
                arca.selectedIpn = user;
                arcaUserService.getUserInfo(user).then(function(user){
                    arca.close({
                        $value: user
                    });
                    arca.dismiss({
                        $value: 'done'
                    });
                });
            } else {
                arca.selectedIpn = user.ipn;
                arcaUserService.saveUserCache(user);
                arca.close({
                    $value: user
                });
                arca.dismiss({
                    $value: 'done'
                });
            }            
        }
        
        arca.close = function() {
            arca.dismiss({
                $value: 'cancel'
            });
        }
    }
});
 
app.component('arcaDisplay', {
    template: '{{arca.data}}',   
    bindings: {
        ipn : '<',
        prop : '@'        
    },
    controllerAs: "arca",
    transclude: true,
    controller: function(arcaUserService) {
        var arca = this;
        arca.data = '';
        arca.$onInit = function(){
            arca.data = arca.ipn;
            arcaUserService.getUserInfo(arca.ipn).then(function(res){
                arca.data = res[arca.prop]?res[arca.prop]:'';
            });
        }
    }
});

//component

app.component('repositoriesList', {
    bindings : {
        repositories : '='
    },
    templateUrl: '../admin_template/views/repositories/list.html',
    controllerAs: 'repList',
    controller: function($uibModal,repositoryService,$filter,$window) {
        var repList= this;
        repList.perpage =10;
        repList.predicate = 'name';    
        repList.reverse = false; 
            
        repList.$onInit = function(){
            repList.repFilter = {};
            repList.universe = repositoryService.universe;
            repList.filterChange();
        }
        repList.deleteRepository=function(item){
            var cont = $filter('cemTranslate')('msg_confirm_delete_milestone');
            if($window.confirm(cont)){
                repositoryService.deleteRep(item.repository_id).then(function() {
                    repList.filtered.splice(repList.filtered.indexOf(item),1);
                    repList.repositories.splice(repList.filtered.indexOf(item),1);
                    repList.setPage(repList.currentPage); 
                });
            }else{
                return false;
            }
        }
            
        repList.changeRepositoryManager = function(type,repid) {
            var user = $filter('filter')(repList.repositories, {
                'repository_id': repid
            });
            var resolve = {};
            if(user) {
                resolve.ipn = function() {
                    return user[0][type];
                }
            }
            
            var modalInstance = $uibModal.open({
                animation: false,
                component: 'arcaSearch',
                resolve: resolve,
                openedClass: 'arca-search-modal'
            });

            modalInstance.result.then(function (selectedUser) {
                if(!(selectedUser && selectedUser.ipn)) {
                    return;
                }
                var postData={};
                postData.ipn=selectedUser.ipn;
                postData.type=type;
                postData.repository_id=repid;
                repositoryService.updateManager(postData).then(function(res) {
                    
                    });
            }, function() {
                
                });
        }
            
        repList.animationsEnabled = true;
        repList.openComponentModal = function (component,id) {
            var modalInstance = $uibModal.open({
                animation: repList.animationsEnabled,
                component: component,
                resolve:{
                    repository:function(repositoryService){
                        var resData =[{}];
                        if(id){
                            return repositoryService.getItem(id).then(function(res){
                                return res.data.repository;
                            });
                        }else{
                            return resData;
                        }
                    }
                }
            });
        };
            
        repList.openSettingModal = function (repid,revisionid) {
            var repository = $filter('filter')(repList.repositories,{
                'repository_id':repid
            },true);
            var resolve = {};
            if(repository) {
                resolve.repository = function() {
                    return repository[0];
                }
                resolve.selectedRevisionId= function() {
                    return revisionid;
                }
            }
            var modalInstanceSetting = $uibModal.open({
                animation: repList.animationsEnabled,
                component: 'formSetting',
                size: 'lg',
                resolve:resolve
            });
                
            modalInstanceSetting.result.then(function() {

                }, function() {
                
                });
        };
            
            
        repList.resetFilters = function () {
            // needs to be a function or it won't trigger a $watch
            repList.repFilter = {};
            repList.filterChange();
        };
        repList.setPage = function (pageNo) {
            repList.currentPage = pageNo;
        };
        repList.pageChanged  = function () {

        };
        repList.order = function (predicate) {    
            repList.reverse = (repList.predicate === predicate) ? !repList.reverse : false;    
            repList.predicate = predicate;    
        };  
        repList.filterChange = function (val) {
            repList.totalItems = $filter('filter')(repList.repositories,repList.repFilter).length;
            if(repList.repFilter.id){
                repList.filtered = $filter('filter')(repList.repositories,{
                    'id':repList.repFilter.id
                });
            }else{
                repList.filtered = $filter('filter')(repList.repositories,repList.repFilter); 
            }
            repList.currentPage = 1;
        };     
    }
});

app.controller('ModalInstanceCtrl', function ($uibModalInstance, items) {
    var $ctrl = this;


    $ctrl.ok = function () {
        $uibModalInstance.close();
    };

    $ctrl.cancel = function () {
        $uibModalInstance.dismiss('cancel');
    };
});
app.component('formAdd', {
    templateUrl: '../admin_template/views/repositories/form.html',
    bindings: {
        resolve: '<',
        close: '&',
        dismiss: '&'
    },
    controller: function (repositoryService,Upload,$route) {
        var $ctrl = this;
        $ctrl.$onInit = function () {
            $ctrl.repositoryData = angular.copy($ctrl.resolve.repository);
            $ctrl.universes = repositoryService.universe;
        };
        $ctrl.ok = function () {
            console.log($ctrl)
            if($ctrl.repositoryFrm.$valid){
            
                repositoryService.saveData($ctrl.repositoryData).then(function(res){
                    if(res.data.success){
                        $route.reload();
                    }else{
                        $ctrl.repositoryFrm.file.$error.pattern =1;
                    }
                });
            }

        };
        $ctrl.deleteFile = function (repid) {
            repositoryService.deleteFile(repid).then(function(res){
                $ctrl.repositoryData.file='';
            });
        };
        $ctrl.cancel = function () {
            $ctrl.dismiss({
                $value: 'cancel'
            });
        };
    }
});
    
app.component('formActivate', {
    templateUrl: '../admin_template/views/repositories/activate.html',
    bindings: {
        resolve: '<',
        close: '&',
        dismiss: '&'
    },
    controller: function (repositoryService,$window,$route,$http,config) {
        var $ctrl = this;
        $ctrl.repositoryActivateData={}
        $ctrl.$onInit = function () {
            $ctrl.repositoryActivateData = $ctrl.resolve.repository;
        };
        $ctrl.ok = function () {
            if($ctrl.repositoryActivateFrm.$valid){
                console.log($ctrl.repositoryActivateData);
                    
                $http.post(config.baseUrl+'/admin_template/ajax/repositories/affected_tdb.php', 
                {
                    'repository_id' :$ctrl.resolve.repository.repository_id
                    }).then(function(res){
                    if(res.data.affectedTdbCount!='0'){
                        var msg =$filter('cemTranslate')('confirm_dashboard_change');
                        msg = msg.replace('#count',res.data.affectedTdbCount);
                        if($window.confirm(msg)){
                            repositoryService.activateRep('affectTdb',$ctrl.repositoryActivateData).then(function(res){
                                });
                        }else{
                            repositoryService.activateRep('activateRep',$ctrl.repositoryActivateData).then(function(res){
                                });
                        }
                    }else{
                        repositoryService.activateRep('activateRep',$ctrl.repositoryActivateData).then(function(res){
                            });
                    }
                })
                    
                     
            }
        };
        $ctrl.cancel = function () {
            $ctrl.dismiss({
                $value: 'cancel'
            });
        };
    }
});
 
 
app.component('formSetting', {
    templateUrl: '../admin_template/views/repositories/setting.html',
    bindings: {
        resolve: '<',
        close: '&',
        dismiss: '&'
    },
    controller: function (repositoryService,$window) {
        var $ctrl = this;
        $ctrl.repositorySettingFrm={}
        $ctrl.$onInit = function () {
            $ctrl.repositorySettingData = $ctrl.resolve.repository;
            if($ctrl.repositorySettingData.active_version_id == $ctrl.resolve.selectedRevisionId){
                $ctrl.repositorySettingData.activity_evaluation =$ctrl.repositorySettingData.ACT.activity_evaluation;
                $ctrl.repositorySettingData.backlog_display =$ctrl.repositorySettingData.ACT.backlog_display;
            }
            $ctrl.repositorySettingFrm.gesper = 0;
            $ctrl.repositorySettingFrm.context =0;
            
        };

        $ctrl.ok = function () {
            $ctrl.repositorySettingFrm.gesper = 0;
            $ctrl.repositorySettingFrm.context =0;
            
            repositoryService.saveSetting($ctrl.repositorySettingData).then(function(res){
                if(res.data.success){
                        
                }else{
                    if(res.data.alerts.error.gesper){
                        $ctrl.repositorySettingFrm.gesper = 1;
                    }
                    if(res.data.alerts.error.context){
                        $ctrl.repositorySettingFrm.context = 1;
                    }
                }
            })
        };
        $ctrl.cancel = function () {
            $ctrl.dismiss({
                $value: 'cancel'
            });
        };
    }
});

app.component('repositoriesView', {
    bindings : {
        repository : '=',
        milestones : '=',
        milestonedata:'='
    },
    transclude: true,
    templateUrl: '../admin_template/views/repositories/view.html',
    controllerAs: 'repView',
    controller: function($route,repositoryMileService,$uibModal,$window,$filter) {
        var repView= this;
        repView.repositoryId = $route.current.params.repID;
        repView.revisionId = $route.current.params.revId;
        repView.perpage =6;
        repView.currentPage = 1;
        repView.animationsEnabled = true;
        repView.displayActivities = 0;
        repView.$onInit = function() {
            repView.totalItems =repView.milestones.length;
            repView.currentPage = 1;
        }
        repView.setPage = function (pageNo) {
            repView.currentPage = pageNo;
        };
        repView.pageChanged  = function () {

        };
        repView.showAllActivities = function() {
            angular.forEach(repView.milestones, function(milestone){
                milestone.showActivities = 1;
            });
            repView.displayActivities = 1;
        }
        repView.hideAllActivities = function() {
            angular.forEach(repView.milestones, function(milestone){
                milestone.showActivities = 0;
            });
            repView.displayActivities = 0;
        }
       
        repView.openComponentModal = function (id) {
            var modalInstance = $uibModal.open({
                animation: repView.animationsEnabled,
                component:'milestoneForm',
                size:'lg',
                resolve:{
                    repositoryMile:function(repositoryMileService){
                        var resData ={};
                        if(id){
                            return repositoryMileService.getItem(id);
                        }else{
                            return resData;
                        }
                    },
                    repository_id:function(){
                        return repView.repositoryId
                    },
                    revision_id:function(){
                        return repView.revisionId
                    }
                }
            });
        };
       
        repView.updateOrder=function($mileId,$order,$action){
            repView.updateOrderData = {};
            repView.updateOrderData.repository_id=repView.repositoryId;
            repView.updateOrderData.revision_id=repView.revisionId;
            repView.updateOrderData.mileId=$mileId;
            repView.updateOrderData.order=$order;
            repositoryMileService.updateOrderMilestones($action,repView.updateOrderData).then(function(res){
                
                });      
        }
        repView.updateOrderAll=function($action){
            repView.updateOrderData = {};
            repView.updateOrderData.repository_id=repView.repositoryId;
            repView.updateOrderData.revision_id=repView.revisionId;
            repositoryMileService.updateOrderAll($action,repView.updateOrderData).then(function(res){
                $route.reload();
            });      
        }  
        
        repView.deleteMilestone=function(item){
            if($window.confirm($filter('cemTranslate')('msg_confirm_delete_milestone')+item.milestone+'?')){
                var data={};
                data.revision_id= repView.revisionId;
                data.milestone_id= item.repository_milestone_id;
                data.repository_id= repView.repositoryId;
                repositoryMileService.deleteItem(data).then(function() {
                    repView.milestones.splice(repView.milestones.indexOf(item),1);
                    repView.setPage(repView.currentPage); 
                });
            }else{
                return false;
            }
        };
        
        repView.openCopyModal= function (size, parentSelector,model,model_id) {
            var modalCopyInstance = $uibModal.open({
                animation: repView.animationsEnabled,
                component:'milestoneCopyForm',
                size: size,
                resolve: {
                    items: function () {
                        var passData ={};
                        passData.model = model;
                        passData.model_id = model_id;
                        passData.milestones = repView.milestones;
                        passData.results = repView.milestonedata.results;
                        passData.activities = repView.milestonedata.activities;
                        return passData;
                    }
                }
            });

            modalCopyInstance.result.then(function (selectedItem) {
                
                }, function () {
                //  $log.info('Modal dismissed at: ' + new Date());
                });
        }
 
        
    }
});  
app.component('repositoryHeader', {
    templateUrl: '../admin_template/views/repositories/header.html',   
    bindings: {
        repository : '='   
    },
    controllerAs: "repHeader",
    transclude: true,
    controller: function() {
        var repHeader = this;
    }
});
app.component('milestoneForm', {
    templateUrl: '../admin_template/views/repositories/milestone_form.html',
    bindings: {
        resolve: '<',
        close: '&',
        dismiss: '&'
    },
    controller: function (repositoryMileService,$route) {
        var $ctrl = this;
        
        $ctrl.$onInit = function () {
            $ctrl.repositoryMileData = $ctrl.resolve.repositoryMile;
        };
        $ctrl.ok = function () {
            if($ctrl.repositoryMileFrm.$valid){
                $ctrl.repositoryMileData.repository_id=$ctrl.resolve.repository_id;
                $ctrl.repositoryMileData.repository_revision_id=$ctrl.resolve.revision_id;
                repositoryMileService.saveItem($ctrl.repositoryMileData).then(function(res){
                    $route.reload();
                });
            }

        };

        $ctrl.cancel = function () {
            $ctrl.dismiss({
                $value: 'cancel'
            });
        };
    }
});
app.component('milestoneCopyForm', {
    templateUrl: '../admin_template/views/repositories/copy.html',
    bindings: {
        resolve: '<',
        close: '&',
        dismiss: '&'
    },
    controller: function (repositoryMileService,$route,$filter) {
        var $ctrl = this;
        $ctrl.$onInit = function () {
            $ctrl.milestones = $ctrl.resolve.items.milestones;
           
        };
        $ctrl.getTopics=function(){
            $ctrl.copyTopicid={};
            $ctrl.rightitems={};
            $ctrl.repositoryMileCopyFrm.$submitted = false;
            if($ctrl.copyMilestoneid && $ctrl.copyMilestoneid.repository_milestone_id){
                
                if($ctrl.resolve.items.model=='milestone'){
                    var mileTopics = $filter('filter')($ctrl.resolve.items.results,{
                        'repository_milestone_id_fk':$ctrl.copyMilestoneid.repository_milestone_id
                    });
                    $ctrl.mileTopicDatas =[];
                    var i =0;
                    angular.forEach(mileTopics,function(datares,key){
                        var mileActivities = $filter('filter')($ctrl.resolve.items.activities,{
                            'repository_result_id_fk':datares.repository_result_id
                        });
                        angular.forEach(mileActivities,function(data,key){
                            $ctrl.mileTopicDatas[i] = data;
                            $ctrl.mileTopicDatas[i]['activity_order_val'] = data.activity_order+' - '+data.activity;
                            $ctrl.mileTopicDatas[i]['result_order_val'] = datares.result_order+' - '+datares.result;
                            $ctrl.mileTopicDatas[i]['repository_result_id'] = data.repository_result_id_fk
                            i++;
                        });
                    });
                }else{
                    $ctrl.mileTopicDatas = $filter('filter')($ctrl.resolve.items.results,{
                        'repository_milestone_id_fk':$ctrl.copyMilestoneid.repository_milestone_id
                    });
                }
            }
        }
        
        $ctrl.getActivities = function(){
            $ctrl.repositoryMileCopyFrm.$submitted = false;
            if($ctrl.copyTopicid && $ctrl.copyTopicid.repository_result_id){
                $ctrl.mileTopicActivityDatas = $filter('filter')($ctrl.resolve.items.activities,{
                    'repository_result_id_fk':$ctrl.copyTopicid.repository_result_id
                });
            }
        }
        
        $ctrl.ok = function () {
            if($ctrl.repositoryMileCopyFrm.$valid){
                var selectedData = {};
                selectedData.mileID= $ctrl.copyMilestoneid.repository_milestone_id;
                selectedData.topicId= $ctrl.copyTopicid.repository_result_id;
                selectedData.model= $ctrl.resolve.items.model;
                selectedData.model_id= $ctrl.resolve.items.model_id;
                selectedData.activity =$ctrl.copyactivityid;
                selectedData.activities =$ctrl.activities;
                repositoryMileService.copyData(selectedData).then(function(res){
                    $route.reload();
                }); 
            }

        };

        $ctrl.cancel = function () {
            $ctrl.dismiss({
                $value: 'cancel'
            });
        };
    }
});