<?php
/**
 * Level 2 menus of modules
 * 
 * PHP version 5
 * 
 * @category Menus
 * @package  Scripts
 * @author   Charles Santucci <charles.santucci@renault.com>
 * @license  http://www.php.net/license/3_0.txt  PHP License 3.0
 * @link     http://baselinesvn.mc2.renault.fr:9090/svn/svn61281
*/
$tableMenusN22=array();
// menus of second level when level one is selected
$cpt=0;
if (!isset($selected_menu_n1)) {
    $selected_menu_n1=$_SESSION['menu_n1'];
}

switch($selected_menu_n1)
{
  // admin g�n�ral gestion des droits r�serv� � l'admin g�n�ral 
  case 'admin':
    // directly select the first level 2 menu  
    if ($_SESSION['menu_n2']==-1)
    {
      $_SESSION['menu_n2']=0;
    } 	  
    $tableMenusN22[$cpt]['name']=$libelle_menu_n2_droits;
    $tableMenusN22[$cpt]['file']='admin_global/administrators_management.php';
    $tableMenusN22[$cpt]['display']  =true;
    $tableMenusN22[$cpt++]['rights']=array("view_user");

    $tableMenusN22[$cpt]['name']=$libelle_menu_n2_profils;
    $tableMenusN22[$cpt]['file']='admin_global/profiles_management.php';
    $tableMenusN22[$cpt]['display']  =true;
    $tableMenusN22[$cpt++]['rights'] = array("super_admin");
    /**
    $tableMenusN22[$cpt]['name']=$libelle_menu_n2_acces;
    $tableMenusN22[$cpt]['file']='admin_global/profiles_items_management.php';
    $tableMenusN22[$cpt]['display']  =true;
    $tableMenusN22[$cpt++]['rights']=array();    **/
    
    $tableMenusN22[$cpt]['name']=$libelle_menu_n2_universe;
    $tableMenusN22[$cpt]['file']='admin_global/universe_management.php';
    $tableMenusN22[$cpt]['display']  =true;
    $tableMenusN22[$cpt++]['rights']=array("system_admin");
    
    $tableMenusN22[$cpt]['name']=$libelle_menu_n2_news;
    $tableMenusN22[$cpt]['file']='admin_global/news_management.php';
    $tableMenusN22[$cpt]['display']  =true;
    $tableMenusN22[$cpt++]['rights']=array("system_admin");  
    
    $tableMenusN22[$cpt]['name']=$libelle_menu_n2_statistiques;
    $tableMenusN22[$cpt]['file']='admin_global/statistics.php';
    $tableMenusN22[$cpt]['display']  =true;
    $tableMenusN22[$cpt++]['rights']=array("view_user");  
    
    /** Modified by Venkatesh **/
    $tableMenusN22[$cpt]['name']=$libelle_menu_n2_user_statistiques;
    $tableMenusN22[$cpt]['file']='admin_global/user_statistics.php';
    $tableMenusN22[$cpt]['display']  =true;
    $tableMenusN22[$cpt++]['rights']=array("view_user"); 
    /** Modified by Venkatesh **/
    
    $tableMenusN22[$cpt]['name']=$libelle_menu_n2_parametres;
    $tableMenusN22[$cpt]['file']='admin_global/parameters_management.php';
    $tableMenusN22[$cpt]['display']  =true;
    $tableMenusN22[$cpt++]['rights']=array("system_admin");

    $tableMenusN22[$cpt]['name']=$libelle_menu_n2_manuals_mngt;
    $tableMenusN22[$cpt]['file']='admin_global/manage_manuals.php';
    $tableMenusN22[$cpt]['display']  =true;
    $tableMenusN22[$cpt++]['rights']=array("system_admin");
    
    /**
     * 1520 - Modified by Selvaraj
     * Add Menu for clear log for authorised ipn
     */
    //$isAuthorisedIpn = array('z004492','z010173','p068621','a068217','a190635','z013820','z000449','z001140');
    //if(in_array($_SESSION['ipn'],$isAuthorisedIpn)){
    $tableMenusN22[$cpt]['name']="Logs";
    $tableMenusN22[$cpt]['display']  =true;
    $tableMenusN22[$cpt]['file']='admin_global/remove_log.php';
    $tableMenusN22[$cpt++]['rights']=array("super_admin");
    
    $tableMenusN22[$cpt]['name']="Query Logs";
    $tableMenusN22[$cpt]['display']  =true;
    $tableMenusN22[$cpt]['file']='admin_global/query_logs.php';
    $tableMenusN22[$cpt++]['rights']=array("system_admin");    
    
     $tableMenusN22[$cpt]['name']="Change user";
    $tableMenusN22[$cpt]['display']  =true;
    $tableMenusN22[$cpt]['file']='admin_global/user.php';
    $tableMenusN22[$cpt++]['rights']=array("system_admin");
    
    //}
    /**
     * End
     */
  break;

  // gestion des biblioth�ques
  case 'biblio':
    // directly select the first level 2 menu  
    if ($_SESSION['menu_n2']==-1)
    {
      $_SESSION['menu_n2']=0;
    } 	        
    
    $tableMenusN22[$cpt]['name']=$libelle_menu_n2_applis;
    $tableMenusN22[$cpt]['file']='admin_libraries/projects_management.php';
    $tableMenusN22[$cpt]['display']  =true;
    $tableMenusN22[$cpt++]['rights']=array();     

    $tableMenusN22[$cpt]['name']=$libelle_menu_n2_families;
    $tableMenusN22[$cpt]['file']='admin_libraries/families_management.php';
    $tableMenusN22[$cpt]['display']  =true;
    $tableMenusN22[$cpt++]['rights']=array();    

    $tableMenusN22[$cpt]['name']=$libelle_menu_n2_departments;
    $tableMenusN22[$cpt]['file']='admin_libraries/departments_management.php';
    $tableMenusN22[$cpt]['display']  =true;
    $tableMenusN22[$cpt++]['rights']=array();
    
    $tableMenusN22[$cpt]['name']=$libelle_menu_n2_roles;
    $tableMenusN22[$cpt]['file']='admin_libraries/roles_management.php';
    $tableMenusN22[$cpt]['display']  =true;
    $tableMenusN22[$cpt++]['rights']=array();
    
    $tableMenusN22[$cpt]['name']=$libelle_menu_n2_processus;
    $tableMenusN22[$cpt]['file']='admin_libraries/process_management.php';
    $tableMenusN22[$cpt]['display']  =true;
    $tableMenusN22[$cpt++]['rights']=array();
    
    $tableMenusN22[$cpt]['name']=$libelle_menu_n2_deliverables;
    $tableMenusN22[$cpt]['display']  =true;
    $tableMenusN22[$cpt]['file']='admin_libraries/deliverables_management.php';
    $tableMenusN22[$cpt++]['rights']=array();
    
    $tableMenusN22[$cpt]['name']=$libelle_menu_n2_subjects;
    $tableMenusN22[$cpt]['file']='admin_libraries/subjects_management.php';
    $tableMenusN22[$cpt]['display']  =true;
    $tableMenusN22[$cpt++]['rights']=array();   
    
    $tableMenusN22[$cpt]['name']=$libelle_menu_n2_assessments_items;
    $tableMenusN22[$cpt]['file']='admin_libraries/assessments_items_management.php';
    $tableMenusN22[$cpt]['display']  =true;
    $tableMenusN22[$cpt++]['rights']=array();       
    
    $tableMenusN22[$cpt]['name']=$libelle_menu_n2_contexts_items;
    $tableMenusN22[$cpt]['display']  =true;
    $tableMenusN22[$cpt]['file']='admin_libraries/contexts_items_management.php';
    $tableMenusN22[$cpt++]['rights']=array();       
  break;

  // Dashboards templates manager
  case 'adm_dashboard':
    // directly select the first menu  
    if ($_SESSION['menu_n2']==-1)
    {
      $_SESSION['menu_n2']=0;
    }  
    $tableMenusN22[$cpt]['name']=$libelle_menu_n2_repositories_list;
    $tableMenusN22[$cpt]['file']='admin_template/repositories.php';
    $tableMenusN22[$cpt]['display']  =true;
    $tableMenusN22[$cpt++]['rights']=array();
    
    $tableMenusN22[$cpt]['name']=$libelle_menu_n2_repository;
    $tableMenusN22[$cpt]['file']='admin_template/repository_view.php';
    $tableMenusN22[$cpt]['display']  =true;
    $tableMenusN22[$cpt++]['rights']=array();
    
    $tableMenusN22[$cpt]['name']=$libelle_menu_n2_milestone_designer;
    $tableMenusN22[$cpt]['file']='admin_template/repository_milestone_designer.php';
    $tableMenusN22[$cpt]['display']  =true;
    $tableMenusN22[$cpt++]['rights']=array();                 

    $tableMenusN22[$cpt]['name']=$libelle_menu_n2_templates;
    $tableMenusN22[$cpt]['file']='admin_template/template_list.php';
    $tableMenusN22[$cpt]['display']  =true;
    $tableMenusN22[$cpt++]['rights']=array();
    
//    $tableMenusN22[$cpt]['name']=$libelle_menu_n2_repository_settings;
//    $tableMenusN22[$cpt]['file']='admin_template/repository_settings.php';
//    $tableMenusN22[$cpt]['display']  =true;
//    $tableMenusN22[$cpt++]['rights']=array(); 
//    
    $tableMenusN22[$cpt]['name']=$libelle_menu_n2_repository_typology;
    $tableMenusN22[$cpt]['file']='admin_template/repository_typology.php';
    $tableMenusN22[$cpt]['display']  =true;
    $tableMenusN22[$cpt++]['rights']=array();
    
    $tableMenusN22[$cpt]['name']=$libelle_menu_n2_repository_typology_items;
    $tableMenusN22[$cpt]['file']='admin_template/repository_typology_items.php';
    $tableMenusN22[$cpt]['display']  =true;
    $tableMenusN22[$cpt++]['rights']=array();

    $tableMenusN22[$cpt]['name']=$libelle_menu_n2_repository_feedbacks;
    $tableMenusN22[$cpt]['file']='admin_template/repository_feedbacks.php';
    $tableMenusN22[$cpt]['display']  =true;
    $tableMenusN22[$cpt++]['rights']=array();
  break; 
  
  case 'my_profile':
    /**$tableMenusN22[$cpt]['name']=$libelle_menu_n2_portefeuille;
    $tableMenusN22[$cpt]['file']='my_portfolio.php';
    $tableMenusN22[$cpt++]['rights']=array();  

    $tableMenusN22[$cpt]['name']=$libelle_menu_n2_manuals;
    $tableMenusN22[$cpt]['file']='online_manuals.php';
    $tableMenusN22[$cpt++]['rights']=array(); 
        
    $tableMenusN22[$cpt]['name']=$libelle_menu_n2_mon_profil;
    $tableMenusN22[$cpt]['file']='my_profile.php';
    $tableMenusN22[$cpt]['display']  =true;
    $tableMenusN22[$cpt++]['rights']=array();**/
  break;  

  case 'home':
    $tableMenusN22[$cpt]['name']=$libelle_menu_n2_create_dashboard;
    $tableMenusN22[$cpt]['file']='scripts_dashboard/dashboard_create.php';
    $tableMenusN22[$cpt]['display']  =true;
    $tableMenusN22[$cpt++]['rights']=array("create_dashboard"); 
    
    if(isset($_GET['dashboard_id'])) {
        $dashboard_id=$_GET['dashboard_id'];
    } else if(isset($_SESSION['dashboard_id'])) {
        $dashboard_id=$_SESSION['dashboard_id'];
    }
      
    
    if($dashboard_id) {
        $tableMenusN22[$cpt]['name']=$libelle_menu_n2_dashboard_monitoring;
        $tableMenusN22[$cpt]['file']='scripts_dashboard/dashboard.php?dashboard_id='.$dashboard_id.'#!/view/' . $dashboard_id;
        $tableMenusN22[$cpt]['display']=true;
        $tableMenusN22[$cpt++]['rights']=array("read_dashboard");         

        $tableMenusN22[$cpt]['name']=$libelle_menu_n2_dashboard_progress;
        $tableMenusN22[$cpt]['file']='scripts_dashboard/dashboard_progress_review.php';
        $tableMenusN22[$cpt]['display']  =true;
        $tableMenusN22[$cpt++]['rights']=array("read_dashboard");

        //US-24
        //Modified by Meenakshi
        //If all the milestones has less than 3 topics then disable radar
        //Start
        $no_radar_menu=1;
        $request = new requete("SELECT tb_instances_results.repository_milestone_id_fk AS milestone_id,count(tb_instances_results.repository_milestone_id_fk) as cnt,"
                . "milestone_name_" . $_SESSION['language'] . " AS milestone_nom, milestone_status AS statut "
                . "FROM tb_instances_results,tb_repositories_results,tb_repositories_milestones,tb_instances_milestones "
                . "WHERE repository_result_id=repository_result_id_fk AND tb_instances_results.repository_milestone_id_fk=repository_milestone_id "
                . "and tb_instances_results.instance_id_fk=tb_instances_milestones.instance_id_fk and tb_instances_results.instance_id_fk=" . $dashboard_id . " "
                . "and tb_instances_milestones.is_deleted = 0 and tb_instances_results.repository_milestone_id_fk=tb_instances_milestones.repository_milestone_id_fk "
                . "group by tb_instances_results.repository_milestone_id_fk ORDER BY milestone_order", $cnx->num);
        $milestones = $request->recup_array_champ();
        $no_radar_menu=0;
        for ($i = 0; $i < count($milestones); $i++) {
            if($milestones[$i]['cnt']>2) {
                $no_radar_menu=1;
                break;
            }
        }
        if($no_radar_menu) {
            $tableMenusN22[$cpt]['name']=$libelle_menu_n2_dashboard_radars;
            $tableMenusN22[$cpt]['file']='scripts_dashboard/dashboard_radars.php';
            $tableMenusN22[$cpt]['display']  =true;
            $tableMenusN22[$cpt++]['rights']=array("read_dashboard"); 
        }
    
            
        $tableMenusN22[$cpt]['name']=$libelle_menu_n2_dashboard_features;
        $tableMenusN22[$cpt]['file']='scripts_dashboard/dashboard.php?dashboard_id='.$dashboard_id.'#!/view/' . $dashboard_id . '/features';        
        $tableMenusN22[$cpt]['display']  =true;
        $tableMenusN22[$cpt++]['rights']=array("read_dashboard"); 
        
        /**$tableMenusN22[$cpt]['name']=$libelle_menu_n2_contexts_items;
        $tableMenusN22[$cpt]['display']  =true;
        $tableMenusN22[$cpt]['file']='scripts_dashboard/dashboard.php?dashboard_id='.$dashboard_id.'#!/view/' . $dashboard_id . '/context';
        $tableMenusN22[$cpt++]['rights']=array();**/

        $tableMenusN22[$cpt]['name']=$libelle_menu_n2_dashboard_assignments;
        $tableMenusN22[$cpt]['file']='scripts_dashboard/dashboard_assignments.php';
        $tableMenusN22[$cpt]['file']='scripts_dashboard/dashboard.php?dashboard_id='.$dashboard_id.'#!/view/' . $dashboard_id . '/assignments';
        $tableMenusN22[$cpt]['display']  =true;
        $tableMenusN22[$cpt++]['rights']=array("read_dashboard");
        
    
        // Added by Michael for Batch 1530
    
        $request = new requete("SELECT COUNT(*) AS fCount FROM tb_instances_feedbacks WHERE feedback_instance_id_fk  = '".$dashboard_id."' ", $cnx->num);
        $feedbackData = $request->recup_objet();                
        $tableMenusN22[$cpt]['name']=$libelle_menu_n2_dashboard_feedback;
        $tableMenusN22[$cpt]['file']='scripts_dashboard/dashboard_feedbacks.php';                        
        $tableMenusN22[$cpt]['display']  =false;
        if($feedbackData->fCount > 0) {
         $tableMenusN22[$cpt]['display']  =true;
        }
        $tableMenusN22[$cpt++]['rights'] = array("read_dashboard");

        $request = new requete("SELECT COUNT(*) AS Count FROM tb_exchange_form WHERE instance_id_fk  = '".$dashboard_id."'", $cnx->num);
        $exFormCount = $request->recup_objet();     
        if($exFormCount->Count > 0) {
            $tableMenusN22[$cpt]['name'] = $libelle_menu_n2_dashboard_exchange_form;
            //$tableMenusN22[$cpt]['file']='scripts_dashboard/dashboard_exchange_form.php';
            $tableMenusN22[$cpt]['file']='scripts_dashboard/dashboard.php?dashboard_id='.$dashboard_id.'#!/view/' . $dashboard_id . '/exchange_forms';
            $tableMenusN22[$cpt]['display']  = true;
            $tableMenusN22[$cpt++]['rights'] = array("read_exchange_form");
        }
        
            $cond = !empty($_REQUEST['action']) && $_REQUEST['action'] == 'read_send_exgform';
            $cond = $cond && (!empty($_REQUEST['exchange_form_id']));
            //$cond = $cond && (!empty($_REQUEST['sendmail']) || (!empty($_REQUEST['view']) && $_REQUEST['view'] =='contributor'));
            if($cond){
                $request = new requete("SELECT exchange_no,leader_ipn,contributor_ipn FROM tb_exchange_form "
                        . "WHERE exchange_form_id  = '".$_REQUEST['exchange_form_id']."'", $cnx->num);
                $exForm = $request->recup_objet(); 
                if(!empty($_SESSION['language']) && $_SESSION['language']=='fr'){
                    $tableMenusN22[$cpt]['name']= ('Fiche navette n°-'.$dashboard_id.'-'.$exForm->exchange_no);
                }else{
                    $tableMenusN22[$cpt]['name']='CLEM-'.$dashboard_id.'-Form-'.$exForm->exchange_no;
                }
                $tableMenusN22[$cpt]['display']  =true;
                $tableMenusN22[$cpt]['file']='';
                $_SESSION['menu_n2'] = $cpt;
                if($exForm->contributor_ipn != $_SESSION['ipn']) {
                    $tableMenusN22[$cpt++]['rights']=array("read_exchange_form");
                } else {
                    $tableMenusN22[$cpt++]['rights']=array();
                }

            }
 

            $tableMenusN22[$cpt]['name']=$libelle_menu_n2_dashboard_pdf;
            $tableMenusN22[$cpt]['file']='scripts_dashboard/dashboard.php?dashboard_id='.$dashboard_id.'#!/view/' . $dashboard_id . '/documents';
            $tableMenusN22[$cpt]['display']  =true;
            $tableMenusN22[$cpt++]['rights']=array("read_dashboard");
            
    }

  break;
  
	case 'export_dashboard':	
		// directly select the first level 2 menu  
		if ($_SESSION['menu_n2']==-1)
		{
		  $_SESSION['menu_n2']=0;
		} 
		$tableMenusN22[$cpt]['name']=$txt_export_dashboard;
        $tableMenusN22[$cpt]['file']='scripts_dashboard/export_dashboard.php';
        $tableMenusN22[$cpt]['display']  =true;
        $tableMenusN22[$cpt]['rights']=array("export_dashboard");
		$cpt++;
		
		$tableMenusN22[$cpt]['name']=$txt_store_request;
        $tableMenusN22[$cpt]['file']='scripts_dashboard/store_request_queries.php';
        $tableMenusN22[$cpt]['display']  =true;
        $tableMenusN22[$cpt]['rights']=array("store_request");
		$cpt++;
                
                $tableMenusN22[$cpt]['name']=$txt_export_dashboard;
        $tableMenusN22[$cpt]['file']='scripts_dashboard/tdb_export.php';
        $tableMenusN22[$cpt]['display']  =true;
        $tableMenusN22[$cpt]['rights']=array("export_dashboard");
		$cpt++;
                
                
		break;

}
//fin switch


?>
