<?php
/**
 * Displays the TdB list
 * 
 * PHP version 5
 * 
 * @category Dashboard_Management
 * @package  Dashboard_Scripts
 * @author   Charles Santucci <charles.santucci@renault.com>
 * @license  http://www.php.net/license/3_0.txt  PHP License 3.0
 * @link     http://baselinesvn.mc2.renault.fr:9090/svn/svn61281
*/

$pathRoot='../../';
$pathBase='../';
$use_angular = true;
$angularFiles = array("ng-pagination.js", "angular-filter.js", "clem-filter.js", "ui-bootstrap-tpls.min.js", "angular-vertilize.js");

$dashboard_init = true;
require_once $pathBase.'header.php';

$_SESSION['dashboard_id'] = $_REQUEST['dashboard_id'];
unset($_SESSION['milestone_id']);
/**
switch ($_REQUEST['action']) {
// destruction du TdB
case 'delete_mboard':
    $json = array("success" => 0, "message" => "");
    if(!empty($_REQUEST['dashboard_id'])){
        if($currentUser->canDeleteDashboard($_REQUEST['dashboard_id'])) {
            
            $request = new requete("UPDATE tb_instances SET is_deleted='1', deletion_date ='".todayDashFormatted()."',deletion_user='".$currentUser->ipn."' "
                    . "WHERE instance_id=".$_REQUEST['dashboard_id'], $cnx->num);
            $json = array("success" => 1, "message" => $msg_info_destruction_dashboard);
        } else {
            $json = array("success" => 0, "message" => sprintf($text_delete_tdb_perm, $_REQUEST['dashboard_id']));            
        }
        unset($_SESSION['dashboard_id']);
    }
    header("Content-Type: text/json");
    echo json_encode($json);
    die;
    break;		
}**/


$cond = $currentUser->checkAccess("read_dashboard");
if(!$cond) {
    include_once $pathBase.'common_scripts/authorisation_error.php';
    require_once $pathBase.'footer.php';
    die;
} ?>
<div class="container-fluid clear" style="overflow-x: hidden">
    <div class="row">
        <div class="col-sm-12" ng-view></div>
    </div>
</div>
<script type="text/javascript">
var app = angular.module('agCem', ['ngRoute', 'ngPagination', 'angular.filter','clem.filters','ui.bootstrap','angular.vertilize']);

app.service('notificationService', function($timeout){
    var nt = this;
    nt.messages = [];
    nt.getMessageTypes = function() {
        return ['info', 'danger', 'warning', 'success'];
    }
    nt.clear = function() {
        nt.messages = [];
    }
    nt.set = function(type, msg) {
        nt.messages.push({type: type, message: msg});
        $timeout(function(){
            nt.messages = [];
        }, 5000);
    }
    nt.setError = function(message) {
        nt.set('danger', message);
    }
    nt.setInfo = function(message) {
        nt.set('info', message);
    }
    nt.setWarning = function(message) {
        nt.set('warning', message);
    }
    nt.setSuccess = function(message) {
        nt.set('success', message);
    }
    nt.getMessages = function() {
        return nt.messages;
    }
});

app.component('notification', {
    templateUrl: 'views/common/notification.html',   
    bindings: {
    },
    controllerAs: "ntf",
    transclude: true,
    controller: function(notificationService) {
        var ntf = this;
        ntf.getMessages = function() {
            return notificationService.getMessages();
        }
    }
});

app.service('arcaUserService', function($timeout, $q, $http, $filter){
    var arca = this;
    arca.searchTimeOut = null;
    arca.searchInputTimeOut = null;
    arca.addFavTimeOut = null;
    arca.addFavUsers = [];
    arca.removeFavTimeOut = null;
    arca.removeFavUsers = [];
    arca.savedUsers = [];
    arca.needToSearchIpns = [];
    
    arca.saveUserCache = function(user) {
        if(arca.savedUsers.indexOf(user) < 0) {
            arca.savedUsers.push(user);
        } 
    }
    
    arca.getFavUsers = function() {
        return $http.post('./ajax/arca.php',{action : 'favourite'});
    }
    
    arca.addFavUser = function(ipn) {
        if(arca.addFavUsers.indexOf(ipn) !== -1) {
            var defer = $q.defer();
            $timeout(function(){defer.resolve(ipn);}, 100);
            return defer.promise;
        }
        
        arca.addFavUsers.push(ipn);
        
        if(arca.addFavTimeOut) {
            $timeout.cancel(arca.addFavTimeOut);
        }
        
        arca.addFavTimeOut = $timeout(function(){
            var request = $http.post(
                './ajax/arca.php',
                {action : 'add_favourite', ipns : arca.addFavUsers}
            );
            arca.addFavUsers = [];
            return request;
        }, 600);
        return arca.addFavTimeOut;
    }
    
    arca.removeFavUser = function(ipn) {
        if(arca.removeFavUsers.indexOf(ipn) !== -1) {
            var defer = $q.defer();
            $timeout(function(){defer.resolve(ipn);}, 100);
            return defer.promise;
        }
        
        arca.removeFavUsers.push(ipn);
        
        if(arca.removeFavTimeOut) {
            $timeout.cancel(arca.addFavTimeOut);
        }
        
        arca.removeFavTimeOut = $timeout(function(){
            var request = $http.post(
                './ajax/arca.php',
                {action : 'remove_favourite', ipns : arca.removeFavUsers}
            );
            arca.removeFavUsers = [];
            return request;
        }, 600);
        return arca.removeFavTimeOut;
    }
    
    arca.searchIpn = function(ipn) {
        var user = $filter('filter')(arca.savedUsers, {ipn: ipn});
        if(arca.needToSearchIpns.indexOf(ipn) !== -1 || user.length > 0) {
            var defer = $q.defer();
            $timeout(function(){defer.resolve(ipn);}, 100);
            return defer.promise;
        }
        
        arca.needToSearchIpns.push(ipn);
        
        if(arca.searchTimeOut) {
            $timeout.cancel(arca.searchTimeOut);
        }
        
        arca.searchTimeOut = $timeout(function(){            
            var request = $http.post(
                './ajax/arca.php',
                {ipns : arca.needToSearchIpns}
            ).then(function(res){
                angular.forEach(res.data.arcaUsers, function(user) {
                    if(arca.savedUsers.indexOf(user) < 0) {
                        arca.savedUsers.push(user);
                    }                    
                });
            });
            arca.needToSearchIpns = [];
            return request;
        }, 300);
        return arca.searchTimeOut;
    }
    
    arca.getUserInfo = function(ipn) {
        arca.searchIpn(ipn).then(angular.noop,angular.noop);
        var user = $filter('filter')(arca.savedUsers, {'ipn': ipn});
        if(user.length > 0) {
            var defer = $q.defer();
            defer.resolve(user[0]);
            return defer.promise;
        }
        return $timeout(function(){
            return arca.getUserInfo(ipn);
        }, 1000);
    }
    
    arca.searchInput = function(input) {
        if(arca.searchInputTimeOut) {
            $timeout.cancel(arca.searchInputTimeOut);
        }
        arca.searchInputTimeOut = $timeout(function(){ 
            return $http.post(
                './ajax/arca.php',
                {action: 'search', input : input}
            );
        }, 600)
        return arca.searchInputTimeOut;
    }
});

app.component('arcaDisplay', {
    template: '{{arca.data}}',   
    bindings: {
        ipn : '<',
        prop : '@'        
    },
    controllerAs: "arca",
    transclude: true,
    controller: function(arcaUserService) {
        var arca = this;
        arca.data = '';
        arca.$onInit = function(){
            if(arca.ipn) {
                arca.data = arca.ipn;
                arca.getUserInfo(arca.ipn);
            }
        }
        
        arca.getUserInfo = function(ipn){        
            arcaUserService.getUserInfo(ipn).then(function(res){
                arca.data = res[arca.prop]?res[arca.prop]:'';
            });
        }
        
        arca.$onChanges = function(changes) {
            if(changes.ipn && changes.ipn.currentValue != changes.ipn.previousValue) {
                arca.getUserInfo(changes.ipn.currentValue);
            }
        }
    }
});

app.component('arcaSearchButton', {
    bindings: {
        ipn: '=',
        onSelectIpn: '&',
        
    },
    template: '<button class="btn btn-secondary" ng-click="$ctrl.openArcaSearch()" uib-tooltip="{{\'explication_arca_nom\' | cemTranslate}}">'+
            '<img src="../../images/pictos/arca_search.png" />'+
        '</button>'+
        '<button class="btn btn-secondary" ng-click="$ctrl.onSelectIpn({ipn:\'\'})" ng-if="$ctrl.ipn">'+
            '<img src="../../images/pictos/eraser.png" />'+
        '</button>'+
        '<button type="button" class="btn btn-secondary" ng-click="$ctrl.copyIPN()" ng-if="$ctrl.ipn" uib-tooltip="{{\'text_content_copy\' | cemTranslate}}">'+
            '<img src="../../images/pictos/copy.png" />'+
        '</button>'+
        '<button type="button" class="btn btn-secondary" ng-click="$ctrl.pasteIPN()" ng-if="$ctrl.checkSessionIpn()" '+
                'uib-tooltip="{{\'text_content_paste\' | cemTranslate}}">'+
            '<img src="../../images/pictos/paste.png" />'+
        '</button>',
    controller: function($uibModal) { 
        var $ctrl = this;
        this.checkSessionIpn = function() {
            return sessionStorage.getItem("copied_ipn");
        }
        this.copyIPN = function() {
            sessionStorage.setItem("copied_ipn", this.ipn);
        }
        this.pasteIPN = function() {
            $ctrl.onSelectIpn({ipn: sessionStorage.getItem("copied_ipn")});
        }
        this.openArcaSearch = function(){
            var modalInstance = $uibModal.open({
                animation: false,
                component: 'arcaSearch',
                openedClass: 'arca-search-modal',
                resolve : {
                    ipn : function() {
                        return $ctrl.ipn;
                    }
                }
            });

            modalInstance.result.then(function (selectedUser) {
               $ctrl.onSelectIpn({ipn: selectedUser.ipn});
            }, function() {
                
            });
        }
    }
});

app.directive('autoFocus', function($timeout) {
  return function(scope, element, attrs) {
    scope.$watch(attrs.autoFocus, 
      function (newValue) { 
        $timeout(function() {
            newValue && element.focus();
        });
      },true);
  };    
});

app.component('arcaSearch', {
    templateUrl: 'views/common/arca_search.html',   
    bindings: {
        resolve: '<',
        close: '&',
        dismiss: '&'
    },
    controllerAs: "arca",
    transclude: true,
    controller: function(arcaUserService) {
        var arca = this;  
        arca.selectedIpn = '';
        arca.users = [];
        arca.searching = false;
        arca.favUsers = [];
        arca.$onInit = function() {
            arcaUserService.getFavUsers().then(function(res){
                arca.favUsers = res.data.favUsers;
            });            
            arca.input = "";
            arca.selectedIpn = arca.resolve.ipn;
        }
        
        arca.inFavUsers = function(ipn) {
            return arca.favUsers.indexOf(ipn) !== -1;
        }
        
        arca.addFavUser = function(ipn) {
            arca.favUsers.push(ipn);
            arcaUserService.addFavUser(ipn).then(function(res){
                if(res && res.favUsers) {
                    arca.favUsers = res.favUsers;
                }
            },angular.noop);
        }
        
        arca.removeFavUser = function(ipn) {
            var i = arca.favUsers.indexOf(ipn);
            if(i >= 0) {
                arca.favUsers.splice(i, 1);
            }
            arcaUserService.removeFavUser(ipn).then(function(res){
                if(res && res.favUsers) {
                    arca.favUsers = res.favUsers;
                }
            },angular.noop);
        }
        
        arca.search = function() {
            arca.searching = true;
            arcaUserService.searchInput(arca.input).then(function(res){
                arca.users = res.data.arcaUsers;
                arca.searching = false;
            },angular.noop);
        }
        
        arca.selectIPN = function(user) {
            if(typeof user == 'string') {
                arca.selectedIpn = user;
                arcaUserService.getUserInfo(user).then(function(user){
                    arca.close({$value: user});
                    arca.dismiss({$value: 'done'});
                });
            } else {
                arca.selectedIpn = user.ipn;
                arcaUserService.saveUserCache(user);
                arca.close({$value: user});
                arca.dismiss({$value: 'done'});
            }            
        }
        
        arca.close = function() {
            arca.dismiss({$value: 'cancel'});
        }
    }
});

app.service('languageService', function($http, $sce){
    var ls = this;
    ls.lang = 'fr';
    ls.languages = {};
    ls.setLang = function(lang) {
        ls.lang = lang;
    }
    ls.set = function(key, value) {
        ls.languages[key] = value;
    }
    ls.get = function(key, args) {        
        if(!args) {
            args = [];
        }
        if(!ls.languages[key]) {
            return key;
        }
        var rt = ls.languages[key];
        for(i=0;i<args.length;i++) {
            rt = rt[args[i]]?rt[args[i]]:rt;
        }        
        rt = $sce.trustAsHtml(rt);
        return rt;
    }
    ls.putlanguages = function(languages) {
        $http.post(
            '<?php echo $pathBase . '/xmlhttprequest/ajax_get_languages.php' ?>',
            {languages : languages, lang : ls.lang}
        ).then(function(res){
            angular.extend(ls.languages, res.data);
        });
    }
    ls.sprintf = function() {
        var args = arguments,
        string = args[0],
        i = 1;
        return string.replace(/%((%)|s|d)/g, function (m) {
            // m is the matched format, e.g. %s, %d
            var val = null;
            if (m[2]) {
                val = m[2];
            } else {
                val = args[i];
                // A switch statement so that the formatter can be extended. Default is %s
                switch (m) {
                    case '%d':
                        val = parseFloat(val);
                        if (isNaN(val)) {
                            val = 0;
                        }
                        break;
                }
                i++;
            }
            return val;
        });
    }
});

app.filter('currentLanguage', function(languageService) {
    return function(string, args) {
        return languageService.lang;
    }
});

app.filter('cemTranslate', function(languageService) {
    return function(string, args) {
        return languageService.get(string, args);
    }
});

app.filter('cemTranslateLang', function(languageService) {
    return function(obj, key) {
        if(obj && obj[key + '_' + languageService.lang]) {
            return obj[key + '_' + languageService.lang];
        }
        if(obj && obj[key]) {
            return obj[key];
        }
        return obj;
    }
});

app.filter('isEmptyObject', function () {
    var bar;
    return function (obj) {
        for (bar in obj) {
            if (obj.hasOwnProperty(bar)) {
                return false;
            }
        }
        return true;
    };
});

app.filter('notInArray', function($filter) {
    return function(list, arrayFilter) {
        if(arrayFilter.length > 0) {
            return $filter("filter")(list, function(listItem) {
                return arrayFilter.indexOf(listItem) == -1;
            });
        } else {
            return list;
        }
    };
});

app.filter('dateFormet', function($filter) {
    return function(date, format) {
        var tmp = new Date(date.replace(/-/g,"/"));
        if(tmp) {
            return $filter('date')(tmp, format);
        } else {
            return date;
        }
    };
});

app.filter('intersect', function(){
    return function(arr1, arr2){
        return arr1.filter(function(n) {
            return arr2.indexOf(n) != -1
        });
    };
});

app.component('multiselect', {
    templateUrl: '../../js/angular/components/multiselect/template.html',   
    bindings: {
        leftitems: '=',
        rightitems: '=',
        model: '=',
        size: '@',
        optionid: '@',
        optionvalue: '@',
        optiongroup: '@',
    },
    controllerAs: "vm",
    controller: function(){
        var vm = this;
        vm.boxStyle = {};        
        vm.rightitems = [];
        
        vm.$onInit = function(){
            if(!vm.size) {
                vm.size = 18;
            }
            if(vm.size > 15) {
                vm.boxStyle = {'margin-top':'110px'};
            }
        }
        
        vm.moveRight = function($event){
            if(typeof $event != 'undefined' && $event.type == 'dblclick' && $event.target.nodeName.toLowerCase() == 'optgroup') {
                //vm.sfamilies = $filter('filter')(vm.families, vm.pjtFilter, function(families){});
            }          
            for (var i = 0; i < vm.leftBox.length; i++) {
                vm.rightitems.push(vm.leftBox[i]);
            }
            vm.model = vm.rightitems;
            vm.leftBox = [];
        }
        
        vm.moveLeft = function($event){
            if(typeof $event != 'undefined' && $event.type == 'dblclick' && $event.target.nodeName.toLowerCase() == 'optgroup') {
                //vm.sfamilies = $filter('filter')(vm.families, vm.pjtFilter, function(families){});
            }
            for (var i = 0; i < vm.rightBox.length; i++) {
                var removeIndex = vm.rightitems.map(function(item) { return item[vm.optionid]; })
                           .indexOf(vm.rightBox[i][vm.optionid]);
                if(removeIndex == -1) {
                    continue;
                }
                vm.rightitems.splice(removeIndex, 1);
            }
            vm.model = vm.rightitems;
            vm.rightBox = [];
        }
        vm.moveRightAll = function() {
            vm.rightitems = [];
            for (var i = 0; i < vm.leftitems.length; i++) {
                vm.rightitems.push(vm.leftitems[i]);
            }
            vm.model = vm.rightitems;
            vm.leftBox = [];
            vm.rightBox = [];
            vm.leftFilter = '';
            vm.rightFilter = '';
        }
        vm.moveLeftAll = function() {
            vm.rightitems = [];
            vm.leftBox = [];
            vm.rightBox = [];
            vm.leftFilter = '';
            vm.rightFilter = '';
            vm.model = vm.rightitems;
        }
    }
});

app.service('aclService', function($http, $q, $timeout, $filter){
    var acl = this;
    acl.userAccess = null;
    acl.dashboardOwned = null;
    acl.getUserAccess = function(force) {
        if(force || !acl.userAccess) {
            return $http.post('./ajax/acl.php', {action : 'get_user_access'}).then(function(res){
                acl.userAccess = res.data.userAccess;
                return acl.userAccess;
            });
        } else {
            return $timeout(function(){
                return acl.userAccess;
            }, 1);
        }
    };
    
    acl.getOwnedDashboards = function(force) {
        if(force || !acl.dashboardOwned) {
            return $http.post('./ajax/acl.php', {action : 'get_owned_dashboards'}).then(function(res){
                acl.dashboardOwned = res.data.dashboardOwned;
                return acl.dashboardOwned;
            });
        } else {
            return $timeout(function(){
                return acl.dashboardOwned;
            }, 1);
        }
    };
    
    acl.checkAccess = function(keyword, params) {
        return acl.getUserAccess().then(function(userAccess){
            if(!userAccess[keyword]) {
                return false;
            }
            if(typeof params == 'undefined') {
                params = [];
            }
            var access_info = userAccess[keyword]; 
            if(params.length == 0) {
                return (access_info)?true:false;
            }
            var accessParams = ["dashboard", "repository", "user_profiles"];
            var anyOneTrue = false;
            angular.forEach(accessParams, function(accessParam){
                if(params[accessParam] && access_info[accessParam]) {
                    if(!angular.isArray(params[accessParam])) {
                        var tmp = [];
                        tmp.push(params[accessParam]);
                        params[accessParam] = tmp;
                    }

                    var types = [];
                    angular.forEach(access_info[accessParam], function(v, key){
                        types.push(key);
                    });
                    access_types = $filter('intersect')(types, params[accessParam]);
                    if(access_types.length > 0) {
                        anyOneTrue = true;
                    }
                }
            });
            return anyOneTrue;
        });
    }
    
    acl.canAccessAll = function(param, keyword, universe_id, accessParams) {
        if(!param || !keyword || !universe_id) {
            return $timeout(function(){return false;}, 1);
        }
        
        if(accessParams && accessParams.indexOf("A") !== -1) {
            return $timeout(function(){return false;}, 1);
        }
        
        var tmp_all_param = [];
        tmp_all_param[param] = ['A'];
        var accessUniverse = acl.getAccessUniverse(keyword, tmp_all_param);
        if(accessUniverse.indexOf('all') === -1 && accessUniverse.indexOf(universe_id) === -1) {
            return $timeout(function(){return false;}, 1);
        }
        
        return acl.checkAccess(keyword, tmp_all_param).then(function(cond){
            return cond;
        });
    }
    
    acl.canAccessDashboard = function(keyword, instance_id, universe_id, accessParams) {
        if(!accessParams) {
            accessParams = ["A", "O", "D", "DR", "C3", "C2"];
        }
        var param = "dashboard";
        return acl.canAccessAll(param, keyword, universe_id, accessParams).then(function(cond){
            if(cond) {
                return true;
            }
            
            var allPermssion = accessParams.indexOf("A");
            if(allPermssion !== -1) {
                accessParams.splice(allPermssion, 1);
            }
            
            if(accessParams.length <= 0) {
                return false;
            }
            
            return acl.getOwnedDashboards().then(function(dashboardOwned){
                var ownedDashboards = $filter('filter')(dashboardOwned, {instance_id : instance_id});
                if(ownedDashboards.length <= 0) {
                    return false;
                }

                var promises = [];
                angular.forEach(ownedDashboards, function(ownedDashboard) {
                    cond = accessParams.indexOf(ownedDashboard.type) !== -1;                    
                    if(cond) {
                        var tmp_param = [];
                        tmp_param[param] = [ownedDashboard.type];
                        promises.push(acl.checkAccess(keyword, tmp_param));
                    }
                });
                if(promises.length > 0) {
                    return $q.all(promises).then(function(datas){
                        var anyOneTrue = false;
                        angular.forEach(datas, function(data){
                           if(data) {
                                anyOneTrue = true;
                            }
                        });  
                        return anyOneTrue;
                    });
                } else {
                    return false;
                }
            });
        });
    }
    
    acl.getAccessUniverse = function(keyword, params) {
        if(!acl.userAccess[keyword]) {
            return false;
        }
        var access_info = acl.userAccess[keyword];
        var return_universe = [];
        if(!params) {
            return_universe = access_info.universe;
            if(return_universe.indexOf(0) !== -1 || return_universe.indexOf("0") !== -1) {
                return ['all'];
            }
            return return_universe;
        }
        
        angular.forEach(["dashboard", "repository", "user_profiles"], function(accessParam) {
            if(params && params[accessParam]) {
                if(!angular.isArray(params[accessParam])) {
                    var tmp = [];
                    tmp.push(params[accessParam]);
                    params[accessParam] = tmp;
                }
                angular.forEach(params[accessParam], function(owner_type) {
                    if(access_info[accessParam] && access_info[accessParam][owner_type]) {
                        var oType = access_info[accessParam][owner_type];
                        if(oType == 0) {
                            return ['all'];
                        }
                        if(return_universe.indexOf(oType) < 0) {
                            return_universe.push(oType);
                        }
                    }
                });            
            }
        });
        
        return return_universe;
    }
});

app.service('dashboardService', function($http, $filter, $sce, $timeout){
    var tdb = this;
    tdb.dashboard = {};
    tdb.getDashboards = function() {
        return $http.post('./ajax/dashboard/list.php',{type : 'all'});
    }
    tdb.getDashboard = function(dashboard_id, ajax) {
        if(!dashboard_id) {
            return {};
        }
        if(ajax == 1 || $filter('isEmptyObject')(tdb.dashboard)) {
            return $http.post('./ajax/dashboard/view.php', {dashboard_id : dashboard_id}).then(function(res){
                tdb.dashboard = res.data.dashboard;
                tdb.dashboard.first_milestone_set = false;
                tdb.dashboard.status = "NEW";
                tdb.dashboard.currentMileStone = null;
                
                tdb.dashboard.milestones = $filter('orderBy')(tdb.dashboard.milestones, tdb.milestoneOrder);
                angular.forEach(tdb.dashboard.milestones, function(milestone){
                    var mlTopics = $filter('filter')(res.data.AllTopics, {repository_milestone_id : milestone.repository_milestone_id});
                    mlTopics = $filter('orderBy')(mlTopics, tdb.topicOrder);
                                        
                    var mlActivities = $filter('filter')(res.data.allActivities, {repository_milestone_id : milestone.repository_milestone_id});
                    mlActivities = $filter('orderBy')(mlActivities, tdb.activityOrder);                    
                    milestone.activities = mlActivities;
                    angular.forEach(mlTopics, function(topic, k){
                        topic.activities = $filter('filter')(mlActivities, {repository_result_id : topic.repository_result_id});
                    });
                    
                    milestone.topics = mlTopics;
                    
                    if(milestone.milestone_status == 'EC' || milestone.milestone_status == 'CLO') {
                        tdb.dashboard.first_milestone_set = true;
                    }
                    
                    milestone.showActivities = 0;
                    var milestone_title_en = (milestone.milestone_title_en)?(milestone.milestone_title_en):'-';
                    var milestone_definition_en = (milestone.milestone_definition_en)?(milestone.milestone_definition_en):'-';
                    var milestone_aer_reference = (milestone.milestone_aer_reference)?(milestone.milestone_aer_reference):'-';
                    var milestone_rpif_reference = (milestone.milestone_rpif_reference)?(milestone.milestone_rpif_reference):'-';
                    var popoverHtml = '<b>'+$filter('cemTranslate')('text_std_milestone')+'</b> : '                    
                            + milestone_title_en + "<br/>"
                            +'<b>'+$filter('cemTranslate')('text_definition')+'</b> : '
                            + (milestone_definition_en) + "<br/>"
                            +'<b>'+$filter('cemTranslate')('text_overall_result')+'</b> : '
                            + (milestone_aer_reference) + "<br/>"
                            +'<b>'+$filter('cemTranslate')('text_RPIF')+'</b> : '
                            + (milestone_rpif_reference);
                    milestone.htmlPopover = $sce.trustAsHtml(popoverHtml);
                    
                    if(!tdb.dashboard.currentMileStone) {
                        tdb.dashboard.currentMileStone = milestone.repository_milestone_id;
                    }
                    
                    if(milestone.milestone_status == 'CLO' && tdb.dashboard.status == 'NEW') {
                        tdb.dashboard.status = "CLO";
                    }
                    
                    if(milestone.milestone_status == 'EC' && tdb.dashboard.status != 'EC') {
                        tdb.dashboard.status = "EC";
                        tdb.dashboard.currentMileStone = milestone.repository_milestone_id;
                    }
                });
                
                tdb.dashboard.selectedMilestone = tdb.dashboard.currentMileStone;
                return tdb.dashboard;
            });
        } else {
            return $timeout(function(){return tdb.dashboard}, 100);
        }
    }
        
    tdb.setSelectedMilestone = function(milestoneId) {
        tdb.dashboard.selectedMilestone = milestoneId;
    }
            
    tdb.milestoneOrder = function(milestone) {
        return parseInt(milestone.milestone_order);
    }
    tdb.topicOrder = function(topic) {
        return parseInt(topic.result_order);
    }
    tdb.activityOrder = function(activity) {
        return parseInt(activity.activity_order);
    }
    
    tdb.getAllPjtContexts = function() {
        return $http.post('./ajax/dashboard/contexts.php', 
                    {dashboard_id : tdb.dashboard.dashboard_id});
    }
    
    tdb.getDashboardOwners = function() {
        return $http.post('./ajax/dashboard/features.php', 
                    {action: 'delegates', dashboard_id : tdb.dashboard.dashboard_id});
    }
    tdb.deleteDashboardOwner = function(ipn, type) {
        return $http.post('./ajax/dashboard/features.php', 
                    {action: 'delete_delegate', dashboard_id : tdb.dashboard.dashboard_id, ipn: ipn, type: type});
    }
    tdb.saveDashboardOwner = function(ipn, type) {
        return $http.post('./ajax/dashboard/features.php', 
                    {action: 'save_owner', dashboard_id : tdb.dashboard.dashboard_id, ipn: ipn, type: type});
    }
    tdb.saveDelegate = function(ipn, type) {
        return $http.post('./ajax/dashboard/features.php', 
                    {action: 'save_delegate', dashboard_id : tdb.dashboard.dashboard_id, ipn: ipn, type: type});
    }
    
    tdb.getDashboardProjects = function() {
        return $http.post('./ajax/dashboard/features.php', 
                    {action: 'projects', dashboard_id : tdb.dashboard.dashboard_id});
    }
    tdb.getRepostoryAllProjects = function() {
        return $http.post('./ajax/dashboard/features.php', 
                    {action: 'rep_projects', dashboard_id : tdb.dashboard.dashboard_id, repository_id : tdb.dashboard.repository_id});
    }
    tdb.saveDashboardProjects = function(pjts) {
        return $http.post('./ajax/dashboard/features.php', 
                    {action : 'save_projects', dashboard_id : tdb.dashboard.dashboard_id, projects: pjts});
    }
        
    tdb.getDashboardFamilies = function() {
        return $http.post('./ajax/dashboard/features.php', 
                    {action: 'families', dashboard_id : tdb.dashboard.dashboard_id});
    }
    tdb.getRepostoryAllFamilies = function() {
        return $http.post('./ajax/dashboard/features.php', 
                    {action: 'rep_families', dashboard_id : tdb.dashboard.dashboard_id, repository_id : tdb.dashboard.repository_id});
    }
    tdb.saveDashboardFamilies = function(families) {
        return $http.post('./ajax/dashboard/features.php', 
                    {action : 'save_families', dashboard_id : tdb.dashboard.dashboard_id, families: families});
    }
    
    tdb.savePjtContexts = function(pjt_contexts) {
        return $http.post('./ajax/dashboard/contexts.php', 
                    {action : 'save', dashboard_id : tdb.dashboard.dashboard_id, pjt_contexts: pjt_contexts});
    }
    
    tdb.setFirstMilestone = function(milestoneId) {
        return $http.post('./ajax/dashboard/actions.php', 
                    {action : 'setFirstMilestone', dashboard_id : tdb.dashboard.dashboard_id, milestone_id : milestoneId});
    }
    tdb.removeMilestone = function(milestoneId) {
        return $http.post('./ajax/dashboard/actions.php', 
                    {action : 'removeMilestone', dashboard_id : tdb.dashboard.dashboard_id, milestone_id : milestoneId});
    }
    
    tdb.getMilestoneDates = function() {
        return $http.post('./ajax/dashboard/features.php', 
                    {action: 'miledates', dashboard_id : tdb.dashboard.dashboard_id});
    }
    
    tdb.saveMilestoneDates = function(mileDates) {
        return $http.post('./ajax/dashboard/features.php', 
                    {action: 'save_miledates', dashboard_id : tdb.dashboard.dashboard_id, mile_dates : mileDates});
    }
    
    tdb.getDashboardDocuments = function() {
        return $http.post('./ajax/dashboard/features.php', 
                    {action : 'documents', dashboard_id : tdb.dashboard.dashboard_id});
    }
    
    tdb.getDashboardAssignments = function(milestone_id) {
        return $http.post('./ajax/dashboard/features.php', 
                    {action : 'assignments', dashboard_id : tdb.dashboard.dashboard_id, milestone_id : milestone_id});
    }
    
    tdb.saveAssignments = function(assignments, milestone_id) {
        return $http.post('./ajax/dashboard/features.php', 
                    {action: 'save_assignments', dashboard_id : tdb.dashboard.dashboard_id, milestone_id : milestone_id, assignments : assignments});
    }
    
    tdb.copyAssignments = function(assignments, milestone_id, next_milestone_id) {
        return $http.post('./ajax/dashboard/features.php', {
            action: 'copy_assignments', 
            dashboard_id : tdb.dashboard.dashboard_id, 
            milestone_id : milestone_id, 
            next_milestone_id : next_milestone_id, 
            assignments : assignments
        });
    }
    
    tdb.sendExchangeForm = function(assignment, milestone_id, contributor) {
        return $http.post('./dashboard_assignments.php', {
            action: 'create_exchange_form', 
            dashboard_id : tdb.dashboard.dashboard_id, 
            milestone_id : milestone_id,
            role_id : assignment.role_id,
            arca_id : assignment.assignment_user,
            contributor : contributor
        });
    }
    
    tdb.getExchangeForms = function() {
        return $http.post('./ajax/dashboard/features.php', 
                    {action : 'exchange_forms', dashboard_id : tdb.dashboard.dashboard_id});
    }
    
    tdb.cancelExchangeForm = function(exchange_form_id) {
        return $http.post('./ajax/dashboard/exchange_form.php', 
                    {action : 'cancel_exg_form', dashboard_id : tdb.dashboard.dashboard_id, exchange_form_id : exchange_form_id});
    }
    
    tdb.recievedByMailExgForm = function(exchange_form_id) {
        return $http.post('./ajax/dashboard/exchange_form.php', 
                    {action : 'received_by_mail', dashboard_id : tdb.dashboard.dashboard_id, exchange_form_id : exchange_form_id});
    }
});

app.config(function($routeProvider) {
    $routeProvider.when('/', {
        template : '<dashboard-list></dashboard-list>'        
    }).when('/view/:id', {
        template : '<dashboard-view dashboard="$resolve.dashboard"></dashboard-view>',
        resolve : {
            dashboard: function($route, dashboardService) {
                return dashboardService.getDashboard($route.current.params.id, false);
            }
        }
    }).when('/view/:id/milestone/:mId', {
        template : '<dashboard-ml-view dashboard="$resolve.dashboard"></dashboard-ml--view>',
        resolve : {
            dashboard: function($route, dashboardService) {
                return dashboardService.getDashboard($route.current.params.id, false);
            }
        }
    }).when('/view/:id/context', {
        template : '<dashboard-contexts dashboard="$resolve.dashboard"></dashboard-contexts>',
        resolve : {
            dashboard: function($route, dashboardService) {
                return dashboardService.getDashboard($route.current.params.id, false);
            }
        }
    }).when('/view/:id/features', {
        template : '<dashboard-features dashboard="$resolve.dashboard"></dashboard-features>',
        resolve : {
            dashboard: function($route, dashboardService) {
                return dashboardService.getDashboard($route.current.params.id, false);
            }
        }
    }).when('/view/:id/projects', {
        template : '<dashboard-projects dashboard="$resolve.dashboard"></dashboard-projects>',
        resolve : {
            dashboard: function($route, dashboardService) {
                return dashboardService.getDashboard($route.current.params.id, false);
            }
        }
    }).when('/view/:id/families', {
        template : '<dashboard-families dashboard="$resolve.dashboard"></dashboard-families>',
        resolve : {
            dashboard: function($route, dashboardService) {
                return dashboardService.getDashboard($route.current.params.id, false);
            }
        }
    }).when('/view/:id/documents', {
        template : '<dashboard-documents dashboard="$resolve.dashboard"></dashboard-documents>',
        resolve : {
            dashboard: function($route, dashboardService) {
                return dashboardService.getDashboard($route.current.params.id, false);
            }
        }
    }).when('/view/:id/miledates', {
        template : '<dashboard-mile-dates dashboard="$resolve.dashboard"></dashboard-mile-dates>',
        resolve : {
            dashboard: function($route, dashboardService) {
                return dashboardService.getDashboard($route.current.params.id, false);
            }
        }
    }).when('/view/:id/assignments', {
        template : '<dashboard-assignments dashboard="$resolve.dashboard"></dashboard-assignments>',
        resolve : {
            dashboard: function($route, dashboardService) {
                return dashboardService.getDashboard($route.current.params.id, false);
            }
        }
    }).when('/view/:id/exchange_forms', {
        template : '<exchange-forms-list dashboard="$resolve.dashboard"></exchange-forms-list>',
        resolve : {
            dashboard: function($route, dashboardService) {
                return dashboardService.getDashboard($route.current.params.id, false);
            }
        }
    }).when('/view/:id/exchange_forms/view/:exgId', {
        template : '<exchange-form-view dashboard="$resolve.dashboard"></exchange-form-view>',
        resolve : {
            dashboard: function($route, dashboardService) {
                return dashboardService.getDashboard($route.current.params.id, false);
            }
        }
    }).when('/view/:id/exchange_forms/send_mail/:exgId', {
        template : '<exchange-send-mail-form dashboard="$resolve.dashboard"></exchange-send-mail-form>',
        resolve : {
            dashboard: function($route, dashboardService) {
                return dashboardService.getDashboard($route.current.params.id, false);
            }
        }
    });
    // use the HTML5 History API
    //$locationProvider.html5Mode(true);
}).run(function(languageService){
    languageService.setLang('<?php echo $_SESSION['language']; ?>');
    languageService.putlanguages(['dashboard_list', 'dashboard_data', 'dashboard_view', 'dashboard_monitoring', 'dashboard_progress_review',
                                      'dashboard_features', 'dashboard_assignments']);
});

app.component('exchangeSendMailForm', {
    bindings : {
        dashboard : '='
    },
    templateUrl: 'views/dashboard/exchange_send_mailform.html',
    controllerAs: 'tdbExg',
    controller: function(dashboardService) {
        var tdbExg = this;
        tdbExg.filter = {};
        tdbExg.exact_filter = {};
        tdbExg.$onInit = function() {
            tdbExg.exchange_forms = [];
            tdbExg.selectedMilestone = tdbExg.dashboard.milestones[0].repository_milestone_id;
            dashboardService.getExchangeForms().then(function(res){
                tdbExg.exchange_forms = res.data.exchange_forms;
            });
            tdbExg.setExactFilter('repository_milestone_id_fk', tdbExg.selectedMilestone);
        }   
        
        tdbExg.setFilter = function(key, value) {
            tdbExg.filter[key] = value;
        }   
        
        tdbExg.setExactFilter = function(key, value) {
            tdbExg.exact_filter[key] = value;
        }
    }
});

app.component('exchangeFormView', {
    bindings : {
        dashboard : '='
    },
    templateUrl: 'views/dashboard/exchange_form_view.html',
    controllerAs: 'tdbExg',
    controller: function(dashboardService) {
        var tdbExg = this;
        tdbExg.filter = {};
        tdbExg.exact_filter = {};
        tdbExg.$onInit = function() {
            tdbExg.exchange_forms = [];
            tdbExg.selectedMilestone = tdbExg.dashboard.milestones[0].repository_milestone_id;
            dashboardService.getExchangeForms().then(function(res){
                tdbExg.exchange_forms = res.data.exchange_forms;
            });
            tdbExg.setExactFilter('repository_milestone_id_fk', tdbExg.selectedMilestone);
        }   
        
        tdbExg.setFilter = function(key, value) {
            tdbExg.filter[key] = value;
        }   
        
        tdbExg.setExactFilter = function(key, value) {
            tdbExg.exact_filter[key] = value;
        }
    }
});

app.component('exchangeFormsList', {
    bindings : {
        dashboard : '='
    },
    templateUrl: 'views/dashboard/exchange_form_list.html',
    controllerAs: 'tdbExg',
    controller: function(dashboardService, aclService) {
        var tdbExg = this;        
        tdbExg.filter = {};
        tdbExg.exact_filter = {};
        tdbExg.$onInit = function() {
            tdbExg.exchange_forms = [];
            tdbExg.selectedMilestone = tdbExg.dashboard.selectedMilestone;
            dashboardService.getExchangeForms().then(function(res){
                tdbExg.exchange_forms = res.data.exchange_forms;
            });
            tdbExg.setExactFilter('repository_milestone_id_fk', tdbExg.selectedMilestone);
            
            tdbExg.canValidateDashboard = false;
            aclService.canAccessDashboard("validate_exchange_form", tdbExg.dashboard.dashboard_id, tdbExg.dashboard.universe_id).then(function(cond){
                tdbExg.canValidateDashboard = cond;
            });            
        }   
        
        tdbExg.mileStoneChange = function() {
            dashboardService.setSelectedMilestone(tdbExg.selectedMilestone);
            tdbExg.setExactFilter('repository_milestone_id_fk', tdbExg.selectedMilestone);
        }
        
        tdbExg.canValidate = function(exchange_form) {
            return exchange_form.status == 4 && tdbExg.canValidateDashboard;
        }
        
        tdbExg.cancelExchangeForm = function(exchange_form) {
            dashboardService.cancelExchangeForm(exchange_form.exchange_form_id).then(function(res){
                if(res.data.success) {
                    exchange_form.status = 8;
                }
            });
        }
        
        tdbExg.recievedByMailExgForm = function(exchange_form) {
            dashboardService.recievedByMailExgForm(exchange_form.exchange_form_id).then(function(res){
                if(res.data.success) {
                    exchange_form.status = 7;
                }
            });
        }
        
        tdbExg.setFilter = function(key, value) {
            tdbExg.filter[key] = value;
        }   
        
        tdbExg.setExactFilter = function(key, value) {
            tdbExg.exact_filter[key] = value;
        }
    }
});

app.component('dashboardAssignments', {
    bindings : {
        dashboard : '='
    },
    templateUrl: 'views/dashboard/assignments.html',
    controllerAs: 'tdbAsm',
    controller: function($filter, $uibModal, dashboardService, languageService) {
        var tdbAsm = this;
        tdbAsm.$onInit = function() {
            tdbAsm.assignments = [];
            tdbAsm.selectedMilestone = tdbAsm.dashboard.selectedMilestone;
            tdbAsm.nextMilestone = tdbAsm.getNextMilestone();
            tdbAsm.loadRoleAssignments();
            tdbAsm.contributorRoles = languageService.languages['contributorRole'];
        }
        
        tdbAsm.loadRoleAssignments = function() {
            tdbAsm.assignments = [];
            dashboardService.setSelectedMilestone(tdbAsm.selectedMilestone);
            dashboardService.getDashboardAssignments(tdbAsm.selectedMilestone).then(function(res){                
                angular.forEach($filter('groupBy')(res.data.assignments, 'role_id'), function(assignments){
                    var assignment = assignments[0];
                    assignment.showExchangeFormIcon = tdbAsm.showExchangeFormIcon(assignment);                    
                    tdbAsm.assignments.push(assignment);
                });
            });
        }
        
        tdbAsm.changeAssignmentUser = function(assignment, ipn) {
            assignment.assignment_user = ipn;
            assignment.showExchangeFormIcon = tdbAsm.showExchangeFormIcon(assignment);
        }
        
        tdbAsm.showExchangeFormIcon = function(assignment) {
            if(!assignment.assignment_user) return false;
            var types = ['O', 'D', 'DR'];
            var owners =  $filter('filter')(tdbAsm.dashboard.owners, function(listItem){
                return listItem.stakeholder_ipn == assignment.assignment_user && types.indexOf(listItem.type) !== -1;
            });
            return owners.length == 0;
        }
        
        tdbAsm.saveAssignments = function() {
            dashboardService.saveAssignments(tdbAsm.assignments, tdbAsm.selectedMilestone).then(function(){});
        }
        
        tdbAsm.getNextMilestone = function() {
            var selectedIndex = -1;
            angular.forEach(tdbAsm.dashboard.milestones, function(milestone, index){
                if(tdbAsm.selectedMilestone == milestone.repository_milestone_id) {
                    selectedIndex = index;
                }
            });
            var nextMilestone = (tdbAsm.dashboard.milestones[selectedIndex+1])?tdbAsm.dashboard.milestones[selectedIndex+1]:null;
            return nextMilestone?nextMilestone.repository_milestone_id:false;
        }
        
        tdbAsm.copyAssignments = function() {
            tdbAsm.nextMilestone = tdbAsm.getNextMilestone();
            dashboardService.copyAssignments(tdbAsm.assignments, tdbAsm.selectedMilestone, tdbAsm.nextMilestone).then(function(){});
        }
        
        tdbAsm.openExchangeFormPopup = function(assignment) {
            var resolve = {
                milestone_id : function() {
                    return tdbAsm.selectedMilestone;
                },
                assignment : function() {
                    return assignment;
                },
                contributorRoles : function() {
                    return tdbAsm.contributorRoles;
                }
            };
            
            var modalInstance = $uibModal.open({
                animation: false,
                component: 'contributorPopup',
                resolve : resolve,
                size : 'lg'
            });

            modalInstance.result.then(function(data) {
            }, function() {});
        }
    }
});

app.component('contributorPopup', {
    bindings : {
        resolve: '<',
        close: '&',
        dismiss: '&'
    },
    template: '<div class="row">'+
            '<div class="col-sm-12">'+
                '<div class="card">'+
                '<div class="card-header">'+
                    '<b>{{"contributor_dialog_title" | cemTranslate}}</b>'+
                '</div>'+
                '<div class="card-block">'+
                    '<div class="btn-group">'+
                        '<button type="button" class="btn hidden-sm-down" '+              
                                'ng-repeat="(type, ctr) in $ctrl.contributorRoles" '+
                                'ng-click="$ctrl.contributorType = type;$ctrl.contributor=ctr;" '+
                                'ng-class="{\'btn-primary\' : $ctrl.contributor == ctr,\'btn-secondary\' : $ctrl.contributor != ctr,}">'+
                                 '{{ctr.name}}'+
                        '</button> '+
                        '<button type="button" class="btn hidden-md-up"  uib-tooltip="{{ctr.name}}" '+
                                'ng-repeat="(type, ctr) in $ctrl.contributorRoles" '+
                                'ng-click="$ctrl.contributorType = type;$ctrl.contributor=ctr;" '+
                                'ng-class="{\'btn-primary\' : $ctrl.contributorType == type,\'btn-secondary\' : $ctrl.contributorType != type,}">'+
                                 '{{type}}'+
                        '</button>'+
                    '</div>'+
                    '<div class="row py-2 mx-0 my-2 bg-faded1 ng-scope" ng-if="$ctrl.contributor">'+
                        '<div class="col-sm-12">'+
                            '{{$ctrl.contributor.info}}'+
                        '</div>'+
                    '</div>'+
                '</div>'+
                '<div class="card-footer">'+
                    '<button class="btn btn-primary" ng-click="$ctrl.sendExchangeForm()" ng-disabled="!$ctrl.contributor || $ctrl.loading">'+
                        '<img src="../../images/pictos/submit.png" />{{\'libelle_oui\' | cemTranslate}}'+
                    '</button>'+
                    '<button class="btn btn-secondary" ng-click="$ctrl.dismiss({$value: \'cancel\'})" ng-disabled="$ctrl.loading">'+
                        '<img src="../../images/pictos/cancel.png" />{{\'libelle_non\' | cemTranslate}}'+
                    '</button>'+
                '</div>'+
            '</div>'+
        '</div>',
    controller: function($filter, $window, dashboardService, notificationService) {
        var $ctrl = this;
        
        $ctrl.$onInit = function() {
            $ctrl.assignment = $ctrl.resolve.assignment;
            $ctrl.milestone_id = $ctrl.resolve.milestone_id;
            $ctrl.contributorRoles = $ctrl.resolve.contributorRoles;
        }
        
        $ctrl.sendExchangeForm = function() {
            $ctrl.loading = true;
            notificationService.clear();
            dashboardService.sendExchangeForm($ctrl.assignment, $ctrl.milestone_id, $ctrl.contributorType).then(function(res){                
                if(res.data.errorMessage) {
                    notificationService.setError($filter('cemTranslate')(res.data.errorMessage));
                } else if(res.data.exchange_form_id) {
                    $window.location = "dashboard_exchange_form.php?&menu_n1=home&menu_n2=6&"
                        + "action=read_send_exgform&sendmail=1&exchange_form_id=" + res.data.exchange_form_id;
                } else {
                }
                $ctrl.dismiss({$value: 'done'}); 
            });            
        }
    }
});
    
app.component('dashboardDocuments', {
    bindings : {
        dashboard : '='
    },
    templateUrl: 'views/dashboard/documents.html',
    controllerAs: 'tdbDoc',
    controller: function(dashboardService) {
        var tdbDoc = this;
        tdbDoc.$onInit = function() {
            tdbDoc.documents = [];
            if(tdbDoc.dashboard.gesper_content) {
                var gesper_content = tdbDoc.dashboard.gesper_content;
                var gesper = {
                    gesper : true,
                    date_creation : tdbDoc.dashboard.date_creation,
                    creator : tdbDoc.dashboard.instance_creator,
                    screenshot_comment : ('GSPER-' + tdbDoc.dashboard.template_name_en + '-' 
                            + tdbDoc.dashboard.typology_name_en + '-' +gesper_content.propo_class),
                    milestone_name_en : "GSPER",
                    milestone_name_fr : "GSPER"
                };
                tdbDoc.documents.push(gesper);
            }
            dashboardService.getDashboardDocuments().then(function(res){
                if(res.data.screenshots) {
                    angular.forEach(res.data.screenshots, function(screenshot){
                        tdbDoc.documents.push(screenshot);
                    });
                }
            });
            console.log(tdbDoc.documents);
        }
    }
})

app.component('dashboardMileDates', {
    bindings : {
        dashboard : '='
    },
    templateUrl: 'views/dashboard/miledates.html',
    controllerAs: 'tdbMD',
    controller: function($location, $filter, dashboardService, notificationService) {
        var tdbMD = this;
        tdbMD.mileDates = [];
        tdbMD.$onInit = function() {
            angular.forEach(tdbMD.dashboard.milestones, function(mile){
                var milestone_date = (mile.milestone_date)?new Date(mile.milestone_date):'';
                tdbMD.mileDates.push({
                    repository_milestone_id : mile.repository_milestone_id,
                    milestone_name_en : mile.milestone_name_en,
                    milestone_name_fr : mile.milestone_name_fr,
                    milestone_date : milestone_date,
                    dateOpened : false
                });
            });
            tdbMD.dateOptions = {
                dateDisabled: false,
                formatYear: 'yy',
                maxDate: new Date(2020, 5, 22),
                minDate: new Date(),
                startingDay: 1
            };
            tdbMD.altInputFormats = ['M!/d!/yyyy'];
        }
        
        tdbMD.openCalender = function(mile) {
            mile.dateOpened = true;
        }
        
        tdbMD.saveMileDates = function() {
            notificationService.clear();
            dashboardService.saveMilestoneDates(tdbMD.mileDates).then(function(){
                angular.forEach(tdbMD.mileDates, function(mileDate){
                    angular.forEach(tdbMD.dashboard.milestones, function(mile, index){
                        if(mileDate.repository_milestone_id == mile.repository_milestone_id) {
                            tdbMD.dashboard.milestones[index].milestone_date = mileDate.milestone_date;
                        }
                    });
                });
                notificationService.setSuccess($filter('cemTranslate')('msg_success_mile'));
                $location.path( "view/" + tdbMD.dashboard.dashboard_id + "/features"  );
            });
        }
    }
})

app.component('dashboardContexts', {
    bindings : {
        dashboard : '='
    },
    templateUrl: 'views/dashboard/contexts.html',
    controllerAs: 'tdbCtx',
    controller: function($filter, $location, dashboardService) {
        var tdbCtx = this;
        tdbCtx.PjtContexts = [];
        
        tdbCtx.$onInit = function() {   
            dashboardService.getAllPjtContexts().then(function(res){
                tdbCtx.PjtContexts = [];
                angular.forEach($filter('groupBy')(res.data.instanceContexts, 'context_item_id'), function(instanceContexts){
                    var context = instanceContexts[0]; 
                    if(context.context_item_type != 'TEXT') {
                        context.context_item_value = [];
                    }
                    angular.forEach(instanceContexts, function(instanceContext){
                        context.repoContexts = $filter('filter')(res.data.repositoryContexts, {context_item_id : instanceContext.context_item_id});
                        angular.forEach(context.repoContexts, function(repoContext){
                            if(repoContext.context_item_value_id == instanceContext.context_item_value_id) {
                                context.context_item_value.push(repoContext);
                            }
                        });
                    });
                    if(context.context_item_type == 'LIST' && context.repoContexts.length) {
                        context.context_item_value = context.context_item_value[0];
                    }
                    tdbCtx.PjtContexts.push(context);                    
                });
            });
        }
        
        tdbCtx.submitForm = function() {
            var pjt_contexts = [];
            for (var i = 0; i < tdbCtx.PjtContexts.length; i++) {
                pjt_contexts[i] = {
                    context_item_id : tdbCtx.PjtContexts[i]['context_item_id'],
                    context_item_value : tdbCtx.PjtContexts[i]['context_item_value'],
                };
            }
            dashboardService.savePjtContexts(pjt_contexts).then(function(){
                $location.path( "view/" + tdbCtx.dashboard.dashboard_id + "/features"  );
            });
        }
        
        tdbCtx.pjtContextOrder = function(pjtContext) {
            if(pjtContext.context_item_type == 'TEXT') return 0;
            else if(pjtContext.context_item_type == 'LIST') return 1;
            else if(pjtContext.context_item_type == 'MULTI') return 2;
            else return 3;
        }
    }
});

app.component('dashboardProjects', {
    bindings : {
        dashboard : '='
    },
    templateUrl: 'views/dashboard/projects.html',
    controllerAs: 'tdbFetPrjs',
    controller: function(dashboardService) {
        var tdbFetPrjs = this;
        tdbFetPrjs.projects = [];
        tdbFetPrjs.addProject = false;
        
        tdbFetPrjs.$onInit = function() {
            dashboardService.getDashboardProjects().then(function(res){
                tdbFetPrjs.projects = res.data.projects;
            });
            dashboardService.getRepostoryAllProjects().then(function(res){
                tdbFetPrjs.repProjects = res.data.repProjects;
            });
        }
        
        tdbFetPrjs.addProjects = function() {
            tdbFetPrjs.addProject = true;
        }
        
        tdbFetPrjs.saveProjects = function() {
            dashboardService.saveDashboardProjects(tdbFetPrjs.projects).then(function(res){
                tdbFetPrjs.dashboard.projects = res.data.projects;
                tdbFetPrjs.goToList();
            });
        }
        
        tdbFetPrjs.goToList = function() {
            tdbFetPrjs.addProject = false;
        }
    }
});

app.component('dashboardFamilies', {
    bindings : {
        dashboard : '='
    },
    templateUrl: 'views/dashboard/families.html',
    controllerAs: 'tdbFetFam',
    controller: function(dashboardService) {
        var tdbFetFam = this;
        tdbFetFam.families = [];
        tdbFetFam.addFamily = false;
        
        tdbFetFam.$onInit = function() {
            dashboardService.getDashboardFamilies().then(function(res){
                tdbFetFam.families = res.data.families;
            });
            dashboardService.getRepostoryAllFamilies().then(function(res){
                tdbFetFam.repFamilies = res.data.repFamilies;
            });
        }
        
        tdbFetFam.addFamilies = function() {
            tdbFetFam.addFamily = true;
        }
        
        tdbFetFam.saveFamilies = function() {
            dashboardService.saveDashboardFamilies(tdbFetFam.families).then(function(res){
                tdbFetFam.dashboard.families = res.data.families;
                tdbFetFam.goToList();
            });
        }
        
        tdbFetFam.goToList = function() {
            tdbFetFam.addFamily = false;
        }
    }
});

app.component('dashboardAddDelegate', {
    bindings : {
        resolve: '<',
        close: '&',
        dismiss: '&'        
    },
    templateUrl: 'views/dashboard/add_delegate_form.html',
    controllerAs: 'tdbAD',
    controller: function($uibModal, $filter, dashboardService, notificationService) {
        var tdbAD = this;
        tdbAD.delegate = {};
        tdbAD.dashboard = {};
        tdbAD.searchTimeOut = null;
        tdbAD.$onInit = function() {
            tdbAD.dashboard = tdbAD.resolve.dashboard;
            tdbAD.openArcaSearch();
        }
        tdbAD.openArcaSearch = function() {
            var modalInstance = $uibModal.open({
                animation: false,
                component: 'arcaSearch',
                openedClass: 'arca-search-modal',
                resolve : {
                    input : function() {
                        return tdbAD.arcaInput;
                    }
                }
            });

            modalInstance.result.then(function (selectedUser) {
                if(selectedUser && selectedUser.ipn) {
                    tdbAD.delegate.user = selectedUser;
                }
            }, function() {
                tdbAD.close();
            });
        }
        
        tdbAD.close = function() {
            tdbAD.dismiss({$value: 'cancel'});
        }
        
        tdbAD.saveDelegate = function() {
            tdbAD.saving = true;
            notificationService.clear();
            dashboardService.saveDelegate(tdbAD.delegate.user.ipn, tdbAD.delegate.type).then(function(res){
                if(res.data.errorMessage) {
                    notificationService.setError($filter('cemTranslate')(res.data.errorMessage));
                } else {
                    notificationService.setSuccess($filter('cemTranslate')('msg_std_stakeholder_added'));
                }
                tdbAD.saving = false;
                tdbAD.close({$value: res.data});
                tdbAD.dismiss({$value: 'saved'});                
            });            
        }
    }
});

app.component('dashboardFeatures', {
    bindings : {
        dashboard : '='
    },
    templateUrl: 'views/dashboard/features.html',
    controllerAs: 'tdbFet',
    controller: function($filter, $uibModal, dashboardService, arcaUserService, notificationService) {
        var tdbFet = this;
        tdbFet.owners = [];
        tdbFet.modify_dashboard = false;
        
        tdbFet.$onInit = function() {
            tdbFet.init();
        }
        
        tdbFet.init = function() {
            dashboardService.getDashboardOwners().then(function(res){
                tdbFet.modify_dashboard = res.data.modify_dashboard;
                tdbFet.initOwners(res.data.owners);
            });
        }
        
        tdbFet.initOwners = function(owners) {
            var types = ['O', 'D', 'DR'];
            tdbFet.owners = $filter('filter')(owners, function(owner){
                return types.indexOf(owner.type) !== -1;
            });
        }
        
        tdbFet.ownerOrder = function(owner) {
            if(owner.type == 'O') return 0;
            else if(owner.type == 'D') return 1;
            else if(owner.type == 'DR') return 2;
            else return 2;
        }
        
        tdbFet.deleteDashboardDelegate = function(owner) {
            arcaUserService.getUserInfo(owner.ipn).then(function(user){
                var messge = $filter('cemTranslate')('msg_std_remove_stakeholder') + (user.nom) + "?";
                if(!confirm(messge)) {
                    return;
                }
                dashboardService.deleteDashboardOwner(owner.ipn, owner.type).then(function() {
                    var index = tdbFet.owners.indexOf(owner);
                    tdbFet.owners.splice(index, 1);
                });
            });
        }
        
        tdbFet.changeDashboardOwner = function() {
            var owner = $filter('filter')(tdbFet.owners, {type: 'O'});
            var resolve = {};
            if(owner) {
                resolve.ipn = function() {return owner[0].ipn;}
            }
            
            var modalInstance = $uibModal.open({
                animation: false,
                component: 'arcaSearch',
                resolve: resolve,
                openedClass: 'arca-search-modal'
            });

            modalInstance.result.then(function (selectedUser) {
                if(!(selectedUser && selectedUser.ipn)) {
                    return;
                }
                notificationService.clear();
                dashboardService.saveDashboardOwner(selectedUser.ipn, 'O').then(function(res) {
                    if(res.data.errorMessage) {
                        notificationService.setError($filter('cemTranslate')(res.data.errorMessage));
                    } else {
                        notificationService.setSuccess($filter('cemTranslate')('msg_std_leader_updated'));
                    }
                    tdbFet.modify_dashboard = res.data.modify_dashboard;
                    tdbFet.initOwners(res.data.owners);
                });
            }, function() {
                
            });
        }
        
        tdbFet.addDashboardDelegate = function() {
            var resolve = {};
            resolve.dashboard = function() {return tdbFet.dashboard;}
            
            var modalInstance = $uibModal.open({
                animation: false,
                component: 'dashboardAddDelegate',
                resolve: resolve
            });

            modalInstance.result.then(function(data) {
                if(data.owners) {
                    tdbFet.modify_dashboard = data.modify_dashboard;
                    tdbFet.initOwners(data.owners);
                }
            }, function() {});
        }
    }
});

app.component('dashboardList', {
    templateUrl: 'views/dashboard/list.html',
    controllerAs: 'tdbList',
    controller: function($window, dashboardService) {
        var tdbList = this;
        tdbList.allDashboards = [];
        
        tdbList.$onInit = function() {
            $window.location.href="dashboard.php?<?php echo $_SERVER['QUERY_STRING']; ?>#!view/<?php echo $_REQUEST['dashboard_id']; ?>";
            /**dashboardService.getDashboards().then(function(res){
                tdbList.allDashboards = res.data.dashboards;
            });**/
        }
    }
});

app.component('dashboardView', {
    bindings : {
        dashboard : '='
    },
    templateUrl: 'views/dashboard/dashboard_view.html',
    controllerAs: 'tdbView',
    controller: function(dashboardService, $window) {
        var tdbView = this;
        tdbView.$onInit = function() {
            tdbView.filterMilestones = [];
        }
        tdbView.showAllActivities = function() {
            angular.forEach(tdbView.dashboard.milestones, function(milestone){
                milestone.showActivities = 1;
            });
        }
        tdbView.hideAllActivities = function() {
            angular.forEach(tdbView.dashboard.milestones, function(milestone){
                milestone.showActivities = 0;
            });
        }
        tdbView.setFirstMilestone = function(mId) {
            dashboardService.setFirstMilestone(mId).then(function(res){
                $window.location.reload();
            });
        }
        tdbView.removeMilestone = function(mId) {
            dashboardService.removeMilestone(mId).then(function(res){
                $window.location.reload();
            });
        }
    }
});

app.component('dashboardMlView', {
    bindings : {
        dashboard : '='
    },
    templateUrl: 'views/dashboard/dashboard_ml_view.html',
    controllerAs: 'mlView',
    controller: function($routeParams, $filter) {
        var mlView = this;
        mlView.$onInit = function() {
            mlView.mlStatus = ['TR', 'ER', 'EC', 'NC', 'NA'];            
            mlView.mId = $routeParams.mId;
            mlView.currentMilestone = $filter('filter')(mlView.dashboard.milestones, {'repository_milestone_id': $routeParams.mId})[0];
        }
    }
});

app.component('dashboardHeader', {
    bindings : {
        dashboard : '<',
        milestone : '<',
        fullDisplay : '@'
    },
    templateUrl: 'views/dashboard/header_info.html',
    controllerAs: 'tdbHeader',
    controller: function() {
        var tdbHeader = this;
        tdbHeader.fullDisplay = 0;
        tdbHeader.$onInit = function() {
        }
    }
});

app.component('dashboardMilestoneList', {
    bindings : {
        dashboard : '<'
    },
    templateUrl: 'views/dashboard/dashboard_milestone_list.html',
    controllerAs: 'tdbMList',
    controller: function() {
    }
});

app.component('colorEvaluation', {
    bindings : {
        dashboard : '<',
        activity : '=',
        readonly: '@'
    },
    templateUrl: 'views/dashboard/color_evaluation.html',
    controllerAs: 'clrEval',
    controller: function() {
        var clrEval = this;
        clrEval.$onInit = function() {
            clrEval.atyStatus = ['TR', 'ER', 'EC', 'NC', 'NA'];            
            clrEval.activity.evaluation = [];
            clrEval.setColorEval('NC');
        }
        clrEval.setColorEval = function(status) {            
            angular.forEach(clrEval.atyStatus, function(st){
                var value = (st == status)?1:0;                
                clrEval.activity.evaluation[st] = value;
            });
        }
    }
});

app.component('activityAssements', {
    bindings : {
        dashboard : '<',
        activity : '=',
        readonly: '@'
    },
    templateUrl: 'views/dashboard/activity_assements.html',
    controllerAs: 'atyAsm',
    controller: function() {
        var atyAsm = this;
        atyAsm.$onInit = function() {
            atyAsm.assements = ['K1', 'K2', 'K3', 'K4'];
        }
    }
});

app.component('activityActionPlan', {
    bindings : {
        dashboard : '<',
        activity : '=',
        readonly: '@'
    },
    templateUrl: 'views/dashboard/activity_action_plan.html',
    controllerAs: 'atyAp',
    controller: function() {
        var atyAp = this;
        atyAp.$onInit = function() {
        }
    }
});

app.component('paginationLinks', {
    bindings : {
        allItems : '<',
        filterItems : '=',
        page : '=',
        pageSize: '@'
    },
    templateUrl: 'views/common/pagination.html',
    controllerAs: 'ptn',
    controller: function(PagerService) {
        var ptn = this;
        ptn.pager = null;
        ptn.page = 1;
        
        ptn.$onInit = function() {            
            
        }
        ptn.$onChanges = function(changes) {
            if(changes.allItems && changes.allItems.currentValue != changes.allItems.previousValue && changes.allItems.currentValue.length > 0) {
                ptn.allItems = changes.allItems.currentValue;
                ptn.setPage(ptn.page);
            }
        }
        ptn.setPage = function(page) {
            ptn.pager = PagerService.GetPager(ptn.allItems.length, page, ptn.pageSize);
            ptn.filterItems = [];
            for(i = ptn.pager.startIndex; i <= ptn.pager.endIndex; i++) {
                ptn.filterItems.push(ptn.allItems[i]);
            }
        }
    }
});

</script>
<?php require_once $pathBase.'footer.php';?>