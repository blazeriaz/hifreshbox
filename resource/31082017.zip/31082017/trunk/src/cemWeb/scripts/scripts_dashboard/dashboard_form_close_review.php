<?php
/**
 * Form used to close a TdB milestone review 
 * 
 * PHP version 5
 * 
 * @category Review
 * @package  Dashboard_Scripts
 * @author   Charles Santucci <charles.santucci@renault.com>
 * @license  http://www.php.net/license/3_0.txt  PHP License 3.0
 * @link     http://baselinesvn.mc2.renault.fr:9090/svn/svn61281
*/
?>

 <form action="<?php echo $targetFile;?>"" method="post" name="form_close_screenshot">
   <input type="hidden" name="action" value="<?php echo $_REQUEST['action'];?>" />
   <input type="hidden" name="close_ok" value="1" />
    <fieldset class="fieldset">    
        
        <label class="label" id="width200" style="float:left;"><?php echo $text_situation;?> : </label>
        <div style="margin:0 0 15px 15px;float:left;">
        <input type="radio" name="screenshot_decision" value="OK" class="screenshot_decision" <?php if ($previous_screenshot_decision=='OK') { echo 'checked="checked"';} ?>/><?php echo $text_milestone_situation_status['OK'];?>
        <input type="radio" name="screenshot_decision" value="OK_PA"  class="screenshot_decision" <?php if ($previous_screenshot_decision=='OK_PA') { echo 'checked="checked"';} ?>/><?php echo $text_milestone_situation_status['OK_PA'];?>
        <input type="radio" name="screenshot_decision" value="KO"  class="screenshot_decision" <?php if ($previous_screenshot_decision=='KO') { echo 'checked="checked"';} ?>/><?php echo $text_milestone_situation_status['KO'];
        // allow eraser only for baseline, not milestone closing
        if ($_REQUEST['action']=='save_review')
        {?> 
        <img src="<?php echo $pathPictures;?>pictos/eraser.png" id="eraseDecision" /><?php
        }?>
        </div><br id="nobr" />
        <label class="label" id="width200" style="padding-right:5px;"><?php echo $text_std_comment_reservations;?> </label> 
        <textarea name="review_comment" cols="80" rows="5" class="legal"><?php echo $previous_screenshot_comment;?></textarea>	  
        <br /><br id="nobr" />
     <br />	  
     <div class="SubmitButtonBlock" style="margin-left:200px;"></label>
     <a href="javascript:document.form_close_screenshot.submit();" class="RnoButton SubmitButton"><?php echo $button_submit;?></a>
     <a href="<?php echo $targetFile;?>" class="RnoButton CancelButton"><?php echo $button_cancel?></a>
     </div>		  		  
  </fieldset>

 </form>