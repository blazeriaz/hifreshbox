<?php
/* Created By Praveen G */

$pathBase = '../';
$pathRoot = '../' . $pathBase;
$pathPictures = $pathRoot . 'images/';
$pathGenPic = $pathBase . 'generation_images/';

require_once $pathBase . 'common_scripts/exchange_form.php';
if(!empty($_REQUEST['exchange_form_id'])){
    $_SESSION['exgformid'] = $_REQUEST['exchange_form_id'];
    $exg_info = getExchangeFormBaseInfo($_REQUEST['exchange_form_id'], $cnx->num);
    $_SESSION['dashboard_id'] = $exg_info->instance_id;
}

$exchange_form_page = true;
require_once $pathBase . 'header.php';
require_once $pathRoot . 'libraries/classes/class_mail.php';
require_once 'dashboard_data.php';

$arca = new arca();
$display_table = true;

$targetFile = 'dashboard_exchange_form.php?';

/* if ipn not set in session mean redirect to home page  */
if (!isset($_SESSION['ipn']) || empty($_SESSION['dashboard_id']) ) {
    header('location: ../index.php');
    exit;
}

$dashboard_header_display = 'short';
$dashboard_header_display_milestone = true;

/* set default action */
if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'default') {
    $_REQUEST['action'] = 'list_exchange_form';
    $new_record = false;
} else {
    $new_record = true;
}
switch ($_REQUEST['action']) {
    case 'validate':
    case 'refuse':
    case 'recieved_by_email':
        if($exg_info->status == 4 || $exg_info->status == 2){
        if (!empty($_REQUEST['exchange_form_id']) && !empty($_REQUEST['action']) &&  $_REQUEST['action'] =='validate') {
          
            $activityId = $_REQUEST['save_activity_id'];
           
            if (!empty($_REQUEST['grid_type']) && ($_REQUEST['grid_type'] == '1' || $_REQUEST['grid_type'] == '2')) {
                $data['activity_comment_' . $activityId] = $_REQUEST['activity_comment_' . $activityId];
                if (!empty($_REQUEST['activity_comment_' . $activityId . '_check'])) {
                    $data['activity_comment_' . $activityId . '_check'] = $_REQUEST['activity_comment_' . $activityId . '_check'];
                }
                $data['status_TR_' . $activityId] = $_REQUEST['status_TR_' . $activityId];
                if (!empty($_REQUEST['status_TR_' . $activityId . '_check'])) {
                    $data['status_TR_' . $activityId . '_check'] = $_REQUEST['status_TR_' . $activityId . '_check'];
                }
                $data['status_EC_' . $activityId] = $_REQUEST['status_EC_' . $activityId];
                if (!empty($_REQUEST['status_EC_' . $activityId . '_check'])) {
                    $data['status_EC_' . $activityId . '_check'] = $_REQUEST['status_EC_' . $activityId . '_check'];
                }
                $data['status_ER_' . $activityId] = $_REQUEST['status_ER_' . $activityId];
                if (!empty($_REQUEST['status_ER_' . $activityId . '_check'])) {
                    $data['status_ER_' . $activityId . '_check'] = $_REQUEST['status_ER_' . $activityId . '_check'];
                }
                $data['status_NC_' . $activityId] = $_REQUEST['status_NC_' . $activityId];
                if (!empty($_REQUEST['status_NC_' . $activityId . '_check'])) {
                    $data['status_NC_' . $activityId . '_check'] = $_REQUEST['status_NC_' . $activityId . '_check'];
                }
                $data['status_NA_' . $activityId] = $_REQUEST['status_NA_' . $activityId];
                if (!empty($_REQUEST['status_NA_' . $activityId . '_check'])) {
                    $data['status_NA_' . $activityId . '_check'] = $_REQUEST['status_NA_' . $activityId . '_check'];
                }
                if (!empty($_REQUEST['deviation_text_' . $activityId])) {
                    $data['deviation_text_' . $activityId] = $_REQUEST['deviation_text_' . $activityId];
                }
                if (!empty($_REQUEST['deviation_text_' . $activityId . '_check'])) {
                    $data['deviation_text_' . $activityId . '_check'] = $_REQUEST['deviation_text_' . $activityId . '_check'];
                }
                if (!empty($_REQUEST['action_plan_' . $activityId])) {
                    $data['action_plan_' . $activityId] = $_REQUEST['action_plan_' . $activityId];
                }
                if (!empty($_REQUEST['action_plan_' . $activityId . '_check'])) {
                    $data['action_plan_' . $activityId . '_check'] = $_REQUEST['action_plan_' . $activityId . '_check'];
                }
                if (!empty($_REQUEST['Fipn_arca_cache_' . $activityId])) {
                    $data['Fipn_arca_cache_' . $activityId] = $_REQUEST['Fipn_arca_cache_' . $activityId];
                }
                if (!empty($_REQUEST['Fnom_arca_' . $activityId . '_check'])) {
                    $data['Fnom_arca_' . $activityId . '_check'] = $_REQUEST['Fnom_arca_' . $activityId . '_check'];
                }
                if (!empty($_REQUEST['activite_due_date_' . $activityId])) {
                    $data['activite_due_date_' . $activityId] = convertDateToMysql($_REQUEST['activite_due_date_' . $activityId]);
                }
                if (!empty($_REQUEST['activite_due_date_' . $activityId . '_check'])) {
                    $data['activite_due_date_' . $activityId . '_check'] = $_REQUEST['activite_due_date_' . $activityId . '_check'];
                }
                if (!empty($_REQUEST['activite_done_date_' . $activityId])) {
                    $data['activite_done_date_' . $activityId] = convertDateToMysql($_REQUEST['activite_done_date_' . $activityId]);
                }

                $activity_data = $data;
                $sampl = serialize($data);
                $request = new requete("UPDATE tb_instances_activities_exgform SET saved_data='" . FormatStringForDB($sampl) . "' WHERE instance_id_fk='" . $exg_info->instance_id . "' AND repository_activity_id_fk=$activityId AND exchange_form_id_fk='" . $exg_info->exgform_id . "' ", $cnx->num);
            }
            if (!empty($_REQUEST['grid_type']) && $_REQUEST['grid_type'] == '4' && !empty($_POST['exgform_activity_ids'])) {
                $evaids = explode(';', $_POST['exgform_activity_ids']);
                $exFrmid = $_REQUEST['exgform_id'];
                if (!empty($evaids)) {

                    foreach ($evaids as $evaid) {
                        $data = array();
                        $data['status_TR_' . $evaid] = $_REQUEST['status_TR_' . $evaid];
                        if (!empty($_REQUEST['status_TR_' . $evaid . '_check'])) {
                            $data['status_TR_' . $evaid . '_check'] = $_REQUEST['status_TR_' . $evaid . '_check'];
                        }
                        $data['status_EC_' . $evaid] = $_REQUEST['status_EC_' . $evaid];
                        if (!empty($_REQUEST['status_EC_' . $evaid . '_check'])) {
                            $data['status_EC_' . $evaid . '_check'] = $_REQUEST['status_EC_' . $evaid . '_check'];
                        }
                        $data['status_ER_' . $evaid] = $_REQUEST['status_ER_' . $evaid];
                        if (!empty($_REQUEST['status_ER_' . $evaid . '_check'])) {
                            $data['status_ER_' . $evaid . '_check'] = $_REQUEST['status_ER_' . $evaid . '_check'];
                        }
                        $data['status_NC_' . $evaid] = $_REQUEST['status_NC_' . $evaid];
                        if (!empty($_REQUEST['status_NC_' . $evaid . '_check'])) {
                            $data['status_NC_' . $evaid . '_check'] = $_REQUEST['status_NC_' . $evaid . '_check'];
                        }

                        if (!empty($_REQUEST['deviation_text_' . $evaid])) {
                            $data['deviation_text_' . $evaid] = $_REQUEST['deviation_text_' . $evaid];
                        }
                        if (!empty($_REQUEST['deviation_text_' . $evaid . '_check'])) {
                            $data['deviation_text_' . $evaid . '_check'] = $_REQUEST['deviation_text_' . $evaid . '_check'];
                        }
                        if (!empty($_REQUEST['action_plan_' . $evaid])) {
                            $data['action_plan_' . $evaid] = $_REQUEST['action_plan_' . $evaid];
                        }
                        if (!empty($_REQUEST['action_plan_' . $evaid . '_check'])) {
                            $data['action_plan_' . $evaid . '_check'] = $_REQUEST['action_plan_' . $evaid . '_check'];
                        }
                        if (!empty($_REQUEST['Fipn_arca_cache_' . $evaid])) {
                            $data['Fipn_arca_cache_' . $evaid] = $_REQUEST['Fipn_arca_cache_' . $evaid];
                        }
                        if (!empty($_REQUEST['Fnom_arca_' . $evaid . '_check'])) {
                            $data['Fnom_arca_' . $evaid . '_check'] = $_REQUEST['Fnom_arca_' . $evaid . '_check'];
                        }
                        if (!empty($_REQUEST['activite_due_date_' . $evaid])) {
                            $data['activite_due_date_' . $evaid] = convertDateToMysql($_REQUEST['activite_due_date_' . $evaid]);
                        }
                        if (!empty($_REQUEST['activite_due_date_' . $evaid . '_check'])) {
                            $data['activite_due_date_' . $evaid . '_check'] = $_REQUEST['activite_due_date_' . $evaid . '_check'];
                        }
                        if (!empty($_REQUEST['activite_done_date_' . $evaid])) {
                            $data['activite_done_date_' . $evaid] = convertDateToMysql($_REQUEST['activite_done_date_' . $evaid]);
                        }
                        $activity_data = $data;
                        $sampl = serialize($data);
                        $request = new requete("UPDATE tb_instances_activities_evaluation_grid_exgform SET evalution_data='" . FormatStringForDB($sampl) . "' WHERE  activity_evaluation_exgform_id=$evaid", $cnx->num);
                    }
                }
            }

            if ($_REQUEST['action'] == 'validate') {
                $getActivityDatas = getActivitisList($exg_info->exgform_id, $_REQUEST['grid_type'], $cnx->num);
                $getsavedActivityDatas = getsavedActivityData($exg_info->exgform_id, $_REQUEST['grid_type'], $cnx->num);
                
                $appliedData = array();
                if (!empty($_REQUEST['grid_type']) && ($_REQUEST['grid_type'] == '1' || $_REQUEST['grid_type'] == '2')) {
                    foreach ($getsavedActivityDatas as $getsavedActivityData) {
                        $actId = $getsavedActivityData['repository_activity_id_fk'];
                        $columns = array();
                        $action_plan = $getsavedActivityData['action_plan'];
                        $pilot = $getsavedActivityData['pilot'];
                        $activite_due_date = $getsavedActivityData['due_date'];
                        $appliedData[$actId]['applied'] = true;
                        if (!empty($getsavedActivityData['saved_data'])) {
                            
                            $appliedData[$actId]['applied'] = true;
                            $savedData = unserialize($getsavedActivityData['saved_data']);
                            if (!empty($savedData['activity_comment_' . $actId . '_check'])) {
                                $columns[] = " activity_comment = '" . $getsavedActivityData['activity_comment'] . "'";
                                $appliedData[$actId]['activity_comment'] = $getsavedActivityData['activity_comment'];
                            }                            
                            
                            if($_REQUEST['grid_type'] == '1'){
                                   
                                
                                    $columns[] = " green = '" . $getsavedActivityData['GREEN'] . "'";
                                    $columns[] = " red = '" . $getsavedActivityData['RED'] . "'";
                                    $columns[] = " orange = '" . $getsavedActivityData['ORANGE'] . "'";
                                    $columns[] = " grey = '" . $getsavedActivityData['GREY'] . "'";
                                    if(!empty($savedData['status_TR_' . $actId . '_check'])){
                                        $appliedData[$actId]['green'] = $getsavedActivityData['GREEN'];
                                    }
                                    if(!empty($savedData['status_ER_' . $actId . '_check'])){
                                        $appliedData[$actId]['red'] = $getsavedActivityData['RED'];
                                    }
                                   if(!empty($savedData['status_EC_' . $actId . '_check'])){
                                        $appliedData[$actId]['orange'] = $getsavedActivityData['ORANGE'];
                                    }
                                    if (isset($savedData['status_NC_' . $actId])) {
                                        $columns[] = " white = '" . $getsavedActivityData['WHITE'] . "'";
                                        if(!empty($savedData['status_NC_' . $actId . '_check'])){
                                            $appliedData[$actId]['white'] = $getsavedActivityData['WHITE'];
                                        }
                                    }
                                    if (isset($savedData['status_NA_' . $actId])) {
                                        $columns[] = " grey = '" . $getsavedActivityData['GREY'] . "'";
                                        if(!empty($savedData['status_NA_' . $actId . '_check'])){
                                            $appliedData[$actId]['grey'] = $getsavedActivityData['GREY'];
                                        }
                                    }else{
                                        $appliedData[$actId]['grey'] = 0;
                                    }
                                
                                
                            }else{
                        
                                if (isset($savedData['status_TR_' . $actId . '_check'])) {
                                    $columns[] = " green = '" . $getsavedActivityData['GREEN'] . "'";
                                    if(!empty($savedData['status_TR_' . $actId . '_check'])){
                                        $appliedData[$actId]['green'] = $getsavedActivityData['GREEN'];
                                    }
                                }
                                if (isset($savedData['status_ER_' . $actId . '_check'])) {
                                    $columns[] = " red = '" . $getsavedActivityData['RED'] . "'";
                                    if(!empty($savedData['status_ER_' . $actId . '_check'])){
                                        $appliedData[$actId]['red'] = $getsavedActivityData['RED'];
                                    }
                                }
                                if (isset($savedData['status_EC_' . $actId . '_check'])) {
                                    $columns[] = " orange = '" . $getsavedActivityData['ORANGE'] . "'";
                                    if(!empty($savedData['status_EC_' . $actId . '_check'])){
                                        $appliedData[$actId]['orange'] = $getsavedActivityData['ORANGE'];
                                    }
                                }
                                if (isset($savedData['status_NC_' . $actId])) {
                                    $columns[] = " white = '" . $getsavedActivityData['WHITE'] . "'";
                                    if(!empty($savedData['status_NC_' . $actId . '_check'])){
                                        $appliedData[$actId]['white'] = $getsavedActivityData['WHITE'];
                                    }
                                }
                                if (isset($savedData['status_NA_' . $actId])) {
                                    $columns[] = " grey = '" . $getsavedActivityData['GREY'] . "'";
                                    if(!empty($savedData['status_NA_' . $actId . '_check'])){
                                        $appliedData[$actId]['grey'] = $getsavedActivityData['GREY'];
                                    }
                                }
                            }
                            if (!empty($savedData['action_plan_' . $actId . '_check'])) {
                                $action_plan = $getsavedActivityData['action_plan'];
                                $appliedData[$actId]['action_plan'] = $getsavedActivityData['action_plan'];
                            }
                            if (!empty($savedData['Fnom_arca_' . $actId . '_check'])) {
                                $pilot = $getsavedActivityData['pilot'];
                                $appliedData[$actId]['pilot'] = $getsavedActivityData['pilot'];
                            }
                            if (!empty($savedData['activite_due_date_' . $actId . '_check'])) {
                                $activite_due_date = $getsavedActivityData['due_date'];
                                $appliedData[$actId]['due_date'] = $getsavedActivityData['due_date'];
                            }
                        }else{
                            
                            $columns[] = " activity_comment = '" . FormatStringForDB($getsavedActivityData['activity_comment']) . "'";                                
                            $columns[] = " green = '" . $getsavedActivityData['GREEN'] . "'";
                            $columns[] = " red = '" . $getsavedActivityData['RED'] . "'";
                            $columns[] = " orange = '" . $getsavedActivityData['ORANGE'] . "'";
                            $columns[] = " white = '" . $getsavedActivityData['WHITE'] . "'";
                            $columns[] = " grey = '" . $getsavedActivityData['GREY'] . "'";
                            $appliedData[$actId]['activity_comment'] = FormatStringForDB($getsavedActivityData['activity_comment_' . $actId]);
                            $appliedData[$actId]['green'] = $getsavedActivityData['GREEN'];
                            $appliedData[$actId]['red'] = $getsavedActivityData['RED'];
                            $appliedData[$actId]['orange'] = $getsavedActivityData['ORANGE'];
                            $appliedData[$actId]['white'] = $getsavedActivityData['WHITE'];
                            if (!empty($getsavedActivityData['action_plan'])) {
                                $action_plan = $getsavedActivityData['action_plan'];
                                $appliedData[$actId]['action_plan'] = FormatStringForDB($getsavedActivityData['action_plan']);
                            }
                            if (!empty($getsavedActivityData['pilot'])) {
                                $pilot = $getsavedActivityData['pilot'];
                                $appliedData[$actId]['pilot'] = $getsavedActivityData['pilot'];
                            }
                            if (!empty($getsavedActivityData['due_date'])) {
                                $activite_due_date = $getsavedActivityData['due_date'];
                                $appliedData[$actId]['due_date'] = $getsavedActivityData['due_date'];
                            }
                        }

                        if (!empty($columns)) {
                            $columns[] =" date_update='" . todayNowDbFormatted() . "'";
                            $columns[] =" user_update='" . $_SESSION['ipn'] . "'";
                            $query = "UPDATE tb_instances_activities SET ";
                            $query .= implode(' , ', $columns);
                            $query .= " where repository_activity_id_fk = " . $getsavedActivityData['repository_activity_id_fk'];
                            $request = new requete($query, $cnx->num);
                        }

                        if (!empty($action_plan) || !empty($pilot) || !empty($activite_due_date)) {
                           $actionPlanCount = getActivitiyActionPlanCount($getsavedActivityData['repository_activity_id_fk'], $_REQUEST['grid_type'], $exg_info->instance_id, $cnx->num);
                            if ($actionPlanCount) {
                                $updateActionPlanQuery="UPDATE tb_instances_activities_action_plans SET";
                                $updateActionColumn = array();
                                if(!empty($action_plan)){
                                   $updateActionColumn[] = " action_plan = '" . FormatStringForDB($action_plan) . "'";
                                }
                                if(!empty($pilot)){
                                    $updateActionColumn[] = " pilot = '" . $pilot . "'";
                                }
                                if(!empty($activite_due_date)){
                                    $updateActionColumn[] = " due_date = '" . ($activite_due_date) . "'";
                                }
                                $updateActionPlanQuery .= implode(',',$updateActionColumn);
                                $updateActionPlanQuery .=" WHERE activity_id_fk = '" . $getsavedActivityData['repository_activity_id_fk'] . "' ";
                                $request = new requete($updateActionPlanQuery, $cnx->num); 

                            } else {
                                $query_action_plan = "INSERT INTO tb_instances_activities_action_plans (instance_id_fk,activity_id_fk,action_plan,pilot,due_date) VALUES
                                  (" . $_SESSION['dashboard_id'] . "," . $getsavedActivityData['repository_activity_id_fk'] . ",'" . trim(FormatStringForDB($action_plan)) . "',
                                      '" . $pilot . "','" . ($activite_due_date) . "')";
                                $request = new requete($query_action_plan, $cnx->num);
                            }
                        }
                        
                        $query = "SELECT ael.activity_external_link_id, ael.activity_external_link, ael.status, aef.activity_exgform_id "
                            . "FROM `tb_instances_activities_exgform_external_link` as ael "
                            . "JOIN tb_instances_activities_exgform as aef ON aef.activity_exgform_id = ael.activity_exgform_id_fk "
                            . "WHERE aef.exchange_form_id_fk = $exg_info->exgform_id AND aef.repository_activity_id_fk = $actId ";
                        $request = new requete($query, $cnx->num);
                        $externalLinkList = $request->recup_array_champ();
                        foreach($externalLinkList as $externalLink) {
                            $name = 'external_link_'.$actId.'_'.$externalLink['activity_external_link_id'];
                            if(isset($_REQUEST[$name.'_D_check'])) {
                                $query = "DELETE FROM tb_instances_activities_external_link "
                                        . "WHERE instance_id_fk = ".$exg_info->instance_id." "
                                        . "AND repository_activity_id_fk = ".$actId." "
                                        . "AND activity_external_link = '".$externalLink['activity_external_link']."'";
                                $request->envoi($query);
                            }
                            if(isset($_REQUEST[$name.'_N_check'])) {
                                $query = "INSERT INTO `tb_instances_activities_external_link` "
                                        . "(`instance_id_fk`, `repository_activity_id_fk`, `activity_external_link`, `date_update`, `user_update` ) "
                                        . "VALUES (".$exg_info->instance_id.", ".$actId.", '".$externalLink['activity_external_link']."', '".todayNowDbFormatted()."', '".$_SESSION['ipn']."')";
                                $request->envoi($query);
                            }
                        }
                        
                        $query = "SELECT count(activity_external_link_id) AS CNT FROM `tb_instances_activities_external_link` "
                                . "WHERE instance_id_fk = ".$exg_info->instance_id." AND `repository_activity_id_fk` = $actId";
                        $request->envoi($query);
                        $tmp = $request->recup_row();
                        if($tmp) {
                           $link_count = (int)$tmp[0];

                           $query = "UPDATE `tb_instances_activities` SET `count_external_link` = $link_count "
                                    . "WHERE instance_id_fk = ".$exg_info->instance_id." AND `repository_activity_id_fk` = $actId";
                           $request->envoi($query);
                        }
                    }
                }
                
                if (!empty($_REQUEST['grid_type']) && $_REQUEST['grid_type'] == '4') {
                    $activityData = array();
                    $actionPlanData = array();
                    foreach ($getsavedActivityDatas as $getsavedActivityData) {
                        $actId = $getsavedActivityData['repository_activity_id_fk'];
                        if (isset($activityData[$actId]['GREEN'])) {
                            $activityData[$actId]['GREEN'] = 0;
                            $activityData[$actId]['RED'] = 0;
                            $activityData[$actId]['ORANGE'] = 0;
                            $activityData[$actId]['WHITE'] = 0;
                        }
                        $activityData[$actId]['GREEN'] +=$getsavedActivityData['GREEN'];
                        $activityData[$actId]['ORANGE'] +=$getsavedActivityData['ORANGE'];
                        $activityData[$actId]['RED'] +=$getsavedActivityData['RED'];
                        $activityData[$actId]['WHITE'] +=$getsavedActivityData['WHITE'];

                        $exgfrmevaid = $getsavedActivityData['activity_evaluation_exgform_id'];
                       
                        if (!empty($getsavedActivityData['activity_evaluation_id_fk'])) {
                            $evaId = $getsavedActivityData['activity_evaluation_id_fk'];
                            $columns = array();
                            $action_plan = $pilot = $activite_due_date = '';
                            $appliedData[$actId][$evaId]['applied'] = true;
                            if (!empty($getsavedActivityData['evalution_data'])) {
                                $savedData = unserialize($getsavedActivityData['evalution_data']);
                                $appliedData[$actId][$evaId]['applied'] = true;
                                if (!empty($savedData['skill_entity_' . $exgfrmevaid . '_check'])) {
                                    $columns[] = " skill_entity = '" . $getsavedActivityData['skill_entity'] . "'";
                                    $appliedData[$actId][$evaId]['skill_entity'] = $getsavedActivityData['skill_entity'];
                                }
                                if (!empty($savedData['deviation_text_' . $exgfrmevaid . '_check'])) {
                                    $columns[] = " deviation_text = '" . $getsavedActivityData['deviation_text'] . "'";
                                    $appliedData[$actId][$evaId]['deviation_text'] = $getsavedActivityData['deviation_text'];
                                }
                                if (isset($savedData['status_TR_' . $exgfrmevaid . '_check'])) {
                                    $columns[] = " green = '" . $getsavedActivityData['GREEN'] . "'";
                                    $appliedData[$actId][$evaId]['GREEN'] = $getsavedActivityData['GREEN'];
                                }

                                if (isset($savedData['status_EC_' . $exgfrmevaid . '_check'])) {
                                    $columns[] = " orange = '" . $getsavedActivityData['ORANGE'] . "'";
                                    $appliedData[$actId][$evaId]['ORANGE'] = $getsavedActivityData['ORANGE'];
                                }

                                if (isset($savedData['status_ER_' . $exgfrmevaid . '_check'])) {
                                    $columns[] = " red = '" . $getsavedActivityData['RED'] . "'";
                                    $appliedData[$actId][$evaId]['RED'] = $getsavedActivityData['RED'];
                                }

                                if (isset($savedData['status_NC_' . $exgfrmevaid . '_check'])) {
                                    $columns[] = " white = '" . $getsavedActivityData['WHITE'] . "'";
                                    $appliedData[$actId][$evaId]['WHITE'] = $getsavedActivityData['WHITE'];
                                }

                  
                                if (!empty($savedData['action_plan_' . $exgfrmevaid . '_check'])) {
                                    $action_plan = $getsavedActivityData['action_plan'];
                                    $appliedData[$actId][$evaId]['action_plan'] = $getsavedActivityData['action_plan'];
                                }
                                if (!empty($savedData['Fnom_arca_' . $exgfrmevaid . '_check'])) {
                                    $pilot = $getsavedActivityData['pilot'];
                                    $appliedData[$actId][$evaId]['pilot'] = $getsavedActivityData['pilot'];
                                }

                                if (!empty($savedData['activite_due_date_' . $exgfrmevaid . '_check'])) {
                                    $activite_due_date = $getsavedActivityData['due_date'];
                                    $appliedData[$actId][$evaId]['due_date'] = $getsavedActivityData['due_date'];
                                }
                            } else {
                                $newlyAdded=array();
                                $columns[] = " skill_entity = '" . $getsavedActivityData['skill_entity'] . "'";
                                $columns[] = " deviation_text = '" . $getsavedActivityData['deviation_text'] . "'";                                
                                $columns[] = " green = '" . $getsavedActivityData['GREEN'] . "'";
                                $columns[] = " orange = '" . $getsavedActivityData['ORANGE'] . "'";
                                $columns[] = " red = '" . $getsavedActivityData['RED'] . "'";
                                $columns[] = " white = '" . $getsavedActivityData['WHITE'] . "'";
                                $action_plan = $getsavedActivityData['action_plan'];
                                $pilot = $getsavedActivityData['pilot'];
                                $activite_due_date = $getsavedActivityData['due_date'];
                                $appliedData[$actId][$evaId]['skill_entity'] = $getsavedActivityData['skill_entity'];
                                $appliedData[$actId][$evaId]['deviation_text'] = $getsavedActivityData['deviation_text'];                                
                                $appliedData[$actId][$evaId]['GREEN'] = $getsavedActivityData['GREEN'];
                                $appliedData[$actId][$evaId]['ORANGE'] = $getsavedActivityData['ORANGE'];
                                $appliedData[$actId][$evaId]['RED'] = $getsavedActivityData['RED'];
                                $appliedData[$actId][$evaId]['WHITE'] = $getsavedActivityData['WHITE'];
                                $appliedData[$actId][$evaId]['action_plan'] = $getsavedActivityData['action_plan'];
                                $appliedData[$actId][$evaId]['pilot'] = $getsavedActivityData['pilot'];
                                $appliedData[$actId][$evaId]['due_date'] = $getsavedActivityData['due_date'];
                            }
                            if (!empty($columns)) {
                                $query = "UPDATE tb_instances_activities_evaluation_grid SET ";
                                $query .= implode(',', $columns);
                                $query .= " where activity_evaluation_id = " . $getsavedActivityData['activity_evaluation_id_fk'];
                                $request = new requete($query, $cnx->num);
                            }
                            if (!empty($action_plan) || !empty($pilot) || !empty($activite_due_date)) {
                                if (!empty($getsavedActivityData['activity_evaluation_id_fk'])) {
                                    $actionPlanCount = getActivitiyActionPlanCount($getsavedActivityData['activity_evaluation_id_fk'], $_REQUEST['grid_type'], $exg_info->instance_id, $cnx->num);
                                } else {
                                    $actionPlanCount = '0';
                                }
                                if ($actionPlanCount) {
                                     $updateActionPlanQuery="UPDATE tb_instances_activities_action_plans SET";
                                    $updateActionColumn = array();
                                    if(!empty($action_plan)){
                                       $updateActionColumn[] = " action_plan = '" . FormatStringForDB($action_plan) . "'";
                                    }
                                    if(!empty($pilot)){
                                        $updateActionColumn[] = " pilot = '" . $pilot . "'";
                                    }
                                    if(!empty($activite_due_date)){
                                        $updateActionColumn[] = " due_date = '" . ($activite_due_date) . "'";
                                    }
                                    $updateActionPlanQuery .= implode(',',$updateActionColumn);
                                    $updateActionPlanQuery .=" WHERE activity_evaluation_id_fk = '" . $getsavedActivityData['activity_evaluation_id_fk'] . "' and activity_id_fk = '" . $getsavedActivityData['repository_activity_id_fk'] . "' ";
                                    $request = new requete($updateActionPlanQuery, $cnx->num); 
                                    

                                } else {
                                   echo $query_action_plan = "INSERT INTO tb_instances_activities_action_plans (instance_id_fk,activity_id_fk,activity_evaluation_id_fk,action_plan,pilot,due_date) VALUES
                                      (" . $_SESSION['dashboard_id'] . "," . $getsavedActivityData['repository_activity_id_fk'] . "," . $getsavedActivityData['activity_evaluation_id_fk'] . ",'" . trim(FormatStringForDB($action_plan)) . "',
                                          '" . $pilot . "','" . ($activite_due_date) . "')";
                                      $request = new requete($query_action_plan, $cnx->num);
                                }
                            }
                        } else {
                            $query_action_plan = "INSERT into tb_instances_activities_evaluation_grid (instance_id_fk,repository_activity_id_fk,skill_entity,deviation_text,
                                        count_external_link,green,red,orange,white) values(" . $exg_info->instance_id . "," . $getsavedActivityData['repository_activity_id_fk'] . ",'" . $getsavedActivityData['skill_entity'] . "','" .
                                    $getsavedActivityData['deviation_text'] . "',0,'" . $getsavedActivityData['GREEN'] . "','" . $getsavedActivityData['RED'] . "','" .
                                    $getsavedActivityData['ORANGE'] . "','" . $getsavedActivityData['WHITE'] . "')";
                            $request = new requete($query_action_plan, $cnx->num);
                            $evaId = $getsavedActivityData['activity_evaluation_id_fk'] = $request->id_new;
                            $action_plan = $getsavedActivityData['action_plan'];
                            $pilot = $getsavedActivityData['pilot'];
                            $activite_due_date = $getsavedActivityData['due_date'];
                            if (!empty($action_plan) || !empty($pilot) || !empty($activite_due_date)) {
                                $query_action_plan = "INSERT INTO tb_instances_activities_action_plans (instance_id_fk,activity_id_fk,activity_evaluation_id_fk,action_plan,pilot,due_date) VALUES
                                      (" . $_SESSION['dashboard_id'] . "," . $getsavedActivityData['repository_activity_id_fk'] . "," . $getsavedActivityData['activity_evaluation_id_fk'] . ",'" . trim(FormatStringForDB($action_plan)) . "',
                                          '" . $pilot . "','" . $activite_due_date . "')";
                                $request = new requete($query_action_plan, $cnx->num);
                            }
                            $appliedData[$actId][$evaId]['skill_entity'] = $getsavedActivityData['skill_entity'];
                            $appliedData[$actId][$evaId]['deviation_text'] = $getsavedActivityData['deviation_text'];                                
                            $appliedData[$actId][$evaId]['GREEN'] = $getsavedActivityData['GREEN'];
                            $appliedData[$actId][$evaId]['ORANGE'] = $getsavedActivityData['ORANGE'];
                            $appliedData[$actId][$evaId]['RED'] = $getsavedActivityData['RED'];
                            $appliedData[$actId][$evaId]['WHITE'] = $getsavedActivityData['WHITE'];
                            $appliedData[$actId][$evaId]['action_plan'] = $getsavedActivityData['action_plan'];
                            $appliedData[$actId][$evaId]['pilot'] = $getsavedActivityData['pilot'];
                            $appliedData[$actId][$evaId]['due_date'] = $getsavedActivityData['due_date'];

                            if (!empty($getsavedActivityData['activity_evaluation_id_fk'])) {
                                $actionPlanCount = getActivitiyActionPlanCount($getsavedActivityData['activity_evaluation_id_fk'], $_REQUEST['grid_type'],$exg_info->instance_id, $cnx->num);
                            } else {
                                $actionPlanCount = '0';
                            }
                            if ($actionPlanCount) {
                              $updateActionPlanQuery="UPDATE tb_instances_activities_action_plans SET";
                                $updateActionColumn = array();
                                if(!empty($action_plan)){
                                   $updateActionColumn[] = " action_plan = '" . FormatStringForDB($action_plan) . "'";
                                }
                                if(!empty($pilot)){
                                    $updateActionColumn[] = " pilot = '" . $pilot . "'";
                                }
                                if(!empty($activite_due_date)){
                                    $updateActionColumn[] = " due_date = '" . ($activite_due_date) . "'";
                                }
                                $updateActionPlanQuery .= implode(',',$updateActionColumn);
                                $updateActionPlanQuery .=" WHERE activity_evaluation_id_fk = '" . $getsavedActivityData['activity_evaluation_id_fk'] . "' and activity_id_fk = '" . $getsavedActivityData['repository_activity_id_fk'] . "' ";
                                $request = new requete($updateActionPlanQuery, $cnx->num); 
                            } else {
                               $query_action_plan = "INSERT INTO tb_instances_activities_action_plans (instance_id_fk,activity_id_fk,activity_evaluation_id_fk,action_plan,pilot,due_date) VALUES
                                      (" . $_SESSION['dashboard_id'] . "," . $getsavedActivityData['repository_activity_id_fk'] . "," . $getsavedActivityData['activity_evaluation_id_fk'] . ",'" . trim(FormatStringForDB($action_plan)) . "',
                                          '" . $pilot . "','" . convertDateToMysql($activite_due_date) . "')";
                                $request = new requete($query_action_plan, $cnx->num);
                            }
                        }
                        
                        $query = "SELECT ael.activity_external_link_id, ael.activity_external_link, ael.status, aef.activity_exgform_id "
                                . "FROM `tb_instances_activities_exgform_external_link` as ael "
                                . "JOIN tb_instances_activities_exgform as aef ON aef.activity_exgform_id = ael.activity_exgform_id_fk "
                                . "WHERE aef.exchange_form_id_fk = $exg_info->exgform_id AND aef.repository_activity_id_fk = $actId "
                                . "AND ael.activity_evaluation_exgform_id_fk = ".$exgfrmevaid." ";
                        $request = new requete($query, $cnx->num);
                        $externalLinkList = $request->recup_array_champ();
                        foreach($externalLinkList as $externalLink) {
                            $name = 'external_link_'.$exgfrmevaid.'_'.$externalLink['activity_external_link_id'];
                            if(isset($_REQUEST[$name.'_D_check'])) {
                                $query = "DELETE FROM tb_instances_activities_external_link "
                                        . "WHERE instance_id_fk = ".$exg_info->instance_id." "
                                        . "AND repository_activity_id_fk = ".$actId." "
                                        . "AND activity_evaluation_id_fk = ".$evaId." "
                                        . "AND activity_external_link = '".$externalLink['activity_external_link']."'";
                                $request->envoi($query);
                            }
                            if(isset($_REQUEST[$name.'_N_check'])) {
                                $query = "INSERT INTO `tb_instances_activities_external_link` "
                                        . "(`instance_id_fk`, `repository_activity_id_fk`, `activity_evaluation_id_fk`, `activity_external_link`, `date_update`, `user_update` ) "
                                        . "VALUES (".$exg_info->instance_id.", ".$actId.", ".$evaId.", '".$externalLink['activity_external_link']."', '".todayNowDbFormatted()."', '".$_SESSION['ipn']."')";
                                $request->envoi($query);
                            }
                        }
                        
                        $query = "SELECT count(activity_external_link_id) AS CNT FROM `tb_instances_activities_external_link` "
                                . "WHERE instance_id_fk = ".$exg_info->instance_id." "
                                . "AND `repository_activity_id_fk` = $actId "
                                . "AND activity_evaluation_id_fk = ".$evaId." ";
                        $request->envoi($query);
                        $tmp = $request->recup_row();
                        if($tmp) {
                           $link_count = (int)$tmp[0];

                           $query = "UPDATE `tb_instances_activities_evaluation_grid` SET `count_external_link` = $link_count "
                                   . "WHERE instance_id_fk = ".$exg_info->instance_id." "
                                   . "AND `repository_activity_id_fk` = $actId "
                                   . "AND activity_evaluation_id = ".$evaId." ";
                           $request->envoi($query);
                        }
                    }
                    foreach($activityData as $actId => $values) {
                        $query = "SELECT SUM(green) as green, SUM(red) as red, SUM(orange) as orange, SUM(white) as white "
                            . "FROM `tb_instances_activities_evaluation_grid` "
                            . "WHERE instance_id_fk = $exg_info->instance_id AND repository_activity_id_fk = $actId ";
                        $request = new requete($query, $cnx->num);
                        $grid = $request->recup_row_champ();

                        $total_color = array_sum($grid);
                        $sum_green = sprintf('%0.0f', ($grid['green'] / $total_color) * 100);
                        $sum_red = sprintf('%0.0f', ($grid['red'] / $total_color) * 100);
                        $sum_orange = sprintf('%0.0f', ($grid['orange'] / $total_color) * 100);
                        $sum_white = sprintf('%0.0f', ($grid['white'] / $total_color) * 100);
                        
                        $query = "UPDATE tb_instances_activities "
                            . "SET GREEN=$sum_green, ORANGE=$sum_orange, RED=$sum_red, WHITE=$sum_white, GREY=0, "
                            . "date_update='" . todayNowDbFormatted() . "',user_update='" . $_SESSION['ipn'] . "' "
                            . "WHERE instance_id_fk='" . $exg_info->instance_id . "' AND repository_activity_id_fk='" . $actId . "'";
                        $request->envoi($query);
                    }
                }
            }
        }

        if (!empty($_REQUEST['action'])) {
            $statusVal = ($_REQUEST['action'] == 'refuse') ? '6' : '7';
            statusUpdateToExchangeForm($_REQUEST['exchange_form_id'], $statusVal, $cnx->num);
        }
        
        if($_REQUEST['action'] !='recieved_by_email'){
            $Mail = new cl_mail();
            $leader_info = $arca->getUserData($exg_info->leader_ipn);
            $contributor_info = $arca->getUserData($exg_info->contributor_ipn);

            $Mail->From = $leader_info->courriel;
            $Mail->To = $contributor_info->courriel;
            $contextOnfo = getContextInfo($exg_info->instance_id, $cnx->num);
            
            $sqlProjectItems = "SELECT p.project_code FROM tb_projects as p "
                    . "JOIN tb_instance_projects as pi ON pi.project_id_fk = p.project_id AND pi.instance_id_fk = ".$exg_info->instance_id." "
                    . "GROUP BY p.project_code";
            $request=new requete($sqlProjectItems,$cnx->num);
            $project_infos = $request->recup_array_mono();
            $exg_info->project_code = join(", ", $project_infos);
            
            $Mail->objet = '[CLEM] exchange form ' . $exg_info->exchange_no . ' reviewed : Tdb ' . $exg_info->instance_id . ' - ' 
                    . $exg_info->milestone_name . ' - ' . $project_infos[0];
            if (!empty($contextOnfo->contextName)) {
                $Mail->objet .=  '/' . $contextOnfo->contextName;
                $exg_info->project_code .=  '/' . $contextOnfo->contextName;
            }
                        
            if ($statusVal == '6') {
                $linkPath = 'http://' . $_SERVER['HTTP_HOST'] . '/cem/scripts/index.php?&action=exgform&exgformid=' . $exg_info->exgform_id;

                $mail_content = '';
                $mail_content .= '<html><head></head><body>';
                $mail_content .= '<p>Bonjour,</p>';
                $mail_content .= ('<p>' . $leader_info->nom . ' a refusé la fiche navette n°' . $exg_info->exchange_no . ':' . $exg_info->instance_id . ' - ' . $exg_info->milestone_name . ' - ' . $exg_info->project_code . '.</p>');
                $mail_content .= '<p>Pour le motif suivant:</p>';
                $mail_content .= '<p>'.($_POST['reason']).'</p>';
                $mail_content .= ('<p>Vous pouvez consulter votre réponse en cliquant <A HREF="' . $linkPath . '"><strong>ici</strong></A></p>');
                $mail_content .= '<p>Cordialement,</p>';
                $mail_content .= '<p>' . $leader_info->nom . '.</p>';
                $mail_content .='<p>---------------------------------------------</p>';            

                $mail_content .= '<p>Hello,</p>';
                $mail_content .= ('<p>' . $leader_info->nom . ' refused the exchange form n°' . $exg_info->exchange_no . ':' . $exg_info->instance_id . ' - ' . $exg_info->milestone_name . ' - ' . $exg_info->project_code . '.</p>');
                $mail_content .= '<p>For the following reason:</p>';
                $mail_content .= '<p>'.($_POST['reason']).'</p>';
                $mail_content .= '<p>You could consult your answer by clicking <A HREF="' . $linkPath . '"><strong>here</strong></A></p>';
                $mail_content .= '<p>Regards,</p>';
                $mail_content .= '<p>' . $leader_info->nom . '.</p>';

                $mail_content .= '</body></html>';
            } else {
                $content_labels = array('headers' => array('activities' => $text_std_activities, 'gor' => $text_exgfrom_gor, 'contributors' => $text_label_contributors, 'last_update' => $text_std_last_update, 'deviation' => $text_exgfrom_deviation, 'action_plan' => $text_std_action_plan, 'arca_name' => $tooltip_arca_name, 'action_plan_due_date' => $text_std_action_plan_due_date, 'gor_eval' => $text_exgfrom_gor_eval));
                $mail_content = getExchangeFormMailContentsValidate($exg_info->exgform_id, $content_labels, $tablo_libelle_statut, $cnx->num, $arca,$getActivityDatas);
            }
             $all_cc_users = '';
            if (!empty($exg_info->cc_users)) {
                $cc_users_info = explode(';', $exg_info->cc_users);
                foreach ($cc_users_info as $values) {
                    $cc_user_info = $arca->getUserData(trim($values));
                    if (empty($all_cc_users)) {
                        $all_cc_users .= $cc_user_info->courriel;
                    } else {
                        $all_cc_users .= ';' . $cc_user_info->courriel;
                    }
                }
            }
            $Mail->CC = $all_cc_users;
            $Mail->set_body($mail_content,  "text/html;charset=UTF-8;");
            $Mail->ajoute_destinataire($contributor_info->courriel, $contributor_info->nom, "To");
            $mail_status = $Mail->envoyer("EACH");
        }
        }        
        
        header("location: " . $pathBase . "scripts_dashboard/dashboard_exchange_form.php?&menu_n1=home&menu_n2=6&action=list_exchange_form");

        break;    
    case 'read_send_exgform':
        $display_table = false;
        include_once 'dashboard_exgform_read_send.php';
        break;
    case 'send_email':
        $Mail = new cl_mail();
        $leader_info = $arca->getUserData($_REQUEST['leader_ipn']);
        $contributor_info = $arca->getUserData($_REQUEST['contributor_ipn']);
        $all_cc_users = array();
         if(isset($_REQUEST['leader_ipn_copy']) && $_REQUEST['leader_ipn_copy'] == 1) {
            $all_cc_users[] = $leader_info->courriel;
        }
        if (!empty($_REQUEST['cc_user_ipn'])) {
            $cc_users_info = explode(';', $_REQUEST['cc_user_ipn']);
            foreach ($cc_users_info as $values) {
                $cc_user_info = $arca->getUserData(trim($values));
                    $all_cc_users[] = $cc_user_info->courriel;
            }
        }
        $Mail->From = $leader_info->courriel;
        $Mail->To = $contributor_info->courriel;
        if(!empty($all_cc_users)){
           $all_cc_users = implode(";",  array_unique($all_cc_users));
        }
        $Mail->CC = $all_cc_users;
        $Mail->objet = $_REQUEST['mail_subject'];
        $mailContent = getExchangeFormMailContents($_REQUEST['exgform_id'], $content_labels, $tablo_libelle_statut, $cnx->num, $arca);
      
        $Mail->set_body($mailContent, "text/html;charset=UTF-8;");
        $Mail->ajoute_destinataire($contributor_info->courriel, $contributor_info->nom, "To");

        $mail_status = $Mail->envoyer("EACH");
        $update_status = ($mail_status) ? '2' : '1';
        $request = new requete(" UPDATE tb_exchange_form SET cc_user_ipn = '" . $_REQUEST['cc_user_ipn'] . "', status = '" . $update_status . "', modified_date = NOW(), status_update = current_date
															WHERE exchange_form_id = '" . $_REQUEST['exgform_id'] . "' ", $cnx->num);

        /* redirect to exchange form list view */
        //header("location: " . $pathBase . "scripts_dashboard/dashboard_exchange_form.php?&menu_n1=home&menu_n2=6&action=list_exchange_form");
        header("location: " . $pathBase . "scripts_dashboard/dashboard.php?"
                . "dashboard_id=".$_SESSION['dashboard_id']."&menu_n1=home&menu_n2=6#!/view/".$_SESSION['dashboard_id']."/exchange_forms");

        break;
    case 'list_exchange_form':
        /* get list view data's */
        $display_table = true;
        $list_exchange_from = array();
        if(isset($_SESSION['milestone_id'])) {
            $exchangeForm_sql = " SELECT exf.*, role.name_" . $_SESSION['language'] . " AS roleName, dept.department_name_" . $_SESSION['language'] . " AS deptName   
                                                               FROM tb_exchange_form AS exf 
                                                               INNER JOIN tb_roles AS role ON role.role_id = exf.role_id_fk 
                                                               INNER JOIN tb_departments AS dept ON dept.department_id = exf.department_id_fk 
                                                               AND exf.instance_id_fk='" . $_SESSION['dashboard_id'] . "' ";


            $exchangeForm_sql .=" AND exf.repository_milestone_id_fk = " . $_SESSION['milestone_id'];


            if (!empty($_REQUEST['filtre_exchange_form_no'])) {
                $exchangeForm_sql .=" AND exf.exchange_no = " . $_REQUEST['filtre_exchange_form_no'];
            }
            if (!empty($_REQUEST['contributor_ipn'])) {
                $exchangeForm_sql .=" AND exf.contributor_ipn = '" . $_REQUEST['contributor_ipn'] . "'";
            }
            if (!empty($_REQUEST['filtre_status'])) {
                $exchangeForm_sql .=" AND exf.status = " . $_REQUEST['filtre_status'];
            }

            $request = new requete($exchangeForm_sql, $cnx->num);
            $request->calc_nb_elt();
            $nb_total = $request->nb_elt;

            $request = new requete($exchangeForm_sql . $requete_sql_marqueur, $cnx->num);
            $list_exchange_from = $request->recup_array_champ();
        }

        break;
    case "cancel":
        $request = new requete(" UPDATE tb_exchange_form  SET status = '8', modified_date = NOW() WHERE instance_id_fk = '" . $_SESSION['dashboard_id'] . "' AND exchange_form_id = '" . $_REQUEST['exchange_form_id'] . "' AND leader_ipn = '" . $_SESSION['ipn'] . "' AND status = '0' ", $cnx->num);
        header("location: " . $pathBase . "scripts_dashboard/dashboard_exchange_form.php?&menu_n1=home&menu_n2=6&action=list_exchange_form");
        break;
}
if ($display_table) {
    require_once 'dashboard_header.php';
    if (!isset($_SESSION['dashboard_id'])) {
        ?>
        <div class="RnoMessageBox RnoWarningMessageBox"><?php echo $msg_no_dashboard; ?></div><?php
    }else if (!isset($_SESSION['milestone_id']))
    {?>
     <div class="RnoMessageBox RnoWarningMessageBox"><?php echo $msg_no_milestone;?></div><?php
    } else {
      
     if (!empty($_SESSION['record_add'])) {
          $_SESSION['record_add'] = '';
            ?>
            <div class="RnoMessageBox RnoCheckOKMessageBox"><?php echo $msg_new_exchange_form_created; ?></div>
            <script>$('.RnoCheckOKMessageBox').delay(<?php echo $delayMsg; ?>).slideUp("slow");</script>
            <?php
        }
        if (!empty($_SESSION['already_created'])) {
          $_SESSION['already_created'] = '';
            ?>
            <div class="RnoMessageBox RnoCheckOKMessageBox"><?php echo $msg_already_created_exchange_form; ?></div>
            <script>$('.RnoCheckOKMessageBox').delay(<?php echo $delayMsg; ?>).slideUp("slow");</script>
            <?php
        }
            $filtres = new filtres($pathBase, $pathPictures, 1);



            $filtres->add_field('filtre_exchange_form_no', $text_label_exform_no . ' : ', 'string', 'exchange_form_id');
            $filtres->define_field_list('filtre_exchange_form_no', 'exchange_form_id', 'tb_exchange_form');


            $contributor = array();
            if(!empty($list_exchange_from)){
                foreach ($list_exchange_from as $list_exchange) {
                    $contributor[$list_exchange['contributor_ipn']] = $list_exchange['contributor_ipn'] . ':' . $arca->getName($list_exchange['contributor_ipn']);
                }
            }
            $filtres->add_field('contributor_ipn', $text_label_contributor . ' : ', 'liste', 'contributor_ipn');

            $filtres->define_field_list('contributor_ipn', implode(',', $contributor));


            $status = array();
            foreach ($exchange_form_filter_status as $key => $val) {
                $status [] = $key . ':' . $val;
            }

            $filtres->add_field('filtre_status', $text_status . ' : ', 'liste', 'status');
            $filtres->define_field_list('filtre_status', implode(',', $status));

            $filtres->afficher($targetFile, $button_filter, $text_inactive);
            
              if (!$nb_total) {
            ?>
            <div class="RnoMessageBox RnoInformationMessageBox"><?php echo $no_exchange_form_found; ?></div>
            <?php
        } else {
            ?>
            <div class="RnoMessageBox RnoInformationMessageBox"><?php echo $msg_exchange_form_list; ?></div>
            <div class="clearleft"></div>
            <table class="RnoTableLevelButtonsTop" summary="">
                <tr><?php
            $targetFilePageNumbering = $targetFile;
            require_once $pathBase . 'common_scripts/pagination.php';
            ?>			
                </tr>
            </table>
            <form name="exchange_form_list" id="exchange_form_list" action="#">
                <table class="RnoTableData">
                    <tr>
                        <th><?php echo $text_label_exform_no; ?></th>
                        <th><?php echo $text_label_modified_date; ?></th>                    
                        <th><?php echo $text_label_contributor; ?></th>
                        <th><?php echo $text_std_role; ?></th>
                        <th><?php echo $text_std_department; ?></th>
                        <th><?php echo $text_status; ?></th>
                        <th><?php echo $text_label_action; ?></th>
                    </tr>
            <?php
            $remainingfeedback = array();
            for ($i = 0; $i < count($list_exchange_from); $i++) {
                ?>
                        <tr> 
                            <td><?php echo $list_exchange_from[$i]['exchange_no']; ?></td>
                            <td><?php echo formatDate($list_exchange_from[$i]['modified_date']); ?></td>  
                            <td><?php echo $arca->getName($list_exchange_from[$i]['contributor_ipn']) . "[" . $list_exchange_from[$i]['contributor_ipn'] . "]"; ?></td>     
                            <td><?php echo $list_exchange_from[$i]['roleName']; ?></td>
                            <td><?php echo $list_exchange_from[$i]['deptName']; ?></td>
                            <td><?php echo $exchange_form_status[$list_exchange_from[$i]['status']]; ?></td>
                            <td>
                            <?php if ($list_exchange_from[$i]['leader_ipn'] == $_SESSION['ipn']) {
                                    ?>
                                    <?php
                                    if ($list_exchange_from[$i]['status'] == '8') {
                                        echo '<b>' . $exchange_form_status[$list_exchange_from[$i]['status']] . '</b>';
                                    } else
                                    if ($list_exchange_from[$i]['status'] == '4') {
                                        ?>
                                        <a href="<?php echo $targetFile ?>&action=read_send_exgform&exchange_form_id=<?php echo $list_exchange_from[$i]['exchange_form_id'] ?>" id="validate_form_action" name="validate_form_action"><?php echo $button_validate; ?></a><br/>
                                    <?php } else { ?>
                                        <a href="<?php echo $targetFile ?>&action=read_send_exgform&exchange_form_id=<?php echo $list_exchange_from[$i]['exchange_form_id'] ?>" id="exform_action" name="exform_action"><?php echo $text_status_open; ?></a><br/>
                                        <?php if ($list_exchange_from[$i]['status'] == '0') { ?>
                                            <a href="<?php echo $targetFile ?>&action=cancel&exchange_form_id=<?php echo $list_exchange_from[$i]['exchange_form_id'] ?>" id="exform_cancel" name="exform_cancel"> <?php echo 'Cancel'; ?> </a>
                                        <?php } ?>
                                        <?php if ($list_exchange_from[$i]['status'] == '1') { ?>
                                            <a href="<?php echo $targetFile ?>&action=retry_sent_email&exchange_form_id=<?php echo $list_exchange_from[$i]['exchange_form_id'] ?>" id="retry_sent_email_action" name="retry_sent_email_action"><?php echo $text_exgfrom_retry_sending; ?></a><br/>
                                        <?php } ?>
                                        <?php if ($list_exchange_from[$i]['status'] == '2') { ?>
                                            <a href="<?php echo $targetFile ?>&action=recieved_by_email&exchange_form_id=<?php echo $list_exchange_from[$i]['exchange_form_id'] ?>" id="received_by_mail" name="received_by_mail"><?php echo $text_received_by_mail; ?></a>
                                        <?php } ?>                                
                                    <?php } ?>

                                <?php } elseif ($list_exchange_from[$i]['contributor_ipn'] == $_SESSION['ipn'] && $list_exchange_from[$i]['status'] > 0) { ?>

                            <?php if ($list_exchange_from[$i]['status'] == '2') { ?>
                                        <a target="_blank" href="<?php echo $targetFile ?>&action=read_send_exgform&view=contributor&exchange_form_id=<?php echo $list_exchange_from[$i]['exchange_form_id'] ?>" id="exform_action" name="exform_action"><?php echo $text_status_open; ?></a>
                                    <?php } else { ?>
                                        <a href="<?php echo $targetFile ?>&action=read_send_exgform&exchange_form_id=<?php echo $list_exchange_from[$i]['exchange_form_id'] ?>" id="exform_action" name="exform_action"><?php echo $text_status_open; ?></a>
                                    <?php } ?>
                                    <?php
                                }else if($list_exchange_from[$i]['status'] > 0){
                                    ?>
                                    <a href="<?php echo $targetFile ?>&action=read_send_exgform&exchange_form_id=<?php echo $list_exchange_from[$i]['exchange_form_id'] ?>" id="exform_action" name="exform_action"><?php echo $text_status_open; ?></a>
                                <?php 
                                }
                                ?>
                            </td>
                        </tr>
                                <?php
                            }
                        }
                        ?> </table> </form>
                <?php
            }
        }
        require_once $pathBase . 'footer.php';
        ?>