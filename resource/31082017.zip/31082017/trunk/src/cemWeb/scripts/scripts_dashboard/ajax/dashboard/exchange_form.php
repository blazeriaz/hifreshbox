<?php
session_start();
$pathBase = '../../../';
$pathRoot = '../' . $pathBase;

require_once $pathRoot . 'libraries/classes/class_connexion_mysql.php';
require_once $pathBase . 'common_scripts/datetime_functions.php';
require_once $pathBase . 'common_scripts/FormatStringForDB.php';
require_once $pathBase . 'common_scripts/url_functions.php';


$cnx = new connexion_db($pathBase);
$request = new requete("SELECT 1", $cnx->num);
require_once $pathRoot.'libraries/classes/models/coreModel.php';
require_once $pathRoot.'libraries/classes/models/UtilisateurModel.php';
require_once $pathRoot . 'libraries/classes/models/DashboardModel.php';
$currentUser = new UtilisateurModel($_SESSION['ipn']);

$post_vars = file_get_contents("php://input");
$post_vars = get_object_vars(json_decode($post_vars));
$currentDashboard = new DashboardModel($post_vars['dashboard_id']);

$jsonOutput = new stdClass();

if(isset($post_vars['action']) && $post_vars['action'] == "received_by_mail") {
    $request->envoi("UPDATE tb_exchange_form  SET status = '7', modified_date = NOW() "
            . "WHERE instance_id_fk = '" . $post_vars['dashboard_id'] . "' AND "
            . "exchange_form_id = '" . $post_vars['exchange_form_id'] . "' "
            . "AND leader_ipn = '" . $currentUser->ipn . "'", $cnx->num);
    $jsonOutput->success = 1;
}

if(isset($post_vars['action']) && $post_vars['action'] == "cancel_exg_form") {
    $request->envoi("UPDATE tb_exchange_form  SET status = '8', modified_date = NOW() "
            . "WHERE instance_id_fk = '" . $post_vars['dashboard_id'] . "' AND "
            . "exchange_form_id = '" . $post_vars['exchange_form_id'] . "' "
            . "AND leader_ipn = '" . $currentUser->ipn . "' AND status = '0' ", $cnx->num);
    $jsonOutput->success = 1;
}


echo json_encode($jsonOutput, JSON_NUMERIC_CHECK);
