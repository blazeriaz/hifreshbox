<?php
ini_set("memory_limit", "-1");
set_time_limit(0);
session_start();
ini_set('display_errors','1');
$pathBase = '../../../';
$pathRoot = '../' . $pathBase;
require_once $pathRoot . 'libraries/classes/class_connexion_mysql.php';
require_once $pathRoot . 'libraries/classes/class_arca.php';
require_once $pathBase . 'common_scripts/datetime_functions.php';
require_once $pathBase . 'common_scripts/FormatStringForDB.php';
require_once $pathBase . 'common_scripts/url_functions.php';
require_once $pathRoot . 'libraries/phplibs/upload.php';
$cnx = new connexion_db($pathBase);
$request = new requete("SELECT 1", $cnx->num);
require_once $pathRoot . 'libraries/classes/models/coreModel.php';
require_once $pathRoot . 'libraries/classes/models/RepositoryModel.php';
if (!empty($_POST)) {
    $post_vars = $_POST;
} else {
    $post_vars = file_get_contents("php://input");
    $post_vars = get_object_vars(json_decode($post_vars));
}

$action = isset($post_vars['action']) ? $post_vars['action'] : '';
$alerts = array("info" => array(), "error" => array(), "success" => array());
$json = array("success" => 1, "alerts" => $alerts);
$affectedCount = '0';
if ($post_vars['repository_id']) {
    $repId = $post_vars['repository_id'];
    $repositoryObj = new RepositoryModel($post_vars['repository_id']);
    $repository = $repositoryObj->getRepositoryInfo();
        $revId = $repository->repository_revision_id;
    $request->envoi("Select inst.instance_id count from tb_instances inst, tb_repositories_versions ver 
        where inst.repository_revision_id_fk = ver.repository_revision_id and inst.is_deleted <> 1 and  
        inst.is_updating in (1,2) and ver.repository_id_fk=$repId");
    $affectedInsts = $request->recup_array_mono();

    $request->envoi("select tv.template_id_fk from tb_templates_versions tv 
    inner join tb_templates t on t.template_id = tv.template_id_fk
    inner join tb_repositories_versions rv on rv.repository_revision_id = tv.repository_revision_id_fk
    where rv.version_status in ('ACT','NEW') and t.template_repository_id_fk = $repId and 
     tv.template_status = 'ACT' 
    and t.is_deleted = 0 group by
    tv.template_id_fk having count(*) > 1");
    $repositoryActiveTemplates = $request->recup_array_mono();
    if (count($repositoryActiveTemplates) > 0) {
        // Getting Active repository version
        $request->envoi("SELECT repository_revision_id FROM tb_repositories_versions WHERE version_status='ACT' AND repository_id_fk=$repId");
        $obs_revision_id = $request->recup_objet();
        $tmpids = implode(',', $repositoryActiveTemplates);



        $request->envoi("select rm.milestone_reference_id, GROUP_CONCAT(tm.template_id_fk),repository_milestone_id,milestone_order from tb_repositories_milestones rm inner join tb_repositories_template_constitution_milestones tm
on tm.milestone_id_fk = rm.repository_milestone_id and tm.revision_id_fk = rm.repository_revision_id_fk where rm.repository_revision_id_fk =$revId
and rm.is_delete =0 and tm.template_id_fk in ($tmpids) group by rm.repository_milestone_id");
        $repository_ref = $request->recup_array_key();

        $request->envoi("select rm.milestone_reference_id from tb_repositories_milestones rm inner join tb_repositories_template_constitution_milestones tm
on tm.milestone_id_fk = rm.repository_milestone_id and tm.revision_id_fk = rm.repository_revision_id_fk 
where rm.repository_revision_id_fk =$obs_revision_id->repository_revision_id
and rm.is_delete =0 and tm.template_id_fk in ($tmpids)  group by rm.repository_milestone_id");
        $instance_ref = $request->recup_array_mono();
        $affaectedInstance = array();
        if (isset($instance_ref) && isset($repository_ref)) {
            $ref_diff = array_diff(array_keys($repository_ref), $instance_ref);
            if (!empty($ref_diff)) {
                foreach ($ref_diff as $refid) {
                    $mileTemp = $repository_ref[$refid][1];
                    $mileid = $repository_ref[$refid][2];
                    $mileOrder = $repository_ref[$refid][3];
                    $request->envoi("select im.instance_id_fk from tb_instances_milestones im 
  inner join tb_repositories_milestones rm on rm.repository_milestone_id = im.repository_milestone_id_fk
  inner join tb_instances i on i.instance_id = im.instance_id_fk
  where rm.milestone_order < $mileOrder and im.is_evaluate =0 and i.is_deleted = 0 and im.is_deleted = 0 
  and i.template_id_fk in ($mileTemp) and i.is_updating !=2");
                    $instanceIds = $request->recup_array_mono();
                    $affaectedInstance = array_merge($newInstances, $instanceIds);
                }
                $newInstanceIds = array_unique($affaectedInstance);
                $instChunks = array_chunk($newInstanceIds, 300);
                foreach ($instChunks as $instIds) {
                    $ins = implode(',', $instIds);
                    $request->envoi("UPDATE tb_instances SET is_updating=2 WHERE instance_id in ($ins)");
                }
            }
        }
        if (!empty($newInstanceIds)) {
            $affectedInsts = array_merge($affectedInsts, $newInstanceIds);
            $affectedInsts = array_unique($affectedInsts);
            $affectedCount = count($affectedInsts);
        }
    }
}
$jsonOutput['affectedTdbCount'] = $affectedCount;
echo json_encode($jsonOutput);
?>