<?php
$pathRoot = '../../';
$pathBase = '../';
$use_angular = true;
$angularFiles = array("ng-pagination.js", "angular-filter.js", "clem-filter.js", "ui-bootstrap-tpls.min.js", "ng-file-upload-shim.js", "ng-file-upload.js","angular-vertilize.js", "repository.js");

require_once $pathBase . 'header.php';
$accessParams = array("repository" => array("A", "M", "BM"));
$cond = $currentUser->checkAccess("read_repository", $accessParams);
if (!$cond) {
    include_once $pathBase . 'common_scripts/authorisation_error.php';
    require_once $pathBase . 'footer.php';
    die;
}
?>
<div class="container-fluid clear" style="overflow-x: hidden">
    <div class="row">
        <div class="col-sm-12" ng-view></div>
    </div>
</div>
<?php require_once $pathBase . 'footer.php'; ?>