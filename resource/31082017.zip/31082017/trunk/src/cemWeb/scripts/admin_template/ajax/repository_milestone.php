<?php

ini_set("memory_limit", "-1");
set_time_limit(0);
session_start();
$pathBase = '../../';
$pathRoot = $pathBase . '../../';

$pathRoot = str_replace("scripts/admin_template/ajax", "", dirname(__FILE__));
$pathBase = $pathRoot . "scripts/";
require_once $pathRoot . 'libraries/classes/class_connexion_mysql.php';
require_once $pathBase.'common_scripts/datetime_functions.php';
require_once $pathBase.'common_scripts/FormatStringForDB.php'; 
$cnx = new connexion_db($pathBase);
$request = new requete("SELECT 1", $cnx->num);
require_once $pathRoot . 'libraries/classes/models/coreModel.php';
require_once $pathRoot . 'libraries/classes/models/RepositoryModel.php';
$post_vars = file_get_contents("php://input");
$post_vars = get_object_vars(json_decode($post_vars));
$action = isset($post_vars['action']) ? $post_vars['action'] : '';
$alerts = array("info" => array(), "error" => array(), "success" => array());
$json = array("success" => 1, "alerts" => $alerts);
$repositoryId = !empty($post_vars['repository_id']) ? $post_vars['repository_id'] :$_SESSION['current_repository_id'];
$repository = new RepositoryModel($repositoryId);
if(empty($_SESSION['current_repository_id'])){
    $_SESSION['current_repository_id'] = $repositoryId;
}
if(empty($_SESSION['current_repository_id']) && !empty($post_vars['revision_id'])){
    $_SESSION['displayed_repository_revision_id'] = $post_vars['revision_id'];
}

switch ($action) {
    case "getItem":
        
        $json['repositoryMile'] = $repository->getRepositoryMileinfo($post_vars['milestone_id']);
        break;
    case "saveItem":
        $postData = $post_vars;
        $table = "tb_repositories_milestones";
        $formFields = array("milestone_name_en", "milestone_name_fr", "milestone_definition_en",
            "milestone_definition_fr", "milestone_expectation_fr", "milestone_expectation_en", "milestone_title_fr", "milestone_title_en",
            "milestone_rpif_reference", "milestone_aer_reference");
        $condnFields = array("repository_milestone_id", "repository_revision_id_fk");
        if (!empty($postData['repository_milestone_id'])) {
            $fieldValues = array();
            foreach ($formFields as $field) {
                $fieldValues[] = "$field ='" . $postData[$field] . "'";
            }
            $fieldValues = implode(',', $fieldValues);
            $condnValues = array();
            foreach ($condnFields as $field) {
                $condnValues[] = "$field ='" . $postData[$field] . "'";
            }
            $condnValues = implode(" and ", $condnValues);
            $query = "update $table set " . $fieldValues . " where " . $condnValues;
        } else {
            $fieldValues = array();
            foreach ($formFields as $field) {
                $fieldValues[] = $postData[$field];
            }
            $formFields[] = "repository_revision_id_fk";
            $fieldValues[] = $postData['repository_revision_id'];
            $request->envoi("SELECT COUNT(*) AS nb FROM tb_repositories_milestones WHERE repository_revision_id_fk=" . $postData['repository_revision_id']);
            $nb_milestones = $request->recup_objet();
            $formFields[] = "milestone_order";
            $fieldValues[] = $nb_milestones->nb+1;
            $formFields[] = "father_id";
            $fieldValues[] = 0;
            $request->envoi("SELECT MAX(milestone_reference_id) AS max FROM tb_repositories_milestones");
            $referenceID = $request->recup_objet();
            $formFields[] = "milestone_reference_id";
            $fieldValues[] = $referenceID->max+1;
            $query = " insert into $table (" . join(',', $formFields) . ") values ('" . join("','", $fieldValues) . "')";
        }
        $request->envoi($query);
        break;
    case "updateOrder":
        $table = "tb_repositories_milestones";
        $condnFields = array("repository_milestone_id" => "milestone_id", "repository_revision_id_fk" => "revision_id");
        $orderValue = ($post_vars['move'] == 'up') ? (int) $post_vars['order'] + 1 : (int) $post_vars['order'] - 1;
        $fieldValues = "milestone_order =" . $orderValue;
        $condnValues = array();
        foreach ($condnFields as $field => $pass) {
            $condnValues[] = "$field ='" . $post_vars[$pass] . "'";
        }
        $condnValues = implode(" and ", $condnValues);
        $query = "update $table set milestone_order = " . $post_vars['order'] . " where repository_revision_id_fk =
               " . $post_vars["revision_id"] . " and milestone_order = $orderValue";
        $request->envoi($query);

        $query = "update $table set " . $fieldValues . " where " . $condnValues;
        $request->envoi($query);


        break;
    case "copy":
        $newDataIds = array();
        if ($post_vars['model'] == 'topic') {
            $activity_order = 0;
            $request->envoi('SELECT MAX(activity_order) AS max_order FROM tb_repositories_activities WHERE repository_result_id_fk=' . $post_vars['model_id']);
            $request->calc_nb_elt();
            if ($request->nb_elt != 0) {
                $request->recup_objet();
                $activity_order = $request->objet->max_order;
            }
            $request->envoi("SELECT MAX(activity_reference_id) AS max FROM tb_repositories_activities");
            $referenceActivityID = $request->recup_objet();
            $referenceID = $referenceActivityID->max;
            $activityData = $post_vars['activity'];
            foreach ($activityData as $activity) {
                $referenceID++;
                $activity_order++;
                $request->envoi('INSERT INTO tb_repositories_activities (repository_revision_id_fk, repository_result_id_fk, name_fr, name_en, description_fr, description_en,activity_order,activity_deliverable_id_fk,activity_subject_id_fk,activity_reference_id) 
                        (SELECT repository_revision_id_fk,' . $post_vars['model_id'] . ", name_fr,name_en,description_fr,description_en," . $activity_order . ',activity_deliverable_id_fk,activity_subject_id_fk,' . $referenceID . ' from tb_repositories_activities where repository_activity_id =' . $activity->repository_activity_id . ' )');
                $id_new = $request->insert_id();
                $request->envoi('INSERT INTO tb_repositories_activities_stakeholder_roles (repository_activity_id_fk,role_id_fk,is_leader,repository_revision_id_fk)  ( select ' . $id_new . ',role_id_fk,is_leader,repository_revision_id_fk from tb_repositories_activities_stakeholder_roles where repository_activity_id_fk =' . $activity->repository_activity_id . ')');
                $newDataIds[] = $id_new;
            }
        }
        if ($post_vars['model'] == 'milestone') {
            $activityData = $post_vars['activities'];
            $resultData = array();
            foreach ($activityData as $activity) {
                $resultData[$activity->repository_result_id][] = $activity->repository_activity_id;
            }
  
            if (!empty($resultData)) {
                $result_order = 0;
                $request->envoi('SELECT MAX(result_order) AS max_order FROM tb_repositories_results WHERE repository_milestone_id_fk=' . $post_vars['model_id']);
                $request->calc_nb_elt();
                if ($request->nb_elt != 0) {
                    $request->recup_objet();
                    $result_order = $request->objet->max_order;
                }

                $request->envoi("SELECT MAX(result_reference_id) AS max   FROM tb_repositories_results");
                $referenceResultID = $request->recup_objet();
                $resultRef = $referenceResultID->max;

                $request->envoi("SELECT MAX(activity_reference_id) AS max FROM tb_repositories_activities");
                $referenceActivityObj = $request->recup_objet();
                $referenceID = $referenceActivityObj->max;

                foreach ($resultData as $resultId => $activity) {
                    $resultRef++;
                    $result_order++;
                    $request->envoi("INSERT INTO tb_repositories_results (SELECT 0,repository_revision_id_fk,".$post_vars['model_id'].",result_name_fr,result_name_en,
                                         '" . $_SESSION['ipn'] . "', '" . todayDashFormatted() . "', result_process_id_fk, 
                                father_id,result_link_to_more_infos," . $result_order . "," . $resultRef . ",0,0 
                      FROM tb_repositories_results WHERE repository_result_id=$resultId)");
                    $id_new = $request->insert_id();
                    $activity_order = 0;
                    foreach ($activity as $actId) {
                        $activity_order++;
                        $referenceID++;
                        $request->envoi("INSERT INTO tb_repositories_activities (repository_revision_id_fk, repository_result_id_fk, name_fr, name_en, description_fr, description_en,activity_order,activity_deliverable_id_fk,activity_subject_id_fk,activity_reference_id) 
                        (SELECT repository_revision_id_fk, $id_new, name_fr,name_en,description_fr,description_en, $activity_order ,activity_deliverable_id_fk,activity_subject_id_fk,' . $referenceID . ' from tb_repositories_activities where repository_activity_id =$actId )");
                        $id_new_activity = $request->insert_id();
                        $request->envoi("INSERT INTO tb_repositories_activities_stakeholder_roles (repository_activity_id_fk,role_id_fk,is_leader,repository_revision_id_fk)  ( select $id_new_activity ,role_id_fk,is_leader,repository_revision_id_fk from tb_repositories_activities_stakeholder_roles where repository_activity_id_fk =$actId)");
                        $request->envoi('INSERT INTO tb_repositories_activities_rpif_link '
                                . '(SELECT NULL, ' . $id_new_activity . ',activity_rpif_link,repository_revision_id_fk, NOW(), \'' . $_SESSION['ipn'] . '\' '
                                . 'FROM tb_repositories_activities_rpif_link '
                                . 'WHERE repository_activity_id_fk=' . $actId . ')');
                        $newDataIds[] = $id_new_activity;
                    }
                }
            }
        }
        $json['resultData'] = $repository->getRepositoryactivites($newDataIds);
        break;
    case 'reorder_activities':
        $revision_id = $post_vars['revision_id'];
        // get all activities for the template revision
        $request->envoi("SELECT repository_activity_id,repository_result_id_fk FROM tb_repositories_activities WHERE is_delete = 0 and repository_revision_id_fk=$revision_id ORDER BY repository_result_id_fk,activity_order");
        $request->calc_nb_elt();
        if ($request->nb_elt != 0) {
            $activities_list = $request->recup_array_champ();
            $curseur_result = 0;
            for ($i = 0; $i < count($activities_list); $i++) {
                if ($curseur_result != $activities_list[$i]['repository_result_id_fk']) {
                    $cpt = 1;
                    $curseur_result = $activities_list[$i]['repository_result_id_fk'];
                }
                $request->envoi('UPDATE tb_repositories_activities SET activity_order=' . $cpt . ' WHERE repository_activity_id=' . $activities_list[$i]['repository_activity_id']);
                $cpt++;
            }
        }
        break;

    case 'reorder_results':
        $revision_id = $post_vars['revision_id'];
        // get all results for the template revision
        $request->envoi("SELECT repository_result_id,repository_milestone_id_fk FROM tb_repositories_results WHERE is_delete = 0 and repository_revision_id_fk= $revision_id ORDER BY repository_milestone_id_fk,result_order");
        $request->calc_nb_elt();
        if ($request->nb_elt != 0) {
            $results_list = $request->recup_array_champ();
            $curseur_milestone = 0;
            for ($i = 0; $i < count($results_list); $i++) {
                if ($curseur_milestone != $results_list[$i]['repository_milestone_id_fk']) {
                    $cpt = 1;
                    $curseur_milestone = $results_list[$i]['repository_milestone_id_fk'];
                }
                echo $cpt;
                $request->envoi('UPDATE tb_repositories_results SET result_order=' . $cpt . ' WHERE repository_result_id=' . $results_list[$i]['repository_result_id']);
                $cpt++;
            }
        }
        break;

    case 'reorder_milestones':
        $revision_id = $post_vars['revision_id'];
        // get all activities for the template revision
        $request->envoi("SELECT repository_milestone_id FROM tb_repositories_milestones WHERE is_delete = 0 and repository_revision_id_fk=$revision_id ORDER BY milestone_order");
        $request->calc_nb_elt();
        if ($request->nb_elt != 0) {
            $cpt = 1;
            $milestones_list = $request->recup_array_mono();
            for ($i = 0; $i < count($milestones_list); $i++) {
                $request->envoi("UPDATE tb_repositories_milestones SET milestone_order= $cpt WHERE repository_milestone_id=" . $milestones_list[$i]);
                $cpt++;
            }
        }
        break;
    case 'deleteMilestone':
        $revision_id = $post_vars['revision_id'];
        $milestone_id = $post_vars['milestone_id'];
        // delete milestone   		    
        $request->envoi("Update tb_repositories_milestones set is_delete = '1' WHERE repository_revision_id_fk= $revision_id AND repository_milestone_id=$milestone_id");
        $request->envoi("DELETE FROM tb_repositories_template_constitution_milestones WHERE revision_id_fk= $revision_id AND milestone_id_fk=$milestone_id");
    case'repository':
        $json['repository'] = $repository->getRepositoryVersionInfo($post_vars['revision_id']);
        break;
    case'milestones':
        $json['milestones'] = $repository->getRepositoryVersionMiles($post_vars['revision_id']);
        break;
    case'miledata':
        $json['miledata']['results'] = $repository->getRepositoryresults($post_vars['revision_id']);
        $json['miledata']['activities'] = $repository->getRepositoryActivities($post_vars['revision_id']);
        break;    
    case"list":
    default:
        $json['repMilestones'] = $repository->getRepositoryVersionMiles($post_vars['revision_id']);
        break;
}
header('Content-Type: application/json');
echo json_encode($json);