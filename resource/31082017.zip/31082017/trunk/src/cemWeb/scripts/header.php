<?php
/**
 * The script displays the HTML header and the standard header for all pages
 * 
 * PHP version 5
 * 
 * @category Header
 * @package  Scripts
 * @author   Charles Santucci <charles.santucci@renault.com>
 * @license  http://www.php.net/license/3_0.txt  PHP License 3.0
 * @link     http://baselinesvn.mc2.renault.fr:9090/svn/svn61281
*/

//error_reporting(E_ALL);
session_start();
ini_set("memory_limit","-1");
set_time_limit(0);
if(empty($_SESSION['SAVE_ALERT'])){
    $_SESSION["SESSION_TIMEOUT"] = time();
}
// traitement de la variable de langue  
if($dashboard_init && isset($_REQUEST['dashboard_id'])) {
    $_SESSION['dashboard_id'] = $_REQUEST['dashboard_id']; 
}
if(isset($_REQUEST['langue']))
{
  $_SESSION['language']=$_REQUEST['langue'];
}   
if(!isset($_SESSION['language']))
{
  $_SESSION['language']='fr';
}   
if (isset($_REQUEST['repository_id']) && isset($_GET['selected_revision_id']))
{
        $_SESSION['current_repository_id']=$_REQUEST['repository_id'];        
}

// default path to root
if (!isset($pathBase))
{  
  $pathBase='./'; 
}
if (!isset($pathRoot))
{  
  $pathRoot='../'.$pathBase; 
}
if (!isset($pathPictures))
{  
  $pathPictures=$pathRoot.'images/';
}
if (!isset($pathGenXls))
{ 
  $pathGenXls=$pathBase.'generation_excel/'; 
}  
if (!isset($pathGenPdf))
{ 
  $pathGenPdf=$pathBase.'generation_pdf/'; 
}  
if (!isset($pathGenPic))
{  
  $pathGenPic=$pathBase.'generation_images/'; 
}  

$pathData='data/';

// traitement de la variable de langue  

$displayHeader = !isset($remove_header_html) || !$remove_header_html;
$needJson = isset($needJson) && $needJson;
// renvoi vers la page d'index si la session ne comprend pas d'identifiant IPN
if (!isset($_SESSION['ipn'])) {
    if ($needJson) {
        $json = array("success" => 0, "message" => "");    
        header("Content-Type: text/json");
        echo json_encode($json);
        die;
    } else {
        header('location: '.$pathBase.'index.php');    
        exit;
    }
}


// recup�ration du nom du script execut�
  $nom_script_avec_chemin=substr($_SERVER['SCRIPT_NAME'],0,strlen($_SERVER['SCRIPT_NAME'])-4);
  $pos=strrpos($nom_script_avec_chemin,'/');
  $nom_script=substr($nom_script_avec_chemin,$pos+1);
  
// inclusion des classes standards
require_once $pathRoot.'libraries/classes/class_connexion_mysql.php';
require_once $pathRoot.'libraries/classes/class_arca.php';
require_once $pathRoot.'libraries/classes/class_filters.php';
require_once $pathRoot.'libraries/phplibs/error_handler.php';
// inclusion des libraries standards
require_once $pathBase.'common_scripts/datetime_functions.php';
require_once $pathBase.'common_scripts/url_functions.php';
require_once $pathBase.'common_scripts/sortColumn.php';
require_once $pathBase.'common_scripts/get_parameter.php';
require_once $pathBase.'common_scripts/FormatStringForDB.php';  
require_once $pathBase.'common_scripts/userIsRepositoryManager.php';

// inclusion des fichiers de langue standards
require_once $pathRoot.'messages/'.$_SESSION['language'].'/standard.msg';
   
// inclusion du fichier de langue seifique � la page   
if (file_exists($pathRoot.'messages/'.$_SESSION['language'].'/'.$nom_script.'.msg'))
{
  include_once $pathRoot.'messages/'.$_SESSION['language'].'/'.$nom_script.'.msg';
}	

require_once $pathBase.'common_scripts/status_data.php';

$cnx=new connexion_db($pathBase);
$delayMsg=1500;
$request = new requete("SELECT 1", $cnx->num);
require_once $pathRoot.'libraries/classes/models/coreModel.php';
require_once $pathRoot.'libraries/classes/models/UtilisateurModel.php';
$currentUser = new UtilisateurModel($_SESSION['ipn']);


if(!$currentUser->checkAccess('super_admin') && file_exists($pathRoot . "maintenance.flag")) {
    if ($needJson) {
        $json = array("success" => 0, "message" => "");    
        header("Content-Type: text/json");
        echo json_encode($json);
        die;
    } else {
        header('location: '.$pathBase.'maintenance.php');    
        exit;
    }
}
   
if($displayHeader) {
// script de gestion des variables de session
require_once $pathBase.'manage_session.php';
require_once $pathBase.'menus_level1.php';
require_once $pathBase.'menus_level2.php';

if(!empty($exchange_form_page) && $exchange_form_page && !$currentUser->haveAccess()) {
    $exg_menu1 = array();
    $exg_menu1['home'] = $tableMenusN1['home'];
    $exg_menu1['home']['file'] = '';
    
    $tableMenusN22 = array();$cpt=0;
    $request = new requete("SELECT exchange_no,leader_ipn,contributor_ipn FROM tb_exchange_form "
            . "WHERE exchange_form_id  = '".$_SESSION['exgformid']."'", $cnx->num);
    $exForm = $request->recup_objet(); 
    if(!empty($_SESSION['language']) && $_SESSION['language']=='fr'){
        $tableMenusN22[$cpt]['name']= ('Fiche navette n°-'.$dashboard_id.'-'.$exForm->exchange_no);
    }else{
        $tableMenusN22[$cpt]['name']='CLEM-'.$dashboard_id.'-Form-'.$exForm->exchange_no;
    }
    $tableMenusN22[$cpt]['display']  =true;
    $tableMenusN22[$cpt]['file']='';
    
    $tableMenusN22[$cpt++]['rights']=array();
    
    $tableMenusN1 = $exg_menu1;
} else {
    while ($menu_item_n1=each($tableMenusN1)) {
        $display_item = true;
        if(!empty($menu_item_n1[1]['rights'])) {
            foreach($menu_item_n1[1]['rights'] as $keyword) {
                $params = isset($menu_item_n1[1]['params'])?$menu_item_n1[1]['params']:array();
                $display_item = $currentUser->checkAccess($keyword, $params);
                if($display_item) {
                    break;
                }
            }
        } else if(isset($menu_item_n1[1]['need_access']) && $menu_item_n1[1]['need_access']){
            $display_item = $currentUser->haveAccess();
        }
        if (!$display_item) {
            unset($tableMenusN1[$menu_item_n1[0]]);
        }
    }
    reset($tableMenusN1);

    if(!isset($tableMenusN1[$_SESSION['menu_n1']])) {
        unset($_SESSION['menu_n1']);
        $_SESSION['menu_n2']=-1;
        header('location: '.$pathBase.'index.php');    
        exit;
    }

    while ($menu_item_n2=each($tableMenusN22)) {
        $display_item = true;
        if(!empty($menu_item_n2[1]['rights'])) {
            foreach($menu_item_n2[1]['rights'] as $keyword) {
                $params = isset($menu_item_n2[1]['params'])?$menu_item_n2[1]['params']:array();
                $display_item = $currentUser->checkAccess($keyword, $params);
                if($display_item) {
                    break;
                }
            }
        }

        if (!$display_item) {
            unset($tableMenusN22[$menu_item_n2[0]]);
        }
    }
    reset($tableMenusN22);
}
}

// Operations to do before displaying HTML 
switch($_REQUEST['action'])
{
  // These cases are treated for the portfolio management menu of the portal
  case 'delete_project_from_portfolio':
    // no need to confirm since no data is deleted, project can be added to portfolio anytime
    $request=new requete("DELETE FROM tb_portfolios WHERE portfolio_project_id_fk=".$_REQUEST['project_to_remove']." AND ipn='".$_SESSION['ipn']."'",$cnx->num);	    
    // Count the projects in the portfolio
    $request->envoi("SELECT portfolio_project_id_fk FROM tb_portfolios WHERE ipn='".$_SESSION['ipn']."'");
    $request->calc_nb_elt();
    // If there is none, de-activate the portfolio
    $displayMsgPortfolioDesactivated=false;
    if ($request->nb_elt==0)
    {
      $_SESSION['portfolio_status']=false;
      // Get status of portfolio. If active, display the message of desactivation.
      $request->envoi("SELECT portfolio_status FROM tb_users_data WHERE ipn='".$_SESSION['ipn']."'");
      $request->recup_objet();
      if ($request->objet->portfolio_status==1)
      {
        $displayMsgPortfolioDesactivated=true;
      }	 
      $request->envoi("UPDATE tb_users_data SET portfolio_status=0 WHERE ipn='".$_SESSION['ipn']."'");	 
    }
  break;  

  case 'desactive_portefeuille':
    $_SESSION['portfolio_status']=false;
    $request=new requete("UPDATE tb_users_data SET portfolio_status=0 WHERE ipn='".$_SESSION['ipn']."'",$cnx->num);
  break;
	  
  case 'active_portefeuille':
    $_SESSION['portfolio_status']=true;	  
    $request=new requete("UPDATE tb_users_data SET portfolio_status=1 WHERE ipn='".$_SESSION['ipn']."'",$cnx->num);	     
    // mise ? z?ro des autres variables de sessions de p?rim?tre (domaine et departement)
    unset($_SESSION['filtre_domaine']);
    unset($_SESSION['filtre_dept']);		
    unset($_SESSION['application_id']);				
    unset($_SESSION['campagne_id']);     						
	break;

  case 'erase_portfolio':
    // empty portfolio
    $request=new requete("DELETE FROM tb_portfolios WHERE ipn='".$_SESSION['ipn']."'",$cnx->num);
    $request=new requete("UPDATE tb_users_data SET portfolio_status=0 WHERE ipn='".$_SESSION['ipn']."'",$cnx->num);
    $_SESSION['portfolio_status']=false;
  break;	
	
}	
if($displayHeader) {
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link rel="stylesheet" type="text/css" href="<?php echo $pathRoot;?>css/bootstrap/css/bootstrap.min.css" />
    <link href="<?php echo $pathRoot?>css/corp.css?t=<?php echo time(); ?>" rel="stylesheet" type="text/css" />	
    <link href="<?php echo $pathRoot?>css/global.css?t=<?php echo time(); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo $pathRoot?>css/formulaire.css" rel="stylesheet" type="text/css" />	
    <link href="<?php echo $pathRoot?>css/checklist.css" rel="stylesheet" type="text/css" />		
    <link href="<?php echo $pathRoot?>css/print.css" rel="stylesheet" type="text/css"  media="print" />
    <link href="<?php echo $pathRoot?>css/masque.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo $pathRoot?>css/filtre.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo $pathRoot?>css/infobulle.css" rel="stylesheet" type="text/css" />	
    <link href="<?php echo $pathRoot?>css/graphique.css" rel="stylesheet" type="text/css" />		
    <link href="<?php echo $pathRoot?>css/onglet.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo $pathRoot?>css/graal.css" rel="stylesheet" type="text/css" />	    		
    <link rel="stylesheet" type="text/css" href="<?php echo $pathRoot;?>css/smoothness/jquery.ui.min.css" />   			
    <link rel="stylesheet" type="text/css" href="<?php echo $pathRoot;?>css/smoothness/jquery.ui.theme.css" />   
      
    
        
    <title><?php echo $nom_modules['graal'].' - '.$descriptions_modules['graal'];?></title>

    <script type="text/javascript" src="<?php echo $pathRoot; ?>js/jquery-1.9.1.js"></script>
    <script type="text/javascript" src="<?php echo $pathRoot;?>js/jquery-ui-1.10.3.custom.min.js"></script>
    
    <?php if(isset($use_high_chart) && $use_high_chart) { ?>
    <script type="text/javascript" src="<?php echo $pathRoot; ?>js/highchart/highcharts.js"></script>
    <script type="text/javascript" src="<?php echo $pathRoot; ?>js/highchart/exporting.js"></script>
    <?php } ?>
    
    <?php //if(isset($jsDataTable) && $jsDataTable) { ?>
    <script type="text/javascript" src="<?php echo $pathRoot; ?>js/jquery.dataTables.min.js"></script>
    <?php //} ?>
    <?php if(isset($use_angular) && $use_angular) { ?>
    <script type="text/javascript" src="<?php echo $pathRoot; ?>js/angular.min.js"></script>
    <script type="text/javascript" src="<?php echo $pathRoot; ?>js/angular-route.min.js"></script>
    <?php if(!empty($angularFiles)){foreach($angularFiles as $angularFile) { ?>
    <script type="text/javascript" src="<?php echo $pathRoot; ?>js/<?php echo $angularFile; ?>"></script>
    <?php }} ?>
    <?php } ?>
    <?php /**
    Lot 1620 Changes
    Add Multiselect for project and sub-family selection
    Modified By : Venkatesh Periyasamy
    **/ ?>
    <?php if(isset($use_multi_select) && $use_multi_select) { ?>
    <script type="text/javascript" src="<?php echo $pathRoot; ?>js/multiselect.js"></script>    
    <?php } ?>
    <?php /** End **/ ?>
    
    <script language="JavaScript">
         inclusion_main='<script language="JavaScript" src="<?php echo $pathRoot ?>js/main.js.php"><\/script>';
         document.write(inclusion_main);
    </script>
  
<?php
  if (file_exists($pathRoot."js/".$nom_script.".js.php"))
  {?>
     <script language="JavaScript">
       lignehtml='<script language="JavaScript" src="<?php echo $pathRoot ?>js/<?php echo $nom_script?>.js.php"><\/script>';
       document.write(lignehtml);
     </script><?php
  } ?>
</head>		
<body class="env-<?php echo strtolower($SERVER_ENV); ?>"  ng-app="agCem">
<div style='display:none' id="pathbase"><?php echo $pathBase;?></div><?php
//Assign the Page Load Time
// gestion des arguments 
$arguments=str_replace('&','&amp;',$_SERVER['QUERY_STRING']);
$arguments=str_replace('&amp;langue=fr','',$arguments);
$arguments=str_replace('&amp;langue=en','',$arguments);
$arguments = str_replace('&amp;action=duplicate','',$arguments);
$arguments = str_replace('&amp;action=update','',$arguments);

$arguments=str_replace('langue=fr','',$arguments);
$arguments=str_replace('langue=en','',$arguments);
$arguments = str_replace('action=duplicate','',$arguments);
$arguments = str_replace('action=update','',$arguments);

if ($arguments!='')
{  
  $arguments.='&amp;'; 
}
$targetFileLanguage=$_SERVER['SCRIPT_NAME'].'?'.$arguments.'langue=';?>

<div id="RnoPage" class="RnoLayout-1col">    
    
<div id="menuFloatable">
    <div id="RnoGlobalLinksTop">
        <div class="RnoGlobalLinks2">
            <div class="RnoUserNameProfile"><?php echo $_SESSION['nom'];?></div>
            <div class="RnoConnexion"> | 
                <a href="<?php echo $pathBase?>index.php?connexion=off"><?php echo $lien_quitter?></a>
                <?php if(!empty($_SESSION['orgIPN']) && $_SESSION['ipn'] != $_SESSION['orgIPN']){ ?>
                 <a href="<?php echo $pathBase?>admin_global/user.php?action=change"> <?php echo $_SESSION['orgIPN']; ?></a>
                 <?php } ?>
            </div>
            <div class="clearleft"></div>
        </div>
        <?php
            $helpUrl = $pathRoot . "docs/user_guide_fr.pptx";
            if($_SESSION['language'] == 'en') {
                $helpUrl = $pathRoot . "docs/user_guide_en.pptx";
            }
        ?>
        <!-- Global Links Top -->
        <div class="RnoGlobalLinks">		
            <p id="flags"><a href="<?php echo $targetFileLanguage?>fr" ><img src="<?php echo $pathPictures?>flags/fr.png" alt=""/></a>
                <a href="<?php echo $targetFileLanguage?>en"><img src="<?php echo $pathPictures?>flags/en.png" alt="" /></a></p>
             <p class="RnoLinks">
            <?php if(!$currentUser->haveAccess()) { ?>
            | <a href="<?php echo $pathBase?>plan.php?menu_n1=plan&amp;menu_n1=<?php echo $_SESSION['menu_n1'];?>"><?php echo $lien_plan?></a> 
            <?php } ?>
                | <a href="javascript:void(0);" onclick="javascript:glossary('<?php echo $pathBase; ?>')" ><?php echo $lien_glossary?></a> 
                | <a href="<?php echo $helpUrl;?>" target="_ext_help"><?php echo $lien_aide?></a></p>			
        </div>
    </div>		
    <div id="RnoBranding" class="sc"> 
        <span  id="RnoLogo"><a href="<?php echo $pathBase ?>my_boards.php?&menu_n1=home"><img src="<?php echo $pathPictures?>logos/logo.png" /></a></span>
        <h1 id="RnoApplicationName">
            <?php
                echo $nom_modules['graal'];
                if($SERVER_ENV == "DEV"  || $SERVER_ENV == "INT" || $SERVER_ENV == "ACCEPTANCE") {
                    echo " - " . strtoupper($SERVER_ENV);
                }
            ?>
        </h1>
        <h2 class="RnoSubTitle"><?php echo $descriptions_modules['graal'];?></h2>	
    </div>
 	
    <?php
        // Build menus
        $menu_selected=$nom_script;
    ?>

    <!-- LEVEL 1 MENUS !-->
    <div id="RnoNav1Top" class="RnoNav1"> 
        <ul>
        <?php
            while ($menu_item_n1=each($tableMenusN1)) { ?>
                <li class="RnoNav1<?php if ($_SESSION['menu_n1']==$menu_item_n1[0]) { echo 'Selected';} else { echo 'Enabled';}?>">
                    <?php if(!empty($menu_item_n1[1]['file'])){ ?>
                    <a href="<?php echo $pathBase.addParamUrl($menu_item_n1[1]['file'],'&amp;menu_n1='.$menu_item_n1[0]);?>">
                        <?php echo $menu_item_n1[1]['name'][$_SESSION['language']];?>
                    </a>
                    <?php } else { ?>
                        <a href="javascript:void(0);return false;"><?php echo $menu_item_n1[1]['name'][$_SESSION['language']];?></a>
                    <?php } ?>
                </li>
            <?php }
            reset($tableMenusN1);
        ?>  
        </ul>
    </div>

    <!-- LEVEL 2 MENUS !-->
    <?php if (count($tableMenusN22)>0) { ?>
        <div id="RnoNav2Top" class="RnoNav2">
            <ul>
            <?php
                while ($menu_item_n2=each($tableMenusN22)) {
                    $displayClass = !($menu_item_n2['1']['display']) ? 'displyHide' : '';
            ?>
                <li class="<?php echo $displayClass; ?> RnoNav2<?php if ($menu_item_n2[0]==$_SESSION['menu_n2']) { echo 'Selected';} else { echo 'Enabled';}?>">
                    <?php if(!empty($menu_item_n2[1]['file'])){ ?>
                        <a href="<?php echo $pathBase.addParamUrl($menu_item_n2[1]['file'],'&amp;menu_n1='.$_SESSION['menu_n1'].'&amp;menu_n2='.$menu_item_n2[0]);?>"><?php echo $menu_item_n2[1]['name'];?></a>
                    <?php } else { ?>
                        <a href="javascript:void(0);return false;"><?php echo $menu_item_n2[1]['name'];?></a>
                    <?php } ?>
                </li>
            <?php }  ?>
            </ul>
        </div>
    <?php } ?>
</div>
    
  <div id="RnoBody">        
   <div id="RnoMainContent"> 
        
<?php }