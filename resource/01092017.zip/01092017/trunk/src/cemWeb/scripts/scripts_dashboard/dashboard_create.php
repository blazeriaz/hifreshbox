<?php
// 
/**
 * The script allows to select all data for the creation of a TdB
 * 
 * PHP version 5
 * 
 * @category DashboardManagement
 * @package  DashboardScripts
 * @author   Charles Santucci <charles.santucci@renault.com>
 * @license  http://www.php.net/license/3_0.txt  PHP License 3.0
 * @link     http://baselinesvn.mc2.renault.fr:9090/svn/svn61281
 */
$pathBase = '../';
$pathRoot = '../' . $pathBase;
/**
  Lot 1620 Changes
  Add variable to attach the script of multiselect in header.php
  Modified By : Venkatesh Periyasamy
 * */
$use_multi_select = true;
$use_angular = true;
$angularFiles = array("app.js");
$creatTdb = false;
$repHasSubfamily = false;
$repHasProjectContext = false;
/** END * */
$pathGenPdf = $pathBase . 'generation_pdf/';
require_once $pathBase . 'header.php';
require_once $pathRoot . 'libraries/fpdf/fpdf.php';
require_once $pathRoot . 'libraries/classes/class_pdf_standard_table.php';
$targetFile = 'dashboard_generator.php?';

$accessUniverses = $currentUser->getAccessUniverse("create_dashboard");
if (!$accessUniverses || empty($accessUniverses)) {
    include_once $pathBase . 'common_scripts/authorisation_error.php';
    require_once $pathBase . 'footer.php';
    die;
}
?>
<script type="text/javascript">
    var gesperClassData = <?php echo json_encode($text_class_data); ?>;
    var typo_definition =  {
            "T1":"<?php echo $text_qa_proposed_typo1_definition;?>",
            "T2":"<?php echo $text_qa_proposed_typo2_definition;?>",
            "T3":"<?php echo $text_qa_proposed_typo3_definition;?>",
            "T4":"<?php echo $text_qa_proposed_typo4_definition;?>",
            "T5":"<?php echo $text_qa_proposed_typo5_definition;?>",
            "T6":"<?php echo $text_qa_proposed_typo6_definition;?>"}; 
</script>
<div ng-controller="tdbCreateController as tdb" class="container" style="width: 100%; margin:2rem 0;" ng-cloak>
    <?php
    $sqlRepositories = "SELECT tb_universe.name, repository_id,repository_name_" . $_SESSION['language'] . " AS repository_name "
            . "FROM tb_repositories,tb_repositories_versions,tb_universe "
            . "WHERE repository_id = repository_id_fk AND tb_universe.id = universe_id_fk "
            . "AND is_deleted = '0' AND version_status = 'ACT' and repository_allow_tdb_creation=1 ";

    if ($accessUniverses[0] != "all") {
        $sqlRepositories .= "AND universe_id_fk IN (" . join(",", $accessUniverses) . ") ";
    }

    $sqlRepositories .= "ORDER BY tb_universe.name ASC, repository_name_" . $_SESSION['language'] . " ASC";

    $request = new requete($sqlRepositories, $cnx->num);
    $repositories = $request->recup_array_key(true);

    if (!empty($repositories)) { ?>
    <ul class="nav nav-pills" ng-class="nav_style">
        <li class="nav-item">
            <button style="width:100%;" class="btn btn-secondary nav-link" 
                    ng-class="{active:step === 1}" ng-click="step=1;submit=false;"><?php echo $text_repository; ?></button></li>
        <li class="nav-item" ng-show="templates.length>0">
            <button style="width:100%;" class="btn btn-secondary nav-link" 
                    ng-class="{active:step === 2}" ng-disabled="step <= 1" ng-click="step=2;submit=false;"><?php echo $text_std_template; ?></button></li>
        <li class="nav-item" ng-show="typologies.length>0">
            <button style="width:100%;" class="btn btn-secondary nav-link" 
                    ng-class="{active:step === 3}" ng-disabled="step <= 2" ng-click="step=3;submit=false;"><?php echo $text_typology; ?></button></li>
        <li class="nav-item" ng-show="projects.length>0">
            <button style="width:100%;" class="btn btn-secondary nav-link" 
                    ng-class="{active:step === 4}" ng-disabled="step <= 3" ng-click="step=4;submit=false;"><?php echo $txt_std_project; ?></button></li>
        <li class="nav-item" ng-show="PjtContexts.length>0">
            <button style="width:100%;" class="btn btn-secondary nav-link" 
                    ng-class="{active:step === 5}" ng-disabled="step <= 4" ng-click="step=5;submit=false;"><?php echo $text_project_context; ?></button></li>
        <li class="nav-item" ng-show="families.length>0">
            <button style="width:100%;" class="btn btn-secondary nav-link" 
                    ng-class="{active:step === 6}" ng-disabled="step <= 5" ng-click="step=6;submit=false;"><?php echo $text_std_family; ?></button></li>
    </ul>
    <form name="createTdb" method="post" novalidate>
        <fieldset ng-show="step == 1" ng-form="step1Form">
            <div class="alert alert-info" role="alert"><?php echo $msg_select_repository; ?></div>
            <div class="form-group row">
                <label class="control-label col-sm-2" for="rep">
                    <?php echo $text_repository; ?> <img src="<?php echo $pathPictures?>pictos/requiredicon.gif" alt=""/> :</label>
                <div class="col-sm-4">
                    <select class="form-control" id="rep" ng-model="repository" name="repository" ng-required='1' ng-change="resetData()">
                        <option value=""></option>
                        <?php foreach ($repositories as $universe_name => $reps) { ?>
                            <optgroup label="<?php echo $universe_name ?>">;
                                <?php foreach ($reps as $rep) { ?>
                                    <option value="<?php echo $rep[1] ?>"><?php echo $rep[2]; ?></option>
                                <?php } ?>
                            </optgroup>            
                        <?php } ?>
                    </select>
                    <div class="alert alert-danger" ng-messages="step1Form.repository.$error" ng-show="step1Form.$submitted && step1Form.repository.$invalid">
                        <span ng-message="required"><?php echo $valid_msg_repo_req; ?></span>
                    </div>
                </div>
            </div>
        </fieldset>
        <fieldset ng-show="step == 2" ng-form="step2Form">            
            <div class="alert alert-info" role="alert"><?php echo $msg_selection_criteres; ?></div>
            <div class="form-group row">
                <label class="control-label col-sm-2" >
                    <?php echo $text_std_template ?> <img src="<?php echo $pathPictures?>pictos/requiredicon.gif" alt=""/> :</label>
                <div class="col-sm-4">
                    <select class="form-control" ng-model="template" name="template" 
                            ng-options="tpl as tpl.tmp for tpl in templates track by tpl.template_id" ng-required='1'>
                        <option  value="" selected="selected"></option>
                    </select>
                    <div class="alert alert-danger" ng-messages="step2Form.template.$error" ng-show="step2Form.$submitted && step2Form.template.$invalid">
                        <span ng-message="required"><?php echo $valid_msg_tpl_req; ?></span>
                    </div>
                </div>
            </div>
        </fieldset>
        <fieldset ng-show="step == 3" ng-form="step3Form"><div ng-controller="typoController">                
            <div class="row">
                <div class="col-sm-7">
                    <div class="row" style="margin-bottom:20px;">
                        <label class="col-sm-5" ng-style="style.align.right"><?php echo $text_gesper_level1_label; ?> : </label>
                        <div class="col-sm-1">
                            <a href="#" class="info_img">
                                <img src="../../images/infos.png"><span><?php echo $text_stake_qutation_tooltip; ?></span></a>
                        </div>
                        <div class="col-sm-1">{{level1_total}}</div>
                        <div class="col-sm-5" ng-style="style.align.left">
                            <span class="number_icon2" ng-if="level1_icon" ng-style="level1_icon.style">{{level1_icon.text}}</span>
                            <div class="graph_css3">
                                <span style="background-color:#00FF00;width:20%;" class="bar intpercent"><?php echo $text_gesper_chart_messages[0]; ?></span>
                                <span style="background-color:#FFBB00;width:23%;" class="bar intpercent"><?php echo $text_gesper_chart_messages[1]; ?></span>
                                <span style="background-color:#FF0000;width:57%;" class="bar intpercent"><?php echo $text_gesper_chart_messages[2]; ?></span> 
                            </div>
                        </div>
                    </div>
                    <div class="row" style="margin-bottom:20px;">
                        <label class="col-sm-5" ng-style="style.align.right"><?php echo $text_gesper_level2_label; ?> : </label>
                        <div class="col-sm-1">
                            <a href="#" class="info_img">
                                <img src="../../images/infos.png"><span><?php echo $text_tech_qutation_tooltip; ?></span></a>
                        </div>
                        <div class="col-sm-1">{{level2_total}}</div>
                        <div class="col-sm-5" ng-style="style.align.left">
                            <span class="number_icon2" ng-if="level2_icon" ng-style="level2_icon.style">{{level2_icon.text}}</span>
                            <div class="graph_css3">
                                <span style="background-color:#00FF00;width:20%;" class="bar intpercent"><?php echo $text_gesper_chart_messages[0]; ?></span>
                                <span style="background-color:#FFBB00;width:23%;" class="bar intpercent"><?php echo $text_gesper_chart_messages[1]; ?></span>
                                <span style="background-color:#FF0000;width:57%;" class="bar intpercent"><?php echo $text_gesper_chart_messages[2]; ?></span> 
                            </div>
                        </div>
                    </div>
                    <div class="row" style="margin-bottom:20px;">
                        <label class="col-sm-5" ng-style="style.align.right"><?php echo $text_gesper_level3_label; ?> : </label>
                        <div class="col-sm-1">&nbsp;</div>
                        <div class="col-sm-1">{{level3_total}}</div>
                        <div class="col-sm-5" ng-style="style.align.left">
                            <span class="number_icon2" ng-if="level3_icon" ng-style="level3_icon.style">{{level3_icon.text}}</span>
                            <div class="graph_css4">
                                <span style="background-color:#00FF00;width:20%;" class="bar intpercent"><?php echo $text_gesper_chart_messages_grad[0]; ?><div></div></span>
                                <span style="background-color:#FFBB00;width:20%;" class="bar intpercent"><?php echo $text_gesper_chart_messages_grad[1]; ?><div>>20</div></span>
                                <span style="background-color:#FF0000;width:20%;" class="bar intpercent"><?php echo $text_gesper_chart_messages_grad[2]; ?><div>>30</div></span>
                                <span style="background-color:#0066FF;width:40%;color:#FFFFFF" class="bar intpercent"><?php echo $text_gesper_chart_messages_grad[3]; ?><div style="color:#FFFFFF">>40</div></span> 
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-5">
                    <div class="row" style="margin-bottom:20px;">
                        <div class="col-sm-8" ng-style="style.align.left">
                            <strong><?php echo $text_proposed_typology; ?> : </strong>
                        </div>
                        <div class="col-sm-1" ng-style="style.align.right" ng-hide="proposedTypology">---</div>
                        <div class="col-sm-1" ng-style="style.align.right" ng-show="proposedTypology"><b>{{proposedTypology.typology}}</b></div>
                        <div class="col-sm-1" ng-style="style.align.right" ng-if="proposedTypology">
                            <a href="#" class="info_img info_left">
                                <img src="../../images/infos.png"><span class="proposed_typo_tooltip">{{proposedTypology.description}}</span></a>
                        </div>
                    </div>
                    <div class="row" style="margin-bottom:20px;">
                        <div class="col-sm-8" ng-style="style.align.left">
                            <strong><?php echo $text_qa_proposed_class; ?> : </strong>
                        </div>
                        <div class="col-sm-1" ng-style="style.align.right" ng-hide="proposedClass">---</div>
                        <div class="col-sm-1" ng-style="style.align.right" ng-show="proposedClass"><b>{{proposedClass}}</b></div>
                        <div class="col-sm-1" ng-style="style.align.right" ng-if="proposedClass">
                            <a href="#" class="info_img info_left">
                                <img src="../../images/infos.png">
                                <span class="proposed_class_tooltip">
                                    <?php echo $text_class_description; ?>: <span>{{proposedDesc.Description}}</span><br> 
                                    <?php echo $text_milestone_name; ?>: <span>{{proposedDesc.Milestone}}</span><br> 
                                    <?php echo $text_checklist; ?>: <span>{{proposedDesc.Checklist}}</span><br> 
                                    <?php echo $text_contribution; ?>: <span>{{proposedDesc.Contribution}}</span><br> 
                                </span>
                            </a>
                        </div>
                    </div>
                    <div class="row" style="margin-bottom:20px;">
                        <div class="col-sm-8" ng-style="style.align.left">
                            <strong><u><?php echo $text_qa_proposed_class_definition; ?> : </u></strong>
                        </div>
                        <div class="col-sm-12">
                            <textarea rows="3" cols="30" ng-model="$parent.gsper_text_comment"></textarea>
                        </div>
                    </div>
                    <div class="row" style="margin-bottom:20px;" ng-if="selectedTypology">
                        <div class="col-sm-8" ng-style="style.align.left">
                            <strong><?php echo $text_selected_typology; ?> : </strong>
                        </div>
                        <div class="col-sm-1" ng-style="style.align.right"><b>{{selectedTypology.typology}}</b></div>
                        <div class="col-sm-1" ng-style="style.align.right">
                            <a href="#" class="info_img info_left">
                                <img src="../../images/infos.png"><span class="proposed_typo_tooltip">{{selectedTypology.description}}</span></a>
                        </div>
                    </div>
                    <div class="row" style="margin-bottom:20px;">
                        <div class="col-sm-12">
                            <button class="btn btn-default" ng-click="prevStep()"><?php echo $txt_std_previous; ?></button>
                            <button class="btn btn-primary" ng-click="$parent.nextStep()" ng-disabled="!proposedTypology">
                                <?php echo $text_validate_typology;?></button>
                            <button type="submit" class="btn btn-default" ng-click="modifyTypo()" ng-disabled="!proposedTypology">
                                <?php echo $text_modifier_typology;?></button>
                        </div>
                    </div>
                </div>
            </div>
            <div style="display:none;" id="modifyTypology" title="<?php echo $text_modifier_typology; ?>">
              <div class="modal-body">
                <div class="form-group row">
                    <label class="control-label col-sm-6" for="rep"><?php echo $text_modifier_typology; ?> :</label>
                    <select class="form-control col-sm-6" ng-model="$parent.selectedTypology"
                            ng-options='ty as ty.typology for ty in typologies track by ty.typology_id'>
                        <option></option>
                    </select>
                </div>
                <div class="col-sm-auto">
                    <button class="btn btn-primary" ng-click="validateTypo()" ng-disabled="!selectedTypology"><?php echo $button_validate; ?></button>
                    <button class="btn btn-primary" ng-click="closeModifyTypo()"><?php echo $button_cancel; ?></button>
                </div>
                </div>
            </div>
            <table border="1px solid black" class="border">
                <tr>
                    <th style="background-color:#CCCCCC;width:436px;text-align: center"><?php echo $text_items; ?></th>
                    <th style="background-color:#CCCCCC;width:120px;text-align: center"><?php echo $text_deviation_quotation; ?></th>
                    <th style="background-color:#CCCCCC;text-align: center"><?php echo $text_quotation; ?></th>
                </tr> 
                <tr>
                    <td colspan="3">
                        <div class="table_wrapper" ng-if="gesperDataGroup"> 
                            <table ng-repeat="gesperGroup in gesperDataGroup">
                                <tbody>
                                    <tr>
                                        <th ng-style="{'background-color':header_color_code[$index]}" colspan="3">
                                            {{$index + 1}}. {{gesperGroup.type}}
                                        </th>
                                    </tr>
                                    <tr ng-repeat="question in gesperData | filter : {questionType:gesperGroup.type}">
                                        <td class="fixed_td_lft">{{question.name}}</td>
                                        <td class="fixed_td">
                                            <select ng-model="question.value" ng-change="gesperChange()">
                                                <?php foreach ($text_gesper_calc_value as $cValues) { ?>
                                                <option value="<?php echo $cValues; ?>"><?php echo $cValues; ?></option>
                                                <?php } ?>
                                            </select>
                                        </td>
                                        <td class="fixed_td_lft_rit">{{question.questionDesc}}</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </td>
                </tr>
            </table>
        </div></fieldset>
        <fieldset ng-show="step == 4" ng-form="step4Form">
            <div class="alert alert-info" role="alert"><?php echo $msg_deplace_appli; ?></div>
            <multiselect leftitems="projects" model="selectedpjts" optionid="project_id" optionvalue="pjt"></multiselect>
            <div class="row" ng-show="step4Form.$submitted && step4Form.$invalid">
                <div class="col-sm-12" style="margin:10px 0;">
                    <div class="alert alert-danger">
                        <span><?php echo $valid_msg_prj_req; ?></span>
                    </div>
                </div>
            </div>
        </fieldset>
        <fieldset ng-show="step == 5" ng-form="step5Form">      
            <div class="alert alert-info" role="alert"><?php echo $msg_fill_contextitems; ?></div>
            <div class="form-group" ng-repeat="pjtcontext in PjtContexts | orderBy:pjtContextOrder">
                <div class="row" ng-if="pjtcontext.context_item_type=='TEXT'">
                    <label class="control-label col-sm-2">
                        {{pjtcontext.contxt}} <img ng-show="pjtcontext.context_item_mandatory==1" src="<?php echo $pathPictures?>pictos/requiredicon.gif" alt=""/> :</label>
                    <div class="col-sm-5">
                        <input type="text" class="form-control" name="context_item_{{pjtcontext.context_item_id}}" 
                               ng-model="pjtcontext.context_value" ng-required="pjtcontext.context_item_mandatory==1" value='' />
                    </div>
                    <div class="col-sm-5"></div>
                </div>
                <div class="row" ng-if="pjtcontext.context_item_type=='LIST'">
                    <label class="control-label col-sm-2">
                        {{pjtcontext.contxt}} <img ng-show="pjtcontext.context_item_mandatory==1" src="<?php echo $pathPictures?>pictos/requiredicon.gif" alt=""/> :</label>
                    <div class="col-sm-5">
                        <select class="form-control" name="context_item_{{pjtcontext.context_item_id}}" 
                                ng-model="pjtcontext.context_value" ng-required="pjtcontext.context_item_mandatory==1" 
                                ng-options="x.context_item_value for x in pjtcontext.values"></select>
                    </div>
                    <div class="col-sm-5"></div>
                </div>
                <div class="row" ng-if="pjtcontext.context_item_type=='MULTI'">
                    <label class="control-label col-sm-2">
                        {{pjtcontext.contxt}} <img ng-show="pjtcontext.context_item_mandatory==1" src="<?php echo $pathPictures?>pictos/requiredicon.gif" alt=""/> :</label>
                    <div class="col-sm-10">
                        <multiselect leftitems="pjtcontext.values" size="6" 
                                     settings="{'boxStyle':'margin:0;'}"
                                     model="pjtcontext.context_value" optionid="context_item_value_id" optionvalue="context_item_value"></multiselect>
                    </div>
                </div>                
            </div>
            <div class="row" ng-show="step5Form.$submitted && step5Form.$invalid">
                <div class="col-sm-12">
                    <div class="alert alert-danger">
                        <span><?php echo $valid_msg_prj_cxt_req; ?></span>
                    </div>
                </div>
             </div>
        </fieldset>
        <fieldset ng-show="step == 6" ng-form="step6Form">
            <div class="alert alert-info" role="alert"><?php echo $msg_deplace_sous; ?></div>
            <multiselect leftitems="families" model="sfamilies" optionid="family_id" optionvalue="subfamily_name" optiongroup="family_name"></multiselect>
            <div class="row" ng-show="step6Form.$submitted && step6Form.$invalid">
                <div class="col-sm-12" style="margin:10px 0;">
                    <div class="alert alert-danger">
                        <span><?php echo $valid_msg_sub_fam_req; ?></span>
                    </div>
                </div>
            </div>
        </fieldset>
        <div class="form-group "> 
            <div class="col-sm-auto" ng-hide="step==3">
                <button class="btn btn-default" ng-click="prevStep()" ng-hide="step==1"><?php echo $txt_std_previous; ?></button>
                <button class="btn btn-primary" ng-click="nextStep()" ng-hide="submit"><?php echo $button_next; ?></button>
                <button type="submit" class="btn btn-primary" ng-click="Tdbcheck()" ng-show="submit"><?php echo $button_submit; ?></button>
            </div>
        </div>
    </form>
    <?php } ?>
</div>
<?php
require_once $pathBase . 'footer.php';