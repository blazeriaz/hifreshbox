<?php 
$pathBase = '../';
$pathRoot = '../' . $pathBase;
require_once $pathBase . 'common_scripts/exchange_form.php';
$exg_info = getExchangeFormBaseInfo($_SESSION['exgformid'], $cnx->num);
$cc_users_data = explode(';', $exg_info->cc_users);

if(($exg_info->contributor_ipn == $_SESSION['ipn']) && ($exg_info->status == '2' || $exg_info->status == '3')) {
        $action_type = 'Edit';
} else if ((in_array($_SESSION['ipn'], $cc_users_data) || $exg_info->contributor_ipn == $_SESSION['ipn']) ){
        $action_type = 'View';
} else if($currentUser->canAccessDashboard("validate_exchange_form", $_SESSION['dashboard_id']) && ($exg_info->status == '4')) {
    $action_type = 'LeaderValidateView';
} else if($currentUser->canAccessDashboard("read_exchange_form", $_SESSION['dashboard_id'])) {
    $action_type = ($exg_info->status == '0')?'LeaderAction':'LeaderView';
} else {
    $access_dashboard = false;
    include_once $pathBase.'common_scripts/authorisation_error.php';
    require_once $pathBase.'footer.php';
    die;
}

require_once 'dashboard_header.php';

if(!isset($_REQUEST['sendmail'])) { ?> 
<script>
var active = 0;





$(document).ready(function() {  
	var grid_type = $('#grid_type').val();
	var exgform_id = $('#current_exgform_id').val();
	var action_type = '<?php echo $action_type; ?>';
	var path_base = $('#pathbase').html();
	
	// var org_data = $("#exg_activity_form").serialize(); 
	
	$(".tr_highlight").hover(function() {
		$(this).children().css('background-color', '#ffdc87');
	}, function() {
		$(this).children().css('background-color', '');
	});
	
	$('tr.tr_highlight').on('click', function(e){
		e.preventDefault();
		var save_id = $('#save_activity_id').val();
		
                if($(this).hasClass('tr_clicked')){
                    return false;
                }
                
                
		// var new_data = $("#exg_activity_form").serialize();
		var allow_save = false;
		/*if(save_id !== undefined && $(this).parents('form').hasClass('js-exchange-form')) {
			var chages = confirm ("<?php echo $text_dialogue_content; ?>");
			if(chages) {
				var allow_save = true;
			} else {
				var allow_save = false;
			}
		} */	
		if(save_id !== undefined && $(this).parents('form').hasClass('js-exchange-form')) {
			
				var allow_save = true;
			
		} 
		if(grid_type == '4' && allow_save==true) {
			var exg_act_ids = $('#exgform_activity_ids').val();
			if(exg_act_ids !== undefined) {
				var exg_act_data = exg_act_ids.split(';');
				var totalError = 0;
				$.each(exg_act_data,function(key, values){
					var error_status = CheckExchangeFormEvaluationGrid(values);
					if(error_status == false) {
						 totalError = key+1;
					}
				});
				if(totalError == 0) {
					$(this).toggleClass('tr_clicked');
					$(this).siblings().removeClass('tr_clicked');
				} else {
					return false;
				}
			} else {
				$(this).toggleClass('tr_clicked');
				$(this).siblings().removeClass('tr_clicked');
			}
		} else {
			$(this).toggleClass('tr_clicked');
			$(this).siblings().removeClass('tr_clicked');
		}
		var activity_id = $(this).data('id');
		var exg_act_id = $(this).data('exg_act_id');
		var activity_id = $(this).data('id');
		if($(this).parents('form').hasClass('js-exchange-form')){
		/* load old grid data */
                    $.ajax({url: $('#pathbase').html()+'xmlhttprequest/ajax_exchange_form.php?action=getOriginalActivityPanels&activity_id='+activity_id+'&grid_type='+grid_type+'&exgform_id='+exgform_id+'&action_type=View',
                    success: function(output) {
                                    if(output != '') {
                                            $('#org_grid_data').html(output);
                                    } else {
                                            $('#org_grid_data').html('');
                                    }    
                            }
                    });
                 }
		
                    /* load new grid data */
                    $.ajax({
                        url: $('#pathbase').html()+'xmlhttprequest/ajax_exchange_form.php?action=getActivityPanels&exg_activity_id='+exg_act_id+'&activity_id='+activity_id+'&grid_type='+grid_type+'&exgform_id='+exgform_id+'&action_type='+action_type,


                    beforeSend: function () {
                            if(allow_save == true) {
                            saveExchangeFormActivity(path_base, grid_type, exgform_id, action_type, '');
                            }
                    },
                    success: function(output) {

                                    if(output != '') {
                                            $('#grid_data').html(output);
                                    } else {
                                            $('#grid_data').html('');
                                    }    
                            }
                    });
               
    });
	
	$("#save_draft").click(function() {
		var errorStatus = beforeSelectValidateForm(grid_type);
		if(errorStatus == true) {
			saveExchangeFormActivity(path_base, grid_type, exgform_id, action_type, 'save_draft');	
		}
	});
	
	$("#send_answer").click(function() {
		var errorStatus = beforeSelectValidateForm(grid_type);
		if(errorStatus == true) {
			saveExchangeFormActivity(path_base, grid_type, exgform_id, action_type, 'send_answer');	
		}	
	});

	$( "#tabs" ).tabs({
		active: 1,
		beforeActivate: function( event, ui ) {
			// $('#org_ *').unbind(); 
		}
	});
	$( ".tr_highlight:eq(0)" ).click();
  
}); 




</script>
<?php } else { ?>
<script type="text/javascript" src="<?php echo $pathRoot; ?>js/nicEdit.js"></script>
<script>
$(document).ready(function() {  
	bkLib.onDomLoaded(function() {
		new nicEditor({buttonList : [], maxHeight : 300}).panelInstance('mail_content');
	});
}); 
function close_window() {
  window.close();
}
</script>
<?php } ?>

<?php
if(!isset($_REQUEST['sendmail'])) {
    $query = "SELECT exgAct.activity_exgform_id AS exgform_activity_id, repAct.repository_activity_id AS activity_id, "
            . "repAct.name_".$_SESSION['language']." AS activity_name, exg.contributor_ipn AS contributor, "
            . "role.name_".$_SESSION['language']." AS role, repRes.result_order AS result_order, repAct.activity_order AS activity_order, "
            . "dept.department_name_".$_SESSION['language']." AS department, "
            . "exgAct.GREEN AS green, exgAct.RED AS red, exgAct.ORANGE AS orange, exgAct.WHITE AS white, exgAct.GREY AS grey, "
            . "exgAct.saved_data, ins.instance_activity_evaluation AS grid_type "
            . "FROM tb_exchange_form AS exg "
            . "LEFT JOIN tb_instances_activities_exgform AS exgAct ON exgAct.exchange_form_id_fk = exg.exchange_form_id "
            . "LEFT JOIN tb_repositories_activities AS repAct ON repAct.repository_activity_id = exgAct.repository_activity_id_fk "
            . "LEFT JOIN tb_repositories_results AS repRes ON repRes.repository_result_id = repAct.repository_result_id_fk "
            . "LEFT JOIN tb_repositories_activities_stakeholder_roles AS repStaRole ON repStaRole.repository_activity_id_fk = repAct.repository_activity_id "
            . "LEFT JOIN tb_roles AS role ON role.role_id = repStaRole.role_id_fk "
            . "LEFT JOIN tb_departments AS dept ON dept.department_id = role.role_department_id_fk "
            . "LEFT JOIN tb_instances AS ins ON ins.instance_id = exgAct.instance_id_fk "
            . "WHERE exgAct.exchange_form_id_fk = '".$_REQUEST['exchange_form_id']."' GROUP BY repAct.repository_activity_id ";
    $request = new requete($query, $cnx->num);
    $activities_list = $request->recup_array_champ();


$formClass = ($action_type == 'Edit' || $action_type == 'LeaderValidateView') ? 'normal js-exchange-form' : 'normal';
if($action_type == 'LeaderValidateView') {
?>
<div class="refuselForm" id="refuse_dialog" title="<?php echo $txt_refusel_form_title; ?>">
    <form name="refuselexgForm" id="refuselexgForm"  action="#" method="POST">
        <input type="hidden" name="exchange_form_id" value="<?php echo $_REQUEST['exchange_form_id']; ?>">
        <input type="hidden" name="action" value ="refuse">
        <textarea name="reason" id="refuselreason" style='width:300px;height:150px;''></textarea>
    </form>
</div>
<?php }?>
<form name="exg_activity_form" id="exg_activity_form" class ='<?php echo $formClass; ?>' action="#" method="POST">
    <?php if($action_type == 'LeaderValidateView') { ?>
<input type="hidden"  value="<?php echo $_REQUEST['action']; ?>" name ="action" id="form_action" >
<?php } ?>
<div class="clearleft"></div>
<?php
if(($action_type != 'Edit') && ($exg_info->exchange_no > 1)){
       $request = new requete(" SELECT exchange_no FROM tb_exchange_form  WHERE status =8 and repository_milestone_id_fk ='".$exg_info->milestone_id."' and
           instance_id_fk = '".$exg_info->instance_id."' and  role_id_fk  = '".$exg_info->role_id_fk."' and exchange_no = '" . ($exg_info->exchange_no-1) . "' ", $cnx->num);
        $exg_base_info_count = $request->recup_objet();
        if($exg_base_info_count->exchange_no){

?>
<div class="RnoMessageBox RnoInformationMessageBox">
        <?php
            $dataArr = array('##CURRENT##'=>$exg_info->exchange_no,
                        '##PREVIOUS##' =>$exg_base_info_count->exchange_no);
            echo strtr($text_outdated_exform,$dataArr);
        ?>
</div>        

  <?php          
    }  
    
    ?>
<?php } ?>
<?php $close_url = "dashboard.php?dashboard_id=".$_SESSION['dashboard_id']."&menu_n1=home&menu_n2=6#!/view/".$_SESSION['dashboard_id']."/exchange_forms"; ?>
<div class="RnoCreateButtons">
	<?php if($action_type == 'LeaderAction') { ?>
        <a href="<?php echo $targetFile; ?>&action=read_send_exgform&sendmail=1&exchange_form_id=<?php echo $_REQUEST['exchange_form_id']; ?>" 
           class="RnoButton StdButton" target="_balnk"><?php echo $text_send_email; ?></a>
        <a href="<?php echo $close_url; ?>" class="RnoButton StdButton"><?php echo $libelle_close; ?></a> 
    <?php } else if($action_type == 'Edit') { ?>
        <a href="#" id="save_draft" name="save_draft" class="RnoButton draft"><?php echo $text_exgform_save_draft; ?></a>
        <a href="#" id="send_answer" name="send_answer" class="RnoButton answer"><?php echo $text_exgform_send_answer; ?></a>
    <?php } else if($action_type == 'LeaderValidateView') { ?>
        <a href="#" id="validate_selection" name="validate_selection" class="RnoButton StdButton"><?php echo $text_exgform_validate_selection; ?></a>
        <a href="#" id="refuse_all" name="refuse_all" class="RnoButton StdButton"><?php echo $text_exgform_refuse_all; ?></a>
        <a href="<?php echo $close_url; ?>" class="RnoButton StdButton"><?php echo $libelle_close; ?></a> 
    <?php } else if(!$exchange_form_only && ($action_type == 'LeaderView' || $action_type == 'View')) { ?> 
    	<a href="<?php echo $close_url; ?>" class="RnoButton StdButton"><?php echo $libelle_close; ?></a> 
    <?php }?>
    
</div>

<div class="clearleft"></div>

<div class="activityListTable">
<table class="RnoTableData" id="mstrTable">
    <thead>
  <tr>
    <th><?php echo $text_std_activities; ?></th>
    <th><?php echo $text_label_contributors; ?></th>
    <?php if($exg_info->grid_type == 4) { ?>
        <th><?php echo $text_overall_results; ?></th>
    <?php } ?>
  </tr> 
    </thead>
    <tbody>
  <?php
	for ($i = 0; $i < count($activities_list); $i++) {
		$grid_type = $activities_list[$i]['grid_type'];
   ?>
  <tr class="tr_highlight" data-id="<?php echo $activities_list[$i]['activity_id']; ?>" data-exg_act_id="<?php echo $activities_list[$i]['exgform_activity_id']; ?>">
    <td><?php echo $activities_list[$i]['result_order'].' - '.$activities_list[$i]['activity_order'].' - '.$activities_list[$i]['activity_name']; ?></td>
    <td><img src="<?php echo $pathPictures;?>pictos/leader.png" border="0" alt="" /> <?php echo $activities_list[$i]['role']. ' ['.$activities_list[$i]['department'].'] '.$arca->getName($activities_list[$i]['contributor']); ?> </td>
    <?php if($grid_type == 4) { ?>
    <td>
        <span id="<?php echo $activities_list[$i]['activity_id']; ?>">
        <div class="graph_css2">
        <?php 
            $statusColor = array("008000"=>"green", "FFC115"=>"orange", "FF4B00"=>"red", "FFFFFF"=>"white");
            $total = 0;
            if(!empty($activities_list[$i]['saved_data'])){
                $saveddata = unserialize($activities_list[$i]['saved_data']);
                $activities_list[$i]['green']=$saveddata['GREEN'];
                $activities_list[$i]['orange']=$saveddata['ORANGE'];
                $activities_list[$i]['red']=$saveddata['RED'];
                $activities_list[$i]['white']=$saveddata['WHITE'];
            }
            $total_color = $activities_list[$i]['green']+$activities_list[$i]['orange']+$activities_list[$i]['red']+$activities_list[$i]['white'];
            foreach($statusColor as $bkey => $bval) { 
                if(!empty($activities_list[$i][$bval])){
                    $val =  round((($activities_list[$i][$bval]/$total_color)*100),2);
                }else{
                   $val =0; 
                }
                $total += $val;
                if($total > 100){
                 $val = 100 - ($total-$val);   
                }
                
                ?>
                     <span class="bar intpercent" style="background-color:<?php echo '#'.$bkey; ?>;width:<?php echo $val.'%'; ?>;"></span>
            <?php } ?>
            </div>
        </span>
	</td>
 <?php } ?>         
  </tr>
  <?php } ?>
    </tbody>
</table>
</div>

<?php if($action_type == 'Edit' || $action_type == 'LeaderValidateView') { ?>
<div id="tabs">
  <ul>
    <li><a href="#tabs-1"><?php echo $text_exgform_original_eva_grid; ?></a></li>
    <li><a href="#tabs-2"><?php echo $text_exgform_eva_grid_update; ?></a></li>
  </ul>
  <div id="tabs-1">
  	<div id="org_grid_data">Loading....!!!</div>
  </div>
  <div id="tabs-2">
    <?php if($grid_type == 4 && $action_type == 'Edit') { ?>
  	<div align="right">
    <a href="javascript:add_exgform_evaluation_grid('<?php echo $pathBase; ?>','exg_activity_form');"><img src="<?php echo $pathPictures;?>pictos/add1_24.png"><?php echo $text_exgform_add_evaluation; ?></a>
    </div>
    <?php } ?>
  	<div id="grid_data">Loading....!!!</div>
  </div>
</div>
<?php } else { ?>
	<div id="grid_data"></div>
<?php }  ?>

<input type="hidden" name="grid_type" id="grid_type" value="<?php echo $grid_type; ?>"  />
<input type="hidden" name="current_exgform_id" id="current_exgform_id" value="<?php echo $_REQUEST['exchange_form_id']; ?>"  />
</form>
<?php } else { 

$content_labels = array('headers'=>array('activities' => $text_std_activities, 'gor' => $text_exgfrom_gor, 'contributors' => $text_label_contributors, 'last_update' => $text_std_last_update, 'deviation' => $text_exgfrom_deviation, 'action_plan' => $text_std_action_plan, 'arca_name' => $tooltip_arca_name, 'action_plan_due_date' => $text_std_action_plan_due_date, 'gor_eval' => $text_exgfrom_gor_eval));

$baseInfo = getExchangeFormBaseInfo($_REQUEST['exchange_form_id'], $cnx->num);
$contextOnfo = getContextInfo($baseInfo->instance_id,$cnx->num);

$leader_info = $arca->getUserData($baseInfo->leader_ipn);
$contributor_info = $arca->getUserData($baseInfo->contributor_ipn);

$sqlProjectItems = "SELECT p.project_code FROM tb_projects as p "
        . "JOIN tb_instance_projects as pi ON pi.project_id_fk = p.project_id AND pi.instance_id_fk = ".$baseInfo->instance_id." "
        . "GROUP BY p.project_code";
$request=new requete($sqlProjectItems,$cnx->num);
$project_infos = $request->recup_array_mono();
$baseInfo->project_code = join(", ", $project_infos);

$subject = '[CLEM] ' . $text_exgfrom_dashboard . ' ' . $baseInfo->instance_id . ' - '.$baseInfo->milestone_name . ' - ' . $project_infos[0];
if(!empty($contextOnfo->contextName)){
    $subject .= '/'.$contextOnfo->contextName;
    $baseInfo->project_code .=  '/' . $contextOnfo->contextName;
}
$subject .= ' - '. $text_sendmail_exform . ' ' . $baseInfo->exchange_no;
$contents = getExchangeFormMailContents($_REQUEST['exchange_form_id'], $content_labels, $tablo_libelle_statut, $cnx->num, $arca);

?>

<form name="email_contents" id="email_contents" action="<?php echo $targetFile; ?>action=send_email&exgform_id=<?php echo $_REQUEST['exchange_form_id']; ?>" method="post">
<div class="clearleft"></div>
<table width="100%" align>
	<tr>
    <td width="200px">
        <a href="javascript:document.email_contents.submit();" class="btn btn-sm btn-secondary sendmailbutton" style="background-position: 2px center;height:auto;">
            <?php echo $text_send_email; ?></a>
	<a href="javascript:close_window()"  class="btn btn-sm btn-secondary mailcancel" style="background-position: 2px center;height:auto;">
            <?php echo $libelle_close; ?></a> 
    </td>
</tr>
</table>    
<div class="clearleft"></div>
<table width="100%" border="0" frame="above">
  <tr>
    <td width="80px" style="text-align:right;height:30px;font-size:large"><?php echo $text_exgfrom_from; ?> : </td>
    <td width="" style="text-align:left;height:30px">
    <input type="hidden" name="leader_ipn" id="leader_ipn" value="<?php echo $baseInfo->leader_ipn; ?>" />
    <span id="leader_mailid"><?php echo $leader_info->courriel; ?></span>
    <input type="checkbox" name="leader_ipn_copy" value="1" checked="checked" /> <?php echo $txt_send_copy; ?>
    </td>
  </tr>
  <tr>
    <td  style="text-align:right;height:30px;font-size:large"><?php echo $text_exgfrom_to; ?> : </td>
    <td style="text-align:left;height:30px;">
    <input type="hidden" name="contributor_ipn" id="contributor_ipn" value="<?php echo $baseInfo->contributor_ipn; ?>" />
    <span id="contributor_mailid"><?php echo $contributor_info->courriel; ?></span>
    
    </td>
  </tr>
  <tr>
    <td  style="text-align:right;height:30px;font-size:large"><?php echo $text_exgfrom_cc; ?> : </td>
    <td style="text-align:left;width:30px;pading-left:10px"><a href="javascript:arca_email_search('<?php echo $pathBase; ?>','email_contents','');" class="info_img">
    <img src="<?php echo $pathPictures;?>pictos/search.png" alt="" width="20" height="20"><span>Email IDs Search</span></a> 
    <input type="hidden" name="cc_user_ipn" id="cc_user_ipn" value="" />
    <div id="cc_user_names"></div>
    </td>
  </tr>
  <tr>
    <td style="text-align:right;height:30px;font-size:large"><?php echo $text_exgfrom_subject; ?> : </td>
    <td style="text-align:left;height:30px;"><input type="text" name="mail_subject" id="mail_subject" size="100" value="<?php echo $subject; ?>" readonly /></td>
  </tr>
  <?php /*?><tr>
  	<td style="text-align:right;font-size:large"><?php echo $text_exgfrom_content; ?></td>
    <td><textarea style="height:800px;width:800px" name="mail_content" id="mail_content"><?php echo $contents; ?></textarea></td>
  </tr><?php */?>
</table>
<div><div style="height:400px;width:100%;overflow-x: hidden; overflow-y: auto;padding:5px;" name="mail_content1" id="mail_content1">
    <?php echo $contents; ?></div></div>
</form>
<?php } ?>
<script language="JavaScript">
function openExgFormExternalLink(path_base, exg_form_id, activity_id, action_type, grid_type) {
    var url = path_base+"xmlhttprequest/external_links_exg_form.php?";
    url += "exg_form_id="+exg_form_id;
    url += "&activity_id="+activity_id;
    url += "&actionType="+action_type;
    url += "&gridType="+grid_type;
    open(url, "target_modify", "toolbar=0, directories=0, status=1, menubar=0, width=900, height=600, scrollbars=1, location=0, resizable=1");
}
jQuery(document).ready(function($){
    $('#cc_user_names').click(function(e){
        var $target = $(e.target);
        if($target.hasClass('remove_ipn')){
            var ipn = $target.data("ipn");
            var ipns = $("#cc_user_ipn").val();
            var tmp = ipns.replace(ipn, '').replace(';;', ';');
            if(tmp[0] == ';') {
                tmp = tmp.slice(1);
            }
            if(tmp[(tmp.length-1)] == ';') {
                tmp = tmp.slice(0, -1);
            }
            $("#cc_user_ipn").val(tmp);
            $target.parent("span").remove();
        }
    });
});    
</script>