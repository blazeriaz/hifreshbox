<?php

session_start();
$pathBase = '../../../';
$pathRoot = '../' . $pathBase;

require_once $pathRoot . 'libraries/classes/class_connexion_mysql.php';
require_once $pathRoot . 'libraries/classes/class_arca.php';
require_once $pathBase . 'common_scripts/datetime_functions.php';
require_once $pathBase . 'common_scripts/FormatStringForDB.php';
require_once $pathBase . 'common_scripts/url_functions.php';
require_once $pathRoot . 'libraries/phplibs/upload.php';
require_once $pathRoot . 'messages/' . $_SESSION['language'] . '/standard.msg';
$cnx = new connexion_db($pathBase);
$request = new requete("SELECT 1", $cnx->num);
require_once $pathRoot . 'libraries/classes/models/coreModel.php';
require_once $pathRoot . 'libraries/classes/models/RepositoryModel.php';
if (!empty($_POST)) {
    $post_vars = $_POST;
} else {
    $post_vars = file_get_contents("php://input");
    $post_vars = get_object_vars(json_decode($post_vars));
}

$action = isset($post_vars['action']) ? $post_vars['action'] : '';
$alerts = array("info" => array(), "error" => array(), "success" => array());
$json = array("success" => 1, "alerts" => $alerts);
if ($post_vars['repository_id']) {
    $repositoryId = $post_vars['repository_id'];
    $repositoryObj = new RepositoryModel($repositoryId);
}

switch ($action) {
    case "save":
        $postData = $post_vars;
        $query = '';
        $table = "tb_repositories";
        $file_directory = $SERVER_HOME . '/uploads/';
        $file_SIZE = 3;
        $upload = new Upload($file_directory, $file_SIZE);
        $data = $upload->Process('document', 'file');
        if (empty($data[0]['errors'])) {
            $fileName = !empty($data[0]['name']) ? $data[0]['name'] : '';
            if (empty($postData['repository_id'])) {
                $formFields = array('repository_name_fr', 'repository_name_en', 'repository_creation_date', 'repository_creator', 'repository_manager', 'file', 'universe_id_fk');
                $fieldValues = array();
                foreach ($formFields as $field) {
                    if ($field == 'repository_creation_date') {
                        $fieldValues[$field] = todayDashFormatted();
                    } else if ($field == 'repository_creator' || $field == 'repository_manager') {
                        $fieldValues[$field] = $_SESSION['ipn'];
                    } else if ($field == 'file' && !empty($_FILES[$field]['name'])) {
                        $fieldValues[$field] = $fileName;
                    } else {
                        $fieldValues[$field] = !empty($postData[$field]) ? $postData[$field] : '';
                    }
                }

                $query = " insert into $table (" . join(',', $formFields) . ") values ('" . join("','", $fieldValues) . "')";
            } else {
                $formFields = array('repository_name_fr', 'repository_name_en', 'file', 'universe_id_fk');
                $conditions = array();
                $conditions[] = "repository_id = " . $repositoryId;
                $query = "update $table set ";
                $updateFields = array();
                foreach ($formFields as $field) {
                    if ($field == 'file') {
                        if ($fileName) {
                            $updateFields[] = "$field = '$fileName'";
                        }
                    } else {
                        $updateFields[] = "$field = '" . $postData[$field] . "'";
                    }
                }
                if (!empty($updateFields)) {
                    $query .=join(',', $updateFields);
                    $query .=" where " . join('AND', $conditions);
                } else {
                    $query = '';
                }
            }
            if ($query) {
                $request->envoi($query);
            }
            if (empty($postData['repository_id'])) {
             $repositoryId = $request->insert_id();
            $request->envoi("INSERT INTO tb_repositories_versions (version_id,repository_version_creator,repository_id_fk) "
                        . "VALUES (1,'" . $_SESSION['ipn'] . "'," . $repositoryId . ")");
                $repQuery = "select u.id, u.name, r.repository_id, r.repository_name_fr, r.repository_name_en, r.repository_status, r.repository_creator,
r.repository_manager,r.repository_manager_backup,r.is_deleted, rv.repository_revision_id, rv.version_id, rv.version_status, 
rv.version_comment,rv.version_date_activation,r.is_request,r.repository_allow_milestone_deletion,r.gesper_status,r.project_context, 
rv.activity_evaluation,rv.backlog_display,r.repository_allow_tdb_creation
 from tb_repositories_versions rv
inner join tb_repositories r on r.repository_id = rv.repository_id_fk
inner join tb_universe u on u.id = r.universe_id_fk
where rv.version_status = 'NEW' and r.is_deleted = 0 and r.repository_id = $repositoryId  order by r.repository_id,rv.version_id";
                $request->envoi($repQuery);
                $repositoriesList = $request->recup_array_champ();
                $repositories = array();
                foreach ($repositoriesList as $repository) {
                        $repositories[$repository['repository_id']] = $repository;
                        $repository_revision_id = $repositories[$repository['repository_id']]['repository_revision_id'];
                        $repositories[$repository['repository_id']]['atLeastOneActivity'] = 0;
                        $repositories[$repository['repository_id']]['noTopics'] = 0;
                        $repositories[$repository['repository_id']]['nbMilestones'] = 0;
                        $repositories[$repository['repository_id']]['atLeastOneTemplate'] = 0;
                        $repositories[$repository['repository_id']]['nbTemplates'] = 0;
                        $repositories[$repository['repository_id']]['nbMilestonesInTemplates'] = 0;
                        $repositories[$repository['repository_id']]['nbTopicsInTemplates'] = 0;
                        $repositories[$repository['repository_id']]['commit'] = false;
                        $repositories[$repository['repository_id']]['active_version'] = '';
                         $repositories[$repository['repository_id']]['ACT']=array();
                }
                 $json['result'] = $repositories;
            }else{
                 $json['result']=$postData;
            }
        } else {
            $json['success'] = 0;
            $json['alerts']['error'] = $data[0]['error_messages'][0];
        }
        break;
    case "affectTdb":
    case "activateRep":
        $instance_id = array();
        $instance_id_major = array();
        if ($action == 'affectTdb') {
            $request->envoi("UPDATE tb_repositories SET is_request='1' WHERE repository_id=$repositoryId");
        } else {
            //update the is_update field to zero

            $request->envoi("Select instance_id from tb_instances inst, tb_repositories_versions ver where inst.repository_revision_id_fk = ver.repository_revision_id and inst.is_updating in (1,2) and ver.repository_id_fk=$repositoryId");
            $instance_list = $request->recup_array_champ();
            foreach ($instance_list as $instance) {
                $instance_id[] = $instance['instance_id'];
            }
            $instanceIds = implode(',', $instance_id);
            if (!empty($instanceIds)) {
                $request->envoi("UPDATE tb_instances SET is_updating=0 WHERE instance_id in (" . $instanceIds . ")");
            }
        }
        // Set active revision to Obsolete  
        $request->envoi("UPDATE tb_repositories_versions SET version_status='OBS' WHERE version_status='ACT' AND repository_id_fk=$repositoryId");
        // set current version to active
        $query = "UPDATE tb_repositories_versions SET version_status='ACT',";
        if (isset($post_vars['comment'])) {
            $query.="version_comment='" . FormatStringForDB($post_vars['comment']) . "',";
        }
        $query.="version_date_activation=DATE(NOW()) WHERE version_status='NEW' AND repository_id_fk= $repositoryId";
        $request->envoi($query);
        // Get  active revision id
        $request->envoi("SELECT repository_revision_id,version_id,activity_evaluation,backlog_display FROM tb_repositories_versions "
                . "WHERE version_status='ACT' AND repository_id_fk=$repositoryId");
        $request->recup_objet();
        $active_revision_id = $request->objet->repository_revision_id;
        $active_version_id = $request->objet->version_id;
        $active_evaluation = $request->objet->activity_evaluation;
        $backlog_display = $request->objet->backlog_display;
        //update is_updating field in milestone,topic,activities,checkpoint
// Create new revision
        $request->envoi("INSERT INTO tb_repositories_versions 
                                (version_id,
                                 repository_version_creator,
                                 repository_id_fk,
                                 activity_evaluation,
                                 backlog_display) 
                         VALUES (" . ($active_version_id + 1) . ",
                                 '" . $_SESSION['ipn'] . "',
                                 " . $repositoryId . ",
                                     " . $active_evaluation . "," . $backlog_display . ")");
        echo $new_revision_id = $request->insert_id();
        // clean father_id fields
        $request->envoi('UPDATE tb_repositories_milestones SET father_id=0 where father_id !=0');
        $request->envoi('UPDATE tb_repositories_results SET father_id=0  where father_id !=0');
        $request->envoi('UPDATE tb_repositories_activities SET father_id=0  where father_id !=0');
        $request->envoi('UPDATE tb_repositories_checkpoints SET father_id=0  where father_id !=0');

        // Copy now active revision to new current revision
        $request->envoi("INSERT INTO tb_repositories_milestones (SELECT 0," . $new_revision_id . ", milestone_name_fr, milestone_name_en, milestone_title_fr, milestone_title_en, milestone_definition_fr, milestone_definition_en, milestone_expectation_fr, milestone_expectation_en, milestone_aer_reference, milestone_rpif_reference, milestone_order,repository_milestone_id,milestone_reference_id,is_delete,0 FROM tb_repositories_milestones WHERE is_delete=0 and repository_revision_id_fk=" . $active_revision_id . ')');
        //US-22
        //Modified by Meenakshi
        //Removed result description field
        $request->envoi("INSERT INTO tb_repositories_results (SELECT 0," . $new_revision_id . ", repository_milestone_id_fk, result_name_fr, result_name_en, '" . $_SESSION['ipn'] . "','" . todayDashFormatted() . "', result_process_id_fk,repository_result_id,result_link_to_more_infos,result_order,result_reference_id,is_delete,0 FROM tb_repositories_results WHERE is_delete=0 and repository_revision_id_fk=" . $active_revision_id . ')');
        $request->envoi("INSERT INTO tb_repositories_activities (SELECT 0," . $new_revision_id . ", repository_result_id_fk, name_fr, name_en, description_fr, description_en,activity_order,activity_deliverable_id_fk,repository_activity_id,activity_subject_id_fk,activity_reference_id,is_delete,0 FROM tb_repositories_activities WHERE is_delete=0 and repository_revision_id_fk=" . $active_revision_id . ')');
        $request->envoi("INSERT INTO tb_repositories_checkpoints (SELECT 0," . $new_revision_id . ", repository_result_id_fk, cp_name_fr, cp_name_en,checkpoint_id,checkpoint_tag,checkpoint_is_compulsory,checkpoint_reference_id,is_delete,0 FROM tb_repositories_checkpoints WHERE is_delete=0 and repository_revision_id_fk=" . $active_revision_id . ')');

        // Update links between objects through the father_id fields
        $q = "UPDATE tb_repositories_results as rr "
                . "JOIN tb_repositories_milestones as rm ON rr.repository_milestone_id_fk = rm.father_id "
                . "SET rr.repository_milestone_id_fk = rm.repository_milestone_id "
                . "WHERE rr.is_delete = 0 and rr.repository_revision_id_fk = " . $new_revision_id;
        $request->envoi($q);
        $q = "UPDATE tb_repositories_activities as ra "
                . "JOIN tb_repositories_results as rr ON ra.repository_result_id_fk = rr.father_id "
                . "SET ra.repository_result_id_fk = rr.repository_result_id "
                . "WHERE ra.is_delete = 0 and ra.repository_revision_id_fk = " . $new_revision_id;
        $request->envoi($q);
        $q = "UPDATE tb_repositories_checkpoints as rc "
                . "JOIN tb_repositories_results as rr ON rc.repository_result_id_fk = rr.father_id "
                . "SET rc.repository_result_id_fk = rr.repository_result_id "
                . "WHERE rc.is_delete = 0 and rc.repository_revision_id_fk = " . $new_revision_id;
        $request->envoi($q);

        // Copy stakeholders definition
        $request->envoi("INSERT INTO tb_repositories_activities_stakeholder_roles "
                . "(SELECT repository_activity_id,role_id_fk,is_leader," . $new_revision_id . " "
                . "FROM tb_repositories_activities,tb_repositories_activities_stakeholder_roles "
                . "WHERE is_delete=0 and repository_activity_id_fk=father_id "
                . "AND tb_repositories_activities_stakeholder_roles.repository_revision_id_fk=" . $active_revision_id . ")");
        // Copy RPIF references
        $request->envoi("INSERT INTO tb_repositories_activities_rpif_link "
                . "(SELECT NULL, repository_activity_id,activity_rpif_link," . $new_revision_id . ", NOW(), '" . $_SESSION['ipn'] . "' "
                . "FROM tb_repositories_activities_rpif_link as rarf "
                . "JOIN tb_repositories_activities as ra ON rarf.repository_activity_id_fk = ra.father_id "
                . "WHERE ra.is_delete=0 AND rarf.repository_revision_id_fk=" . $active_revision_id . ")");

        // Duplicate all templates
        $request->envoi('INSERT INTO tb_templates_versions (SELECT template_id_fk,' . $new_revision_id . ',template_status FROM tb_templates_versions WHERE repository_revision_id_fk=' . $active_revision_id . ')');
        $request->envoi('INSERT INTO tb_repositories_template_constitution_milestones (SELECT ' . $new_revision_id . ',template_id_fk,repository_milestone_id FROM tb_repositories_template_constitution_milestones,tb_repositories_milestones WHERE milestone_id_fk=father_id AND revision_id_fk=' . $active_revision_id . ')');
        $request->envoi('INSERT INTO tb_repositories_template_constitution_results (SELECT ' . $new_revision_id . ',template_id_fk,repository_result_id FROM tb_repositories_template_constitution_results,tb_repositories_results WHERE result_id_fk=father_id AND revision_id_fk=' . $active_revision_id . ')');
        $request->envoi('INSERT INTO tb_repositories_template_constitution_activities (SELECT ' . $new_revision_id . ',template_id_fk,repository_activity_id FROM tb_repositories_template_constitution_activities,tb_repositories_activities WHERE activity_id_fk=father_id AND revision_id_fk=' . $active_revision_id . ')');
        $request->envoi('INSERT INTO tb_repositories_template_constitution_checkpoints (SELECT ' . $new_revision_id . ',template_id_fk,checkpoint_id FROM tb_repositories_template_constitution_checkpoints,tb_repositories_checkpoints WHERE checkpoint_id_fk=father_id AND revision_id_fk=' . $active_revision_id . ')');

        // Adding typology items into new version


        $request->envoi("INSERT INTO tb_typologies_items (select ti.typology_id_fk,ra.repository_activity_id from tb_typologies_items ti inner join 
tb_repositories_activities ra on ra.father_id = ti.item_activity_id_fk where ra.repository_revision_id_fk = $new_revision_id and ra.is_delete =0)");

        break;
    case "getItem":
        $json['repository'] = $repositoryObj->getRepositoryFullInfo();
        break;
    case "getRepositoryVersion":
        $revisionId = !empty($post_vars['revision_id']) ? $post_vars['revision_id'] : '';
        $json['repositoryVersion'] = $repositoryObj->getRepositoryVersionInfo($revisionId);
        break;
    case "delete":
        /* added by praveen : changed to soft delete */
        $request->envoi("UPDATE tb_repositories SET is_deleted='1' WHERE repository_id=$repositoryId", $cnx->num);
        break;
    case "update_manger":
        $updateQry = "UPDATE tb_repositories SET " . $post_vars['type'] . " = '" . $post_vars['ipn'] . "' where repository_id=$repositoryId";
        $request->envoi($updateQry);
        break;
    case "deletefile":
        $updateQry = "UPDATE tb_repositories SET file = '' where repository_id=$repositoryId";
        $request->envoi($updateQry);
        break;
    case "save_setting":
        $error = false;
        if ($post_vars['gesper_status'] == '1') {
            $request->envoi("SELECT typology_name_" . $_SESSION['language'] . " AS repTyps FROM tb_typologies WHERE 
								typology_status = 'ACT' AND 
								typology_name_en IN ('" . implode("', '", $text_default_typologies) . "') AND 
								typology_name_fr IN ('" . implode("', '", $text_default_typologies) . "') AND 
								typology_repository_id_fk=$repositoryId");
            $rep_typologies = $request->recup_array_mono();

            if (!array_diff($text_default_typologies, array_unique($rep_typologies)) && !array_diff(array_unique($rep_typologies), $text_default_typologies)) {
                $error = true;
                $json['alerts']['error']['gesper'] = true;
            }
        }
        if ($post_vars['roject_context'] == '1') {
            $request->envoi("SELECT count(*) as count FROM tb_contexts_items WHERE context_item_repository_id_fk=$repositoryId AND context_item_status= 'ACT'");
            $contextcount = $request->recup_objet();
            if ($contextcount->count == 0) {
                $error = true;
                $json['alerts']['error']['context'] = true;
            }
        }

        if (!$error) {

            $updateQryData = array();
            if (isset($post_vars['gesper_status'])) {
                $updateQryData[] = "gesper_status = '" . $post_vars['gesper_status'] . "'";
            }
            if (isset($post_vars['repository_allow_milestone_deletion'])) {
                $updateQryData[] = "repository_allow_milestone_deletion = '" . $post_vars['repository_allow_milestone_deletion'] . "'";
            }
            if (isset($post_vars['repository_allow_tdb_creation'])) {
                $updateQryData[] = "repository_allow_tdb_creation = '" . $post_vars['repository_allow_tdb_creation'] . "'";
            }
            if (isset($post_vars['project_context'])) {
                $updateQryData[] = "project_context = '" . $post_vars['project_context'] . "'";
            }
            if (!empty($updateQryData)) {
                $updateQry = "UPDATE tb_repositories SET " . join(', ', $updateQryData) . " where repository_id=$repositoryId";
                $request->envoi($updateQry);
            }

            $updateQryData = array();
            if (isset($post_vars['activity_evaluation'])) {
                $updateQryData[] = "activity_evaluation = '" . $post_vars['activity_evaluation'] . "'";
            }
            if (isset($post_vars['backlog_display'])) {
                $updateQryData[] = "backlog_display = '" . $post_vars['backlog_display'] . "'";
            }
            if (!empty($updateQryData)) {
                $updateQry = "UPDATE tb_repositories_versions SET " . join(', ', $updateQryData) . " where repository_revision_id=" . $post_vars['repository_revision_id'];
                $request->envoi($updateQry);
            }
        } else {
            $json['success'] = 0;
        }

        break;
}
header('Content-Type: application/json');
echo json_encode($json);