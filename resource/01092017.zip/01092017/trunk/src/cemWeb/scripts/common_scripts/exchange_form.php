<?php

session_start();

$pathBase = '../';
$pathRoot = '../' . $pathBase;
$pathPictures = $pathRoot . 'images/';
$pathGenPic = $pathBase . 'generation_images/';

require_once $pathRoot . 'libraries/classes/class_connexion_mysql.php';
require_once $pathRoot . 'messages/' . $_SESSION['language'] . '/standard.msg';
require_once $pathRoot . 'messages/' . $_SESSION['language'] . '/evaluation_grid.msg';
require_once $pathBase . 'common_scripts/datetime_functions.php';
require_once $pathBase . 'common_scripts/url_functions.php';
require_once $pathRoot . 'libraries/classes/class_arca.php';
require_once $pathBase . 'scripts_dashboard/dashboard_data.php';

$cnx = new connexion_db($pathBase);
$arca = new arca();

/** 
* CLEM 1720 - Multiple Proof
* Venkatesh Periyasamy (z016375)
* Remove "activity_external_link" column and place new column "count_external_link" in all functions
**/

function getOldAndNewActivityLists($base_action, $gridType, $exgform_id, $activity_id, $conn) {

    $exg_info = getExchangeFormBaseInfo($exgform_id, $conn);

    if ($base_action == 'getActivityPanels') {
        if ($gridType == 4) {
            $request = new requete(" SELECT actEva.activity_evaluation_exgform_id AS activity_eva_id, actEva.skill_entity AS skill_entity, actEva.count_external_link,
								  actEva.deviation_text AS deviation_text,
								  actEva.green AS green, actEva.red AS red, actEva.orange AS orange, actEva.white AS white,
								  actActPl.action_plan AS action_plan, actActPl.pilot AS pilot, actActPl.due_date AS due_date, actActPl.done_date AS done_date ,
                                                                  actExg.saved_data,actExg.repository_activity_id_fk,actEva.evalution_data,actEva.activity_evaluation_id_fk
								  FROM tb_instances_activities_evaluation_grid_exgform AS actEva
								  LEFT JOIN tb_instances_activities_exgform AS actExg ON actEva.activity_exgform_id_fk = actExg.activity_exgform_id 
								  LEFT JOIN tb_instances_activities_action_plans_exgform AS actActPl 
								  ON actActPl.activity_evaluation_exgform_id_fk = actEva.activity_evaluation_exgform_id
								  LEFT JOIN tb_exchange_form AS exg ON exg.exchange_form_id = actExg.exchange_form_id_fk
								  WHERE exg.status != '8' AND exg.exchange_form_id = '" . $exgform_id . "' AND actExg.repository_activity_id_fk = '" . $activity_id . "' 
								  GROUP BY actEva.activity_evaluation_exgform_id ", $conn);
        } else {
            $request = new requete(" SELECT actExg.activity_comment AS activity_comment, actExg.count_external_link,
								  actExg.GREEN AS green, actExg.RED AS red, actExg.ORANGE AS orange, actExg.WHITE AS white, actExg.GREY AS grey,  
								  actActPl.action_plan AS action_plan, actActPl.pilot AS pilot, actActPl.due_date AS due_date, actActPl.done_date AS done_date,
                                                                  actExg.saved_data,actExg.repository_activity_id_fk
								  FROM tb_instances_activities_exgform AS actExg
								  LEFT JOIN tb_instances_activities_action_plans_exgform AS actActPl ON actActPl.activity_exgform_id_fk = actExg.activity_exgform_id 
								  LEFT JOIN tb_exchange_form AS exg ON exg.exchange_form_id = actExg.exchange_form_id_fk
								  WHERE exg.status != '8' AND exg.exchange_form_id = '" . $exgform_id . "' AND actExg.repository_activity_id_fk = '" . $activity_id . "' ", $conn);
        }
    } else {
        if ($gridType == 4) {
            $request = new requete(" SELECT actEva.activity_evaluation_id AS activity_eva_id,
                    actEva.instance_id_fk, actEva.skill_entity AS skill_entity, actEva.count_external_link, actEva.deviation_text AS deviation_text,
                    actEva.green AS green, actEva.red AS red, actEva.orange AS orange, actEva.white AS white,
                    actActPl.action_plan AS action_plan, actActPl.pilot AS pilot, actActPl.due_date AS due_date   
                    FROM tb_instances_activities_evaluation_grid AS actEva 
                    LEFT JOIN tb_instances_activities_action_plans AS actActPl ON actActPl.activity_evaluation_id_fk = actEva.activity_evaluation_id
                    LEFT JOIN tb_instances_milestones  AS insMil ON insMil.instance_id_fk = actEva.instance_id_fk
                    WHERE actEva.repository_activity_id_fk = '" . $activity_id . "' AND actEva.instance_id_fk = '" . $exg_info->instance_id . "' 
                    and insMil.is_deleted = 0 AND insMil.repository_milestone_id_fk = '" . $exg_info->milestone_id . "' "
                    . "GROUP BY actEva.activity_evaluation_id ", $conn);
        } else {
            $request = new requete(" SELECT insAct.activity_comment AS activity_comment, insAct.count_external_link,
                    insAct.GREEN AS green, insAct.RED AS red, insAct.ORANGE AS orange, insAct.WHITE AS white, insAct.GREY AS grey,  
                    actActPl.action_plan AS action_plan, actActPl.pilot AS pilot, actActPl.due_date AS due_date  
                    FROM tb_instances_activities AS insAct
                    LEFT JOIN tb_instances_activities_action_plans AS actActPl ON actActPl.activity_id_fk = insAct.repository_activity_id_fk 
                    LEFT JOIN tb_instances_milestones  AS insMil ON insMil.instance_id_fk = insAct.instance_id_fk
                    WHERE insAct.repository_activity_id_fk = '" . $activity_id . "' AND insAct.instance_id_fk = '" . $exg_info->instance_id . "' 
                    and insMil.is_deleted = 0 AND insMil.repository_milestone_id_fk = '" . $exg_info->milestone_id . "' ", $conn);
        }
    }
    $activity_list = $request->recup_array_champ();
    return $activity_list;
}

function checkBox($name, $old_value, $new_value, $savedVal = '') {
    $display = false;
    $checked = '';
    if ($old_value != $new_value) {
        $display = true;
        $checked = 'checked';
        if (!empty($savedVal)) {
            $data = unserialize($savedVal);
            if (!isset($data[$name . '_check'])) {
                $checked = '';
            }
        }
    }
    $html = ' <script> $( document ).ready(function() { jQuery("#' . $name . '").addClass("bk_color"); });</script> ';
    $html .= ' <input type="checkbox" name="' . $name . '_check" id="' . $name . '_check" ' . $checked . ' /> ';
    $checkBoxData = ($display) ? $html : '';
    return $checkBoxData;
}

function statusUpdateToExchangeForm($exg_form_id, $status_value, $conn) {
    $request = new requete(" UPDATE tb_exchange_form SET status = '" . $status_value . "' WHERE exchange_form_id = '" . $exg_form_id . "' ", $conn);
}

function getActivityIds($exg_form_id, $activity_id, $grid_type, $conn) {
    if ($grid_type == '4') {
        $request = new requete(" SELECT actEva.activity_evaluation_exgform_id AS activity_eva_id 
									 FROM tb_instances_activities_evaluation_grid_exgform AS actEva
									 LEFT JOIN tb_instances_activities_exgform AS insAct ON insAct.activity_exgform_id = actEva.activity_exgform_id_fk
									 LEFT JOIN tb_exchange_form AS exg ON exg.exchange_form_id = insAct.exchange_form_id_fk
									 WHERE exg.exchange_form_id = '" . $exg_form_id . "' AND insAct.repository_activity_id_fk = '" . $activity_id . "' ", $conn);
        $activity_ids = $request->recup_array_champ();
    } else {
        $request = new requete(" SELECT insAct.activity_exgform_id AS exg_activity_id 
										FROM tb_instances_activities_exgform AS insAct
										LEFT JOIN tb_exchange_form AS exg ON exg.exchange_form_id = insAct.exchange_form_id_fk
										WHERE exg.exchange_form_id = '" . $exg_form_id . "' AND insAct.repository_activity_id_fk = '" . $activity_id . "' ", $conn);
        $activity_ids = $request->recup_array_champ();
    }
    return $activity_ids;
}

function getActionPlanCount($act_eva_id, $grid_type, $conn) {

    $field_name = ($grid_type == '4') ? 'activity_evaluation_exgform_id_fk' : 'activity_exgform_id_fk';
    $request = new requete("SELECT COUNT(*) AS actionPlanCount FROM tb_instances_activities_action_plans_exgform WHERE " . $field_name . " = '" . $act_eva_id . "' ", $conn);
    $actionPlanData = $request->recup_objet();
    return $actionPlanData->actionPlanCount;
}

function getActivitiyActionPlanCount($act_eva_id, $grid_type, $dashboard_id, $conn) {

    $field_name = ($grid_type == '4') ? 'activity_evaluation_id_fk' : 'activity_id_fk';
    $request = new requete("SELECT COUNT(*) AS actionPlanCount FROM tb_instances_activities_action_plans WHERE instance_id_fk = ".$dashboard_id." and ". $field_name . " = '" . $act_eva_id . "' ", $conn);
    $actionPlanData = $request->recup_objet();
    return $actionPlanData->actionPlanCount;
}

function getExchangeFormBaseInfo($exg_form_id, $conn) {

    $request = new requete(" SELECT exg.exchange_form_id AS exgform_id, exg.instance_id_fk AS instance_id, exg.repository_milestone_id_fk AS milestone_id, exg.leader_ipn, 
                        exg.contributor_ipn, mil.repository_milestone_id AS milestone_id, mil.milestone_name_" . $_SESSION['language'] . " AS milestone_name,                         
                        ins.instance_activity_evaluation as grid_type,
                        exg.cc_user_ipn AS cc_users, exg.status AS status,exg.exchange_no,exg.role_id_fk,exg.department_id_fk
                        FROM tb_exchange_form AS exg
                        LEFT JOIN tb_instances AS ins ON ins.instance_id = exg.instance_id_fk
                        LEFT JOIN tb_repositories_milestones AS mil ON mil.repository_milestone_id = exg.repository_milestone_id_fk 
                        WHERE exg.exchange_form_id = '" . $exg_form_id . "' GROUP BY exg.exchange_form_id", $conn);
    $exg_base_info = $request->recup_objet();

    return $exg_base_info;
}

function getExgFormActivitisList($exg_form_id, $grid_type, $conn) {

    if ($grid_type == 4) {
        $request = new requete(" SELECT exg.exchange_form_id AS exgform_id, exg.instance_id_fk AS instance_id, repRes.result_name_en AS topic_name_en,repRes.result_name_fr AS topic_name_fr, instAct.date_update,
            exg.repository_milestone_id_fk AS milestone_id, 
            exg.leader_ipn, exg.contributor_ipn, 
            ins.instance_activity_evaluation AS grid_type, exgAct.repository_activity_id_fk AS activity_id, repAct.name_en AS activity_name_en, repAct.name_fr AS activity_name_fr,
            repRes.result_order AS result_order, repRes.repository_result_id AS result_id, repAct.activity_order AS activity_order, exgAct.GREEN AS green, exgAct.RED AS red, exgAct.ORANGE AS orange, exgAct.WHITE AS white, exgAct.GREY AS grey 
            FROM tb_instances_activities_exgform AS exgAct 
            LEFT JOIN tb_exchange_form AS exg ON exg.exchange_form_id = exgAct.exchange_form_id_fk
            LEFT JOIN tb_instances_activities instAct on instAct.repository_activity_id_fk = exgAct.repository_activity_id_fk and instAct.instance_id_fk = exg.instance_id_fk
            LEFT JOIN tb_repositories_activities AS repAct ON repAct.repository_activity_id = exgAct.repository_activity_id_fk
            LEFT JOIN tb_repositories_results AS repRes ON repRes.repository_result_id = repAct.repository_result_id_fk
            LEFT JOIN tb_instances AS ins ON ins.instance_id = exg.instance_id_fk
            WHERE exg.exchange_form_id = '" . $exg_form_id . "' 
             order by repRes.result_order asc, repAct.activity_order asc ", $conn);
    } else {
        $request = new requete(" SELECT exg.exchange_form_id AS exgform_id, exg.instance_id_fk AS instance_id, repRes.result_name_en AS topic_name_en,repRes.result_name_fr AS topic_name_fr,  instAct.date_update,
                exg.repository_milestone_id_fk AS milestone_id, 
                exg.leader_ipn, exg.contributor_ipn, 
                ins.instance_activity_evaluation AS grid_type, exgAct.repository_activity_id_fk AS activity_id, repAct.name_en AS activity_name_en, repAct.name_fr AS activity_name_fr, 
                repRes.result_order AS result_order,repRes.repository_result_id AS result_id, repAct.activity_order AS activity_order, exgAct.GREEN AS green, exgAct.RED AS red, exgAct.ORANGE AS orange,
                exgAct.WHITE AS white, exgAct.GREY AS grey, actActPl.action_plan AS action_plan, actActPl.pilot AS pilot, actActPl.due_date AS due_date 
                FROM tb_instances_activities_exgform AS exgAct 
                LEFT JOIN tb_instances_activities instAct on instAct.repository_activity_id_fk = exgAct.repository_activity_id_fk and instAct.instance_id_fk = exgAct.instance_id_fk 
                LEFT JOIN tb_instances_activities_action_plans_exgform AS actActPl ON actActPl.activity_exgform_id_fk = exgAct.activity_exgform_id 
                LEFT JOIN tb_exchange_form AS exg ON exg.exchange_form_id = exgAct.exchange_form_id_fk 
                LEFT JOIN tb_repositories_activities AS repAct ON repAct.repository_activity_id = exgAct.repository_activity_id_fk 
                LEFT JOIN tb_repositories_results AS repRes ON repRes.repository_result_id = repAct.repository_result_id_fk 
                LEFT JOIN tb_instances AS ins ON ins.instance_id = exg.instance_id_fk 
                WHERE exg.exchange_form_id = '" . $exg_form_id . "' 
                order by repRes.result_order asc, repAct.activity_order asc", $conn);
    }
    $activity_list = $request->recup_array_champ();
    $activity_data = array();
    foreach ($activity_list as $key => $val) {
        if ($grid_type == 4) {
            $val['grid_data'] = getEvaluationGridData($exg_form_id, $val['activity_id'], $conn);
        }
        $activity_data[$key] = $val;
    }
    return $activity_data;
}

function getEvaluationGridData($exg_form_id, $activity_id, $conn) {

    $request = new requete(" SELECT actEva.skill_entity, actEva.deviation_text, actEva.count_external_link, actEva.green, actEva.red, actEva.orange, 
								actEva.white, actEvaPl.action_plan, actEvaPl.pilot, actEvaPl.due_date, actEva.activity_evaluation_id_fk,actEva.activity_evaluation_exgform_id
								FROM tb_instances_activities_evaluation_grid_exgform AS actEva
								LEFT JOIN tb_instances_activities_action_plans_exgform AS actEvaPl 
								ON actEvaPl.activity_evaluation_exgform_id_fk = actEva.activity_evaluation_exgform_id 
								LEFT JOIN tb_instances_activities_exgform AS act ON act.activity_exgform_id = actEva.activity_exgform_id_fk
								WHERE act.exchange_form_id_fk = '" . $exg_form_id . "' AND act.repository_activity_id_fk = '" . $activity_id . "' ", $conn);
    $gridData = $request->recup_array_champ();
    return $gridData;
}

function getExchangeFormMailContents($exg_form_id, $content_labels, $tablo_libelle_statut, $conn, $arca) {

    $color_label = $tablo_libelle_statut;
    $act_base_info = getExchangeFormBaseInfo($exg_form_id, $conn);
    $leader_info = $arca->getUserData($act_base_info->leader_ipn);
    $contributor_info = $arca->getUserData($act_base_info->contributor_ipn);
    $activityData = getExgFormActivitisList($exg_form_id, $act_base_info->grid_type, $conn);
    
    $sqlProjectItems = "SELECT p.project_code FROM tb_projects as p "
            . "JOIN tb_instance_projects as pi ON pi.project_id_fk = p.project_id AND pi.instance_id_fk = ".$act_base_info->instance_id." "
            . "GROUP BY p.project_code";
    $request = new requete($sqlProjectItems,$conn);
    $project_infos = $request->recup_array_mono();
    $act_base_info->project_code = join(", ", $project_infos);
    
    $reminder = false;
    if ($act_base_info->exchange_no > 1) {
        $request = new requete(" SELECT exchange_no FROM tb_exchange_form  WHERE status =8 and repository_milestone_id_fk ='" . $act_base_info->milestone_id . "' and
           instance_id_fk = '" . $act_base_info->instance_id . "' and  role_id_fk  = '" . $act_base_info->role_id_fk . "' and exchange_no = '" . ($act_base_info->exchange_no - 1) . "' ", $conn);
        $exg_base_info_count = $request->recup_objet();
        if ($exg_base_info_count->exchange_no) {
            $reminder = true;
        }
    }
    $columnspan = array('1' => 7 , '2'=>8, '4'=>'9');
    $status_color = array("green", "orange", "red", "white", "grey");
    $linkPath = 'http://' . $_SERVER['HTTP_HOST'] . '/cem/scripts/index.php?&action=exgform&exgformid=' . $exg_form_id;
    $html = '';
    $html .= ' <html> <head> </head> <body> ';
    $html .= "\r\n";

    //FR Template  
    $html .= ' <p> Bonjour, </p> ';
    $html .= "\r\n";

    if ($reminder) {
        $html .= (' <p>' . $leader_info->nom . ' vous a transmis une nouvelle fiche navette n°' . $act_base_info->exchange_no . ' </p> ');
        $html .= (' <p>Merci d\'ignorer les précédentes fiches navette.</p> ');
        $html .= (' <p>Vous pouvez y répondre soit dans le tableau ci-dessous, soit en cliquant <a HREF="' . $linkPath . '"> ici </a> </p> ');
    } else {
        $html .= (' <p>Veuillez trouver ci-dessous la fiche navette n°' . $act_base_info->exchange_no . ' concernant le projet: ' . $act_base_info->project_code . ' </p> ');
        $html .= (' <p>Cette fiche contient tous les attendus à évaluer vous concernant pour le jalon: ' . $act_base_info->milestone_name . ' </p> ');
    }
    $html .= "\r\n";


    $html .= ' <table width="100%" border="1" cellpadding="0" cellspacing="0"> ' . "\r\n";
    $html .= ' <tbody> ' . "\r\n";
    $html .= ' <tr style="background-color:#CECECE;"> ' . "\r\n";

    $html .= ' <th width="15%">Attendu</th> ' . "\r\n";
    $html .= ' <th width="7%"> ' . ('ROV activité') . ' </th> ' . "\r\n";
    $html .= ' <th width="15%"> Contributeur </th> ' . "\r\n";
    $html .= ' <th width="8%"> ' . ('Dernière mise à jour') . ' </th> ' . "\r\n";
    if ($act_base_info->grid_type == '4') {
        $html .= ' <th width="15%"> ' . ('Identification de l\'écart') . ' </th> ' . "\r\n";
    }
    $html .= ' <th width="10%"> ' . ('Plan d\'action') . ' </th> ' . "\r\n";
    $html .= ' <th width="15%">Pilote</th> ' . "\r\n";
    $html .= ' <th width="8%"> ' . ('Echéance') . ' </th> ' . "\r\n";
    if ($act_base_info->grid_type == '4' || $act_base_info->grid_type == '2') {
        $html .= ' <th width="7%">ROV Plan</th> ' . "\r\n";
    }
    $html .= ' </tr> ' . "\r\n";
    $resultId = 0;
    $color_label['TR'] = 'V';

    if (count($activityData) > 0) {
        foreach ($activityData as $aKey => $aValues) {
      
            if ($resultId != $aValues['result_id']) {
                $resultId = $aValues['result_id'];
                $html .= ' <tr> <td colspan="' . $columnspan[$act_base_info->grid_type] . '"> ' . $aValues['topic_name_fr'] . ' </td> </tr> ' . "\r\n";
            }
            $html .= ' <tr> ' . "\r\n";
            $html .= ' <td width="15%"> ' . $aValues['result_order'] . '-' . $aValues['activity_order'] . '-' . $aValues['activity_name_fr'] . ' </td> ' . "\r\n";

            $colurVal = '';
            $fillColor ='';

            if (!empty($aValues[$status_color['4']])) {
                $colurVal = 'NA';
                $fillColor =$status_color['4'];
            }else  if (!empty($aValues[$status_color['3']])) {
                 $colurVal = 'NE';
                 $fillColor =$status_color['3'];
            }else  if (!empty($aValues[$status_color['2']])) {
                 $colurVal = 'R';
                 $fillColor =$status_color['2'];
            }else  if (!empty($aValues[$status_color['1']])) {
                 $colurVal = 'O';
                 $fillColor =$status_color['1'];
            }else  if (!empty($aValues[$status_color['0']])) {
                 $colurVal = 'V';
                 $fillColor =$status_color['0'];
            }
            $html.=' <td style="background-color:'.$fillColor.';text-align:center;"> '.$colurVal.' </td> ';
           
            if (checkDateTime($aValues['date_update'])) {
                $lastupdatedate = date('Y-m-d', strtotime($aValues['date_update']));
                $lastUpdateDate = formatDateEmail($lastupdatedate, 'fr');
            } else {
                $lastUpdateDate = '-';
            }

            $html .= ' <td width="15%"> ' . $contributor_info->nom . ' </td> ' . "\r\n";
            $html .= ' <td width="8%" align="center"> ' . $lastUpdateDate . ' </td> ' . "\r\n";

            if ($act_base_info->grid_type == '4') {
                $html .= ' <td colspan="5"> ' ;

                if (count($aValues['grid_data']) > 0) {
                    $html .= ' <table width="100%" border="1" cellpadding="0" cellspacing="0"> ';
                    foreach ($aValues['grid_data'] as $gdKey => $gdValues) {
                        
                        if (strtotime($gdValues['due_date'])) {
                            $dueDate = formatDateEmail($gdValues['due_date'], 'fr');
                        } else {
                            $dueDate = '-';
                        }
                        $html .= ' <tr> ' . "\r\n";
                        $html .= ' <td width="15%"> ' . $gdValues['deviation_text'] . ' </td> ' . "\r\n";
                        $html .= ' <td width="10%"> ' . $gdValues['action_plan'] . ' </td> ' . "\r\n";
                        $pilot_name = (!empty($gdValues['pilot'])) ? $arca->getName($gdValues['pilot']) : '';
                        $html .= ' <td width="15%"> ' . $pilot_name . ' </td> ' . "\r\n";
                        $html .= ' <td width="8%"> ' . $dueDate . ' </td> ' . "\r\n";
                        $html .= ' <td width="7%" align="center"> <table width="100%" border="1" cellpadding="0" cellspacing="0"> ' . "\r\n";
                        $d = 0;
                        foreach ($color_label as $eskey => $esval) {
                            if ($eskey != 'NA') {
                                $html .= ' <tr> <td width="7%" >' . $esval . ' </td> <td>' . $gdValues[$status_color[$d]] . ' </td> </tr> ' . "\r\n";
                                $d++;
                            }
                        }
                        $html .= ' </table> </td> </tr> ' . "\r\n";
                    }
                    $html .= ' </table> ' . "\r\n";
                }
                $html .= ' </td> ' . "\r\n";
            } else {
                $html .= ' <td width="10%"> '. $aValues['action_plan'] .' </td> ' . "\r\n";
                $pilot_name = (!empty($aValues['pilot'])) ? $arca->getName($aValues['pilot']) : '';
                $html .= ' <td width="15%"> ' . $pilot_name . ' </td> ' . "\r\n";
                
                if (strtotime($aValues['due_date'])) {
                    $dueDate = formatDateEmail($aValues['due_date'], 'fr');
                } else {
                    $dueDate = '-';
                }
                $html .= ' <td width="7%" align="center"> ' . $dueDate . ' </td> ' . "\r\n";
                if($act_base_info->grid_type == '2'){
                     $html .= ' <td> ' . "\r\n";
                    $c = 0;
                    $border = 1;
                    $html .= ' <table width="100%" border="1" cellpadding="0" cellspacing="0"> ' . "\r\n";

                    foreach ($color_label as $skey => $sval) {
                         $html .= ' <tr> <td width="7%"> ' . $sval . ' </td> <td>' . $aValues[$status_color[$c]] . ' </td> </tr> ' . "\r\n";
                        if($c==2){
                            break;
                        }
                    $c++;
                    }
                        $html .= ' </table> ' . "\r\n";
                        $html .= ' </td> ' . "\r\n";
                }
            }
            $html .= ' </tr> ' . "\r\n";
        }
        $html .= ' </tbody> ' . "\r\n";
        $html .= ' </table> ' . "\r\n";
    }
    if (!$reminder) {
        $html .= (' <p>Vous pouvez saisir votre évaluation directement dans CLEM en cliquant <a HREF="' . $linkPath . '">ici</a> ou en répondant par mail.</p>' . "\r\n");
        $html .= (' <p>La réponse par mail implique une prise en compte plus longue.</p>' . "\r\n");
    }
    $html .= ' <p>Cordialement,</p> ' . "\r\n";
    $html .= ' <p>' . $leader_info->nom . '.</p> ' . "\r\n";

    $html .=' <p>---------------------------------------------</p> ' . "\r\n";

    $html .= ' <p>Hello,</p> ' . "\r\n";
    if ($reminder) {
        $html .= (' <p>' . $leader_info->nom . ' sent you a new exchange form the n°' . $act_base_info->exchange_no . '. The previous one n°' . ($exg_base_info_count->exchange_no) . ' is cancelled</p>');
        $html .= "\r\n";
    } else {
        $html .= (' <p>Please find below the exchange form n°' . $act_base_info->exchange_no . ' regarding project: ' . $act_base_info->project_code . ' </p>');
        $html .= ' <p>This form contains all activities to evaluate, affected to you, for the milestone: ' . $act_base_info->milestone_name . ' </p> ';
        $html .= "\r\n";
    }

    $html .= ' <table width="100%" border="1" cellpadding="0" cellspacing="0"> ';
    $html .= ' <tbody> ';
    $html .= ' <tr style="background-color:#CECECE"> ';

    $html .= ' <th width="15%"> Activities </th> ';
    $html .= ' <th width="7%"> GOR </th> ';
    $html .= ' <th width="15%"> Contributor </th> ';
    $html .= ' <th width="8%"> Last update </th> ';
    if ($act_base_info->grid_type == '4') {
        $html .= ' <th width="15%"> Deviation </th> ';
    }
    $html .= ' <th width="10%"> Action plan </th> ';
    $html .= ' <th width="15%"> Pilot </th> ';
    $html .= ' <th width="8%"> Due date </th> ';
    if ($act_base_info->grid_type == '4' || $act_base_info->grid_type == '2') {
        $html .= ' <th width="7%"> GOR Eval </th> ';
    }
    $html .= ' </tr> ' . "\r\n";
    $color_label['TR'] = 'G';
    $resultId = 0;
    if (count($activityData) > 0) {
        foreach ($activityData as $aKey => $aValues) {
            if ($resultId != $aValues['result_id']) {
                $resultId = $aValues['result_id'];
                $html .= ' <tr> <td colspan="' . $columnspan[$act_base_info->grid_type] . '"> ' . ($aValues['topic_name_en']) . ' </td> </tr> ' . "\r\n";
            }
            $html .= ' <tr> ' . "\r\n";
            $html .= ' <td width="15%"> ' . $aValues['result_order'] . '-' . $aValues['activity_order'] . '-' . ($aValues['activity_name_en']) . ' </td> ' . "\r\n";
            $colurVal = '';
            $fillColor ='';

            if (!empty($aValues[$status_color['4']])) {
                $colurVal = 'NA';
                $fillColor =$status_color['4'];
            }else  if (!empty($aValues[$status_color['3']])) {
                 $colurVal = 'NE';
                 $fillColor =$status_color['3'];
            }else  if (!empty($aValues[$status_color['2']])) {
                 $colurVal = 'R';
                 $fillColor =$status_color['2'];
            }else  if (!empty($aValues[$status_color['1']])) {
                 $colurVal = 'O';
                 $fillColor =$status_color['1'];
            }else  if (!empty($aValues[$status_color['0']])) {
                 $colurVal = 'G';
                 $fillColor =$status_color['0'];
            }
            $html.=' <td style="background-color:'.$fillColor.';text-align:center;"> '.$colurVal.' </td> ' . "\r\n";
            

            if (checkDateTime($aValues['date_update'])) {
                $lastupdatedate = date('Y-m-d', strtotime($aValues['date_update']));
                $lastUpdate = formatDateEmail($lastupdatedate, 'en');
            } else {
                $lastUpdate = '-';
            }

            $html .= ' <td width="15%"> ' . $contributor_info->nom . ' </td> ' . "\r\n";
            $html .= ' <td width="8%" align="center"> ' . $lastUpdate . ' </td> ' . "\r\n";

            if ($act_base_info->grid_type == '4') {
                $html .= ' <td colspan="5"> ' . "\r\n";

                if (count($aValues['grid_data']) > 0) {
                    $html .= ' <table width="100%" border="1" cellpadding="0" cellspacing="0"> ' . "\r\n";
                    foreach ($aValues['grid_data'] as $gdKey => $gdValues) {
                        
                        if (strtotime($gdValues['due_date'])) {
                           $dueDate = formatDateEmail($gdValues['due_date'], 'en');
                        } else {
                            $dueDate = '-';
                        }
                        $html .= ' <tr> ' . "\r\n";
                        $html .= ' <td width="15%"> ' . $gdValues['deviation_text'] . ' </td> ' . "\r\n";
                        $html .= ' <td width="10%"> ' . $gdValues['action_plan'] . ' </td> ' . "\r\n";
                        $pilot_name = (!empty($gdValues['pilot'])) ? $arca->getName($gdValues['pilot']) : '';
                        $html .= ' <td width="15%"> ' . $pilot_name . ' </td> ' . "\r\n";
                        $html .= ' <td width="8%" align="center"> ' . $dueDate . ' </td> ' . "\r\n";
                        $html .= ' <td width="7%"> <table width="100%" border="1"> ' . "\r\n";
                        $d = 0;
                        foreach ($color_label as $eskey => $esval) {
                            if ($eskey != 'NA') {
                                $html .= ' <tr> <td width="7%" >' . $esval . ' </td> <td>' . $gdValues[$status_color[$d]] . ' </td> </tr> ' . "\r\n";
                                $d++;
                            }
                        }
                        $html .= ' </table> </td> </tr> ' . "\r\n";
                    }
                    $html .= ' </table> ' . "\r\n";
                }
                $html .= ' </td> ' . "\r\n";
            } else {
                $html .= ' <td width="10%"> '. strip_tags($aValues['action_plan']).' </td> ' . "\r\n";
                $pilot_name = (!empty($aValues['pilot'])) ? $arca->getName($aValues['pilot']) : '';
                $html .= ' <td width="15%"> '.strip_tags($pilot_name).' </td> ' . "\r\n";
                
                if (strtotime($aValues['due_date'])) {
                    $dueDate = formatDateEmail($aValues['due_date'], 'en');
                } else {
                    $dueDate = '-';
                }
                $html .= ' <td width="7%"> '.strip_tags($dueDate). ' </td> ' . "\r\n";
                 if($act_base_info->grid_type == '2'){
                     $html .= ' <td> ' . "\r\n";
                    $c = 0;
                    $border = 1;
                    $html .= ' <table width="100%" border="1" cellpadding="0" cellspacing="0"> ' . "\r\n";

                    foreach ($color_label as $skey => $sval) {
                        
                         $html .= ' <tr> <td width="7%"> ' . $sval . ' </td> <td>' . $aValues[$status_color[$c]] . ' </td> </tr> ' . "\r\n";
                        if($c==2){
                            break;
                        }
                        $c++;
                        }
                        $html .= ' </table> ' . "\r\n";
                        $html .= ' </td> ' . "\r\n";
                }
            }
            $html .= ' </tr> ' . "\r\n";
        }
        $html .= ' </tbody> ' . "\r\n";
        $html .= ' </table> ' . "\r\n";
        $html .= ' <p>You could input your evaluation directly by clicking <a HREF="' . $linkPath . '">here</a> or by answering to this email.</p> ' . "\r\n";
        $html .= ' <p>The mail answer implies a longer processing delay.</p> ' . "\r\n";
        $html .= ' <p>Regards,</p> ' . "\r\n";
        $html .= ' <p>' . $leader_info->nom . '.</p> ' . "\r\n";
    }


    $html .= ' </body> </html> ';
    return $html;
}

function getContextInfo($instance_id, $conn) {
    $request = new requete("select instcont.instance_id_fk, cont.context_item_name_" . $_SESSION['language'] . " as contextName, "
            . "cont.context_item_type, instcont.context_item_value,cont.context_item_id  from tb_instances_contexts instcont "
            . "join tb_contexts_items cont on cont.context_item_id = instcont.context_item_id_fk "
            . "where instcont.instance_id_fk = " . $instance_id . " limit 0,1", $conn);
    $inst_context_info = $request->recup_objet();
    if($inst_context_info && $inst_context_info->context_item_type != 'TEXT') {
        $request->envoi("SELECT civ.context_item_value_" . $_SESSION['language'] . " as contextValue "
                . "FROM tb_instances_contexts_values as icv "
                . "JOIN tb_contexts_items_values as civ on icv.context_item_value_id_fk = civ.context_item_value_id "
                . "WHERE civ.context_item_id_fk = " . $inst_context_info->context_item_id . " "
                . "AND icv.instance_id_fk = " . $instance_id);
        $contextValues = $request->recup_array_mono();
        $inst_context_info->context_item_value = join(", ", $contextValues);
    }

    return $inst_context_info;
}

function getsavedActivityData($exgFormId, $grid, $conn) {
    if ($grid == 4) {
        $request = new requete("select exgact.activity_exgform_id,exgact.instance_id_fk,exgact.repository_activity_id_fk,exgact.exchange_form_id_fk, 
            eva.activity_evaluation_exgform_id,eva.skill_entity,eva.deviation_text,eva.count_external_link,
            eva.green as GREEN,eva.red as RED,eva.orange as ORANGE,eva.white as WHITE,eva.evalution_data,eva.activity_evaluation_id_fk,
            evaction.action_plan, evaction.pilot, evaction.due_date
from tb_instances_activities_exgform exgact join tb_instances_activities_evaluation_grid_exgform eva on eva.activity_exgform_id_fk = exgact.activity_exgform_id
left join tb_instances_activities_action_plans_exgform evaction on evaction.activity_evaluation_exgform_id_fk =  eva.activity_evaluation_exgform_id
 where exgact.exchange_form_id_fk = " . $exgFormId, $conn);
        $savedActivityData = $request->recup_array_champ();
    } else {
        $request = new requete("select exgact.activity_exgform_id,exgact.instance_id_fk,exgact.repository_activity_id_fk,
            exgact.activity_comment,exgact.date_update,exgact.user_update,exgact.count_external_link,exgact.GREEN,exgact.RED,
            exgact.ORANGE,exgact.WHITE,exgact.GREY,exgact.saved_data,exgact.exchange_form_id_fk ,
            evaction.action_plan, evaction.pilot, evaction.due_date
            from tb_instances_activities_exgform exgact 
            left join tb_instances_activities_action_plans_exgform evaction on evaction.activity_exgform_id_fk =  exgact.activity_exgform_id
            where exgact.exchange_form_id_fk =" . $exgFormId, $conn);
        $savedActivityData = $request->recup_array_champ();
    }
    return $savedActivityData;
}

function getExchangeFormMailContentsValidate($exg_form_id, $content_labels, $tablo_libelle_statut, $conn, $arca, $appliedData) {

    $color_label = $tablo_libelle_statut;
    $columnspan = array('1' => 8 , '2'=>8, '4'=>'9');
    $act_base_info = getExchangeFormBaseInfo($exg_form_id, $conn);
    $leader_info = $arca->getUserData($act_base_info->leader_ipn);
    $contributor_info = $arca->getUserData($act_base_info->contributor_ipn);
    $activityData = getExgFormActivitisList($exg_form_id, $act_base_info->grid_type, $conn);
    $currentActivityDatas = getActivitisList($exg_form_id, $act_base_info->grid_type, $conn);
  
    $sqlProjectItems = "SELECT p.project_code FROM tb_projects as p "
            . "JOIN tb_instance_projects as pi ON pi.project_id_fk = p.project_id AND pi.instance_id_fk = ".$act_base_info->instance_id." "
            . "GROUP BY p.project_code";
    $request=new requete($sqlProjectItems,$conn);
    $project_infos = $request->recup_array_mono();
    $act_base_info->project_code = join(", ", $project_infos);
    
    $linkPath = 'http://' . $_SERVER['HTTP_HOST'] . '/cem/scripts/index.php?&action=exgform&exgformid=' . $exg_form_id;
    $status_color = array("green", "orange", "red", "white", "grey");
    $html = '';
    $html .= ' <html> <head> </head> <body> ' . "\r\n";

    //FR Template  
    $html .= ' <p>Bonjour,</p> ' . "\r\n";
    $html .= (' <p>' . $leader_info->nom . ' a revu la fiche navette n°' . $act_base_info->exchange_no . ':' . $act_base_info->instance_id . ' - ' . $act_base_info->milestone_name . ' - ' . $act_base_info->project_code . '.</p>');
    $html .= (' <p>Voici le résultat :</p> ' . "\r\n");


    $html .= ' <table width="100%" border="1" cellpadding="0" cellsapcing="0"> ' . "\r\n";
    $html .= ' <tbody> ' . "\r\n";
    $html .= ' <tr style="background-color:#CECECE"> ' . "\r\n";

    $html .= ' <th width="15%"> Attendu </th> ' . "\r\n";
    $html .= ' <th width="7%"> ROV </th> ' . "\r\n";
    $html .= ' <th width="15%"> Contributeur </th> ' . "\r\n";
    $html .= ' <th width="8%"> ' . ('Dernière mise à jour') . ' </th> ' . "\r\n";
    if ($act_base_info->grid_type == '4') {
        $html .= ' <th width="15%"> ' . ('Identification de l\'écart') . ' </th> ' . "\r\n";
    }
    $html .= ' <th width="10%"> ' . ('Plan d\'action') . ' </th> ' . "\r\n";
    $html .= ' <th width="15%"> Pilote </th> ' . "\r\n";
    $html .= ' <th width="8%"> ' . ('Echéance') . ' </th> ' . "\r\n";
    $html .= ' <th width="7%"> ROV Plan </th> ' . "\r\n";
    
    $html .= ' </tr> ' . "\r\n";
    $color_label['TR'] = 'V';
    $resultId = 0;
    if (count($activityData) > 0) {
        foreach ($activityData as $aKey => $aValues) {
            $currentActivitiesData = $currentActivityDatas[$aValues['activity_id']];
            $appliedActivitesData = $appliedData[$aValues['activity_id']];
            if ($resultId != $aValues['result_id']) {
                $resultId = $aValues['result_id'];
                $html .= ' <tr> <td colspan="' . $columnspan[$act_base_info->grid_type] . '"> ' . $aValues['topic_name_fr'] . ' </td> </tr> ' . "\r\n";
            }
            $html .= ' <tr> ' . "\r\n";
            $html .= ' <td width="15%"> ' . $aValues['result_order'] . '-' . $aValues['activity_order'] . '-' . $aValues['activity_name_fr'] . ' </td> ' . "\r\n";
             $colurVal = '';
            $fillColor ='';

            if (!empty($aValues[$status_color['4']])) {
                $colurVal = 'NA';
                $fillColor =$status_color['4'];
            }else  if (!empty($aValues[$status_color['3']])) {
                 $colurVal = 'NE';
                 $fillColor =$status_color['3'];
            }else  if (!empty($aValues[$status_color['2']])) {
                 $colurVal = 'R';
                 $fillColor =$status_color['2'];
            }else  if (!empty($aValues[$status_color['1']])) {
                 $colurVal = 'O';
                 $fillColor =$status_color['1'];
            }else  if (!empty($aValues[$status_color['0']])) {
                 $colurVal = 'V';
                 $fillColor =$status_color['0'];
            }
            $html.=' <td style="background-color:'.$fillColor.';text-align:center;"> '.$colurVal.' </td> ' . "\r\n";
            if (checkDateTime($aValues['date_update'])) {
                $lastupdatedate = date('Y-m-d', strtotime($aValues['date_update']));
                $lastUpdateDate = formatDateEmail($lastupdatedate, 'fr');
                $lastUpdate = $lastUpdateDate;
            } else {
                $lastUpdate = '-';
            }

            $html .= ' <td width="15%"> ' . $contributor_info->nom . ' </td> ' . "\r\n";
            $html .= ' <td width="8%" align="center"> ' . $lastUpdate . ' </td> ' . "\r\n";

            if ($act_base_info->grid_type == '4') {
                $html .= ' <td colspan="5"> ';

                if (count($aValues['grid_data']) > 0) {
                    $html .= ' <table width="100%" border="1" cellpadding="0" cellsapcing="0"> ' . "\r\n";
                    foreach ($aValues['grid_data'] as $gdKey => $gdValues) {

                        if (!empty($gdValues['activity_evaluation_id_fk'])) {
                            $currentdata = $currentActivitiesData['grid_data'][$gdValues['activity_evaluation_id_fk']];
                            $appliedActData = $appliedData[$aValues['activity_id']]['grid_data'][$gdValues['activity_evaluation_id_fk']];
                        }

                        
                        if (strtotime($gdValues['due_date'])) {
                            $dueDate = formatDateEmail($gdValues['due_date'], 'fr');
                        } else {
                            $dueDate = '-';
                        }
                        $html .= ' <tr> ';
                        $appllied = '#FFFFFF';
                        if (!empty($gdValues['activity_evaluation_id_fk'])) {
                            if ($currentdata['deviation_text'] == $gdValues['deviation_text'] && $currentdata['deviation_text'] != $appliedActData['deviation_text']) {
                                $appllied = '#ffff00';
                            }
                            if ($currentdata['deviation_text'] != $gdValues['deviation_text'] && $currentdata['deviation_text'] == $appliedActData['deviation_text']) {
                                $appllied = '#ff0000';
                            }
                        } else {
                            $appllied = '#ffff00';
                        }
                        $html .= ' <td width="15%" style="background-color:' . $appllied . '"> ' . $gdValues['deviation_text'] . ' </td> ';
                        $appllied = '#FFFFFF';
                        if (!empty($gdValues['activity_evaluation_id_fk'])) {
                            if ($currentdata['action_plan'] == $gdValues['action_plan'] && $currentdata['action_plan'] != $appliedActData['action_plan']) {
                                $appllied = '#ffff00';
                            }
                            if ($currentdata['action_plan'] != $gdValues['action_plan'] && $currentdata['action_plan'] == $appliedActData['action_plan']) {
                                $appllied = '#ff0000';
                            }
                        } else {
                            $appllied = '#ffff00';
                        }
                        $html .= ' <td width="10%" style="background-color:' . $appllied . '"> ' . $gdValues['action_plan'] . ' </td> ';
                        $appllied = '#FFFFFF';
                        if (!empty($gdValues['activity_evaluation_id_fk'])) {
                            if ($currentdata['pilot'] == $gdValues['pilot'] && $currentdata['pilot'] != $appliedActData['pilot']) {
                                $appllied = '#ffff00';
                            }
                            if ($currentdata['pilot'] != $gdValues['pilot'] && $currentdata['pilot'] == $appliedActData['pilot']) {
                                $appllied = '#ff0000';
                            }
                        } else {
                            $appllied = '#ffff00';
                        }
                        $pilot_name = (!empty($gdValues['pilot'])) ? $arca->getName($gdValues['pilot']) : '';
                        $html .= ' <td width="15%" style="background-color:' . $appllied . '"> ' . $pilot_name . ' </td> ' . "\r\n";
                        $appllied = '#FFFFFF';
                        if (!empty($gdValues['activity_evaluation_id_fk'])) {
                            if ($currentdata['due_date'] == $gdValues['due_date'] && $currentdata['due_date'] != $appliedActData['due_date']) {
                                $appllied = '#ffff00';
                            }
                            if ($currentdata['due_date'] != $gdValues['due_date'] && $currentdata['due_date'] == $appliedActData['due_date']) {
                                $appllied = '#ff0000';
                            }
                        } else {
                            $appllied = '#ffff00';
                        }
                        $html .= ' <td width="8%" style="background-color:' . $appllied . '" align="center"> ' . $dueDate . ' </td> ' . "\r\n";
                        $html .= ' <td width="7%"> <table width="100%" border="1" cellpadding="0" cellsapcing="0"> ' . "\r\n";
                        $d = 0;
                        foreach ($color_label as $eskey => $esval) {
                            if ($eskey != 'NA') {
                                $colorName = $status_color[$d];
                                 $appllied = '#FFFFFF';
                                if (!empty($gdValues['activity_evaluation_id_fk'])) {
                                    if ($currentdata[$colorName] == $gdValues[$colorName] && $currentdata[$colorName] != $appliedActData[$colorName]) {
                                        $appllied = '#ffff00';
                                    }
                                    if ($currentdata[$colorName] != $gdValues[$colorName] && $currentdata[$colorName] == $appliedActData[$colorName]) {
                                        $appllied = '#ff0000';
                                    }
                                } else {
                                    $appllied = '#ffff00';
                                }
                                $html .= ' <tr style="background-color:' . $appllied . '"> <td width="7%"> ' . $esval . ' </td> <td>' . $gdValues[$colorName] . ' </td> </tr> ' . "\r\n";
                                $d++;
                            }
                        }
                        $html .= ' </table> </td> </tr> ' . "\r\n";
                    }
                    $html .= ' </table> ' . "\r\n";
                }

                $html .= ' </td> ' . "\r\n";
            } else {
                $appllied = '#FFFFFF';
                if ($currentActivitiesData['action_plan'] == $aValues['action_plan'] && $currentActivitiesData['action_plan'] != $appliedActivitesData['action_plan']) {
                    $appllied = '#ffff00';
                }
                if ($currentActivitiesData['action_plan'] != $aValues['action_plan'] && $currentActivitiesData['action_plan'] == $appliedActivitesData['action_plan']) {
                    $appllied = '#ff0000';
                }
                $html .= ' <td width="10%" style="background-color:' . $appllied . '"> ' . $aValues['action_plan'] . ' </td> ';
                $appllied = '#FFFFFF';
                if ($currentActivitiesData['pilot'] == $aValues[$status_color[$c]] && $currentActivitiesData['pilot'] != $appliedActivitesData['pilot']) {
                    $appllied = '#ffff00';
                }
                if ($currentActivitiesData['pilot'] != $aValues['pilot'] && $currentActivitiesData['pilot'] == $appliedActivitesData['pilot']) {
                    $appllied = '#ff0000';
                }
                $pilot_name = (!empty($aValues['pilot'])) ? $arca->getName($aValues['pilot']) : '';
                $html .= ' <td width="15%" style="background-color:' . $appllied . '"> ' . $pilot_name . ' </td> ';
                $appllied = '#FFFFFF';
                if ($currentActivitiesData['due_date'] == $aValues['due_date'] && $currentActivitiesData['due_date'] != $appliedActivitesData['due_date']) {
                    $appllied = '#ffff00';
                }
                if ($currentActivitiesData['due_date'] != $aValues['due_date'] && $currentActivitiesData['due_date'] == $appliedActivitesData['due_date']) {
                    $appllied = '#ff0000';
                }
                if (strtotime($aValues['due_date'])) {
                    $dueDate = formatDateEmail($aValues['due_date'], 'fr');
                } else {
                    $dueDate = '-';
                }
                $html .= ' <td width="7%" style="background-color:' . $appllied . '"> ' . $dueDate . ' </td> ' . "\r\n";
                $html .= ' <td> ' . "\r\n";
                
                $c = 0;
                $html .= ' <table width="100%" border="1" cellpadding="0" cellsapcing="0"> ' . "\r\n";

                foreach ($color_label as $skey => $sval) {
                    $appllied = '#FFFFFF';
                    if ($currentActivitiesData[strtoupper($status_color[$c])] == $aValues[$status_color[$c]] && $currentActivitiesData[strtoupper($status_color[$c])] != $appliedActivitesData[strtoupper($status_color[$c])]) {
                        $appllied = '#ffff00';
                    }
                    if ($currentActivitiesData[strtoupper($status_color[$c])] != $aValues[$status_color[$c]] && $currentActivitiesData[strtoupper($status_color[$c])] == $appliedActivitesData[strtoupper($status_color[$c])]) {
                        $appllied = '#ff0000';
                    }


                    $html .= ' <tr style="background-color:' . $appllied . '"> <td width="7%"> ' . $sval . ' </td> <td > ' . $aValues[$status_color[$c]] . ' </td> </tr> ' . "\r\n";
                    $c++;
                }
                $html .= ' </table> ' . "\r\n";
                $html .= ' </td> ' . "\r\n";
            }
            $html .= ' </tr> ' . "\r\n";
        }
    }



    $html .= ' </tbody> ';
    $html .= ' </table> ' . "\r\n";
    $html .= (' <p>Vous pouvez consulter votre réponse en cliquant <a HREF="' . $linkPath . '"> <strong>ici</strong> </a> </p>');
    $html .= ' <p>Cordialement,</p> ';
    $html .= ' <p>' . $leader_info->nom . '.</p> ';
    $html .=' <p>---------------------------------------------</p> ' . "\r\n";

    //EN Template
    $html .= ' <p>Hello,</p> ' . "\r\n";
    $html .= (' <p>' . $leader_info->nom . ' reviewed your answer to the exchange form n°' . $act_base_info->exchange_no . ':' . $act_base_info->instance_id . ' - ' . $act_base_info->milestone_name . ' - ' . $act_base_info->project_code . '.</p>');
    $html .= ' <p>Here the result :</p> ' . "\r\n";


    $html .= ' <table width="100%" border="1" cellpadding="0" cellspacing="0"> ' . "\r\n";
    $html .= ' <tbody> ' . "\r\n";
    $html .= ' <tr style="background-color:#CECECE"> ' . "\r\n";

    $html .= ' <th width="15%"> Activities </th> ' . "\r\n";
    $html .= ' <th width="7%"> GOR </th> ' . "\r\n";
    $html .= ' <th width="15%"> Contributor </th> ' . "\r\n";
    $html .= ' <th width="8%"> Last update </th> ' . "\r\n";
    if ($act_base_info->grid_type == '4') {
        $html .= ' <th width="15%"> Deviation </th> ' . "\r\n";
    }
    $html .= ' <th width="10%"> Action plan </th> ' . "\r\n";
    $html .= ' <th width="15%"> Pilot </th> ' . "\r\n";
    $html .= ' <th width="8%"> Due date </th> ' . "\r\n";
    $html .= ' <th width="7%"> GOR Eval </th> ' . "\r\n";

    $html .= ' </tr> ' . "\r\n";
     $color_label['TR'] = 'G';
     $resultId = 0;
    if (count($activityData) > 0) {
        foreach ($activityData as $aKey => $aValues) {
            $currentActivitiesData = $currentActivityDatas[$aValues['activity_id']];
            $appliedActivitesData = $appliedData[$aValues['activity_id']];
            if ($resultId != $aValues['result_id']) {
                $html .= ' <tr> <td colspan="' . $columnspan[$act_base_info->grid_type] . '"> ' . ($aValues['topic_name_en']) . ' </td> </tr> ' . "\r\n";
            }
            $html .= ' <tr> ' . "\r\n";
            $html .= ' <td width="15%"> ' . $aValues['result_order'] . '-' . $aValues['activity_order'] . '-' . ($aValues['activity_name_en']) . ' </td> ' . "\r\n";
              $colurVal = '';
            $fillColor ='';

            if (!empty($aValues[$status_color['4']])) {
                $colurVal = 'NA';
                $fillColor =$status_color['4'];
            }else  if (!empty($aValues[$status_color['3']])) {
                 $colurVal = 'NE';
                 $fillColor =$status_color['3'];
            }else  if (!empty($aValues[$status_color['2']])) {
                 $colurVal = 'R';
                 $fillColor =$status_color['2'];
            }else  if (!empty($aValues[$status_color['1']])) {
                 $colurVal = 'O';
                 $fillColor =$status_color['1'];
            }else  if (!empty($aValues[$status_color['0']])) {
                 $colurVal = 'V';
                 $fillColor =$status_color['0'];
            }
            $html.=' <td style="background-color:'.$fillColor.';text-align:center;"> '.$colurVal.' </td> ' . "\r\n";
            

            
            if (checkDateTime($aValues['date_update'])) {
                $lastupdatedate = date('Y-m-d', strtotime($aValues['date_update']));
                $lastUpdateDate = formatDateEmail($lastupdatedate, 'en');
                $lastUpdate = $lastUpdateDate;
            } else {
                $lastUpdate = '-';
            }

            $html .= ' <td width="15%"> ' . $contributor_info->nom . ' </td> ' . "\r\n";
            $html .= ' <td width="8%" align="center"> ' . $lastUpdate . ' </td> ' . "\r\n";

            if ($act_base_info->grid_type == '4') {
                $html .= ' <td colspan="5"> ' . "\r\n";

                if (count($aValues['grid_data']) > 0) {
                    $html .= ' <table width="100%" border="1" cellpadding="0" cellspacing="0"> ' . "\r\n";
                    foreach ($aValues['grid_data'] as $gdKey => $gdValues) {

                        if (!empty($gdValues['activity_evaluation_id_fk'])) {
                            $currentdata = $currentActivitiesData['grid_data'][$gdValues['activity_evaluation_id_fk']];
                            $appliedActData = $appliedData[$aValues['activity_id']]['grid_data'][$gdValues['activity_evaluation_id_fk']];
                        }

                        
                        if (strtotime($gdValues['due_date'])) {
                            $dueDate = formatDateEmail($gdValues['due_date'], 'en');
                        } else {
                            $dueDate = '-';
                        }
                        $html .= ' <tr> ' . "\r\n";
                        $appllied = '#FFFFFF';
                        if (!empty($gdValues['activity_evaluation_id_fk'])) {
                            if ($currentdata['deviation_text'] == $gdValues['deviation_text'] && $currentdata['deviation_text'] != $appliedActData['deviation_text']) {
                                $appllied = '#ffff00';
                            }
                            if ($currentdata['deviation_text'] != $gdValues['deviation_text'] && $currentdata['deviation_text'] == $appliedActData['deviation_text']) {
                                $appllied = '#ff0000';
                            }
                        } else {
                            $appllied = '#ffff00';
                        }
                        $html .= ' <td width="15%" style="background-color:' . $appllied . '"> ' . $gdValues['deviation_text'] . ' </td> ' . "\r\n";
                        $appllied = '#FFFFFF';
                        if (!empty($gdValues['activity_evaluation_id_fk'])) {
                            if ($currentdata['action_plan'] == $gdValues['action_plan'] && $currentdata['action_plan'] != $appliedActData['action_plan']) {
                                $appllied = '#ffff00';
                            }
                            if ($currentdata['action_plan'] != $gdValues['action_plan'] && $currentdata['action_plan'] == $appliedActData['action_plan']) {
                                $appllied = '#ff0000';
                            }
                        } else {
                            $appllied = '#ffff00';
                        }
                        $html .= ' <td width="10%" style="background-color:' . $appllied . '"> ' . $gdValues['action_plan'] . ' </td> ' . "\r\n";
                        $appllied = '#FFFFFF';
                        if (!empty($gdValues['activity_evaluation_id_fk'])) {
                            if ($currentdata['pilot'] == $gdValues['pilot'] && $currentdata['pilot'] != $appliedActData['pilot']) {
                                $appllied = '#ffff00';
                            }
                            if ($currentdata['pilot'] != $gdValues['pilot'] && $currentdata['pilot'] == $appliedActData['pilot']) {
                                $appllied = '#ff0000';
                            }
                        } else {
                            $appllied = '#ffff00';
                        }
                        $pilot_name = (!empty($gdValues['pilot'])) ? $arca->getName($gdValues['pilot']) : '';
                        $html .= ' <td width="15%" style="background-color:' . $appllied . '"> ' . $pilot_name . ' </td> ' . "\r\n";
                        $appllied = '#FFFFFF';
                        if (!empty($gdValues['activity_evaluation_id_fk'])) {
                            if ($currentdata['due_date'] == $gdValues['due_date'] && $currentdata['due_date'] != $appliedActData['due_date']) {
                                $appllied = '#ffff00';
                            }
                            if ($currentdata['due_date'] != $gdValues['due_date'] && $currentdata['due_date'] == $appliedActData['due_date']) {
                                $appllied = '#ff0000';
                            }
                        } else {
                            $appllied = '#ffff00';
                        }
                        $html .= ' <td width="8%" style="background-color:' . $appllied . '"> ' . $dueDate . ' </td> ' . "\r\n";
                        $html .= ' <td width="7%"> <table width="100%" border="1" cellpadding="0" cellspacing="0"> ' . "\r\n";
                        $d = 0;
                        foreach ($color_label as $eskey => $esval) {
                            if ($eskey != 'NA') {
                               $colorName = $status_color[$d];
                                 $appllied = '#FFFFFF';
                                if (!empty($gdValues['activity_evaluation_id_fk'])) {
                                    if ($currentdata[$colorName] == $gdValues[$colorName] && $currentdata[$colorName] != $appliedActData[$colorName]) {
                                        $appllied = '#ffff00';
                                    }
                                    if ($currentdata[$colorName] != $gdValues[$colorName] && $currentdata[$colorName] == $appliedActData[$colorName]) {
                                        $appllied = '#ff0000';
                                    }
                                } else {
                                    $appllied = '#ffff00';
                                }
                                $html .= ' <tr style="background-color:' . $appllied . '"> <td width="7%" > ' . $esval . ' </td> <td>' . $gdValues[$colorName] . ' </td> </tr> ' . "\r\n";
                                $d++;
                            }
                        }
                        $html .= ' </table> </td> </tr> ' . "\r\n";
                    }
                    $html .= ' </table> ' . "\r\n";
                }

                $html .= ' </td> ' . "\r\n";
            } else {
                $appllied = '#FFFFFF';
                if ($currentActivitiesData['action_plan'] == $aValues['action_plan'] && $currentActivitiesData['action_plan'] != $appliedActivitesData['action_plan']) {
                    $appllied = '#ffff00';
                }
                if ($currentActivitiesData['action_plan'] != $aValues['action_plan'] && $currentActivitiesData['action_plan'] == $appliedActivitesData['action_plan']) {
                    $appllied = '#ff0000';
                }
                $html .= ' <td width="10%" style="background-color:' . $appllied . '"> ' . $aValues['action_plan'] . ' </td> ' . "\r\n";
                $appllied = '#FFFFFF';
                if ($currentActivitiesData['pilot'] == $aValues[$status_color[$c]] && $currentActivitiesData['pilot'] != $appliedActivitesData['pilot']) {
                    $appllied = '#ffff00';
                }
                if ($currentActivitiesData['pilot'] != $aValues['pilot'] && $currentActivitiesData['pilot'] == $appliedActivitesData['pilot']) {
                    $appllied = '#ff0000';
                }
                $pilot_name = (!empty($aValues['pilot'])) ? $arca->getName($aValues['pilot']) : '';
                $html .= ' <td width="15%" style="background-color:' . $appllied . '"> ' . $pilot_name . ' </td> ' . "\r\n";
                $appllied = '#FFFFFF';
                if ($currentActivitiesData['due_date'] == $aValues['due_date'] && $currentActivitiesData['due_date'] != $appliedActivitesData['due_date']) {
                    $appllied = '#ffff00';
                }
                if ($currentActivitiesData['due_date'] != $aValues['due_date'] && $currentActivitiesData['due_date'] == $appliedActivitesData['due_date']) {
                    $appllied = '#ff0000';
                }
                
                if (strtotime($aValues['due_date'])) {
                    $dueDate = formatDateEmail($aValues['due_date'], 'en');
                } else {
                    $dueDate = '-';
                }
                $html .= ' <td width="7%" style="background-color:' . $appllied . '" align="center"> ' . $dueDate . ' </td> ' . "\r\n";
                $c = 0;
                $html .= ' <td> <table width="100%" border="1" cellpadding="0" cellspacing="0"> ' . "\r\n";

                foreach ($color_label as $skey => $sval) {
                    $appllied = '#FFFFFF';
                    if ($currentActivitiesData[strtoupper($status_color[$c])] == $aValues[$status_color[$c]] && $currentActivitiesData[strtoupper($status_color[$c])] != $appliedActivitesData[strtoupper($status_color[$c])]) {
                        $appllied = '#ffff00';
                    }
                    if ($currentActivitiesData[strtoupper($status_color[$c])] != $aValues[$status_color[$c]] && $currentActivitiesData[strtoupper($status_color[$c])] == $appliedActivitesData[strtoupper($status_color[$c])]) {
                        $appllied = '#ff0000';
                    }


                    $html .= ' <tr style="background-color:' . $appllied . '"> <td width="7%"> ' . $sval . ' </td> <td> ' . $aValues[$status_color[$c]] . ' </td> </tr> ' . "\r\n";
                    $c++;
                }
                $html .= ' </table> ' . "\r\n";
                $html .= ' </td> ' . "\r\n";
            }
            $html .= ' </tr> ' . "\r\n";
        }
    }
    $html .= ' </tbody> ';
    $html .= ' </table> ' . "\r\n";
    $html .= ' <p>You could consult your answer by clicking <a HREF="' . $linkPath . '"> <strong> here </strong> </a> </p> ' . "\r\n";
    $html .= ' <p>Regards,</p> ';
    $html .= ' <p>' . $leader_info->nom . '.</p> ' . "\r\n";
    $html .= ' </body> </html> ';
    return $html;
}

function getExchangeFormRemainderMailContents($exg_form_id, $content_labels, $tablo_libelle_statut, $conn, $arca) {
 global $SERVER_URL;
    $color_label = $tablo_libelle_statut;
    $columnspan = array('1' => 7 , '2'=>8, '4'=>'9');
    $act_base_info = getExchangeFormBaseInfo($exg_form_id, $conn);
    $leader_info = $arca->getUserData($act_base_info->leader_ipn);
    $contributor_info = $arca->getUserData($act_base_info->contributor_ipn);
    $activityData = getExgFormActivitisList($exg_form_id, $act_base_info->grid_type, $conn);
    $linkPath = 'http://' . $SERVER_URL . '/cem/scripts/index.php?&action=exgform&exgformid=' . $exg_form_id;
    $status_color = array("green", "orange", "red", "white", "grey");
    $html = '';
    $html .= ' <html> <head> </head> <body> ' . "\r\n";

    //EN Template
    //FR TEmplate

    $html .= ' <p>Bonjour,</p> ' . "\r\n";
    $html .= (' <p>Ceci est une relance, ' . $leader_info->nom . ' vous a transmis la fiche navette n°' . $act_base_info->exchange_no . '. </p>');
    $html .= (' <p>Merci de répondre dès que possible, soit dans le tableau ci-dessous, soit en cliquant <a HREF="' . $linkPath . '"> <strong>ici</strong> </a>.</p>' . "\r\n");
    $html .= ' <table width="100%" border="1" cellpadding="0" cellspacing="0"> ';
    $html .= ' <tbody> ' . "\r\n";
    // Header data
    $html .= ' <tr style="background-color:#CECECE;"> ' . "\r\n";
    $html .= ' <th width="15%"> Attendu </th> ' . "\r\n";
    $html .= ' <th width="7%"> ROV </th> ' . "\r\n";
    $html .= ' <th width="15%"> Contributeur </th> ' . "\r\n";
    $html .= ' <th width="8%"> ' . ('Dernière mise à jour') . ' </th> ' . "\r\n";
    if ($act_base_info->grid_type == '4') {
        $html .= ' <th width="15%"> ' . ('Identification de l\'écart') . ' </th> ' . "\r\n";
    }
    $html .= ' <th width="10%"> ' . ('Plan d\'action') . ' </th> ' . "\r\n";
    $html .= ' <th width="15%"> Pilote </th> ' . "\r\n";
    $html .= ' <th width="8%"> ' . ('Echéance') . ' </th> ' . "\r\n";
    if ($act_base_info->grid_type == '4' || $act_base_info->grid_type == '2') {
        $html .= ' <th width="7%"> ROV Plan </th> ' . "\r\n";
    }
    $html .= ' </tr> ' . "\r\n";
    // Header Data
     $color_label['TR'] = 'V';
    if (count($activityData) > 0) {
        $resultId = 0;
        foreach ($activityData as $aKey => $aValues) {
            if ($resultId != $aValues['result_id']) {
                $resultId = $aValues['result_id'];
                $html .= ' <tr> <td colspan="' . $columnspan[$act_base_info->grid_type] . '"> ' . $aValues['topic_name_fr'] . ' </td> </tr> ' . "\r\n";
            }
            $html .= ' <tr> ' . "\r\n";
            $html .= ' <td width="15%"> ' . $aValues['result_order'] . '-' . $aValues['activity_order'] . '-' . addslashes($aValues['activity_name_fr']) . ' </td> ' . "\r\n";
             if (!empty($aValues[$status_color['4']])) {
                $colurVal = 'NA';
                $fillColor =$status_color['4'];
            }else  if (!empty($aValues[$status_color['3']])) {
                 $colurVal = 'NE';
                 $fillColor =$status_color['3'];
            }else  if (!empty($aValues[$status_color['2']])) {
                 $colurVal = 'R';
                 $fillColor =$status_color['2'];
            }else  if (!empty($aValues[$status_color['1']])) {
                 $colurVal = 'O';
                 $fillColor =$status_color['1'];
            }else  if (!empty($aValues[$status_color['0']])) {
                 $colurVal = 'V';
                 $fillColor =$status_color['0'];
            }
            $html.=' <td style="background-color:'.$fillColor.';text-align:center;"> '.$colurVal.' </td> ' . "\r\n";
            $html .= ' <td width="15%"> ' . $contributor_info->nom . ' </td> ' . "\r\n";
            if (checkDateTime($aValues['date_update'])) {
                $lastupdatedate = date('Y-m-d', strtotime($aValues['date_update']));
                $lastUpdateDate = formatDateEmail($lastupdatedate . 'fr');
            } else {
                $lastUpdateDate = '-';
            }
            $html .= ' <td width="8%" center="align"> ' . $lastUpdateDate . ' </td> ' . "\r\n";

            if ($act_base_info->grid_type == '4') {
                $html .= ' <td colspan="5"> ';

                if (count($aValues['grid_data']) > 0) {
                    $html .= ' <table width="100%" border="1" cellpadding="0" cellspacing="0"> ';
                    foreach ($aValues['grid_data'] as $gdKey => $gdValues) {

                        if(!empty($gdValues['activity_evaluation_exgform_id'])){
                            if (strtotime($gdValues['due_date'])) {
                                $due_date = formatDateEmail($gdValues['due_date'], 'fr');
                            } else {
                                $due_date = '-';
                            }
                            $html .= ' <tr> ' . "\r\n";
                            $html .= ' <td width="15%"> ' . $gdValues['deviation_text'] . ' </td> ' . "\r\n";
                            $html .= ' <td width="10%"> ' . $gdValues['action_plan'] . ' </td> ' . "\r\n";
                            $pilot_name = (!empty($gdValues['pilot'])) ? $arca->getName($gdValues['pilot']) : '';
                            $html .= ' <td width="15%"> ' . $pilot_name . ' </td> ' . "\r\n";
                            $html .= ' <td width="8%" center="align"> ' . $due_date . ' </td> ' . "\r\n";
                            $html .= ' <td width="7%">
                                 <table width="100%" border="1"> ' . "\r\n";
                            $d = 0;
                            foreach ($color_label as $eskey => $esval) {
                                if ($eskey != 'NA') {
                                    $html .= ' <tr> <td width="7%" >' . $esval . ' </td> <td>' . $gdValues[$status_color[$d]] . ' </td> </tr> ' . "\r\n";
                                    $d++;
                                }
                            }
                            $html .= ' </table> </td>
                           </tr> ' . "\r\n";
                        }
                    }
                    $html .= ' </table> ' . "\r\n";
                }
                $html .= ' </td> ' . "\r\n";
            } else {
                $html .= ' <td width="10%"> ' . $aValues['action_plan'] . ' </td> ' . "\r\n";
                $pilot_name = (!empty($aValues['pilot'])) ? $arca->getName($aValues['pilot']) : '';
                $html .= ' <td width="15%"> ' . $pilot_name . ' </td> ' . "\r\n";
                
                if (strtotime($aValues['due_date'])) {
                    $due_date = formatDateEmail($aValues['due_date'], 'fr');
                } else {
                    $due_date = '-';
                }
                $html .= ' <td width="7%" center="align"> ' . $due_date . ' </td> ' . "\r\n";
                 if($act_base_info->grid_type == '2'){
                     $html .= ' <td> ';
                    $c = 0;
                    $border = 1;
                    $html .= ' <table width="100%" border="1" cellpadding="0" cellspacing="0"> ' . "\r\n";

                    foreach ($color_label as $skey => $sval) {
                        $html .= ' <tr> <td width="7%"> ' . $sval . ' </td> <td>' . $aValues[$status_color[$c]] . ' </td> </tr> ' . "\r\n";
                        if($c==2){
                            break;
                        }
                    $c++;
                    }
                        $html .= ' </table> ' . "\r\n";
                        $html .= ' </td> ' . "\r\n";
                }
            }
            $html .= ' </tr> ' . "\r\n";
        }
        $html .= ' </tbody> ' . "\r\n";
        $html .= ' </table> ' . "\r\n";
    }
    $html .= ' <p>Cordialement,</p> ' . "\r\n";
    $html .= ' <p>' . $leader_info->nom . '.</p> ' . "\r\n";


    $html .=' <p>---------------------------------------------</p> ' . "\r\n";

    $html .= ' <p>Hello,</p> ' . "\r\n";
    $html .= (' <p>This is a reminder, ' . $leader_info->nom . ' send you the exchange form n°' . $act_base_info->exchange_no . '. </p>' . "\r\n");
    $html .= ' <p>Thank you to answer as soon as possible, either in the table below, or by clicking <a HREF="' . $linkPath . '"> <strong>here</strong> </a>. </p> ' . "\r\n";
    $html .= ' <table width="100%" border="1" cellpadding="0" cellspacing="0"> ' . "\r\n";
    $html .= ' <tbody> ' . "\r\n";
    $html .= ' <tr style="background-color:#CECECE;"> ' . "\r\n";

    $html .= ' <th width="15%"> Activities </th> ' . "\r\n";
    $html .= ' <th width="7%"> GOR </th> ' . "\r\n";
    $html .= ' <th width="15%"> Contributor </th> ' . "\r\n";
    $html .= ' <th width="8%"> Last update </th> ' . "\r\n";
    if ($act_base_info->grid_type == '4') {
        $html .= ' <th width="15%"> Deviation </th> ' . "\r\n";
    }
    $html .= ' <th width="10%"> Action plan </th> ' . "\r\n";
    $html .= ' <th width="15%"> Pilot </th> ' . "\r\n";
    $html .= ' <th width="8%"> Due date </th> ' . "\r\n";
    if ($act_base_info->grid_type == '4' || $act_base_info->grid_type == '2') {
        $html .= ' <th width="7%"> GOR Eval </th> ' . "\r\n";
    }
    $html .= ' </tr> ' . "\r\n";
    $color_label['TR'] = 'G';
    $resultId = 0;
    if (count($activityData) > 0) {
        foreach ($activityData as $aKey => $aValues) {
            if ($resultId != $aValues['result_id']) {
                $resultId = $aValues['result_id'];
                $html .= ' <tr> <td colspan="' . $columnspan[$act_base_info->grid_type] . '"> ' . ($aValues['topic_name_en']) . ' </td> </tr> ' . "\r\n";
            }
            $html .= ' <tr> ' . "\r\n";
            $html .= ' <td width="15%"> ' . $aValues['result_order'] . '-' . $aValues['activity_order'] . '-' . addslashes($aValues['activity_name_en']) . ' </td> ' . "\r\n";
            if (!empty($aValues[$status_color['4']])) {
                $colurVal = 'NA';
                $fillColor =$status_color['4'];
            }else  if (!empty($aValues[$status_color['3']])) {
                 $colurVal = 'NE';
                 $fillColor =$status_color['3'];
            }else  if (!empty($aValues[$status_color['2']])) {
                 $colurVal = 'R';
                 $fillColor =$status_color['2'];
            }else  if (!empty($aValues[$status_color['1']])) {
                 $colurVal = 'O';
                 $fillColor =$status_color['1'];
            }else  if (!empty($aValues[$status_color['0']])) {
                 $colurVal = 'G';
                 $fillColor =$status_color['0'];
            }
            $html.=' <td style="background-color:'.$fillColor.';text-align:center" align ="center"> '.$colurVal.' </td> ' . "\r\n";
            if (checkDateTime($aValues['date_update'])) {
                $lastupdatedate = date('Y-m-d', strtotime($aValues['date_update']));
                $lastUpdateDate = formatDateEmail($lastupdatedate . 'en');
            } else {
                $lastUpdateDate = '-';
            }

            $html .= ' <td width="15%"> ' . $contributor_info->nom . ' </td> ' . "\r\n";
            $html .= ' <td width="8%" align="center"> ' . $lastUpdateDate . ' </td> ' . "\r\n";

            if ($act_base_info->grid_type == '4') {
                $html .= ' <td colspan="5"> ' . "\r\n";

                if (count($aValues['grid_data']) > 0) {
                    $html .= ' <table width="100%" border="1" cellpadding="0" cellspacing="0"> ' . "\r\n";
                    foreach ($aValues['grid_data'] as $gdKey => $gdValues) {
                        if(!empty($gdValues['activity_evaluation_exgform_id'])){
                        
                        if (strtotime($gdValues['due_date'])) {
                            $due_date = formatDateEmail($gdValues['due_date'], 'en');
                        } else {
                            $due_date = '-';
                        }
                        $html .= ' <tr> ' . "\r\n";
                        $html .= ' <td width="15%"> ' . $gdValues['deviation_text'] . ' </td> ' . "\r\n";
                        $html .= ' <td width="10%"> ' . $gdValues['action_plan'] . ' </td> ' . "\r\n";
                        $pilot_name = (!empty($gdValues['pilot'])) ? $arca->getName($gdValues['pilot']) : '';
                        $html .= ' <td width="15%"> ' . $pilot_name . ' </td> ' . "\r\n";
                        $html .= ' <td width="8%"> ' . $due_date . ' </td> ' . "\r\n";
                        $html .= ' <td width="7%" align="center"> <table width="100%" border="1" cellpadding="0" cellspacing="0"> ' . "\r\n";
                        $d = 0;
                        foreach ($color_label as $eskey => $esval) {
                            if ($eskey != 'NA') {
                                $html .= ' <tr> <td width="7%" >' . $esval . ' </td> <td>' . $gdValues[$status_color[$d]] . ' </td> </tr> ' . "\r\n";
                                $d++;
                            }
                        }
                        $html .= ' </table> </td> </tr> ' . "\r\n";
                        }
                    }
                    $html .= ' </table> ' . "\r\n";
                }
                $html .= ' </td> ' . "\r\n";
            } else {
                $html .= ' <td width="10%"> ' . $aValues['action_plan'] . ' </td> ' . "\r\n";
                $pilot_name = (!empty($aValues['pilot'])) ? $arca->getName($aValues['pilot']) : '';
                $html .= ' <td width="15%"> ' . $pilot_name . ' </td> ' . "\r\n";
                
                if (strtotime($aValues['due_date'])) {
                    $due_date = formatDateEmail($aValues['due_date'], 'en');
                } else {
                    $due_date = '-';
                }
                $html .= ' <td width="7%" align="center"> ' . $due_date . ' </td> ' . "\r\n";
                 if($act_base_info->grid_type == '2'){
                     $html .= ' <td> ' . "\r\n";
                    $c = 0;
                    $border = 1;
                    $html .= ' <table width="100%" border="1" cellpadding="0" cellspacing="0"> ' . "\r\n";

                    foreach ($color_label as $skey => $sval) {
                       $html .= ' <tr> <td width="7%"> ' . $sval . ' </td> <td>' . $aValues[$status_color[$c]] . ' </td> </tr> ' . "\r\n";
                      if($c==2){
                          break;
                      }
                        $c++;
                    }
                        $html .= ' </table> ' . "\r\n";
                        $html .= ' </td> ' . "\r\n";
                }
            }
            $html .= ' </tr> ' . "\r\n";
        }
        $html .= ' </tbody> ' . "\r\n";
        $html .= ' </table> ' . "\r\n";
        $html .= ' <p>Regards,</p> ' . "\r\n";
        $html .= ' <p>' . $leader_info->nom . '.</p> ' . "\r\n";
    }


    $html .= ' </body> </html> ';
    return $html;
}

// Getting activity Data 
function getActivitisList($exg_form_id, $grid_type, $conn) {

    if ($grid_type == 4) {
        $request = new requete(" select act.repository_activity_id_fk as activity_id,act.GREEN,act.ORANGE, act.RED, act.GREY, act.WHITE,act.count_external_link,
                        act.activity_comment,exgact.instance_id_fk
			 from tb_instances_activities act 
            left join tb_instances_activities_exgform exgact on exgact.repository_activity_id_fk = act.repository_activity_id_fk
            and act.instance_id_fk = exgact.instance_id_fk
            where exgact.exchange_form_id_fk= '" . $exg_form_id . "'", $conn);
    } else {
        $request = new requete("select act.repository_activity_id_fk as activity_id,act.GREEN,act.ORANGE, act.RED, act.GREY, act.WHITE,act.count_external_link, act.activity_comment,
            plan.action_plan_id, plan.action_plan, plan.pilot, plan.due_date,exgact.instance_id_fk from tb_instances_activities act 
            left join tb_instances_activities_action_plans plan on plan.activity_id_fk = act.repository_activity_id_fk and 
            plan.instance_id_fk = act.instance_id_fk
            left join tb_instances_activities_exgform exgact on exgact.repository_activity_id_fk = act.repository_activity_id_fk 
            and act.instance_id_fk = exgact.instance_id_fk
            where exgact.exchange_form_id_fk = '" . $exg_form_id . "'", $conn);
    }
    $activity_list = $request->recup_array_champ();
    $activity_data = array();
    foreach ($activity_list as $key => $val) {
        if ($grid_type == 4) {
            $griddatas = getActivityEvaluationGridData($val['instance_id_fk'], $val['activity_id'], $conn);
            if (!empty($griddatas)) {
                foreach ($griddatas as $griddata) {
                    $val['grid_data'][$griddata['activity_evaluation_id']] = $griddata;
                }
            }
        }
        $activity_data[$val['activity_id']] = $val;
    }
    return $activity_data;
}

function getActivityEvaluationGridData($exg_form_id, $activity_id, $conn) {

    $request = new requete("select grid.activity_evaluation_id, grid.skill_entity, grid.deviation_text, grid.count_external_link,
grid.green, grid.orange, grid.red, grid.white, plan.pilot, plan.action_plan, plan.due_date
 from tb_instances_activities_evaluation_grid grid 
left join tb_instances_activities_action_plans plan on plan.activity_evaluation_id_fk = grid.activity_evaluation_id
and plan.instance_id_fk = grid.instance_id_fk where grid.repository_activity_id_fk = '" . $activity_id . "'  and grid.instance_id_fk ='" . $exg_form_id . "' ", $conn);
    $gridData = $request->recup_array_champ();
    return $gridData;
}