<?php 
/**
 * Page footer for all scripts
 * 
 * PHP version 5
 * 
 * @category Portal
 * @package  Scripts
 * @author   Charles Santucci <charles.santucci@renault.com>
 * @license  http://www.php.net/license/3_0.txt  PHP License 3.0
 * @link     http://baselinesvn.mc2.renault.fr:9090/svn/svn61281
*/

// get last release name
$request=new requete("SELECT MAX(version) AS version FROM tb_news",$cnx->num);
$request->recup_objet();
$release=$request->objet->version;
$cnx->close();
$release="${pom_ped_version}";
$deploymentDate="${build_date}";
if(!empty($deploymentDate)){
    if($_SESSION['language'] == 'fr'){
            $deploymentDate	= "(".date("d-m-Y",strtotime($deploymentDate)).")";
    }else{
            $deploymentDate	= "(".date("m-d-Y",strtotime($deploymentDate)).")";
    }
}
$release="V1730.5$deploymentDate"; 
?>
  </div><!-- RnoMaincontent!-->
</div>		<!-- RnoBody!-->	
  <!-- Footer -->
  <div id="dialogAlert" title="<?php echo $text_dialogue_title; ?>"><?php echo $text_session_timeout; ?></div>
  <div id="dialogTimeout" title="<?php echo $text_dialogue_title; ?>"><?php echo $text_session_expired; ?></div>
  <div id="dialogSaveAlert" title="<?php echo $text_dialogue_title; ?>"><?php echo $text_save_automatic; ?></div>
  
  <div id="dialog_gsper_alert" title="<?php echo $text_dialogue_title; ?>">
      <div class="js_content_block">
        <?php echo $text_gsper_dialogue_content; ?>
    </div>
    <div class="js_dialog_block">
        <button type="button" class="js_dialog_gsper_ok ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only" role="button" aria-disabled="false"><span class="ui-button-text"><?php echo $libelle_oui; ?></span></button>
        <button type="button" class="js_dialog_gsper_close ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only" role="button" aria-disabled="false"><span class="ui-button-text"><?php echo $libelle_annuler; ?></span></button>
    </div>
</div>
  
  
  
  <div id="RnoFooter" class="pied" >
        <p><?php echo $nom_modules['graal'].' '.$release;?> - &copy; Renault 2013-<?php echo date('Y',time());?> <?php  echo '- '.$descriptions_modules['graal']; ?></p>
  </div>		
  <!-- END Footer -->  
</div>	<!-- RnoPage!-->
</body>
</html>