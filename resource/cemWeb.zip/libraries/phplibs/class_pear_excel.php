<?php
/**
* File class_pear_excel.php
*
* This script defines the class to generate Excel file from PEAR library
*
* @package   PHPLIBS
* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
* @version   1.0.1	09/07/2008		Revision initiale du code
* @copyright Etablissement VSF - RENAULT
* 
* @filesource
*/
require_once 'Spreadsheet/Excel/Writer.php';

/**
* Class cl_Pear_Excel
*
* Class to generate Excel file from PEAR library
*
* @package   PHPLIBS
* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
* @version   1.0.1	09/07/2008		Revision initiale du code
* @copyright Etablissement VSF - RENAULT
*/
class cl_Pear_Excel extends Spreadsheet_Excel_Writer
{
	/**
	* Spreadsheet_Excel_Writer object
    * 
	* @var    object
	*/
	var	$Fichier;
	/**
	* Sheet of the Excel file
    * 
	* @var    object
	*/
	var	$FeuilleActive;
	/**
	* List of the sheets
    * 
	* @var    array
	*/
	var	$TabFeuilles;
	/**
	* List of formats
    * 
	* @var    array
	*/
	var	$TabFormats;
		
	/**
	* Class constructor
	*
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Revision initiale du code
	* @copyright Etablissement VSF - RENAULT
	* 
        * @global 	 Profiler               class Profiler object
        * 
	* @param     string 	name of the file to generate
	* @param     int        flag to indicate if the file should be generated or displayed in the browser
	* @return    void
	*/	
	public function cl_Pear_Excel()
	{
            global $Profiler;
            if($Profiler)	{$Profiler->startTimer("cl_Pear_Excel->cl_Pear_Excel");}

            $this->Fichier = new Spreadsheet_Excel_Writer();
            $this->Fichier->setVersion(8);
            //array to store sheets
            $this->TabFeuilles	= array();	
            //array to store formats
            $this->TabFormats	= array();	

            $this->tags_to_strip = array("a","table","tr","td","body","font","u","b");

            if($Profiler)	{$Profiler->stopTimer("cl_Pear_Excel->cl_Pear_Excel");}
	}
                
        /**
        * Method that manages the display of a debug trace.
	*
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Initial revision code
        * @copyright Etablissements Operationnel d'Ile de France - RENAULT
	* 
	* @param     void
	* @return    void
	*/	
	function  Debug()
	{
		echo "--------------------------------------------------<BR>\n";
		echo "DEBUT DEBUG DE LA CLASSE cl_Pear_Excel	   		<BR>\n";
		echo "--------------------------------------------------<BR>\n";
		echo "<PRE>\n";
		print_r($this);
		echo "</PRE>\n";
		echo "--------------------------------------------------<BR>\n";
		echo "FIN DEBUG DE LA CLASSE cl_Pear_Excel				<BR>\n";
		echo "--------------------------------------------------<BR>\n";
	}
	
	/**
	* Method that adds a sheet to the Excel file
	*
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Revision initiale du code
	* @copyright Etablissement VSF - RENAULT
	* 
        * @global 	 Profiler               class Profiler object
        * 
	* @param     string     name of the sheet
	* @return    void
	*/	
	function Ajout_feuille($parNom_feuille="")
	{
            global $Profiler;
            if($Profiler)	{$Profiler->startTimer("cl_Pear_Excel->Ajout_feuille");}

            //processing name of the sheet
            if($parNom_feuille)
            {
                    $this->FeuilleActive =& $this->Fichier->addWorksheet($parNom_feuille);
            } 
            else 
            {
                    $this->FeuilleActive =& $this->Fichier->addWorksheet();
            }
        
            //Added the sheet to the array
            $this->TabFeuilles[] = $this->FeuilleActive;

            if($Profiler)	{$Profiler->stopTimer("cl_Pear_Excel->Ajout_feuille");}
	}
	
	/**
	* Method that selects a sheet
	*
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Revision initiale du code
	* @copyright Etablissement VSF - RENAULT
	* 
        * @global 	 Profiler               class Profiler object
        * 
	* @param     void
	* @return    void
	*/	
	function SelectionnerFeuille()
	{
		global $Profiler;
		if($Profiler)	{$Profiler->startTimer("cl_Pear_Excel->SelectionnerFeuille");}

		$this->FeuilleActive->activate();
		
		if($Profiler)	{$Profiler->stopTimer("cl_Pear_Excel->SelectionnerFeuille");}
	}
	
	/**
	* Method that sets the output format (landscape or portrait)
	*
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Revision initiale du code
	* @copyright Etablissement VSF - RENAULT
	* 
        * @global 	 Profiler               class Profiler object
        *  
	* @param     string     type of the output format
	* @return    void
	*/	
	function Type_sortie($parType_sortie="Portrait")
	{
		global $Profiler;
		if($Profiler)	{$Profiler->startTimer("cl_Pear_Excel->Type_sortie");}

		if ($parType_sortie=="Portrait") 
		{
			$this->FeuilleActive->setPortrait();
		}
		else							 
		{
			$this->FeuilleActive->setLandscape();
		}
		
		if($Profiler)	{$Profiler->stopTimer("cl_Pear_Excel->Type_sortie");}
	}

	
	/**
	* Method that hides the sheet grid
	*
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Revision initiale du code
	* @copyright Etablissement VSF - RENAULT
	* 
        * @global 	 Profiler               class Profiler object
        *  
	* @param     void
	* @return    void
	*/
	
	function CacherLaGrille()
	{
		global $Profiler;
		if($Profiler)	{$Profiler->startTimer("cl_Pear_Excel->CacherLaGrille");}

		$this->FeuilleActive->hideGridlines();
		
		if($Profiler)	{$Profiler->stopTimer("cl_Pear_Excel->CacherLaGrille");}
	}

	
	/**
	* Methdod that sets the zoom
        * 
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Revision initiale du code
	* @copyright Etablissement VSF - RENAULT
	* 
        * @global 	 Profiler               class Profiler object
        * 
	* @param     int    value of the zoom
	* @return    void
	*/
	
	function ChangeZoom($parZoom=100)
	{
		global $Profiler;
		if($Profiler)	{$Profiler->startTimer("cl_Pear_Excel->ChangeZoom");}

		$this->FeuilleActive->setZoom($parZoom);
		
		if($Profiler)	{$Profiler->stopTimer("cl_Pear_Excel->ChangeZoom");}
	}

	
	/**
	* Method tha writes the cell value
	*
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Revision initiale du code
	* @copyright Etablissement VSF - RENAULT
	* 
        * @global 	 Profiler               class Profiler object
        * 
	* @param     int        line number
	* @param     int        column number
	* @param     string     text to write
	* @param     string     format to use
	* @return    void
	*/
	
	function EcritTexte($parLigne=0, $parColonne=0, $parTexte="", $parNomFormat="")
	{
		global $Profiler, $langue;
		if($Profiler)	{$Profiler->startTimer("cl_Pear_Excel->EcritTexte");}

		// processing text
		$parTexte = str_replace(chr(10), "\n", $parTexte);
		$parTexte = str_replace(chr(13), "\n", $parTexte);
		
		foreach( $this->tags_to_strip as $tag) 
		{
			$parTexte = preg_replace("/<\/?".$tag."(.|\s)*?>/", "", $parTexte );
		}
		
		// checking date format ^([0-9]{1,2})/([0-9]{1,2})/([0-9]{4})$
		if(preg_match("/^(0[1-9]|[1-2][0-9]|3[0-1])\/(0[1-9]|1[0-2])\/([1-9][0-9][0-9][0-9])$/", $parTexte, $regs))
		{
                    $date_en_jour   = ceil((mktime(0,0,0,$regs[2], $regs[1], $regs[3]) + 86400*25569)/86400);
                    $parTexte       = $date_en_jour;
                    $parNomFormat   = $parNomFormat."_dt";
		}
                
                $parTexte = htmlentities($parTexte, ENT_QUOTES, 'utf-8');
                $parTexte = html_entity_decode($parTexte, ENT_QUOTES , 'Windows-1252');
                
                if(in_array($parNomFormat,array_keys($this->TabFormats))){
			$msg=$this->FeuilleActive->write($parLigne, $parColonne, $parTexte, $this->TabFormats["$parNomFormat"]);
		}else{
                    $msg=$this->FeuilleActive->write($parLigne, $parColonne, $parTexte);
                }
		if($Profiler)	{$Profiler->stopTimer("cl_Pear_Excel->EcritTexte");}
	}
		
	/**
	* Method that write cell formula
	*
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Revision initiale du code
	* @copyright Etablissement VSF - RENAULT
	* 
        * @global 	 Profiler               class Profiler object
        *  
	* @param     int        line number
	* @param     int        column number
	* @param     string 	formula
	* @param     string 	format to use
	* @return    void
	*/
	function EcritFormule($parLigne=0, $parColonne=0, $parFormule="", $parNomFormat="")
	{
		global $Profiler;
		if($Profiler)	{$Profiler->startTimer("cl_Pear_Excel->EcritFormule");}

		$this->FeuilleActive->writeFormula($parLigne, $parColonne, $parFormule, $this->TabFormats["$parNomFormat"]);
		
		if($Profiler)	{$Profiler->stopTimer("cl_Pear_Excel->EcritFormule");}
	}
		
	/**
	* Method that converts cell coordinates
        * 
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Revision initiale du code
	* @copyright Etablissement VSF - RENAULT
	* 
        * @global 	 Profiler               class Profiler object
        * 
	* @param     int	cell column
	* @param     int 	cell line
	* @return    object cell with converted coordinates
	*/
	function convertCellCoordonneesToPearFormat($Row,$Col)
	{
		global $Profiler;
		if($Profiler)	{$Profiler->startTimer("cl_Pear_Excel->convertCellCoordonneesToPearFormat");}

		$cell = $this->Fichier->rowcolToCell($Row,$Col);		
		
		if($Profiler)	{$Profiler->stopTimer("cl_Pear_Excel->convertCellCoordonneesToPearFormat");}
		return $cell;
	}
			
	/**
	* Method that inserts an url in a celle
	*
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Revision initiale du code
	* @copyright Etablissement VSF - RENAULT
	* 
        * @global 	 Profiler               class Profiler object
        *
	* @param     int	line number
	* @param     int	column number
	* @param     url to insert
	* @param     text to insert
	* @param     string format to use
	* @return    void
	*/	
	function EcritUrl($parLigne=0, $parColonne=0, $parUrl="", $parTexte="", $parNomFormat="")
	{
		global $Profiler;
		if($Profiler)	{$Profiler->startTimer("cl_Pear_Excel->EcritUrl");}

		//processing text
		$parTexte = str_replace(chr(10), "\n", $parTexte);
		$parTexte = str_replace(chr(13), "\n", $parTexte);
		
		$this->FeuilleActive->writeUrl($parLigne, $parColonne, $parUrl, $parTexte, $this->TabFormats["$parNomFormat"]);
		
		if($Profiler)	{$Profiler->stopTimer("cl_Pear_Excel->EcritUrl");}
	}
		
	/**
	* Method that merges celles
	*
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Revision initiale du code
	* @copyright Etablissement VSF - RENAULT
	* 
        * @global 	 Profiler               class Profiler object
        * 
	* @param     int	number of the first line
	* @param     int	number of the first column
	* @param     int	number of the last line
	* @param     int	number of the last column
	* @return    void
	*/	
	function FusionnerCellules($parLigne1, $parColonne1, $parLigne2, $parColonne2)
	{
		global $Profiler;
		if($Profiler)	{$Profiler->startTimer("cl_Pear_Excel->FusionnerCellules");}

		$this->FeuilleActive->mergeCells($parLigne1, $parColonne1, $parLigne2, $parColonne2);
		
		if($Profiler)	{$Profiler->stopTimer("cl_Pear_Excel->FusionnerCellules");}
	}
	
	/**
	* Method that selects several cells
	*
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Revision initiale du code
	* @copyright Etablissement VSF - RENAULT
	* 
        * @global 	 Profiler               class Profiler object
        * 
	* @param     int	number of the first line
	* @param     int	number of the first column
	* @param     int	number of the last line
	* @param     int	number of the last column
	* @return    void
	*/	
	function SelectionnerPlage($parLigne1, $parColonne1, $parLigne2, $parColonne2)
	{
		global $Profiler;
		if($Profiler)	{$Profiler->startTimer("cl_Pear_Excel->SelectionnerPlage");}

		$this->FeuilleActive->setSelection($parLigne1, $parColonne1, $parLigne2, $parColonne2);
		// Exemple : $this->Feuille->setSelection (7, 2, 9, 5);	# Plage C8-F10
		
		if($Profiler)	{$Profiler->stopTimer("cl_Pear_Excel->SelectionnerPlage");}
	}
		
	/**
	* Method that locks a sheet with a password
        * 
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Revision initiale du code
	* @copyright Etablissement VSF - RENAULT
	* 
        * @global 	 Profiler               class Profiler object
        * 
	* @param     string 	password
	* @return    void
	*/	
	function ProtegerFeuille($parMot_de_passe)
	{
		global $Profiler;
		if($Profiler)	{$Profiler->startTimer("cl_Pear_Excel->ProtegerFeuille");}

		$this->FeuilleActive->protect($parMot_de_passe);
		
		if($Profiler)	{$Profiler->stopTimer("cl_Pear_Excel->ProtegerFeuille");}
	}	
	
	/**
	* Method that associates a note to a given cell
        * 
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Revision initiale du code
	* @copyright Etablissement VSF - RENAULT
	* 
        * @global 	 Profiler               class Profiler object
        * 
	* @param     int	line number
	* @param     int	column number
	* @param     string text of the note
	* @return    void
	*/	
	function EcritNote($parLigne, $parColonne, $parNote)
	{
		global $Profiler;
		if($Profiler)	{$Profiler->startTimer("cl_Pear_Excel->EcritNote");}

		$parNote = strip_tags($parNote);
		if($parLigne && $parColonne && $parNote) 
		{
			$this->FeuilleActive->writeNote($parLigne, $parColonne, $parNote);
		}
		
		if($Profiler)	{$Profiler->stopTimer("cl_Pear_Excel->EcritNote");}
	}	
	
	/**
	* Method that insert a picture in agiven cell
        * 
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Revision initiale du code
	* @copyright Etablissement VSF - RENAULT
	* 
        * @global 	 Profiler               class Profiler object
        * 
	* @param     int	line number
	* @param     int	column number
	* @param     string picture to insert
	* @param     void
	* @return    void
	*/	
	function InsererImage($parLigne, $parColonne, $parImage)
	{
		global $Profiler;
		if($Profiler)	{$Profiler->startTimer("cl_Pear_Excel->Type_sortie");}

		$this->FeuilleActive->insertBitmap($parLigne, $parColonne, $parImage );
		
		if($Profiler)	{$Profiler->stopTimer("cl_Pear_Excel->Type_sortie");}
	}	
	
	/**
	* Method that adds a new format
        * 
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Revision initiale du code
	* @copyright Etablissement VSF - RENAULT
	* 
        * @global 	 Profiler               class Profiler object
        * 
	* @param     void
	* @return    void
	*/	
	function AjoutFormat($parNomFormat, $parFormat)
	{
		global $Profiler;
		if($Profiler)	{$Profiler->startTimer("cl_Pear_Excel->AjoutFormat");}

		$this->TabFormats["$parNomFormat"] = & $this->Fichier->addFormat($parFormat);
		$this->TabFormats[$parNomFormat."_dt"] = & $this->Fichier->addFormat($parFormat);
		$this->TabFormats[$parNomFormat."_dt"]->setNumFormat("DD/MM/YYYY");
		
		if($Profiler)	{$Profiler->stopTimer("cl_Pear_Excel->AjoutFormat");}
	}
		
	/**
	* Method that sets the format and the width of given columns
        * 
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Revision initiale du code
	* @copyright Etablissement VSF - RENAULT
	* 
        * @global 	 Profiler               class Profiler object
        * 
	* @param     int		first column
	* @param     int		last column
	* @param     int		width to set
	* @param     string		format to use
	* @return    void
	*/	
	function FormatColonne($parColonne1, $parColonne2, $parLargeur, $parNomFormat="")
	{
		global $Profiler;
		if($Profiler)	{$Profiler->startTimer("cl_Pear_Excel->FormatColonne");}

		if($parNomFormat)	
		{
			$this->FeuilleActive->setColumn($parColonne1, $parColonne2, $parLargeur, $this->TabFormats[$parNomFormat]);
		}
		else				
		{
			$this->FeuilleActive->setColumn($parColonne1, $parColonne2, $parLargeur);
		}
		
		if($Profiler)	{$Profiler->stopTimer("cl_Pear_Excel->FormatColonne");}
	}	
	
	/**
	* Method that sets the height of a given line
        * 
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Revision initiale du code
	* @copyright Etablissement VSF - RENAULT
	* 
        * @global 	 Profiler               class Profiler object
        * 
	* @param     int 	line to resize
	* @param     int 	height of the line
	* @return    void
	*/	
	function HauteurLigne($parLigne, $parHauteur=10)
	{
		global $Profiler;
		if($Profiler)	{$Profiler->startTimer("cl_Pear_Excel->HauteurLigne");}

		$this->FeuilleActive->setRow($parLigne, $parHauteur);
		
		if($Profiler)	{$Profiler->stopTimer("cl_Pear_Excel->HauteurLigne");}
	}
		
	/**
	* Method that freezes an area of cells
        * 
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Revision initiale du code
	* @copyright Etablissement VSF - RENAULT
	* 
        * @global 	 Profiler               class Profiler object
        * 
	* @param     array 	coordinate of the area to freeze
	* @return    void
	*/	
	function FigerCellules($TabZone=array(3,1,1,1,1))
	{
		global $Profiler;
		if($Profiler)	{$Profiler->startTimer("cl_Pear_Excel->FigerCellules");}

		$this->FeuilleActive->freezePanes($TabZone);
		
		if($Profiler)	{$Profiler->stopTimer("cl_Pear_Excel->FigerCellules");}
	}
	
	/**
	* Method that repeats lines in each sheet to print
        * 
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Revision initiale du code
	* @copyright Etablissement VSF - RENAULT
	* 
        * @global 	 Profiler               class Profiler object
        * 
	* @param     int 	number of the first line
	* @param     int 	number of the last line
	* @return    void
	*/	
	function RepeterImpressionLignes($LigneDebut, $LigneFin)
	{
		global $Profiler;
		if($Profiler)	{$Profiler->startTimer("cl_Pear_Excel->RepeterImpressionLignes");}

		$this->FeuilleActive->repeatRows($LigneDebut, $LigneFin);
		
		if($Profiler)	{$Profiler->stopTimer("cl_Pear_Excel->RepeterImpressionLignes");}
	}
	
	/**
	* Method that sets the print area
        * 
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Revision initiale du code
	* @copyright Etablissement VSF - RENAULT
	* 
        * @global 	 Profiler               class Profiler object
        *
	* @param     int 	number of the first line
	* @param     int 	number of the first column
	* @param     int 	number of the last line
	* @param     int 	number of the last column
	* @return    void
	*/	
	function DefinirZoneImpression($LigneDebut, $ColonneDebut, $LigneFin, $ColonneFin)
	{
		global $Profiler;
		if($Profiler)	{$Profiler->startTimer("cl_Pear_Excel->DefinirZoneImpression");}

		$this->FeuilleActive->printArea($LigneDebut, $ColonneDebut, $LigneFin, $ColonneFin);
		
		if($Profiler)	{$Profiler->stopTimer("cl_Pear_Excel->DefinirZoneImpression");}
	}
	
	/**
	* Method that sets the zoom for printing
        * 
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Revision initiale du code
	* @copyright Etablissement VSF - RENAULT
	* 
        * @global 	 Profiler               class Profiler object
        * 
	* @param     int    zoom level
	* @return    void
	*/	
	function ZoomImpression($Zoom=100)
	{
		global $Profiler;
		if($Profiler)	{$Profiler->startTimer("cl_Pear_Excel->ZoomImpression");}

		$this->FeuilleActive->setPrintScale($Zoom);
		
		if($Profiler)	{$Profiler->stopTimer("cl_Pear_Excel->ZoomImpression");}
	}
	
        /**
	* Method sendExcel
        * Generates excel file
	*
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Revision initiale du code
	* @copyright Etablissement VSF - RENAULT
	* 
        * @global 	 Profiler               class Profiler object
        * 
	* @param     string 	name of the file to generate
	* @param     int        flag to indicate if the file should be generated or displayed in the browser
	* @return    void
	*/
        public function sendExcel($parNom_fichier="",$AfficheWeb=1)
        {
            global $Profiler;
            if($Profiler)	{$Profiler->startTimer("cl_Pear_Excel->cl_Pear_Excel");}
            // used of the passed filename
            if($parNom_fichier)
            {
                // checking the filename is ok
                if(!strstr($parNom_fichier , ".xls"))	
                {
                        $parNom_fichier = $parNom_fichier . ".xls";
                }
                if($AfficheWeb) 
                {
                        $this->Fichier->send($parNom_fichier);
                }
            } 
            else 
            {
                //use of a generic name
                $this->Fichier->send("Feuille de calcul.xls");
            }
            
            if($Profiler)	{$Profiler->stopTimer("cl_Pear_Excel->cl_Pear_Excel");}
        }
        
	/**
	* Method that closes the Excel file
        * 
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Revision initiale du code
	* @copyright Etablissement VSF - RENAULT
	* 
        * @global 	 Profiler               class Profiler object
        * 
	* @param     void
	* @return    void
	*/
	function FermeExcel()
	{
		global $Profiler;
		if($Profiler)	{$Profiler->startTimer("cl_Pear_Excel->FermeExcel");}

		$this->Fichier->close();
		
		if($Profiler)	{$Profiler->stopTimer("cl_Pear_Excel->FermeExcel");}
	}
}
