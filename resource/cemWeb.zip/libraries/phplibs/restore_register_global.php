<?php
// �mulation de register_globals � on
if (!ini_get('register_globals')) {
    $superglobals = array($_REQUEST, $_ENV, $_GET, $_POST, $_COOKIE, $_SERVER, $_FILES);
	if (isset($_SESSION)) {
		array_unshift($superglobals, $_SESSION);
	}
	foreach ($superglobals as $superglobal) {
		extract($superglobal, EXTR_SKIP);
	}
}
?>