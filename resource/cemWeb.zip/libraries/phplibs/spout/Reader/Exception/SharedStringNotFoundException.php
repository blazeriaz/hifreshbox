<?php

namespace Box\Spout\Reader\Exception;

/**
 * Class SharedStringNotFoundException
 *
 * @api
 * @package Box\Spout\Reader\Exception
 */
class SharedStringNotFoundException extends ReaderException
{
}
