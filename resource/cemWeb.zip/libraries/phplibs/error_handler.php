<?php

/**
 * File error_handler.php
 * To handle run time php errors
 *
 * @package   PHPLIBS
 * @author    Selvaraj
 * @version   1.0.1	23-04-15
 * @copyright RNTBCI
 * @filesource
 */
/*
 * Inclusion of configuration for error handler
 */
require_once "config_error_handler.php";
set_error_handler("errorHandler", $errorReporting);
set_exception_handler("intimateErrorInfo");

$pathLog = $SERVER_HOME . "/logs";
$fileLog = "error_php_" . date("dmY") . ".txt";
if (!file_exists($pathLog)) {
    mkdir($pathLog);
}
ini_set("log_errors", "on");
ini_set("error_log", "$pathLog/$fileLog");

/**
 * custom error handler - throws exception on any error
 * 
 * @param int $errNo
 * @param string $errStr
 * @param string $errFile
 * @param double $errLine
 * @param mixed $errContext
 * @throws ErrorException
 */
function errorHandler($errNo, $errStr, $errFile, $errLine, $errContext) {
    throw new ErrorException($errStr, 0, $errNo, $errFile, $errLine);
}

register_shutdown_function("fatalErrorHandler");

/**
 * Error handler for fatal errors
 */
function fatalErrorHandler() {
    $error = error_get_last();

    if ($error && in_array($error["type"], array(E_ERROR, E_PARSE))) {
        $errStr = $error["message"];
        $errNo = $error["type"];
        $errFile = $error["file"];
        $errLine = $error["line"];
        //echo "<pre>";print_r($error);
        $e = new ErrorException($errStr, 0, $errNo, $errFile, $errLine);
        intimateErrorInfo($e, 1);
    }
}

/**
 * Sends mail to DEV team for exception
 * 
 * @param Exception $e
 * @param boolean $isFatal 
 * @return void 
 */
function intimateErrorInfo(Exception $e, $isFatal = 0) {
    global $errorInfo_fromMail, $errorInfo_toMail, $SERVER_ENV;;

    $userImpacted = isset($_SESSION['nom']) ? $_SESSION['nom']." (".$_SESSION['ipn'].")" : "";
    $environment = strtoupper($SERVER_ENV);

    if (method_exists($e, "getSeverity")) {
        $errorType = getErrorType($e->getSeverity());
    } else {
        $errorType = "E_ERROR";
    }
    $msgContent = "<html><head>\n";
    $msgContent.= "<style type=\"text/css\">\n
                        body {
                            background: #fff;
                            color: #000;
                            font-family: cambria,arial,verdana,helvetica,sans-serif;
                            font-style: normal;
                            font-size: 14px;
                            line-height: 20px;
                            margin: 0;
                        }
                        table {
                            border: 1px solid;
                            border-spacing: 2px;
                            border-collapse: collapse;
                            clear: both;
                            width: auto;
                        }
                        table tr th,
                        table tr td {
                            background-color: wheat;
                            border: 1px solid;
                            padding: 4px;
                            vertical-align: middle;
                        }
                        table tr th {
                            text-align: center;
                        }
                        table tr td{
                            text-align: left;
                        }
                        ul.discList li{
                            list-style-type: disc;
                        }
                        ul.circleList li{
                            list-style-type: circle;
                        }
                    </style>\n";
    $msgContent.= "</head><body>\n";

    $msgContent.= "Dear " . implode(", ", $errorInfo_toMail) . ",<br/><br/>\n";
    $msgContent.= "The following exception is caught on :<br/>\n";

    $msgContent.= "<table>
                    <tr><th>Environment</th>
                    <td>$environment</td></tr>           
                    <tr><th>User Impacted</th>
                    <td>$userImpacted</td></tr>
                    <tr><th>File</th>
                    <td>" . $e->getFile() . "</td></tr>
                    <tr><th>Error Type</th>
                    <td>$errorType</td></tr>
                    <tr><th>Message</th>
                    <td>" . $e->getMessage() . "</td></tr>
                    <tr><th>Line Number</th>
                    <td>" . $e->getLine() . "</td></tr>
                    <tr><th>Url</th>
                    <td>http://".$_SERVER['HTTP_HOST']."/".$_SERVER['REQUEST_URI']."</td></tr> 
                    </table><br/><br/>\n";

    $msgContent.= "<b>StackTrace:</b>";
    $msgContent.= "<table><tr>\n";
    $msgContent.= "<th>File</th>\n";
    $msgContent.= "<th>Line Number</th>\n";
    $msgContent.= "<th>Class</th>\n";
    $msgContent.= "<th>Function</th></tr>\n";

    error_log("PHP $errorType:  {$e->getMessage()}");
    error_log("Stacktrace: (File|Line)");

    if (!$isFatal) {
        $stackTrace = array_reverse($e->getTrace());
        foreach ($stackTrace as &$trace) {
            if (isset($trace["args"])) {
                unset($trace["args"]);
            }
            $class = isset($trace["class"]) ? $trace["class"] : "&nbsp;";
            $function = isset($trace["function"]) ? $trace["function"] : "&nbsp;";

            if (isset($trace["file"]) && isset($trace["line"])) {
                $msgContent.= "<tr><td>";
                $msgContent.= $trace["file"] . "</td><td>";
                $msgContent.= $trace["line"] . "</td><td>";
                $msgContent.= "$class</td><td>";
                $msgContent.= "$function</td></tr>";

                error_log("{$trace["file"]}|{$trace["line"]}");
            }
        }
    } else {
        error_log("{$e->getFile()}|{$e->getLine()}");
    }
    error_log("****************************************************");

    $msgContent.= "</table>\n";
    $msgContent.= "</body></html>";

    $toMail = "";
    foreach ($errorInfo_toMail as $mailId => $name) {
        $toMail.= "$mailId,";
    }
    $toMail = rtrim($toMail, ",");
    $subject = "Exception caught - $environment - " . _APP_NAME;
    $msgContent = wordwrap($msgContent, 70, "\n");
    $headers = "From:$errorInfo_fromMail\n";
    $headers.= "MIME-Version: 1.0\n";
    $headers.= "Content-Type: text/html; charset=ISO-8859-1\n";
    
    //Sending mail to DEV team
    mail($toMail, $subject, $msgContent, $headers);
}

/**
 * Returns error type from error number
 * 
 * @param int $errNo Error Number
 * @return string Type of error
 */
function getErrorType($errNo) {
    $errorType = "";
    switch ($errNo) {
        case E_ERROR:
            $errorType = "E_ERROR";
            break;
        case E_WARNING:
            $errorType = "E_WARNING";
            break;
        case E_PARSE:
            $errorType = "E_PARSE";
            break;
        case E_NOTICE:
            $errorType = "E_NOTICE";
            break;
        case E_CORE_ERROR:
            $errorType = "E_CORE_ERROR";
            break;
        case E_CORE_WARNING:
            $errorType = "E_CORE_WARNING ";
            break;
        case E_COMPILE_ERROR:
            $errorType = "E_COMPILE_ERROR ";
            break;
        case E_COMPILE_WARNING:
            $errorType = "E_COMPILE_WARNING";
            break;
        case E_USER_ERROR:
            $errorType = "E_USER_ERROR";
            break;
        case E_USER_WARNING:
            $errorType = "E_USER_WARNING";
            break;
        case E_USER_NOTICE:
            $errorType = "E_USER_NOTICE";
            break;
        case E_STRICT:
            $errorType = "E_STRICT";
            break;
        case E_RECOVERABLE_ERROR:
            $errorType = "E_RECOVERABLE_ERROR";
            break;
        case E_DEPRECATED:
            $errorType = "E_DEPRECATED";
            break;
        case E_USER_DEPRECATED:
            $errorType = "E_USER_DEPRECATED";
            break;
        case E_ALL:
            $errorType = "E_ALL";
            break;
    }
    return $errorType;
}

?>
