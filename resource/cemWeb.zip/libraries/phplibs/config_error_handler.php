<?php

/**
 * File config_error_handler.php
 *
 * Configuration to handle run time php errors
 *
 * @package   PHPLIBS
 * @author    Selvaraj
 * @version   1.0.1	23/04/2015
 * @copyright RNTBCI
 * @filesource
 */
include_once "scripts/conf/server.conf";
define("_APP_NAME", "CLEM");

//$errorReporting = ini_get("error_reporting");
$errorReporting = E_ALL & ~E_STRICT & ~E_NOTICE;

$errorInfo_fromMail = "clem@renault.com";
$errorInfo_toMail = array(
    "Kanagavel.Ganesan@rntbci.com" => "GANESAN Kanagavel",
    "Venkatesh.Periyasamy@rntbci.com" => "Venkatesh Periyasamy"
);
if($SERVER_ENV == 'INT'){
   // $errorInfo_toMail['selvaraj.muniasamy@rntbci.com'] = "Selvaraj Muniasamy";
}
if($SERVER_ENV == 'ACCEPTANCE'){
 
   // $errorInfo_toMail['alexandre.parissenti-extern@renault.com'] = "Alexandre PARISSENTI";
}
if($SERVER_ENV == 'PRODUCTION'){
 
  //  $errorInfo_toMail['alexandre.parissenti-extern@renault.com'] = "Alexandre PARISSENTI";
}
?>
