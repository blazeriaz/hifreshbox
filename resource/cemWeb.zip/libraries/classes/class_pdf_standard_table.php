<?php
/* FILE---------------------------------------------------------
1-FILENAME : cartographie_uet.php
2-DESCRIPTION : 
The script displays two tables counting NC for each status and 
for each gravity level
3-IN :
Name      |    Description
4-DEPENDANCIES : used by suivi_nc.php
                         tdb_nc_uet.php
                         tdb_nc_global.php
---------------------------------------------------------------*/

/* CLASS---------------------------------------------------------
1-CLASSNAME : PDF
2-EXTENSION OF : FPDF 
3-DESCRIPTION : 
The class add some standard table method to the FPDF class
---------------------------------------------------------------*/
class PDF extends FPDF
{
  var $cellHeight=6;  
  var $displayHeader = false; 
  var $displayPage = false;
  var $displayFooter = false;
  var $headerTitle = '';
  var $widths;
  var $heights;
  var $aligns;
//Chargement des donn�es
function LoadData($text_sql)
{
    //Lecture des lignes du fichier
  $cnx=new connexion_db();
  $request= new requete($text_sql,$cnx->num);
  $request->recup_array();
  $cnx->close();	

  return $request->array;
}

function setCellHeight($h)
{
  $this->cellHeight=$h;  
}

function hex2rgb($hex) {
   $hex = str_replace("#", "", $hex);

   if(strlen($hex) == 3) {
      $r = hexdec(substr($hex,0,1).substr($hex,0,1));
      $g = hexdec(substr($hex,1,1).substr($hex,1,1));
      $b = hexdec(substr($hex,2,1).substr($hex,2,1));
   } else {
      $r = hexdec(substr($hex,0,2));
      $g = hexdec(substr($hex,2,2));
      $b = hexdec(substr($hex,4,2));
   }
   $rgb = array($r, $g, $b);
   //return implode(",", $rgb); // returns the rgb values separated by commas
   return $rgb; // returns an array with the rgb values
}

//Tableau color�
function creer_listing($header,$data,$header_w="",$column_align='',$color_entete='',$dataHidden='',$table_fill_cell='')
{
    
  // couleur de fond de l'ent�te
  if ($color_entete=='')
  {
    $this->SetFillColor(125);
  }
  else
  {
    $this->SetFillColor($color_entete[0],$color_entete[1],$color_entete[2]);
  }
  //Couleurs, �paisseur du trait et police grasse    
  $this->SetTextColor(0);
  $this->SetDrawColor(0,0,0);
  $this->SetLineWidth(.3);
  $this->SetFont('','B');
  
  $ori_header = $header;
  
  if(empty($header)) {
      $header = $data;
  }
	
  //En-t�te
	if ($header_w!="")
	{
	  $w=$header_w;
	}
	else
	{
	  for($i=0;$i<count($header);$i++)
	  {
	    $max_len=strlen($header[$i]);
	    for($j=0;$j<count($data);$j++)
	    {
        $max_len=max($max_len,strlen($data[$j][$i]));
      }  
      $w[$i]=$max_len*4;
	  }  
	}
  if ($column_align=='')
  {
	  for($i=0;$i<count($header);$i++)
	  {
	    $column_align[$i]='C';
    }    
  }  	  
  
  if(!empty($ori_header)) {
	// entete du fichier
  for($i=0;$i<count($header);$i++)
  {
    $this->Cell($w[$i],7,$header[$i],1,0,'C',1);
    $this->SetTextColor(0);
  }  
  $this->Ln();
  }
    //Restauration des couleurs et de la police
    $this->SetFillColor(220);
    $this->SetTextColor(0);
    $this->SetFont('');
    //Donn�es
    $fill=0;
    $colonne_a_colorier=500;
    if ($table_fill_cell!='')
    {
      $colonne_a_colorier=$table_fill_cell['targetCol'];
    }	        
    
    // creation des lignes  
    $nbRows=0;
    foreach($data as $row)
    {
	    // calcul du nombre de retour � la ligne pour cet �l�ment
	    $max_nbl=0;
      for($i=0;$i<count($header);$i++)
      {
	      $nbl[$i]=$this->calcule_ligne_MultiCell($w[$i],$row[$i]);	
		    $max_nbl=max($max_nbl,$nbl[$i]);
	    }
      // Placement aux bonnes coordonn�es
      
	    if ($max_nbl*$this->cellHeight>round($this->h-$this->GetY()-$this->bMargin))
	    { 
        $this->AddPage();
	    }
      $x_cur=$this->GetX();
      $y_cur=$this->GetY();

      for($i=0;$i<count($header);$i++)
      {
        $row[$i]=stripslashes(trim($row[$i]));
        for ($j=0;$j<($max_nbl-$nbl[$i]);$j++)
        {
          $row[$i].="\n ";
        } 
        $tmp_fill=$fill;  
        if ($i==$colonne_a_colorier)
        {
          $colors=$this->hex2rgb($table_fill_cell['values'][$dataHidden[$nbRows]]);
          $this->SetFillColor($colors[0],$colors[1],$colors[2]);
          $fill=1;
        }
        $this->MultiCell($w[$i],$this->cellHeight,$row[$i],'LRBT',$column_align[$i],$fill);  
	$this->SetTextColor(0);
	$this->SetFillColor(220);
	$fill=$tmp_fill;
	$x_cur+=$w[$i];
        $this->SetXY($x_cur,$y_cur);
      } 
      // decalage
      $this->Ln($this->cellHeight*$max_nbl);
      $fill=!$fill;
	    unset($nbl); 
      $nbRows++;      
    }
    $this->Cell(array_sum($w),0,'','T');
}


function calcule_ligne_MultiCell($w,$txt)
{
	//Output text with automatic or explicit line breaks
	$cw=&$this->CurrentFont['cw'];
	if($w==0)
	{
  	$w=$this->w-$this->rMargin-$this->x;
  }	
	$wmax=($w-2*$this->cMargin)*1000/$this->FontSize;
	$s=str_replace("\r",'',$txt);
	$nb=strlen($s);
	if($nb>0 and $s[$nb-1]=="\n")
	{
  	$nb--;
  }	
	$b=0;
	$sep=-1;
	$i=0;
	$j=0;
	$l=0;
	$ns=0;
	$nl=1;
	while($i<$nb)
	{
		//Get next character
		$c=$s{$i};
		if($c=="\n")
		{
			//Explicit line break
			if($this->ws>0)
			{
				$this->ws=0;
			}
			$i++;
			$sep=-1;
			$j=$i;
			$l=0;
			$ns=0;
			$nl++;
			continue;
		}
		if($c==' ')
		{
			$sep=$i;
			$ls=$l;
			$ns++;
		}
		$l+=$cw[$c];
		if($l>$wmax)
		{
			//Automatic line break
			if($sep==-1)
			{
				if($i==$j)
				{
        	$i++;
        }	
				if($this->ws>0)
				{
					$this->ws=0;
				}
			}
			else
			{
				$i=$sep+1;
			}
			$sep=-1;
			$j=$i;
			$l=0;
			$ns=0;
			$nl++;
		}
		else
		{
    	$i++;
    }	
	}
	//Last chunk
	if($this->ws>0)
	{
		$this->ws=0;
	}
	$this->x=$this->lMargin;
	return $nl;
}
//Tableau color�
function creer_listing_data($header,$data,$header_w="",$color_entete='',$topicSingleIndexs) {
   // couleur de fond de l'ent�te
    if ($color_entete=='') {
        $this->SetFillColor(125);
    } else {
        $this->SetFillColor($color_entete[0],$color_entete[1],$color_entete[2]);
    }
    //Couleurs, �paisseur du trait et police grasse    
    $this->SetTextColor(0);
    $this->SetDrawColor(0,0,0);
    $this->SetLineWidth(.3);
    $this->SetFont('','B');
	
	
    //En-t�te
    if ($header_w!="") {
        $w=$header_w;
    } else {
        for($i=0;$i<count($header);$i++) {
            $max_len=strlen($header[$i]);
            for($j=0;$j<count($data);$j++) {
                $max_len=max($max_len,strlen($data[$j][$i]));
            }
            $w[$i]=$max_len*4;
        }
    }
    $column_align=array();
    for($i=0;$i<count($header);$i++) {
        if($i == 0){
            $column_align[$i]='L';
        }else{
            $column_align[$i]='C';
        }
    }
    
    // entete du fichier
    for($i=0;$i<count($header);$i++) {
        $this->Cell($w[$i],7,$header[$i],1,0,'C',1);
        $this->SetTextColor(0);
    } 
    $this->Ln();
	
    //Restauration des couleurs et de la police
    $this->SetFillColor(220);
    $this->SetTextColor(0);
    $this->SetFont('');
    //Donn�es
    $fill=0;
    // creation des lignes  
    $nbRows=0;
    foreach($data as $dataResults) {
        $dataCount = count($dataResults);
        $tmp_fill=$fill;
        $nbrowsCount =0;
        foreach($dataResults as $row) {
            // calcul du nombre de retour � la ligne pour cet �l�ment
	    $max_nbl=0;
            for($i=0;$i<count($header);$i++) {
                if(!isset($row[$i])){
                    $row[$i] = '';
                }
                $row[$i] = preg_replace('/\s+/', ' ', $row[$i]);
                $row[$i] = stripslashes(trim($row[$i]));
                $nbl[$i]=$this->calcule_ligne_MultiCell($w[$i],$row[$i]);
                $max_nbl=max($max_nbl,$nbl[$i]);
            }  
            
            // Placement aux bonnes coordonn�es
      	    if ($max_nbl*$this->cellHeight > round($this->h-$this->GetY()-$this->bMargin)) { 
                $this->AddPage();
	    }
            $x_cur=$this->GetX();
            $y_cur=$this->GetY();
      
            for($i=0;$i<count($header);$i++) {
                if($row[$i] == 'G' || $row[$i] == 'V') {
                    $fill = 1;
                    $this->SetFillColor(0,128,0);
                    $this->SetTextColor(0);
                }
                if($row[$i] == 'R') {
                    $fill =1;
                    $this->SetFillColor(255,75,0);
                    $this->SetTextColor(0);
                }
                if($row[$i] == 'O'){
                    $fill =1;
                    $this->SetFillColor(225,193,21);
                    $this->SetTextColor(0);
                }
                if($row[$i] == 'NE'){
                    $fill =1;
                    $this->SetFillColor(255,255,255);
                    $this->SetTextColor(0);
                }
                if($row[$i] == 'NA'){
                    $fill =1;
                    $this->SetFillColor(147,147,147);
                    $this->SetTextColor(0);
                }
                for ($j=0;$j<($max_nbl-$nbl[$i]);$j++) {
                    $row[$i].="\n ";
                }
                
                $line = 'LRBT';
                if($dataCount > 1) {
                    if(in_array($i, $topicSingleIndexs)) {
                        $line = 'LR';
                    }
                }
                
                $this->MultiCell($w[$i],$this->cellHeight,$row[$i],$line,$column_align[$i],$fill);
                
                $this->SetTextColor(0);
                $this->SetFillColor(220);
                $fill=$tmp_fill;
                $x_cur+=$w[$i];
                $this->SetXY($x_cur,$y_cur);
            }
            // decalage
            $this->Ln($this->cellHeight*$max_nbl);
            $nbrowsCount++;
        }
        $fill=!$fill;
        unset($nbl); 
        $nbRows++; 
    }
    $this->Cell(array_sum($w),0,'','T');
}


function creer_listing_filter_data($header,$data,$header_w="",$color_entete='',$topicname,$topicSingleIndexs) {
    $this->SetFillColor(0);
	
    //En-t�te
    if ($header_w!="") {
        $w=$header_w;
    } else {
        for($i=0;$i<count($header);$i++) {
            $max_len=strlen($header[$i]);
            for($j=0;$j<count($data);$j++) {
                $max_len=max($max_len,strlen($data[$j][$i]));
            }
            $w[$i]=$max_len*4;
        }
    }
    $column_align=array();
    for($i=0;$i<count($header);$i++) {
        if($i == 0){
            $column_align[$i]='L';
        }else{
            $column_align[$i]='C';
        }
    }
    $columnCount = count($header);
    $totalWidth = array_sum($w);
    // calcul du nombre de retour � la ligne pour cet �l�ment
    $max_nbl=0;
    for($i=0;$i<$columnCount;$i++) {
        $nbh=$this->calcule_ligne_MultiCell($w[$i],$header[$i]);
        $max_nbh=max($max_nbh,$nbh);
    }
    $th = $this->calcule_ligne_MultiCell($totalWidth,$topicname);
    
    //Restauration des couleurs et de la police
    //$this->SetFillColor(220);
    //Donn�es
    $fill=0;

    // creation des lignes  
    $nbRows=0;
    $need_header = true;
    foreach($data as $key => $dataResults) {
        $dataCount = count($dataResults);
        $tmp_fill=$fill;
        $nbrowsCount =0;
        foreach($dataResults as $rowNum => $row) {
            // calcul du nombre de retour � la ligne pour cet �l�ment
	    $max_nbl=0;
            for($i=0;$i<$columnCount;$i++) {
                if(!isset($row[$i])){
                    $row[$i] = '';
                }
                $row[$i] = preg_replace('/\s+/', ' ', $row[$i]);
                $row[$i] = stripslashes(trim($row[$i]));
                $nbl[$i]=$this->calcule_ligne_MultiCell($w[$i],$row[$i]);
                $max_nbl=max($max_nbl,$nbl[$i]);
	    }
               
            $new_page = false;
            $tmp_max_nbl = $max_nbl;
            if($rowNum == 0) {
                $tmp_max_nbl = $max_nbl + $max_nbh + $th;
            }
            // Placement aux bonnes coordonn�es
            if ($tmp_max_nbl*$this->cellHeight > round($this->h-$this->GetY()-$this->bMargin)) {
                $new_page = true;
                $need_header = true;
            }
            if($new_page) {
                if($rowNum > 0) {
                    $this->MultiCell($totalWidth,1,"","T");
                }
                $this->AddPage();
            }
            if($need_header) {
                if ($color_entete=='') {
                    $this->SetFillColor(125);
                } else {
                    $this->SetFillColor($color_entete[0],$color_entete[1],$color_entete[2]);
                }
                $this->clearWHA();
                $this->SetWidths($w);
                $aligns = array();
                for($i=0;$i<count($header);$i++) {
                    $aligns[] = "C";
                }
                $this->SetAligns($aligns);                
                $this->Row($header, true);
                
                $this->SetFillColor(0);
                $this->clearWHA();
                $this->SetWidths(array($totalWidth));
                $this->Row(array($topicname));
            }
            $need_header = false;
            $x_cur=$this->GetX();
            $y_cur=$this->GetY();
      
            for($i=0;$i<count($header);$i++) {
                $fill = 0;
                
                if($row[$i] == 'G' || $row[$i] == 'V'){
                    $fill = 1;
                    $this->SetFillColor(0,128,0);
                    $this->SetTextColor(0);
                }
                if($row[$i] == 'R'){
                    $fill =1;
                    $this->SetFillColor(255,75,0);
                    $this->SetTextColor(0);
                }
                if($row[$i] == 'O'){
                    $fill =1;
                    $this->SetFillColor(255,193,21);
                    $this->SetTextColor(0);
                }
                if($row[$i] == 'NE'){
                    $fill =1;
                    $this->SetFillColor(255,255,255);
                    $this->SetTextColor(0);
                }
                if($row[$i] == 'NA'){
                    $fill =1;
                    $this->SetFillColor(147,147,147);
                    $this->SetTextColor(0);
                }
                if($i==1 && $rowNum > 0 && $dataCount > 1){
                    $row[$i] ='';
                }
                for ($j=0;$j<($max_nbl-$nbl[$i]);$j++) {
                    $row[$i].="\n ";
                } 
               
                $line = 'LRBT';
                if($dataCount > 1) {
                    if(in_array($i, $topicSingleIndexs)) {
                        $line = 'LR';
                    }
                }
                
                $this->MultiCell($w[$i],$this->cellHeight,$row[$i],$line,$column_align[$i],$fill);                 
                $fill=$tmp_fill;
                $x_cur+=$w[$i];
                $this->SetXY($x_cur,$y_cur);
                $this->SetFillColor(0);
            }
            // decalage
            $this->Ln($this->cellHeight*$max_nbl);
            $nbrowsCount++;
        }
        if($dataCount > 1) {
            $this->MultiCell($totalWidth,1,"","T");
        }
        $fill=!$fill;
	unset($nbl);
        $nbRows++; 
    }
    
}

public function Header() {
    parent::Header();
    if($this->displayHeader){
        $this->setX(0);
        $pathBase='../';
        $pathRoot='../'.$pathBase;
        $pathPictures=$pathRoot.'images/';
        $this->Image($pathPictures."logo.gif",10,8,16,18);
        if($this->PageNo() != 1){
            $this->SetXY(25,5);
            $this->Cell(40,5,'CONFIDENTIAL',0,'R',0,0);
            $this->SetXY(65,5);
            $this->Cell(4, 4, 'C', 1);
            $this->SetXY(90,6);
            $this->Cell(109,6,$this->headerTitle,'',1,'L',false);
            $this->SetXY(25,9);
            $this->Cell(40,5,'RENAULT PROPERTY',0,'R',0,0);
            $this->SetXY(100,15);
           if($_SESSION['language'] == 'en'){
                $this->Cell(209,6,  'Created on'." : ".date('m/d/Y'),'',1,'L',false);
            }else{
                $this->Cell(209,6,  iconv('UTF-8', 'windows-1252','Date de création')." : ".date('d/m/Y'),'',1,'L',false);                
            }
            
        }
    }
        if(($this->PageNo() != 1)&& $this->displayPage){
            $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'R');
          
        }
        if($this->displayHeader || $this->displayPage){
            $this->Ln(20);        
        }
        
    
}

public function Footer() {
    parent::Footer();
     if($this->displayFooter){
            $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'R');
       }
}

function creer_listing_gesper($header,$data,$header_w="",$column_align='',$color_entete='',$dataHidden='',$table_fill_cell='')
{
    
  // couleur de fond de l'ent�te
  if ($color_entete=='')
  {
    $this->SetFillColor(125);
  }
  else
  {
    $this->SetFillColor($color_entete[0],$color_entete[1],$color_entete[2]);
  }
  //Couleurs, �paisseur du trait et police grasse    
  $this->SetTextColor(0);
  $this->SetDrawColor(0,0,0);
  $this->SetLineWidth(.3);
  $this->SetFont('','B');
	
	
  //En-t�te
	if ($header_w!="")
	{
	  $w=$header_w;
	}
	else
	{
	  for($i=0;$i<count($header);$i++)
	  {
	    $max_len=strlen($header[$i]);
	    for($j=0;$j<count($data);$j++)
	    {
        $max_len=max($max_len,strlen($data[$j][$i]));
      }  
      $w[$i]=$max_len*4;
	  }  
	}
  if ($column_align=='')
  {
	  for($i=0;$i<count($header);$i++)
	  {
	    $column_align[$i]='C';
    }    
  }  	  
 $this->SetFillColor(203,203,203);
 $borderData=array('LTB','TB','TBR');
  // entete du fichier
  for($i=0;$i<count($header);$i++)
  {
    
    $this->Cell($w[$i],7,$header[$i],$borderData[$i],0,'C',1);
    $this->SetTextColor(0);
  }  
  $this->Ln();

    if(!empty($data['name']))
  
    //Restauration des couleurs et de la police
    $this->SetFillColor(203);
    $this->SetTextColor(0);
    $this->SetFont('');
    //Donn�es
    $fill=0;
    $colonne_a_colorier=500;
    if ($table_fill_cell!='')
    {
      $colonne_a_colorier=$table_fill_cell['targetCol'];
    }	        
    
    // creation des lignes  
    $nbRows=0;
    foreach($data as $key => $dataResult){
        if($key == 1){
            $this->SetFillColor('255','0','0');
        }elseif($key == 2){
            $this->SetFillColor('0','128','129'); 
        }elseif($key == 3){
            $this->SetFillColor('153','51','101');
        }
        $this->MultiCell(280,7,$dataResult['name'],1, 'L', 1);
        $this->SetFillColor(0);
    foreach($dataResult['data'] as $row)
    {
	    // calcul du nombre de retour � la ligne pour cet �l�ment
	    $max_nbl=0;
      for($i=0;$i<count($header);$i++)
      {
              
	      $nbl[$i]=$this->calcule_ligne_MultiCell($w[$i],$row[$i]);	
		    $max_nbl=max($max_nbl,$nbl[$i]);
	    }
      // Placement aux bonnes coordonn�es
      
	    if ($max_nbl*$this->cellHeight>round($this->h-$this->GetY()-$this->bMargin))
	    { 
                $this->AddPage();
                $this->SetFillColor(203,203,203);
                  $this->SetFont('','B');
                  for($i=0;$i<count($header);$i++)
                    {
                      $this->Cell($w[$i],7,$header[$i],$borderData[$i],0,'C',1);
                      $this->SetTextColor(0);
                    }  
                    $this->Ln();
                    if($key == 1){
                         $this->SetFillColor('255','0','0');
                    }elseif($key == 2){
                        $this->SetFillColor('0','128','129'); 
                    }elseif($key == 3){
                        $this->SetFillColor('153','51','101');
                    }
                    $this->MultiCell(280,7,$dataResult['name'],1, 'L', 1);
                    $this->SetFont('');
	    }
      $x_cur=$this->GetX();
      $y_cur=$this->GetY();

      for($i=0;$i<count($header);$i++)
      {
        $row[$i]=stripslashes(trim($row[$i]));
        for ($j=0;$j<($max_nbl-$nbl[$i]);$j++)
        {
          $row[$i].="\n ";
        } 
        $tmp_fill=$fill;  
        $fill = 0;
        $align = $column_align[$i];
        if($i==1){
          $align ='C';
        }
        $this->MultiCell($w[$i],$this->cellHeight,$row[$i],'LRBT',$align,$fill);  
	$this->SetTextColor(0);
	$this->SetFillColor(220);
	$fill=$tmp_fill;
	$x_cur+=$w[$i];
        $this->SetXY($x_cur,$y_cur);
      } 
      // decalage
      $this->Ln($this->cellHeight*$max_nbl);
      $fill=!$fill;
	    unset($nbl); 
      $nbRows++;      
    }
}
    $this->Cell(array_sum($w),0,'','T');
}



function clearWHA()
{
    $this->widths=array();
    $this->heights=array();
    $this->aligns=array();
}
function SetWidths($w)
{
    //Set the array of column widths
    $this->widths=$w;
}

function SetHeights($h)
{
    //Set the array of column heights
    $this->heights=$h;
}

function SetAligns($a)
{
    //Set the array of column alignments
    $this->aligns=$a;
}

function Row($data, $fill = false, $border = true)
{
    //Calculate the height of the row
    $h = 0; $dataLines = array();
    for($i=0;$i<count($data);$i++) {        
        $this->heights[$i] = isset($this->heights[$i])?$this->heights[$i]:7;
        $dataLines[$i] = $this->NbLines($this->widths[$i],$data[$i]);        
        $nb = $this->heights[$i] * $dataLines[$i];
        if(is_array($data[$i]) && $data[$i]["type"] == "image") {
            $image = $data[$i];
            $nb = $this->heights[$i];
        }
        $h=max($h, $nb);
    }
    
    //Issue a page break first if needed
    $this->CheckPageBreak($h);
    //Draw the cells of the row    
    for($i=0;$i<count($data);$i++) {
        $w=$this->widths[$i];
        $lh = $this->heights[$i];
        $a=isset($this->aligns[$i]) ? $this->aligns[$i] : 'L';
        //Save the current position
        $x=$this->GetX();
        $y=$this->GetY();
        $b = 0;
        //Print the text        
        if(is_array($data[$i])) {
            if($data[$i]["type"] == "image") {            
                $image = $data[$i];
                $imageData = $this->Image($image["source"],$x+5, $y+2,$image["width"],$image["height"]);
                $this->MultiCell($w,$lh,$imageData,$b,$a,$fill);
            } else if($data[$i]["type"] == "link") {            
                $link = $data[$i];
                $linkText = isset($link["text"])?$link["text"]:$link["href"];
                $this->MultiCell($w,$lh,$linkText,$b,$a,$fill,$link["href"]);
            }
        } else {
            $data[$i] = iconv('UTF-8', 'windows-1252',$data[$i]);
            $this->MultiCell($w,$lh,$data[$i],$b,$a,$fill);
            $spaceLines = ceil($h / $lh) - $dataLines[$i];            
            if($fill && $spaceLines > 0) {
                for($k=0; $k<$spaceLines; $k++) {
                    $this->SetXY($x,$y+(($k+1) * $lh));
                    $this->MultiCell($w,$lh," ",$b,$a,$fill);
                }
            }
        }
        
        //Draw the border
        if($border) {
            $this->Rect($x,$y,$w,$h);
        }
        //Put the position to the right of the cell
        $this->SetXY($x+$w,$y);
    }
    //Go to the next line
    $this->Ln($h);
}

function CheckPageBreak($h) {
    //If the height h would cause an overflow, add a new page immediately
    if($this->GetY()+$h>$this->PageBreakTrigger) {
        $this->AddPage($this->CurOrientation);
    }
}

function NbLines($w,$txt)
{
    //Computes the number of lines a MultiCell of width w will take
    $cw=&$this->CurrentFont['cw'];
    if($w==0)
        $w=$this->w-$this->rMargin-$this->x;
    $wmax=($w-2*$this->cMargin)*1000/$this->FontSize;
    $s=str_replace("\r",'',$txt);
    $nb=strlen($s);
    if($nb>0 and $s[$nb-1]=="\n")
        $nb--;
    $sep=-1;
    $i=0;
    $j=0;
    $l=0;
    $nl=1;
    while($i<$nb)
    {
        $c=$s[$i];
        if($c=="\n")
        {
            $i++;
            $sep=-1;
            $j=$i;
            $l=0;
            $nl++;
            continue;
        }
        if($c==' ')
            $sep=$i;
        $l+=$cw[$c];
        if($l>$wmax)
        {
            if($sep==-1)
            {
                if($i==$j)
                    $i++;
            }
            else
                $i=$sep+1;
            $sep=-1;
            $j=$i;
            $l=0;
            $nl++;
        }
        else
            $i++;
    }
    return $nl;
}

}