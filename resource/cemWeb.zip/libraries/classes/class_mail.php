<?php
/**
* class_mail.php File
*
* Class manages the functionalities of sending email
*
* @package   PHPLIBS
* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
* @version   1.0.1	09/07/2008		Initial revision code
* @copyright Etablissement VSF - RENAULT
* @filesource
*/

/**
* Classe cl_mail
*
* Definition of Class Mail
*
* @package   PHPLIBS
* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
* @version   1.0.1	09/07/2008		Initial revision code
* @copyright Etablissement VSF - RENAULT
*/

class cl_mail
{
	/**
	* receiver
	* 
	* @var    string
	* @access public
	*/
	var $To;
	
	/**
	* Copy recipients
	* 
	* @var    string
	* @access public
	*/
	var $CC;
	
	/**
	* Bcc recipient
	* 
	* @var    string
	* @access public
	*/
	var $Bcc;
	
	/**
	* Transmitter
	* 
	* @var    string
	* @access public
	*/
	var $From;
	
	/**
	* For special headers
	* 
	* @var    string
	* @access public
	*/
	var $entetes;
	
	/**
	* Message Subject
	* 
	* @var    string
	* @access public
	*/
	var $objet;
	
	/**
	* Message Body
	* 
	* @var    string
	* @access public
	*/
	var $body;
	
	/**
	* Contains parts attached - if multipart email
	* 
	* @var    string
	* @access public
	*/
	var $parts;
	
	/**
	* Mime type of the body of the email (text / plain or html)
	* 
	* @var    string
	* @access public
	*/
	var $mime_body;
	
	/**
	* List of recipients
	* 
	* @var    array
	* @access public
	*/
	var $tab_destinataires;
        
        var $envirunment = true;
	
	/**
	* Function cl_Mail()
	*
	* Class constructor
	*
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Initial revision code
	* @copyright Etablissement VSF - RENAULT
	*
	* @param     void
	* @return    void
	*/
	function cl_Mail()
	{
		global $profiler;
		if($profiler)	{$profiler->startTimer("cl_Mail->cl_Mail");}

		$this->To="";
		$this->CC="";
		$this->Bcc="";
		$this->From="";
		$this->entetes="";
		$this->objet="";
		$this->body="";
		$this->parts="";
		$this->mime_body="text/plain";
		$this->accuse_reception = "";
		
		if($profiler)	{$profiler->stopTimer("cl_Mail->cl_Mail");}
	}

	/**
	* Function Debug()
	*
	* Based debugging Class
	*
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Initial revision code
	* @copyright Etablissement VSF - RENAULT
	*
	* @param     void
	* @return    void
	*/
	function Debug()
	{
		echo "-------------------------------------------------<BR>\n";
		echo "BEGIN DEBUG cl_Mail							   <BR>\n";
		echo "-------------------------------------------------<BR>\n";
		echo "<PRE>\n";
		print_r($this);
		echo "</PRE>\n";
		echo "-------------------------------------------------<BR>\n";
		echo "END DEBUG cl_Mail								   <BR>\n";
		echo "-------------------------------------------------<BR>\n";
	}
	
	/**
	* Function set_body()
	*Fonction
	* Initializes the message body
	*
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Initial revision code
	* @copyright Etablissement VSF - RENAULT
	*
	* @param     string	$msg_body	message text
	* @param     string	$ctype		type text
	* @return    void
	*/
	function  set_body($msg_body,$ctype="text/plain")
	{
		global $profiler;
		if($profiler)	{$profiler->startTimer("cl_Mail->set_body");}

		$this->body=$msg_body;
		$this->mime_body=$ctype;
		
		if($profiler)	{$profiler->stopTimer("cl_Mail->set_body");}
	}
	
	/**
	* Function ajoute_piece()
	*
	* Adds an attachment
	*
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Initial revision code
	* @copyright Etablissement VSF - RENAULT
	*
	* @param     string	$message	texte du message
	* @param     string	$nom		nom de la piece
	* @param     string	$ctype		type du texte
	* @param     string	$encode		type d'encodage
	* @return    void
	*/
	function  ajoute_piece($message,$nom="",$ctype="application/octet-stream",$encode="base64")
	{
		global $profiler;
		if($profiler)	{$profiler->startTimer("cl_Mail->ajoute_piece");}

		$this->parts[]=array (	"ctype"=>$ctype,
								"message"=>$message,
								"encode"=>$encode,
								"nom"=>$nom );
								
		if($profiler)	{$profiler->stopTimer("cl_Mail->ajoute_piece");}
	}
	
	/**
	* Function ajoute_destinataire()
	*
	* Adds a recipient
	*
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Initial revision code
	* @copyright Etablissement VSF - RENAULT
	*
	* @param     string	$Email			Email address of recipient
	* @param     string	$nom_prenom		full name of the recipient
	* @param     string	$mode			transmission mode (direct, copy or blind copy)
	* @return    void
	*/
	function  ajoute_destinataire($Email,$nom_prenom="",$mode = "To")
	{
		global $profiler;
		if($profiler)	{$profiler->startTimer("cl_Mail->ajoute_destinataire");}

		/**
                 * If the value of Email is empty, exit!
                 */
		if(empty($Email) || $Email=="") 
		{
			if($profiler)	{$profiler->stopTimer("cl_Mail->ajoute_destinataire");}
			return;
		}
		
		$this->tab_destinataires[]=array (	"email"		=>$Email,
											"nom_prenom"=>$nom_prenom,
											"mode"		=>$mode
										);
												
		//echo "<pre>";print_r($this->tab_destinataires);echo "</pre>";
										
		if($mode == "To")
		{
			$this->To.=(!empty($this->To)?",":"").$Email;
		}
		
		if($mode == "CC")
		{
			$this->CC.=(!empty($this->CC)?",":"").$Email;
		}
		
		if($mode == "Bcc")
		{
			$this->Bcc.=(!empty($this->Bcc)?",":"").$Email;
		}
								
		if($profiler)	{$profiler->stopTimer("cl_Mail->ajoute_destinataire");}
	}
	
	/**
	* Function ajoute_fichier()
	*
	* Add a file
	*
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Initial revision code
	* @copyright Etablissement VSF - RENAULT
	*
	* @param     file	$file			file to add
	* @param     string	$intitule		file's title
	* @return    void
	*/
	function  ajoute_fichier($file,$intitule = "")
	{
		global $profiler;
		if($profiler)	{$profiler->startTimer("cl_Mail->ajoute_fichier");}

		require_once "fichier.php";
		$FileSize=filesize($file);
		if($this->Taille_mail + $FileSize > 5000000)
		{
			if($profiler)	{$profiler->stopTimer("cl_Mail->ajoute_fichier");}
			return false;
		}
		$this->Taille_mail += $FileSize;
		$Fichier = new cl_fichier($file,0);
		$fp=fopen($file,"r");
		if($intitule == "") 
		{
			$intitule = $Fichier->NomFichier;
		}
		$this->ajoute_piece( fread($fp,$FileSize) , $intitule , $Fichier->TypeMime , "base64");
		fclose($fp);
								
		if($profiler)	{$profiler->stopTimer("cl_Mail->ajoute_fichier");}
		return true;
	}
	
	/**
	* Function construit_message()
	*
	* Encode email
	*
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Initial revision code
	* @copyright Etablissement VSF - RENAULT
	*
	* @param     array	$part			data to be encoded
	* @return    string	$MessageEncode          encoded mail
	*/
	function  construit_message($part)
	{
		global $profiler;
		if($profiler)	{$profiler->startTimer("cl_Mail->construit_message");}

		$message = $part["message"];
		
		$encoding = $part["encode"];
		
		if($encoding =="base64")
		{
			$message = chunk_split(base64_encode($message),72);
		}
					   
		$MessageEncode = "Content-Type: ".$part["ctype"].
				"\nContent-Transfer-Encoding: $encoding".
				($part["nom"]?"\nContent-Disposition: attachment; filename=\"".$part["nom"]."\"":"").
				"\n\n$message\n";
								
		if($profiler)	{$profiler->stopTimer("cl_Mail->construit_message");}
		return $MessageEncode;
	}
	
	/**
	* Function construit_multipart()
	*
	* Built the mail encoding attachments
	*
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Initial revision code
	* @copyright Etablissement VSF - RENAULT
	*
	* @param     void
	* @return    string		$multipart	encoded mail
	*/
	function  construit_multipart()
	{
		global $profiler;
		if($profiler)	{$profiler->startTimer("cl_Mail->construit_multipart");}

		$boundary="b".md5(uniqid(time()));
		$multipart =
			"Content-Type: multipart/mixed; charset=iso-8859-1; boundary = $boundary\n\nCeci est un message de type MIME.\n\n--$boundary";
		
		if(!empty($this->body))
		{
			$partBody  =array (	"ctype"=>$this->mime_body,
								"message"=>$this->body."\n",
								"encode"=>"8bit",
								"nom"=>"" );
			$multipart .= "\n".$this->construit_message($partBody)."--$boundary";
		}
		if(is_array($this->parts))
		{
			reset($this->parts);
			while(list($i,$part)=each($this->parts))
			{
				$multipart .= "\n".$this->construit_message($part)."--$boundary";
			}
		}	
		$multipart .="--\n";
								
		if($profiler)	{$profiler->stopTimer("cl_Mail->construit_multipart");}
		return $multipart;
	}
	
	/**
	* Function get_mail()
	*
	* Returns the full email
	*
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Initial revision code
	* @copyright Etablissement VSF - RENAULT
	*
	* @param     boolean	$complete               true if you put the recipient and subject line (default)
	* @return    string		$mime		full Mail
	*/
	function  get_mail($complete = true)
	{
		global $app, $profiler, $langue, $user;
		if($profiler)	{$profiler->startTimer("cl_Mail->get_mail");}

		$mime="";
		$ListeTo = array();
		$ListeCC = array();
		$ListeBcc = array();
	
		/**
                 * Depending on the server shipping, sends emails
                 * to the sender with the recipient list in the message body (dev)
                 * or sent to recipients with a message (re7)
                 * or sends normal (prod)
                 */
		
		$SautLigne="<BR>";

		if(!$this->envirunment)
		{
			if(count($this->tab_destinataires))
			{
				foreach ($this->tab_destinataires as $tab)
				{
					if($tab["mode"]=="To")
					{
						$ListeTo[] = $tab["nom_prenom"]." ".$tab["email"];
					}
					if($tab["mode"]=="CC")
					{
						$ListeCC[] = $tab["nom_prenom"]." ".$tab["email"];
					}
					if($tab["mode"]=="Bcc")
					{
						$ListeBcc[] = $tab["nom_prenom"]." ".$tab["email"];
					}
				}
			}
			else 
			{
				if($this->To!="")
				{
					$ListeTo = explode(",",$this->To);
				}
				if($this->CC!="")
				{
					$ListeCC = explode(",",$this->CC);
				}
				if($this->Bcc!="")
				{
					$ListeBcc = explode(",",$this->Bcc);
				}
			}
			if(count($ListeTo))
			{
				$this->body .= "<BR><BR><B>Liste des destinataires :</B><BR>".implode($SautLigne,$ListeTo);
			}
			if(count($ListeCC))
			{
				$this->body .= "<BR><BR><B>Liste des destinataires en copie :</B><BR>".implode($SautLigne,$ListeCC);
			}
			if(count($ListeBcc))
			{
				$this->body .= "<BR><BR><B>Liste des destinataires en copie cachée :</B><BR>".implode($SautLigne,$ListeBcc);
			}
			
			if($user->Email)
			{
				$this->To=$user->Email;
			}
			else
			{
				$this->To=$this->From;
			}
			$this->CC="";
			$this->Bcc="";
		}
		if(!$this->envirunment)
		{
			if(!$langue->Cl_Mail_mail_re7)
			{
				$langue->Cl_Mail_mail_re7 = "Ce mail est envoyé par une application en cours de test.<BR>Si vous ne participez pas à cette phase de recette, merci d'ignorer ce message.<BR>
											<BR>This mail is sent by an application under test. <BR> If you do not participate in this test, thank you to ignore this message.";
			}
			$this->body = "<FONT COLOR=\"ORANGE\"><B>$langue->Cl_Mail_mail_re7</B></FONT><BR><BR>".$this->body;
		}
		if(!empty($this->From))
		{
			$mime.="From: ".$this->From."\n";
		}
		if(!empty($this->entetes))
		{
			$mime.=$this->entetes."\n";
		}
		if(!empty($this->CC))
		{
			$mime.="CC: ".$this->CC."\n";
		}
		if(!empty($this->Bcc))
		{
			$mime.="Bcc: ".$this->Bcc."\n";
		}
		
		if($complete)
		{
			if(!empty($this->To))
			{
				$mime.="To: $this->To\n";
			}
			
			if(!empty($this->objet))
			{
				$mime.="Subject: ".$this->objet."\n";
			}
		}
	
		$mime .= "MIME-Version: 1.0\n".$this->construit_multipart();
								
		if($profiler)	{$profiler->stopTimer("cl_Mail->get_mail");}
		return $mime;
	}
	
	/**
	* Function envoyer()
	*
	* Send email to recipients
	*
	* @author    Emilie HUEBER <emilie.hueber-renexter@renault.com>
	* @version   1.0.1	09/07/2008		Initial revision code
	* @copyright Etablissement VSF - RENAULT
	*
	* @param     string		$Diffusion	EACH = send an email to each recipient, ALL = send an email to all recipients
	* @return    boolean	$ok			If sent ok or not
	*/
	function  envoyer($Diffusion)
	{
		global $profiler,$SERVER_ENV;
		if($profiler)	{$profiler->startTimer("cl_Mail->envoyer");}

		$mime = $this->get_mail(false);
		
		//$subjet ="=?ISO-8859-1?B?".base64_encode($this->objet)."?=";
		//GR  modif pour que les mails deviennent lisible à travers toute la galaxie, c'est magique utf8
		$subjet ="=?UTF-8?B?".base64_encode($this->objet)."?=";
		/**
                 * Either we diffuses all recipients at once
                 */
                
		if($Diffusion=="ALL")
		{
                    $ok =  mail($this->To, $subjet ,"",$mime,"-f$this->From");
		}
		/**
                 * or a broadcast receiver is carried out by
                 */
		else if($Diffusion=="EACH")
		{	
                    
                        reset($this->tab_destinataires);                       
			while(list($indexe,$destinataire)=each($this->tab_destinataires))
			{                           
                            if($SERVER_ENV == "DEV"  || $SERVER_ENV == "INT" || $SERVER_ENV == "ACCEPTANCE")
                            {                               
                                $toEmail= array(
                                    "GANESAN Kanagavel" => "Kanagavel.Ganesan@rntbci.com",                                       
                                    "Periyasamy Venkatesh" => "venkatesh.periyasamy@rntbci.com",
                                    "Sherin Abraham" => "sherin.abraham@rntbci.com"
                                );
                                if($SERVER_ENV == "ACCEPTANCE"){
                                //   $toEmail["PARISSENTI Alexandre"] = "alexandre.parissenti-extern@renault.com";
                                 //  $toEmail["Mayor Martine"] = "martine.mayor@renault.com";
                                }
                                
                                $destinataire["email"] = implode(", ",$toEmail);
                            } 
                            $ok = mail($destinataire["email"],$subjet ,"",$mime,"-f$this->From");
                        }
                        
		}
		if($profiler)	{$profiler->stopTimer("cl_Mail->envoyer");}
		return $ok; 
	}	
}
?>
