<?php
  class arca
  {
    var $ldap_cnx;
    var $justthese=array("dn","uid","givenname","sn","preferredlanguage","mail"); 
    var $infos_completes=array("dn","uid","givenname","sn","preferredlanguage","mail","telephonenumber","facsimiletelephonenumber", "employeenumber","rencostcenter", "mobile","title","renpersontype"); 	
	var $entry;
    
    function arca()
	{
	  $this->ldap_cnx=ldap_connect("annope01.mc2.renault.fr");
	  $this->cache=array();
    }

	function getName($ipn)
	{
	  $ipn=strtolower($ipn);
	  if (!in_array($ipn,$this->cache))
	  {		
   	    $filter="(|(uid=".$ipn."))";
        $results=ldap_search($this->ldap_cnx,"ou=people,o=renault",$filter,$this->justthese);	
        $infos=ldap_get_entries($this->ldap_cnx, $results);
		if ($infos['count'])
		  $this->cache[$ipn]=$infos[0]['givenname'][0]." ".strtoupper($infos[0]['sn'][0]);	
		else
		  $this->cache[$ipn]="";  
	  }	
	  return $this->cache[$ipn];
	}

    function ipn_valide($ipn)
	{
	  $ipn=strtolower($ipn);	
   	  $filter="(|(uid=".$ipn."))";
      $results=ldap_search($this->ldap_cnx,"ou=people,o=renault",$filter,$this->justthese);	
      $infos=ldap_get_entries($this->ldap_cnx, $results);
	  return $infos['count'];
	}

    function getUserData($ipn)
	{
	  $user = new stdClass();
	  $ipn=strtolower($ipn);	
   	  $filter="(|(uid=".$ipn."))";
      $results=ldap_search($this->ldap_cnx,"ou=people,o=renault",$filter,$this->justthese);	
      $infos=ldap_get_entries($this->ldap_cnx, $results);
 
	  $user->nom=$infos[0]['givenname'][0]." ".strtoupper($infos[0]['sn'][0]);	  
	  if (isset($infos[0]['mail'][0]))
 	  {  $user->courriel=$infos[0]['mail'][0]; }
	  else
      {  $user->courriel="no_mail"; }
	  return $user;
	}

  function is_renault_employee($ipn)
	{
	  $ipn=strtolower($ipn);	
    $lettre=substr($ipn,0,1);
    switch ($lettre)
    {
      case 'a':
      case 'z':
      case 's':
        $result=true;
      break;  
      
      default:
        $result=false;
    }
    return $result;
	}
	
    function load_infos($ipn) {
        $ipn=strtolower($ipn);	
        $filter="(&(objectclass=inetorgperson)(uid=".$ipn."))";
        $results=ldap_search($this->ldap_cnx,"ou=people,o=renault",$filter,$this->infos_completes);
        $infos=ldap_get_entries($this->ldap_cnx, $results);
        $user = new stdClass();	
        $user->prenom=$infos[0]['givenname'][0];
        $user->nom1=$infos[0]['sn'][0];
        $user->nom=$infos[0]['givenname'][0]." ".strtoupper($infos[0]['sn'][0]);
        $user->phone='';
        $user->mobile='';	  
        $user->photo='';    
        $user->dept='';   
        $user->title= '';
        $user->category = '';
        $user->fax = '';
        if (isset($infos[0]['renpersontype'])) {
            $filter1="(objectclass=*)";
            $key = 'description;lang-' . $_SESSION['language'];
            $sr=ldap_read($this->ldap_cnx, $infos[0]['renpersontype'][0], $filter1, array($key));
            $entry = ldap_get_entries($this->ldap_cnx, $sr);
            $user->category=$entry[0][$key][0];
        }
        if (isset($infos[0]['facsimiletelephonenumber'])) {
            $user->fax=$infos[0]['facsimiletelephonenumber'][0];
        }
        if (isset($infos[0]['telephonenumber'])) {
            $user->phone=$infos[0]['telephonenumber'][0];
        }
        if (isset($infos[0]['mobile'])) {
            $user->mobile=$infos[0]['mobile'][0];
        }
        if (isset($infos[0]['rencostcenter'])) {
            $user->dept=$infos[0]['rencostcenter'][0];
        }
        if (isset($infos[0]['title'])) {
            $user->title=$infos[0]['title'][0];
        }
        if (isset($infos[0]['mail'])) {
            $user->courriel=$infos[0]['mail'][0];
        } else {
            $user->courriel="no_mail";
        }
        return $user;
    }	

	
   function search_name($nom,$prenom,&$nb_total,$depart=0,$nb=10)
	{
	  // if firstname is used, filter has to be adapted
	  if ($prenom!="" && $nom!="")
	  {
   	    $filter="(&(sn=*".$nom."*)(givenname=*".$prenom."*)(!(renaccountsuspended=1)))";
	  }	
          else if ($prenom!=""){
              $filter="(&(givenname=*".$prenom."*)(!(renaccountsuspended=1)))";
          }
	  else
	  {
   	    $filter="(&(sn=*".$nom."*)(!(renaccountsuspended=1)))";	  
	  }
      $results=ldap_search($this->ldap_cnx,"ou=people,o=renault",$filter,$this->justthese);	
      $nb_total=ldap_count_entries($this->ldap_cnx, $results);
      if ($nb_total<300)
      {
        $infos=ldap_get_entries($this->ldap_cnx, $results);
        $nb_resultats=min($depart+$nb,$infos['count']);
	  $cpt=0;
	  $tablo=array();
	  for ($i=$depart;$i<$nb_resultats;$i++)
	  {
	    $tablo[$cpt]['ipn']=$infos[$i]['uid'][0];
  	    $tablo[$cpt]['nom']=$infos[$i]['givenname'][0]." ".strtoupper($infos[$i]['sn'][0]);	
		$user=$this->getUserData($tablo[$cpt]['ipn']);
 	    $tablo[$cpt++]['mail']=$user->courriel;
	  }
	  return $tablo;
      }
      else
      {
        return false;    
      }
     }	


     function search_ipn($ipns,&$nb_total,$depart=0,$nb=10)
     {
       if(is_array($ipns)) {
        $ipnFilter = "|";
        foreach($ipns as $ipn) {
            $ipnFilter .= "(uid=".$ipn.")";
        }
        $filter="(&(".$ipnFilter.")(!(renaccountsuspended=1)))";	  
       } else {
         $filter="(&(uid=*".$ipns."*)(!(renaccountsuspended=1)))";  
       }
       $results=ldap_search($this->ldap_cnx,"ou=people,o=renault",$filter,$this->justthese);	
       $nb_total=ldap_count_entries($this->ldap_cnx, $results);
       if ($nb_total<=300)
       {
         $infos=ldap_get_entries($this->ldap_cnx, $results);
         $nb_resultats=min($depart+$nb,$infos['count']);
	 $cpt=0;
	 $tablo=array();
	 for ($i=$depart;$i<$nb_resultats;$i++)
	 {
	   $tablo[$cpt]['ipn']=$infos[$i]['uid'][0];
  	   $tablo[$cpt]['nom']=$infos[$i]['givenname'][0]." ".strtoupper($infos[$i]['sn'][0]);	
	   $user=$this->getUserData($tablo[$cpt]['ipn']);
 	   $tablo[$cpt++]['mail']=$user->courriel;
	 }
	 return $tablo;
       }
       else
       {
         return false;    
       }
     }
     
     function setUserInfos($info) {
         $user = new stdClass();	
        $user->ipn=$info['uid'][0];
        $user->prenom=$info['givenname'][0];
        $user->nom1=$info['sn'][0];
        $user->nom=$info['givenname'][0]." ".strtoupper($info['sn'][0]);
        $user->phone='';
        $user->mobile='';	  
        $user->photo='';    
        $user->dept='';   
        $user->title= '';
        $user->category = '';
        $user->fax = '';
        if (isset($info['renpersontype'])) {
            $filter1="(objectclass=*)";
            $key = 'description;lang-' . $_SESSION['language'];
            $sr=ldap_read($this->ldap_cnx, $info['renpersontype'][0], $filter1, array($key));
            $entry = ldap_get_entries($this->ldap_cnx, $sr);
            $user->category=$entry[0][$key][0];
        }
        if (isset($info['facsimiletelephonenumber'])) {
            $user->fax=$info['facsimiletelephonenumber'][0];
        }
        if (isset($info['telephonenumber'])) {
            $user->phone=$info['telephonenumber'][0];
        }
        if (isset($info['mobile'])) {
            $user->mobile=$info['mobile'][0];
        }
        if (isset($info['rencostcenter'])) {
            $user->dept=$info['rencostcenter'][0];
        }
        if (isset($info['title'])) {
            $user->title=$info['title'][0];
        }
        if (isset($info['mail'])) {
            $user->courriel=$info['mail'][0];
        } else {
            $user->courriel="no_mail";
        }
        return $user;
     }
     function search_ipn_all($ipns,&$nb_total,$depart=0,$nb=10)
     {
       if(is_array($ipns)) {
        $ipnFilter = "|";
        foreach($ipns as $ipn) {
            $ipnFilter .= "(uid=".$ipn.")";
        }
        $filter="(&(".$ipnFilter.")(!(renaccountsuspended=1)))";	  
       } else {
         $filter="(&(uid=*".$ipns."*)(!(renaccountsuspended=1)))";  
       }
       $results=ldap_search($this->ldap_cnx,"ou=people,o=renault",$filter,$this->infos_completes);	
       $nb_total=ldap_count_entries($this->ldap_cnx, $results);
       if ($nb_total<=300)
       {
           ldap_sort($this->ldap_cnx, $results, 'givenname');
         $infos=ldap_get_entries($this->ldap_cnx, $results);
         $nb_resultats=min($depart+$nb,$infos['count']);
	 $cpt=0;
	 $tablo=array();
	 for ($i=$depart;$i<$nb_resultats;$i++) {
 	   $tablo[$cpt++] = $this->setUserInfos($infos[$i]);
	 }
	 return $tablo;
       }
       else
       {
         return false;    
       }
     }
     
    function search($input, &$nb_total, $depart=0, $nb=10) {
        $input = trim($input);
        $input = str_replace(",", " ", $input);
        $input = preg_split ('!\s+!', $input);
        if(count($input) == 0 || count($input) > 3) {
            return false;
        }
        $filter="(&";
        if(count($input) == 1) {
            $filter .= "(|(uid=*".$input[0]."*)(sn=*".$input[0]."*)(givenname=*".$input[0]."*))";
        }
        if(count($input) == 2) {
            $filter .= "(|";
            $filter .= "(&(uid=*".$input[0]."*)(sn=*".$input[1]."*))";
            $filter .= "(&(uid=*".$input[1]."*)(sn=*".$input[0]."*))";
            $filter .= "(&(uid=*".$input[0]."*)(givenname=*".$input[1]."*))";
            $filter .= "(&(uid=*".$input[1]."*)(givenname=*".$input[0]."*))";
            $filter .= "(&(givenname=*".$input[0]."*)(sn=*".$input[1]."*))";
            $filter .= "(&(givenname=*".$input[1]."*)(sn=*".$input[0]."*))";
            $filter .= ")";
        }
        if(count($input) == 3) {
            $filter .= "(|";
            $filter .= "(&(uid=*".$input[0]."*)(sn=*".$input[1]."*)(givenname=*".$input[2]."*))";
            $filter .= "(&(uid=*".$input[0]."*)(sn=*".$input[2]."*)(givenname=*".$input[1]."*))";
            $filter .= "(&(uid=*".$input[1]."*)(sn=*".$input[0]."*)(givenname=*".$input[2]."*))";
            $filter .= "(&(uid=*".$input[1]."*)(sn=*".$input[2]."*)(givenname=*".$input[0]."*))";
            $filter .= "(&(uid=*".$input[2]."*)(sn=*".$input[0]."*)(givenname=*".$input[1]."*))";
            $filter .= "(&(uid=*".$input[2]."*)(sn=*".$input[1]."*)(givenname=*".$input[0]."*))";
            $filter .= ")";
        }
        $filter .= "(!(renaccountsuspended=1)))";
        //die;
        $results=ldap_search($this->ldap_cnx,"ou=people,o=renault",$filter,$this->infos_completes);	
        $nb_total=ldap_count_entries($this->ldap_cnx, $results);
        if ($nb_total<=300) {
            ldap_sort($this->ldap_cnx, $results, 'givenname');
            $infos = ldap_get_entries($this->ldap_cnx, $results);
            $nb_resultats = min($depart+$nb, $infos['count']);
            $cpt=0;
            $tablo=array();
            for ($i=$depart;$i<$nb_resultats;$i++) {
                $tablo[$cpt++] = $this->setUserInfos($infos[$i]);
            }
            return $tablo;
        } else {
            return false;    
        }
    }
     
     function search_ipn_name($ipn,$name,&$nb_total,$depart=0,$nb=10) {
        $filter="(&";
        if(trim($ipn) != '') {
            $filter .= "(uid=*".$ipn."*)";
        }
        if(trim($name) != '') {
            list($n1, $n2) = explode(" ", $name);
            if(!isset($n2)) {
                $filter .= "(|(sn=*".$n1."*)(givenname=*".$n1."*))";
            } else {
                $filter .= "(|(&(sn=*".$n1."*)(givenname=*".$n2."*))(&(sn=*".$n2."*)(givenname=*".$n1."*)))";
            }
        }
        $filter .= "(!(renaccountsuspended=1)))";
        
        $results=ldap_search($this->ldap_cnx,"ou=people,o=renault",$filter,$this->justthese);	
        $nb_total=ldap_count_entries($this->ldap_cnx, $results);
        
        if ($nb_total<300) {
            ldap_sort($this->ldap_cnx, $results, 'sn');
            $infos = ldap_get_entries($this->ldap_cnx, $results);         
            $nb_resultats=min($depart+$nb,$infos['count']);
            $cpt=0;
            $tablo=array();
            for ($i=$depart;$i<$nb_resultats;$i++) {
                $tablo[$cpt]['ipn']=$infos[$i]['uid'][0];
                $tablo[$cpt]['nom']=$infos[$i]['givenname'][0]." ".strtoupper($infos[$i]['sn'][0]);	
                if (isset($infos[$i]['mail'][0])) {
                    $user_courriel=$infos[$i]['mail'][0];
                } else {
                    $user_courriel="no_mail";
                }
                $tablo[$cpt++]['mail']=$user_courriel;
            }
            return $tablo;
        }
        return array();
     }	

    function search_ipn_key($ipns)
     {
       if(is_array($ipns)) {
        $ipnFilter = "|";
        foreach($ipns as $ipn) {
            $ipnFilter .= "(uid=".$ipn.")";
        }
        $filter="(&(".$ipnFilter.")(!(renaccountsuspended=1)))";	  
       } else {
         $filter="(&(uid=*".$ipns."*)(!(renaccountsuspended=1)))";  
       }
       $results=ldap_search($this->ldap_cnx,"ou=people,o=renault",$filter,$this->justthese);	
       $nb_total=ldap_count_entries($this->ldap_cnx, $results);
       if ($nb_total<=300)
       {
         $infos=ldap_get_entries($this->ldap_cnx, $results);
         $tablo = array();
         foreach($infos as $info)
	 {
	   $ipn=$info['uid'][0];
           if($ipn){
            $tablo[$ipn]['ipn']=$info['uid'][0];
            $tablo[$ipn]['first_name']=$info['givenname'][0];
            $tablo[$ipn]['last_name']=strtoupper($info['sn'][0]);
            $tablo[$ipn]['full_name']=$info['givenname'][0]." ".strtoupper($info['sn'][0]);	
            $tablo[$ipn]['mail']=$info['mail'][0];
            $tablo[$ipn]['lang']=$info['preferredlanguage'][0];
           }
	 }
	 return $tablo;
       }
       else
       {
         return false;    
       }
     } 
     
	function authentif($ipn,$pass)
	{
            try {
                    $ipn=strtolower($ipn);
                if ($ipn!="" && $pass!="")
                {
                   $liaison=@ldap_bind($this->ldap_cnx,"uid=AWCEM81,ou=XXX,ou=People,o=renault", 'r9344021');  
                   if(!$liaison){
                        return false;
                   }else{
                    $filter="(|(uid=".$ipn."))";	
              $results=ldap_search($this->ldap_cnx,"ou=people,o=renault",$filter,$this->justthese);
              $infos=ldap_get_entries($this->ldap_cnx, $results);
                if ($infos['count']!=0)
                {
                   $entry=ldap_first_entry($this->ldap_cnx,$results);

                    $bind = @ldap_bind($this->ldap_cnx, ldap_get_dn($this->ldap_cnx,$entry), $pass);
                    if ($bind === false){
                          return false; 
                    }
                        else {
                            
                         $_SESSION['nom'] = $infos[0]['givenname'][0]." ".strtoupper($infos[0]['sn'][0]); 
          
                        if (isset($infos[0]['mail'][0]))
                        {   $_SESSION['courriel']=$infos[0]['mail'][0]; }
                        else
                        {   $_SESSION['courriel']="no_mail"; 
                        
                        }
                            
                            
                          return true;
                        }
                }
                      else
                        return false;
                }
                }
                else
                    return false;
            } catch (Exception $e) {
                //echo 'Caught exception: ',  $e->getMessage(), "\n";
                return false;
            }
	}
	function getFirstLastName($ipn)
	{
	  $ipn=strtolower($ipn);
	  if (!in_array($ipn,$this->cache))
	  {		
   	    $filter="(|(uid=".$ipn."))";
        $results=ldap_search($this->ldap_cnx,"ou=people,o=renault",$filter,$this->justthese);	
        $infos=ldap_get_entries($this->ldap_cnx, $results);
		if ($infos['count']){
		  $this->cache[$ipn]['first_name'] = $infos[0]['givenname'][0];
                  $this->cache[$ipn]['last_name'] =  strtoupper($infos[0]['sn'][0]);	
                }
		else{
		  $this->cache[$ipn]="";  
                }
	  }	
	  return $this->cache[$ipn];
	}
	function arca_close()
	{
	  ldap_close($this->ldap_cnx);	
	}
  }

?>