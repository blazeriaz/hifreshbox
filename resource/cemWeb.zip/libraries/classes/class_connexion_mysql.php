<?php
$pathconf = str_replace("libraries/classes", "", dirname(__FILE__));
include_once $pathconf . "libraries/classes/class_mail.php";
include_once $pathconf."scripts/conf/server.conf";
require_once $pathconf.'scripts/const_clem.php';
require_once $pathconf.'scripts/common_scripts/FormatStringForDB.php';

Class connexion_db
{
    var $host;
    var $user;
    var $password;
    var $num;
    var $nom_db;
    var $charset;

    // le constructeur cree la connexion physique.
    function connexion_db($path="")
    {
        require($path."conf/connect.conf");
        $this->host=$PARAM_host;
        $this->user=$PARAM_user;
        $this->password=$PARAM_password;
        $this->nom_db=$PARAM_db;
        if (isset($PARAM_charset)) {
            $this->charset=$PARAM_charset;
        } else {
            $this->charset='utf8';
        }
        $this->num=mysqli_connect($this->host,$this->user,$this->password);
        if (!$this->num) { 
            echo "<br>Erreur d ouverture de la base de donnees<br>"; 
            echo mysqli_error($this->num)."<BR>\n";            
        }
        else
        {   
            $this->select_db();
            mysqli_set_charset($this->num, $this->charset);
            mysqli_query($this->num, "SET NAMES '".$this->charset."'");
        }	  
    }

    function select_db($chgt=false,$nlle_base="")
    {
        if ($chgt) $this->nom_db=$nlle_base;
        $cr_select_db=mysqli_select_db($this->num, $this->nom_db);
        if (!$cr_select_db) {
            echo "base non selectionnee <br>";
            echo mysqli_error($this->num)."<BR>\n";            
        }
    }
    
    function close()
    {
        mysqli_close($this->num);       
    }
};//fin def classe connexion_db

class requete{
  var $objet;
  var $resultat;
  var $nb_elt;
  var $array;
  var $connex;
  var $array_obj;
  var $id_new;
  var $updated_rows;
  var $query_execution_time = 3;
  var $auto_commit = true;
 
  function requete($chaine,$cnx)
  {
    $this->connex=$cnx;
   
   $start_microtime = explode(" ",microtime());  
   $start_time = (float)$start_microtime[1] + (float)$start_microtime[0];  
   $this->resultat=mysqli_query($this->connex, $chaine);
	  
	  if (!$this->resultat)
    {  
        echo "Requete $chaine non effectuee <BR>\n";
        $queryError = $chaine."<br/>".mysqli_error($this->connex);
        throw new Exception($queryError);
        echo mysqli_error($this->connex)."<BR>";
    }
	  else
	  {
              
           $this->id_new=mysqli_insert_id($this->connex);
           $this->updated_rows = mysqli_affected_rows($this->connex);
           if($this->auto_commit){
	    mysqli_query($this->connex, 'COMMIT');
           }
            $end_microtime = explode(" ", microtime());  
            $end_time = (float)$end_microtime[1] + (float)$end_microtime[0];  
            $timediff = $end_time - $start_time;
           // $this->get_query_execution_time();
            if($timediff > $this->query_execution_time){
                $this->Send_mail_for_query_execution($chaine, $timediff);
            }
        }  
  }
 
  function envoi($chaine)
  {
    $start_microtime = explode(" ",microtime());  
    $start_time = (float)$start_microtime[1] + (float)$start_microtime[0];  
    $this->resultat=mysqli_query($this->connex, $chaine);
    
    if (!$this->resultat)
    {  
        echo "Requete $chaine non effectuee <BR>\n";
        $queryError = $chaine."<br/>".mysqli_error($this->connex);
        throw new Exception($queryError);
        echo mysqli_error($this->connex)."<BR>";
    }
 	  else
	  {
            $this->id_new=mysqli_insert_id($this->connex);
            $this->updated_rows = mysqli_affected_rows($this->connex);
            if($this->auto_commit){
                mysqli_query($this->connex, 'COMMIT');
             }
            $end_microtime = explode(" ", microtime());  
            $end_time = (float)$end_microtime[1] + (float)$end_microtime[0];  
            $timediff = $end_time - $start_time;
           // $this->get_query_execution_time();
            if($timediff > $this->query_execution_time){
                $this->Send_mail_for_query_execution($chaine, $timediff);
            }
	  }  
  }
  
  function recup_objet()
  { 
         
        $this->objet=mysqli_fetch_object($this->resultat);
        if (!$this->objet)
        {  
         //echo "Recuperation ligne resultat objet non effectuee <BR>\n";
         //echo mysqli_error($this->connex);
        }
        return $this->objet;
	
  }
  
  function insert_id()
  {
    return $this->id_new;	
  }
  
  function updated_rows()
  {
    return $this->updated_rows;	
  }
  
  function recup_row()
  {
    $one_row=mysqli_fetch_row($this->resultat);
    if (!$one_row)
    {  
      //echo "Recuperation ligne resultat tablo non effectuee <BR>\n";
	  //echo mysqli_error($this->connex)."<BR>";
    }
	else
	{ return $one_row; }
	
  } 
  
    function recup_row_champ()
  {
    $one_row=mysqli_fetch_assoc($this->resultat);
    if (!$one_row)
    {  
     // echo "Recuperation ligne resultat tablo non effectuee <BR>\n";
	  //echo mysqli_error($this->connex)."<BR>";
    }
	else
	{ return $one_row; }
	
  }      
   
  
  function calc_nb_elt()
  {
    $this->nb_elt=mysqli_num_rows($this->resultat);  
	return  $this->nb_elt;
  }
  
  function positionne($pos)
  {
    $this->calc_nb_elt();
    if ($pos<=$this->nb_elt)
	{ 
	  $cr_dat_seek=mysqli_data_seek($this->resultat,$pos);
	  if (!$cr_dat_seek)
      {    
        //echo "Positionnement non effectuee <BR>\n";
	    //echo mysqli_error($this->connex)."<BR>";
      }
	}
	else
	{
	  echo "Position hors d'atteinte.";
	} 
  }		 
  
  function recup_array()
  {  
    $this->array=array();
	$this->calc_nb_elt();
    for($i=0;$i<$this->nb_elt;$i++)
    { $this->array[$i]=$this->recup_row(); }
	return $this->array;
  }
  
  function recup_array_mono()
  {  
    $this->array=array();
	$this->calc_nb_elt();
    for($i=0;$i<$this->nb_elt;$i++)
    { 
	  $row=$this->recup_row();
	  $this->array[$i]=$row[0];
    }
	return $this->array;
  }  
  // for getting count 
    function recup_array_count()
  {  
    $this->array='';
	$this->calc_nb_elt();
    for($i=0;$i<$this->nb_elt;$i++)
    { 
	  $row=$this->recup_row();
	  $this->array=$row[0];
    }
	return $this->array;
  }  
    function recup_array_key($group= false)
  {  
    $this->array=array();
	$this->calc_nb_elt();
    for($i=0;$i<$this->nb_elt;$i++)
    { 
	  $row=$this->recup_row();
          $rowcount = count($row);
          if($rowcount < 3){
            if($group) {
                $key = $row[0];
                if(!isset($this->array[$key])) {
                    $this->array[$key] = array();
                }
                $this->array[$key][]=$row[1];
            } else {
                $this->array[$row[0]]=$row[1];
            }
          }else{
              if($group) {
                  if(!isset($this->array[$row[0]])) {
                      $this->array[$row[0]] = array();
                  }
                  $key = $row[0];
                  unset($row[0]);
                  $this->array[$key][]=$row;
              } else {
            for($j=1; $j<$rowcount; $j++){
             $this->array[$row[0]][$j]=$row[$j]; 
            }
              }
          }
    }
	return $this->array;
  } 
  
    function recup_object_keys($objKeys, $group = false) {
        $this->array=array();
        $this->calc_nb_elt();
        $objKeys = is_array($objKeys)?$objKeys:array($objKeys);
        for($i=0;$i<$this->nb_elt;$i++) { 
            $row = $this->recup_objet();
            $arrRow = (array)$row;            
            $this->recKeyArray($this->array, $objKeys, $row, $group);
        }
        return $this->array;
    }
    
    function recup_single_object_keys($objKeys, $valuekey, $group = false) {
        $this->array=array();
        $this->calc_nb_elt();
        for($i=0;$i<$this->nb_elt;$i++) { 
            $row = $this->recup_objet();
            $arrRow = (array)$row;            
            $this->recKeyArray($this->array, $objKeys, $row, $group, $valuekey);
        }
        return $this->array;
    }
    
    function recKeyArray(&$array, $keys = array(), $row, $group = false, $valuekey = '') {
        $arrRow = (array)$row;
        if(empty($keys)) {
            $arrayVal = $row;
            if($valuekey != "" && isset($arrRow[$valuekey])) {
                $arrayVal = $arrRow[$valuekey];
            }
            if($group) {
                $array[] = $arrayVal;
            } else {
                $array = $arrayVal;
            }
        } else {            
            $key = $arrRow[$keys[0]];
            if(!isset($array[$key])) {
                $array[$key] = array();
            }
            array_shift($keys);
            $this->recKeyArray($array[$key], $keys, $row, $group, $valuekey);
        }
    }
      
  function recup_array_champ()
  {  
    $this->array=array();
	$this->calc_nb_elt();
    for($i=0;$i<$this->nb_elt;$i++)
    { $this->array[$i]=$this->recup_row_champ(); }
	return $this->array;
	
  }  
  
  function recup_array_objet()
  {  
    $this->array=array();
	$this->calc_nb_elt();
    for($i=0;$i<$this->nb_elt;$i++)
    { $this->array[$i]=mysqli_fetch_object($this->resultat); }
	return $this->array;
  }
  function get_query_execution_time(){
            $query = "SELECT parameter_value FROM tb_global_settings where parameter_tag = 'CMQET'";
            $default_query_execution =mysqli_query($this->connex, $query);
            $default_query_execution_time = mysqli_fetch_assoc($default_query_execution);
            if(!empty($default_query_execution_time['parameter_value'])){
                $this->query_execution_time = $default_query_execution_time['parameter_value'];
            }
  }
  function Send_mail_for_query_execution($query,$total_time){
      global $SERVER_ENV,$SERVER_HOME;
            $total_login_count =mysqli_query($this->connex, "select count(is_login) as total_login_count from tb_users_data where is_login = 1");
            $active_login_count = mysqli_fetch_assoc($total_login_count);
            $User_Email = array(
                "kanagavel.ganesan@rntbci.com" => "GANESAN Kanagavel",
                "venkatesh.periyasamy@rntbci.com" => "Venkatesh Periyasamy"
            );
            if($SERVER_ENV =='PRODUCTION' || $SERVER_ENV =='ACCEPTANCE'){
                $User_Email["alexandre.parissenti-extern@renault.com"] = "PARISSENTI Alexandre";
                $User_Email["martine.mayor@renault.com"] ="Mayor Martine";
            }
            
            $queryLogData = array();
            $queryLogData['execution_time'] = $total_time;
            $queryLogData['query'] = FormatStringForDB($query);
            $queryLogData['user'] = $_SESSION['ipn'];
            $queryLogData['path'] = $_SERVER['SCRIPT_NAME'];
            $this->query_log($queryLogData);
            
            $userName = !empty($_SESSION['nom']) ? $_SESSION['nom']." (".$_SESSION['ipn'].") " : '';
            $queryLog = date("Y-m-d H:i:s").' - '.'Query: '.$query."\r\n";
            $queryLog .= date("Y-m-d H:i:s").' - '.'Execution Time: '.$total_time."\r\n";
            $queryLog .= date("Y-m-d H:i:s").' - '.'Impacted User: '.$userName."\r\n";
            $queryLog .= date("Y-m-d H:i:s").' - '.'Active Login Count: '.$active_login_count['total_login_count']."\r\n";
            $queryLog .= date("Y-m-d H:i:s").' - '.'File Path: '.$_SERVER['SCRIPT_NAME']."\r\n";
            $queryLog .= date("Y-m-d H:i:s").' - '.'Environment: '.$SERVER_ENV."\r\n";
            if($_SERVER['HTTP_HOST']) {
                $queryLog .= date("Y-m-d H:i:s").' - '.'Url: http://'.$_SERVER['HTTP_HOST'].'/'.$_SERVER['REQUEST_URI']."\r\n";
            } else {
                $queryLog .= date("Y-m-d H:i:s").' - '.'Batch Run'. "\r\n";
            }
            $queryLog .= date("Y-m-d H:i:s ").'******************************************************************'."\r\n";
            $pathLog = $SERVER_HOME . "/logs";
            $fileLog = "query_run_time_php_" . date("dmY") . ".txt";
	    $filePath = $pathLog."/".$fileLog;
            if (!file_exists($pathLog)) {
                mkdir($pathLog);
            }
            $fp = fopen($filePath, 'a');
            fwrite($fp, $queryLog);
            fclose($fp);
            if($total_time > $this->query_execution_time){
            $Mail = new cl_mail();
            $Mail->From = "clem@renault.com";
            $Mail->objet = "Query Execution Time - $SERVER_ENV - CLEM";
            
            $Body = "<html><head>\n";
            $Body.= "<style type=\"text/css\">\n
                        body {
                            background: #fff;
                            color: #000;
                            font-family: cambria,arial,verdana,helvetica,sans-serif;
                            font-style: normal;
                            font-size: 14px;
                            line-height: 20px;
                            margin: 0;
                        }
                        table {
                            border: 1px solid;
                            border-spacing: 2px;
                            border-collapse: collapse;
                            clear: both;
                            width: auto;
                        }
                        table tr th,
                        table tr td {
                            background-color: wheat;
                            border: 1px solid;
                            padding: 4px;
                            vertical-align: middle;
                        }
                        table tr th {
                            text-align: center;
                        }
                        table tr td{
                            text-align: left;
                        }
                        ul.discList li{
                            list-style-type: disc;
                        }
                        ul.circleList li{
                            list-style-type: circle;
                        }
                    </style>\n";
            $Body.= "</head><body>\n";
            $Body.= "Dear " . implode(", ", $User_Email) . ",<br/><br/>\n";
            $Body.= "The following query executed :<br/>\n";
          
            $Body.= "<table>
                            <tr>
                            <th>Query</th>
                            <td>$query</td>
                            </tr>
                            <tr>
                            <th>Execution Time</th>
                            <td>$total_time</td>
                            </tr>
                            <tr>
                            <th>Impacted User</th>
                            <td>$userName</td>
                            </tr>
                            <tr>
                            <th>Active Login Count</th>
                            <td>".$active_login_count['total_login_count']."</td>
                            </tr>
                            <tr>
                            <th>Date & Time</th>
                            <td>".date("Y-m-d H:i:s")."</td>
                            </tr>
                            <tr>
                            <th>File Path</th>
                            <td>".$_SERVER['SCRIPT_NAME']."</td>
                            </tr>
                            <tr>
                            <th>Environment</th>
                            <td>$SERVER_ENV</td>
                            </tr>
                            <tr>
                            <th>Url</th>";
            if($_SERVER['HTTP_HOST']) {
                            $Body.= "<td>http://".$_SERVER['HTTP_HOST']."/".$_SERVER['REQUEST_URI']."</td>";
            } else {
                $Body.= "<td>Batch Run</td>";
            }
                            $Body.= "</tr>
                        </table>\n";
            $Body.= "</body></html>";
            
            $Mail->set_body($Body,"text/html");
            foreach($User_Email as $toEmail=>$userNom){
               $Mail->ajoute_destinataire($toEmail,$userNom,"To");
            }
            $Mail->envoyer("EACH");
            }
  }
   function query_log($data){
       $query ="INSERT INTO  query_log ";
       if(!empty($data)){
           $query .= "(".implode(",", array_keys($data)).")";
           $query .=" values ";
           $query .= "('".implode("','", $data)."')";
       }
       mysqli_query($this->connex, $query);
  }
}
function pr($data){
    echo '<pre>';
    print_r($data);
    echo"</pre>";
}