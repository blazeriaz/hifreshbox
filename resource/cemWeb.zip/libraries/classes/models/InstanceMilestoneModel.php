<?php
class InstanceMilestoneModel extends coreModel {    
    protected $instance_id;
    protected $milestone_id;
    
    public function __construct($instance_id, $milestone_id) {
        parent::__construct();
        $this->instance_id = $instance_id;
        $this->milestone_id = $milestone_id;
    }
    
    public function getInstanceDetail() {
        $query = "SELECT * FROM tb_instances WHERE instance_id = " . $this->instance_id;
        return $this->getDetailsFromQuery('instance', $query, true);
    }
    
    public function getMilestoneDetail() {
        $query = "SELECT rm.milestone_name_".$_SESSION['language']." AS milestone_name, "
                . "rm.milestone_definition_".$_SESSION['language']." as milestoneDefn, "
                . "rm.milestone_order, im.milestone_status,im.milestone_date,rm.milestone_rpif_reference  "
                . "FROM tb_repositories_milestones as rm "
                . "LEFT JOIN tb_instances_milestones as im ON im.repository_milestone_id_fk = rm.repository_milestone_id "
                . "WHERE repository_milestone_id=". $this->milestone_id ." "
                . "AND im.instance_id_fk = " . $this->instance_id;
        return $this->getDetailsFromQuery('milestone', $query, true);
    }
    
    public function getProjects() {
        $query = "SELECT p.project_code, p.project_name FROM tb_projects as p "
                . "JOIN tb_instance_projects as pi ON pi.project_id_fk = p.project_id AND pi.instance_id_fk = ".$this->instance_id." ";        
        if(!isset($this->values['projects']) || $name == '') {
            $this->request->envoi($query);
            $project_infos = $this->request->recup_array_key();
            $this->values['projects'] = (object)array(
                'project_names' => array_values($project_infos),
                'project_codes' => array_keys($project_infos)
            );
        }
        return $this->values['projects'];
    }
    
    public function getFamilies() {
        $query = "SELECT f.family_name_".$_SESSION['language'].", sf.subfamily_name_".$_SESSION['language']." "
                . "FROM tb_instance_subfamilies as sfi "
                . "JOIN tb_subfamilies as sf ON sf.subfamily_id = sfi.subfamily_id_fk "
                . "JOIN tb_families as f ON sf.family_id_fk = f.family_id "
                . "WHERE sfi.instance_id_fk = ".$this->instance_id." ";
        if(!isset($this->values['families']) || $name == '') {
            $this->request->envoi($query);
            $family_infos = $this->request->recup_array_key(true);
            $subfamily_infos = array();
            foreach($family_infos as $subfamiles) {
                $subfamily_infos = array_merge($subfamily_infos, $subfamiles);
            }
            $family_infos = array_keys($family_infos);
            $this->values['families'] = (object)array(
                'family_names' => $family_infos,
                'subfamily_names' => $subfamily_infos
            );
        }
        return $this->values['families'];
    }
    
    public function getProjectContextName() {
        $query = "SELECT context_item_id, context_item_type, context_item_name_".$_SESSION['language']." as context_item_name, context_item_value "
                . "FROM tb_instances_contexts instance_context "
                . "JOIN tb_contexts_items context_item ON context_item.context_item_id = instance_context.context_item_id_fk "
                . "WHERE instance_id_fk = ". $this->instance_id . "";
        $this->request->envoi($query);
        $inst_contexts = $this->request->recup_array_objet();
        
        $this->request->envoi("SELECT civ.context_item_id_fk, civ.context_item_value_" . $_SESSION['language'] . " as contextValue "
                . "FROM tb_instances_contexts_values as icv "
                . "JOIN tb_contexts_items_values as civ on icv.context_item_value_id_fk = civ.context_item_value_id "
                . "WHERE icv.instance_id_fk = " . $this->instance_id);
        $insContextValues = $this->request->recup_array_key(true);
        
        $projectContextString = array();
        foreach($inst_contexts as $inst_context) {
            if($inst_context->context_item_type != 'TEXT' && !empty($insContextValues[$inst_context->context_item_id])) {
                $inst_context->context_item_value = join(", ", $insContextValues[$inst_context->context_item_id]);
            }
            $tmp = $inst_context->context_item_name;
            $tmp .= ($inst_context->context_item_value != "")?" : " . $inst_context->context_item_value:"";
            $projectContextString[] = $tmp;
        }
            
        return $projectContextString;
    }
    
    public function getAssemntItems() {
        $query = "SELECT item_id, item_name_".$_SESSION['language']." as name "
                . "FROM tb_assessments_items,tb_repositories_versions,tb_instances "
                . "WHERE item_repository_id_fk=repository_id_fk "
                . "AND item_status = 'ACT' and repository_revision_id=repository_revision_id_fk "
                . "AND instance_id = ".$this->instance_id;
        $this->request->envoi($query);
        return $this->request->recup_array_key();
    }
    
    public function getActivityRoles() {
        $query = "SELECT ras.repository_activity_id_fk, "
                . "tb_roles.name_".$_SESSION['language']." AS role_name, "
                . "tb_departments.department_name_".$_SESSION['language']." AS department_name, "
                . "ima.assignment_user AS assignment_users "
                . "FROM tb_repositories_activities_stakeholder_roles AS ras "
                . "JOIN tb_instances_activities AS ia ON ia.repository_activity_id_fk = ras.repository_activity_id_fk AND ia.instance_id_fk = ".$this->instance_id." "
                . "JOIN tb_roles ON tb_roles.role_id = ras.role_id_fk "
                . "JOIN tb_departments ON tb_departments.department_id = tb_roles.role_department_id_fk "
                . "LEFT JOIN tb_instances_milestones_assignments AS ima ON ima.role_id_fk = ras.role_id_fk AND ia.instance_id_fk = ima.instance_id_fk AND ima.repository_milestone_id_fk = ".$this->milestone_id." "
                . "ORDER BY tb_roles.name_".$_SESSION['language']." ASC";
        $this->request->envoi($query);
        return $this->request->recup_array_key(true);
    }
    
    public function getActivityActionPlans() {
        $query = "SELECT activity_id_fk, action_plan, pilot, due_date, deviation_text, green, red, orange, white, activity_evaluation_id "
                . "FROM tb_instances_activities_action_plans AS action_plan "
                . "LEFT JOIN tb_instances_activities_evaluation_grid AS grid ON action_plan.activity_evaluation_id_fk = grid.activity_evaluation_id "
                . "WHERE action_plan.instance_id_fk = ".$this->instance_id." ";
        $this->request->envoi($query);
        return $this->request->recup_array_key(true);
    }
    
    public function getTopicModel() {
        if(!isset($this->values['topicModel'])) {
            $model = new InstanceMilestoneTopicsModel();
            $model->setInstanceMilestone($this);
            $this->values['topicModel'] = $model;
        }
        return $this->values['topicModel'];
    }
    
    public function getMilestoneOrders() {
        $query = "SELECT rm.repository_milestone_id, im.milestone_status, rm.milestone_order, im.milestone_date "
                . "FROM tb_instances_milestones AS im "
                . "LEFT JOIN tb_repositories_milestones AS rm ON im.repository_milestone_id_fk = rm.repository_milestone_id "
                . "WHERE instance_id_fk = ". $this->instance_id . " "
                . "ORDER BY rm.milestone_order ASC";
        $this->request->envoi($query);
        return $this->request->recup_array_key();
    }
    
    public function getPreviousClosedMilestoneOrder() {
        $milestoneOrders = $this->getMilestoneOrders();
        $previousMilestoneId = $this->getPrevKey($this->milestone_id, $milestoneOrders);
        if($previousMilestoneId && $milestoneOrders[$this->milestone_id][1] != 'NEW' && $milestoneOrders[$previousMilestoneId][1] == 'CLO') {
            return $milestoneOrders[$previousMilestoneId][2];
        }
        return false;
    }
    
    public function getMilestoneScreenshot() {    
        $query = "SELECT screenshot_comment,screenshot_decision "
                . "FROM tb_instances_screenshot "
                . "WHERE repository_milestone_id_fk = ". $this->milestone_id ." "
                . "AND instance_id_fk = ". $this->instance_id ." AND screenshot_status='CLO' "
                . "AND is_milestone_review = 1 ORDER BY date_closed DESC LIMIT 0,1";
        return $this->getDetailsFromQuery('screenshot', $query, true);
    }
}
