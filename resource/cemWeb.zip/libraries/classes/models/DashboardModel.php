<?php
class DashboardModel extends coreModel {    
    protected $dashboard_id = array();

    
    public function __construct($dashboard_id) {
        parent::__construct();
        $this->dashboard_id = $dashboard_id;
        $this->lang = !empty($_SESSION['language']) ? $_SESSION['language'] : 'fr';
    }
    
    public function getActivityRolesAssignments($milestone_id) {
        $query = "SELECT r.role_id, r.name_fr AS role_name_fr, r.name_en AS role_name_en, r.role_external_link, "
                . "d.department_id, d.department_name_fr, d.department_name_en, ras.is_leader, ima.assignment_user, "
                . "ra.repository_activity_id, rr.repository_result_id, rr.repository_milestone_id_fk AS repository_milestone_id "
                . "FROM tb_repositories_activities_stakeholder_roles AS ras "
                . "JOIN tb_instances_activities AS ia ON ia.repository_activity_id_fk = ras.repository_activity_id_fk "
                . "JOIN tb_instances AS i ON ia.instance_id_fk = i.instance_id AND i.repository_revision_id_fk = ras.repository_revision_id_fk "
                . "JOIN tb_repositories_activities AS ra ON ra.repository_activity_id = ia.repository_activity_id_fk "
                . "JOIN tb_repositories_results AS rr ON rr.repository_result_id = ra.repository_result_id_fk "
                . "JOIN tb_roles AS r ON ras.role_id_fk = r.role_id "
                . "JOIN tb_departments AS d ON r.role_department_id_fk = d.department_id "
                . "LEFT JOIN tb_instances_milestones_assignments AS ima ON ima.role_id_fk = r.role_id "
                . "AND rr.repository_milestone_id_fk = ima.repository_milestone_id_fk "
                . "AND i.instance_id = ima.instance_id_fk "
                . "WHERE i.instance_id = " . $this->dashboard_id ." AND rr.repository_milestone_id_fk = " . $milestone_id ."";
        return $this->getDetailsFromQuery('getActivityRolesAssignments'.$milestone_id, $query);
    }

    public function getScreenshotInfos() {
        $query = "SELECT screen.screenshot_id, screen.creator, screen.date_creation, screen.date_closed, screen.closed_by, screen.screenshot_comment, "
                . "screen.screenshot_decision, miles.milestone_name_en, miles.milestone_name_fr FROM tb_instances_screenshot AS screen "
                . "LEFT JOIN tb_repositories_milestones AS miles ON miles.repository_milestone_id = screen.repository_milestone_id_fk "
                . "WHERE screen.screenshot_status='CLO' AND screen.instance_id_fk=" . $this->dashboard_id ." "
                . "ORDER BY screen.date_closed";
        return $this->getDetailsFromQuery('getScreenshotInfos', $query);
    }
    
    public function getDashboardInfo() {
        $query = "select i.instance_id as dashboard_id, i.date_creation, i.instance_creator, i.repository_revision_id_fk as version_id,i.instance_activity_evaluation,
        i.instance_backlog_display,r.repository_id, r.repository_name_".$this->lang." as repository,u.name as universe_name,
        r.repository_allow_milestone_deletion, COUNT(ic.instance_id_fk) as instance_had_contexts, i.gesper_content, i.gesper_comment, 
        tpl.template_name_fr, tpl.template_name_en, tpl.is_enable_gesper
        from tb_instances i 
        inner join tb_repositories_versions rv on rv.repository_revision_id = i.repository_revision_id_fk
        inner join tb_repositories r on r.repository_id = rv.repository_id_fk
        inner join tb_universe u on u.id = r.universe_id_fk 
        left join tb_instances_contexts as ic ON ic.instance_id_fk = i.instance_id 
        JOIN tb_templates as tpl ON tpl.template_id = i.template_id_fk
        where i.instance_id = $this->dashboard_id GROUP BY i.instance_id";
        $dashboard = $this->getDetailsFromQuery('dashboard', $query,true);
        $dashboard->gesper_content = unserialize($dashboard->gesper_content);
        $typology_id = $dashboard->gesper_content['propo_typo_id'];
        if($typology_id) {
            $query = "SELECT typology_name_en, typology_name_fr FROM tb_typologies WHERE typology_id = ".$typology_id;
            $typoData = $this->getDetailsFromQuery('dashboardTypo', $query, true);
            $dashboard->typology_name_en = $typoData->typology_name_en;
            $dashboard->typology_name_fr = $typoData->typology_name_fr;
        }
        $dashboard->owners = $this->getDashboardOwners();
        return $dashboard;
    }
    
    public function getDashboardOwners() {
        $query = "SELECT stakeholder_ipn, type FROM tb_instances_stakeholders WHERE instance_id_fk = " . $this->dashboard_id;
        return $this->getDetailsFromQuery('getDashboardOwners', $query);
    }
    
    public function getDashboardProjects() {
        $query = "select p.project_code, p.project_name from tb_instance_projects ip "
                . "join tb_projects p on p.project_id = ip.project_id_fk "
                . "where ip.instance_id_fk = " . $this->dashboard_id;
        return $this->getDetailsFromQueryKeyValue('dashboardPjts', $query);
    }
    
    public function getDashboardFamilies() {
        $query = "select f.family_id, f.family_name_en, f.family_name_fr, sub.subfamily_id,sub.subfamily_name_en,sub.subfamily_name_fr 
        from tb_instance_subfamilies isub join tb_subfamilies sub on sub.subfamily_id = isub.subfamily_id_fk
        join tb_families f on f.family_id = sub.family_id_fk
        where isub.instance_id_fk =".$this->dashboard_id;
        return $this->getDetailsFromQuery('dashboardFamilies', $query);
    }
    
    public function getDashboardMiles() {
        $query = "select  im.instance_id_fk, im.milestone_status, im.milestone_date, rm.milestone_name_".$this->lang." as milestone ,
            rm.milestone_title_".$this->lang." as milestone_title,rm.milestone_definition_".$this->lang." as milestone_definition,
            rm.milestone_expectation_".$this->lang." as milestone_expectation,rm.milestone_aer_reference, rm.milestone_rpif_reference, 
           rm.repository_milestone_id, rm.milestone_order
           from tb_instances_milestones im 
        join tb_repositories_milestones rm on rm.repository_milestone_id = im.repository_milestone_id_fk
        where im.is_deleted = 0 and im.instance_id_fk = ".$this->dashboard_id." order by rm.milestone_order";
        return $this->getDetailsFromQueryArray('dashboardMilestones', $query);
    }
    
    public function getDashboardfulldatas() {
        $query = "select  im.instance_id_fk, im.milestone_status, rm.milestone_name_".$this->lang." as milestone ,
            rm.milestone_title_".$this->lang." as milestone_title,rm.milestone_definition_".$this->lang." as milestone_definition,
            rm.milestone_expectation_".$this->lang." as milestone_expectation,rm.milestone_aer_reference, rm.milestone_rpif_reference, 
           rm.repository_milestone_id,rr.result_name_".$this->lang." as result, rr.repository_result_id,ra.repository_activity_id,
           ra.name_".$this->lang." as activity,ia.GREEN, ia.RED, ia.ORANGE,ia.WHITE,ia.GREY,rm.milestone_order,rr.result_order,ra.activity_order from tb_instances_milestones im 
        join tb_repositories_milestones rm on rm.repository_milestone_id = im.repository_milestone_id_fk
        join tb_repositories_results rr on rr.repository_milestone_id_fk = rm.repository_milestone_id 
        and rm.repository_revision_id_fk = rr.repository_revision_id_fk
        join tb_repositories_activities ra on ra.repository_result_id_fk = rr.repository_result_id
        and ra.repository_revision_id_fk = rr.repository_revision_id_fk
        join tb_instances_activities ia on ia.repository_activity_id_fk = ra.repository_activity_id
        and ia.instance_id_fk = im.instance_id_fk
        where im.is_deleted = 0 and  im.instance_id_fk = ".$this->dashboard_id." order by rm.milestone_order, rr.result_order, ra.activity_order";
        return $this->getDetailsFromQueryArray('dashboardData', $query);
    }
    
    public function getRepositoryresultdatas() {
        $query = "select  ir.instance_id_fk,rr.repository_milestone_id_fk,rr.result_name_".$this->lang." as result, 
            rr.repository_result_id,ra.repository_activity_id,
           ra.name_".$this->lang." as activity,rr.result_order,ra.activity_order,ia.GREEN, ia.RED, ia.ORANGE,ia.WHITE,ia.GREY
            from tb_instances_milestones im  
            join tb_instances_results ir on ir.repository_milestone_id_fk = im.repository_milestone_id_fk
	and ir.instance_id_fk = im.instance_id_fk
        join tb_repositories_results rr on rr.repository_milestone_id_fk = ir.repository_milestone_id_fk 
        and rr.repository_result_id = ir.repository_result_id_fk
        join tb_repositories_activities ra on ra.repository_result_id_fk = rr.repository_result_id
        and ra.repository_revision_id_fk = rr.repository_revision_id_fk
                 join tb_instances_activities ia on ia.repository_activity_id_fk = ra.repository_activity_id
        and ia.instance_id_fk = im.instance_id_fk
        where im.is_deleted = 0 and ir.instance_id_fk = ".$this->dashboard_id." order by  rr.result_order, ra.activity_order";
        return $this->getDetailsFromQueryArray('dashboardMilestonesResultDatas', $query);
    }
    
    public function getDashboardMileResultTopics() {
        $query = "SELECT im.instance_id_fk AS instance_id, im.milestone_status, im.is_evaluate, im.date_closed, im.milestone_date, im.closed_by, "
                . "rm.repository_milestone_id, rm.milestone_name_fr, rm.milestone_name_en, rm.milestone_order, "
                . "rm.milestone_title_fr, rm.milestone_title_en, rm.milestone_definition_fr, rm.milestone_definition_en, "
                . "rm.milestone_aer_reference, rm.milestone_rpif_reference, "
                . "rr.repository_result_id, rr.result_name_fr, rr.result_name_en, rr.result_order, "
                . "ra.repository_activity_id, ra.name_fr AS activity_name_fr, ra.name_en AS activity_name_en, ra.activity_order, "
                . "ra.activity_deliverable_id_fk AS activity_deliverable_id, ra.activity_subject_id_fk AS activity_subject_id, "
                . "ia.activity_comment, ia.date_update, ia.user_update, ia.activity_assessment_id_fk AS activity_assessment_id, "
                . "ia.GREEN, ia.RED, ia.ORANGE, ia.WHITE, ia.GREY "
                . "FROM tb_instances_milestones AS im "
                . "JOIN tb_repositories_milestones AS rm ON rm.repository_milestone_id = im.repository_milestone_id_fk "
                . "JOIN tb_instances_results AS ir ON ir.repository_milestone_id_fk = rm.repository_milestone_id AND im.instance_id_fk = ir.instance_id_fk "
                . "JOIN tb_repositories_results AS rr ON rr.repository_result_id = ir.repository_result_id_fk AND rr.repository_milestone_id_fk = rm.repository_milestone_id "
                . "JOIN tb_repositories_activities AS ra ON ra.repository_result_id_fk = rr.repository_result_id "
                . "JOIN tb_instances_activities AS ia ON ia.repository_activity_id_fk = ra.repository_activity_id AND im.instance_id_fk = ia.instance_id_fk "
                . "WHERE im.is_deleted = 0 AND im.instance_id_fk = ".$this->dashboard_id." ORDER BY rm.milestone_order, rr.result_order, ra.activity_order";
        return $this->getDetailsFromQueryArray('dashboardMileResultTopics', $query);
    }
    
    public function getAllMilestones() {
        $query = "SELECT im.instance_id_fk AS instance_id, im.milestone_status, im.is_evaluate, im.date_closed, im.milestone_date, im.closed_by, "
                . "rm.repository_milestone_id, rm.milestone_name_fr, rm.milestone_name_en, rm.milestone_order "
                . "FROM tb_instances_milestones AS im "
                . "JOIN tb_repositories_milestones AS rm ON rm.repository_milestone_id = im.repository_milestone_id_fk "
                . "WHERE im.is_deleted = 0 AND im.instance_id_fk = " . $this->dashboard_id;
        return $this->getDetailsFromQueryArray('dashboardMileStonesAll', $query);
    }
    
    public function getAllTopics() {
        $query = "SELECT rr.repository_milestone_id_fk AS repository_milestone_id, rr.repository_result_id, "
                . "rr.result_name_fr, rr.result_name_en, rr.result_order "
                . "FROM tb_instances_results AS ir "
                . "JOIN tb_repositories_results AS rr ON rr.repository_result_id = ir.repository_result_id_fk "
                . "WHERE ir.instance_id_fk = " . $this->dashboard_id;
        return $this->getDetailsFromQueryArray('dashboardTopicsAll', $query);
    }
    
    public function getAllActivities() {
        $query = "SELECT rr.repository_result_id, rr.repository_milestone_id_fk AS repository_milestone_id, "
                . "ra.repository_activity_id, ra.name_fr AS activity_name_fr, ra.name_en AS activity_name_en, ra.activity_order, "
                . "ra.activity_deliverable_id_fk AS activity_deliverable_id, ra.activity_subject_id_fk AS activity_subject_id, "
                . "ia.activity_comment, ia.date_update, ia.user_update, ia.activity_assessment_id_fk AS activity_assessment_id, "
                . "ia.GREEN, ia.RED, ia.ORANGE, ia.WHITE, ia.GREY "
                . "FROM tb_instances_activities AS ia "
                . "JOIN tb_repositories_activities AS ra ON ia.repository_activity_id_fk = ra.repository_activity_id "
                . "JOIN tb_repositories_results AS rr ON ra.repository_result_id_fk = rr.repository_result_id "
                . "WHERE ia.instance_id_fk = " . $this->dashboard_id;
        return $this->getDetailsFromQueryArray('dashboardActivitiesAll', $query);
    }
    
    public  function getAllProjectContexts() {
        $query = "SELECT ci.context_item_repository_id_fk AS repository_id, ic.context_item_value, ci.context_item_id, ci.context_item_name_en, ci.context_item_name_fr, "
                . "ci.context_item_status, ci.context_item_mandatory, ci.context_item_type, "
                . "civ.context_item_value_id, civ.context_item_value_en, civ.context_item_value_fr "
                . "FROM tb_instances_contexts AS ic "
                . "JOIN tb_contexts_items AS ci ON ic.context_item_id_fk = ci.context_item_id "
                . "LEFT JOIN tb_instances_contexts_values AS icv ON icv.context_item_id_fk = ic.context_item_id_fk AND icv.instance_id_fk = ic.instance_id_fk "
                . "LEFT JOIN tb_contexts_items_values AS civ ON civ.context_item_value_id = icv.context_item_value_id_fk "
                . "WHERE ic.instance_id_fk = " . $this->dashboard_id;
        return $this->getDetailsFromQueryArray('dashboardPjtCtxsAll', $query);
    }
        
    public function getAllProjects() {
        $query = "select p.project_id, p.project_code, p.project_name, p.project_status from tb_instance_projects ip "
                . "join tb_projects p on p.project_id = ip.project_id_fk "
                . "where ip.instance_id_fk = " . $this->dashboard_id;
        return $this->getDetailsFromQueryArray('dashboardAllPjts', $query);
    }

    public function setFirstMilestone($mileStoneId, $currentUser) {
        $query = "UPDATE tb_instances_milestones SET milestone_status='EC' "
                . "WHERE instance_id_fk=".$this->dashboard_id." AND repository_milestone_id_fk = " . $mileStoneId;
        $this->execQuery($query);

        // get milestone order
        $query = "SELECT milestone_order,repository_revision_id_fk FROM tb_repositories_milestones "
                . "WHERE repository_milestone_id = " . $mileStoneId;
        $firstMileStone = $this->getDetailsFromQuery('', $query, true);

        $order_first_milestone = $firstMileStone->milestone_order;
        $revision_id = $firstMileStone->repository_revision_id_fk;

        $query = "UPDATE tb_instances_milestones im INNER JOIN tb_repositories_milestones rm on rm.repository_milestone_id = im.repository_milestone_id_fk "
                . "set im.is_deleted = 1 where im.instance_id_fk = ".$this->dashboard_id."  and rm.milestone_order < $order_first_milestone "
                . "and rm.repository_milestone_id <> " . $mileStoneId;
        $this->execQuery($query);
      
        // init a screenshot 
        $query = "INSERT INTO tb_instances_screenshot (instance_id_fk,creator,date_creation,repository_milestone_id_fk) "
                . "VALUES (".$this->dashboard_id.",'".$currentUser->ipn."','".todayDashFormatted()."',".$mileStoneId.")";
        $this->execQuery($query);
        $screenshot2init_id = $this->getRequest()->id_new;
        //Create data on screenshot : checkpoints of the result

        $query = "INSERT INTO tb_instances_screenshot_checkpoints "
                . "(SELECT checkpoint_id,tb_repositories_checkpoints.repository_result_id_fk,"
                . "".$mileStoneId.",".$screenshot2init_id.",'','0000-00-00 00:00:00','' FROM tb_repositories_checkpoints,tb_instances_results "
                . "WHERE tb_repositories_checkpoints.repository_result_id_fk=tb_instances_results.repository_result_id_fk "
                . "AND instance_id_fk=".$this->dashboard_id." AND repository_milestone_id_fk=".$mileStoneId.")";  
        $this->execQuery($query);
    }
    
    public function removeMilestone($mileStoneId) {
        $query = "UPDATE tb_instances_milestones SET is_deleted=1 "
                . "WHERE instance_id_fk=".$this->dashboard_id." AND repository_milestone_id_fk = " . $mileStoneId;
        $this->execQuery($query);
    }
    
    public function getAllTypeOwners() {
        $query = "SELECT `stakeholder_ipn` AS ipn, `type` FROM tb_instances_stakeholders WHERE instance_id_fk = " . $this->dashboard_id;
        return $this->getDetailsFromQueryArray('getAllTypeOwners', $query);
    }
}
