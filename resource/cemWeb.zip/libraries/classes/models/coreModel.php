<?php
class coreModel {
    protected $values = array();    
    protected $request;
    
    public function __construct($instance_id = '', $milestone_id = '') {
        global $request;
        $this->request = $request;
        
        $this->instance_id = $instance_id;
        $this->milestone_id = $milestone_id;
    }
    
    public function execQuery($query) {
        $this->request->envoi($query);
    }
    public function getRequest() {
        return $this->request;
    }
    
    public function __call($function, $args = array()) {
        if(substr($function, 0, 3) == 'get') {
            $key = strtolower(preg_replace('/(.)([A-Z])/', '$1_$2', substr($function, 3)));
            if(!isset($this->$key)) {
                return false;
            }
            $getVar = $this->$key;
            if(empty($args)) {
                return $getVar;
            } else if(is_array($this->$key)) {
                return isset($getVar[$args[0]])?$getVar[$args[0]]:'';
            }
        }
        
        if(substr($function, 0, 3) == 'set') {
            $key = strtolower(preg_replace('/(.)([A-Z])/', '$1_$2', substr($function, 3)));
            if(isset($args[0])) {
                $this->$key = $args[0];
            }
        }
    }
    
    protected function getDetailsFromQuery($name, $query, $singleRow = false) {
        if(!isset($this->values[$name]) || $name == '') {    
            if($name == '') {
                $name = "temp";
            }
            $this->request->envoi($query);
            unset($this->values[$name]);
            $count = (int)$this->request->calc_nb_elt();
            if($count > 0 && $singleRow) {
                $this->request->recup_objet();
                $this->values[$name] = $this->request->objet;                
            } else if($count > 0) {
                $this->values[$name] = $this->request->recup_array_objet();
            } else {
                return false;
            }
        }
        return $this->values[$name];
    }
    
    public function calculateROGPercentage($obj, $evaluation) {
        $per = array();
        $keys = array('green' => 'G', 'orange' => 'O', 'red' => 'R', 'white' => 'W', 'grey' => 'N');
      //  $keys = array('green' => 'G', 'orange' => 'O', 'red' => 'R', 'white' => 'W');
        
        $total = 0;
        /**if($evaluation == 2) { 
            $mulify = 1;
            if(!isset($obj->total_count)) {
                $obj->total_count = 1;
            }
            $total = ($obj->total_count * 100) - $obj->grey;
        }
        **/
       
    //        unset($keys['grey']);
       
        
        //if($evaluation != 2) { 
            foreach($keys as $k => $v) {
                $total += $obj->$k;
            }
        //}
        
        foreach($keys as $k => $v) {
            $per[$v] = round((($obj->$k * 100) / $total) , 2);
        }
        return $per;
    }
    
    public function saveROGBarImage($array, $file_name) {
        global $pathRoot;
        $width = 500;
        $height = 20;
        
        $im = @imagecreatetruecolor($width+2,$height+2);
        $green  = imagecolorallocate ($im,0x00,0x80,0x00);
        $orange = imagecolorallocate ($im,0xff,0xc1,0x15);
        $red = imagecolorallocate ($im,0xff,0x4b,0x00);
        $white = imagecolorallocate ($im,0xff,0xff,0xff);
        $grey = imagecolorallocate ($im,0x93,0x93,0x93);

        imagefilledrectangle($im,0,0,$width+2,$height+2,$grey);
        imagefilledrectangle($im,1,1,$width,$height,$white);

        $color_bars = array('green', 'orange', 'red', 'grey');

        $start_x = 1;
        foreach($color_bars as $color) {
            if(isset($array[$color]) && (int)$array[$color] > 0) {
                $per = $array[$color];  
                $end_x = $start_x + ($width * $per / 100);
                imagefilledrectangle($im,$start_x,1,$end_x,$height,${$color});
                $start_x += $width * ($per / 100);
            }
        }

        $path = $pathRoot . "images/bar/" . date("dmY", strtotime('now')) . "/";
        if(!file_exists($path)) {
            mkdir($path, 0777, true);
        }
        
        imagepng($im, $path.$file_name);
        imagedestroy($im);
        
        return $path.$file_name;
    }
    
    public function getRadarGraphImage($titles, $dataValues, $filename, $order) {
        global $tablo_couleur_statut;
        // Create the basic rtadar graph
        $h = 400;
        $w = 1050;
        $graph = new RadarGraph(1050,400);
        
        // Set background color and shadow
        $graph->SetColor("#".$tablo_couleur_statut['BG']);
        $graph->SetScale("lin", 0, 100);
        $graph->SetBox(false); 
        
        // Position the graph
        $graph->SetCenter(0.50,0.45);
        $graph->SetPlotSize(0.6);

        // Setup the axis formatting     
        $graph->axis->SetFont(FF_FONT1,FS_BOLD);
        $graph->axis->SetWeight(1);
 
        // Setup the grid lines
        $graph->grid->SetColor("navy");
        $graph->grid->Show();   
        $graph->HideTickMarks();
        $graph->legend->pos(0.05,0.88);
        
        ksort($order);
        $order = array_values($order);
        $firstOrder = array_shift($order);
        array_push($order, $firstOrder);
        $graph->SetTitles($order);
        
        foreach(array('NC', 'ER', 'EC', 'TR') as $status) {
            if(!isset($dataValues[$status])) {
                continue;
            }
            $dataValue = $dataValues[$status];
            ksort($dataValue);
            $dataValue = array_values($dataValue);
            $firstValue = array_shift($dataValue);
            array_push($dataValue, $firstValue);
            $plot = new RadarPlot($dataValue);
            $plot->SetColor("#".$tablo_couleur_statut[$status], "#".$tablo_couleur_statut[$status]);
            $plot->SetLineWeight(4);
            $graph->Add($plot);
        }
        
        ksort($titles);
        $titles = array_values($titles);
        $total = count($titles);
        $leftCount = ceil($total/2);
        $rightCount = $total - $leftCount;

        $textLeftSpace = ($graph->img->height * 0.7) / $leftCount;
        $textRightSpace = ($graph->img->height * 0.7) / $rightCount;

        $textBoxTop = ($graph->img->height * 0.1);

        $firstTitle = array_shift($titles);
        array_push($titles, $firstTitle);
        foreach($titles as $i => $title) {
            $txt = new Text();
            $txt->SetFont($graph->title->font_family,$graph->title->font_style,$graph->title->font_size);
            $txt->Set($title);
            $txt->SetParagraphAlign('top');

            if($i < $leftCount) {
                $xp = ($w/2) - min($w,$h)*0.35 - 20;
                $yp = ($i * $textLeftSpace) + $textBoxTop;
                $txt->SetPos($xp, $yp, 'right');
            } else {
                $xp = ($w/2) + min($w,$h)*0.35 + 20;
                $yp = (($total - $i - 1) * $textRightSpace) + $textBoxTop;
                $txt->SetPos($xp, $yp, 'left');
            }
            $graph->Add($txt);
        }
        
        $graph->SetImgFormat('PNG',60);
        // And output the graph
        $graph->Stroke($filename);        
    }
    
    public function getPrevKey($key, $hash = array()) {
        $keys = array_keys($hash);
        $found_index = array_search($key, $keys);
        if ($found_index === false || $found_index === 0)
            return false;
        return $keys[$found_index-1];
    }
    
        protected function getDetailsFromQueryGroup($name, $query, $singleRow = false, $group = '') {
        if(!isset($this->values[$name]) || $name == '') {    
            if($name == '') {
                $name = "temp";
            }
            $this->request->envoi($query);
            unset($this->values[$name]);
            $count = (int)$this->request->calc_nb_elt();
            if($count > 0 && $singleRow) {
                $this->request->recup_objet();
                $this->values[$name] = $this->request->objet;                
            } else if($count > 0) {
                $this->values[$name] = $this->request->recup_array_objet();
            } else {
                return false;
            }
        }
        $datas = $this->values[$name];
        $groupData = array();
        foreach( $datas as $data){
            $rdata = (array)$data;
            unset($rdata[$group]);
            $groupData[$data->$group][] = $rdata;
        }
        $this->values[$name] = (object)$groupData;
        return $this->values[$name];
    }
    
    public function arrayFilter($inputDatas=array(), $filterData=array(),$type='select'){
        $filteredDataArray = array();
        if(!$inputDatas || empty($inputDatas)) {
            return array();
        }
        foreach($inputDatas as $inputData){
           $filteredArr = array_intersect_key((array)$inputData, array_flip($filterData));
           if($type='keyval'){
                $filteredDataArray[$filteredArr[$filterData[0]]] = $filteredArr[$filterData[1]];
           }else{
               $filteredDataArray = array_merge($filteredDataArray,$filteredArr);
           }
        }
        return $filteredDataArray;
    }
    
    protected function getDetailsFromQueryKeyValue($name, $query) {
        if(!isset($this->values[$name]) || $name == '') {    
            if($name == '') {
                $name = "temp";
            }
            $this->request->envoi($query);
            unset($this->values[$name]);
            $count = (int)$this->request->calc_nb_elt();
            if($count > 0) {
                $this->request->recup_array_key();
                $this->values[$name] = $this->request->array;                
            } else {
                return false;
            }
        }
        return $this->values[$name];
    }
     protected function getDetailsFromQueryArray($name, $query) {
        if(!isset($this->values[$name]) || $name == '') {    
            if($name == '') {
                $name = "temp";
            }
            $this->request->envoi($query);
            unset($this->values[$name]);
            $count = (int)$this->request->calc_nb_elt();
            if($count > 0) {
                $this->request->recup_array_champ();
                $this->values[$name] = $this->request->array;                
            } else {
                return false;
            }
        }
        return $this->values[$name];
    }
    
}    