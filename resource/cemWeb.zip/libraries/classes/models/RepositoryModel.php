<?php
class RepositoryModel extends coreModel {    
    protected $repository_id = array();

    
    public function __construct($repository_id) {
        parent::__construct();
        $this->repository_id = $repository_id;
        $this->lang = !empty($_SESSION['language']) ? $_SESSION['language'] : 'fr';
    }
    public function getRepositoryInfo(){
       $query = "select r.repository_id, r.repository_name_" . $this->lang . " as rep_name , r.gesper_status, r.universe_id_fk,
r.project_context,rv.version_id,rv.activity_evaluation,rv.backlog_display,rv.repository_revision_id,rv.version_status
from tb_repositories r 
join tb_repositories_versions rv on rv.repository_id_fk = r.repository_id
where rv.version_status = 'ACT' and r.repository_id = ".$this->repository_id;
       return $this->getDetailsFromQuery('repositories', $query, true);
    }
    public function getRepositoryVersionInfo($repositoryVersionId){
            $query = "select r.repository_id, r.repository_name_" . $this->lang . " as rep_name, r.gesper_status, r.universe_id_fk,
     r.project_context,rv.version_id,rv.activity_evaluation,rv.backlog_display,rv.repository_revision_id,rv.version_status
     from tb_repositories r 
     join tb_repositories_versions rv on rv.repository_id_fk = r.repository_id
     where rv.repository_revision_id = $repositoryVersionId";
       return $this->getDetailsFromQuery('repositories', $query, true);
    }
    public function getRepositoryTemplates(){
       $query = "select t.template_id,t.template_name_" . $this->lang . " as tmp,t.is_enable_gesper, t.default_template from tb_templates t where 
           t.is_deleted =0 and t.template_repository_id_fk = ".$this->repository_id." order by tmp asc";
       return $this->getDetailsFromQuery('templates', $query);
    }
    
    public function getRepositoryProjects(){
       $query = "select p.project_id, CONCAT(p.project_code, ' - ', p.project_name) as pjt from tb_projects p where p.project_status = 'ACT' 
           and p.project_repository_id_fk = ".$this->repository_id." order by pjt asc";
       return $this->getDetailsFromQuery('projects', $query);
    }
    
    public function getAllProjects() {
        $query = "select project_id, project_code, project_name, project_status from tb_projects AS p "
                . "where project_repository_id_fk = " . $this->repository_id;
        return $this->getDetailsFromQueryArray('repoAllPjts', $query);
    }
        
    public function getRepositoryFamilies(){
       $query = "select f.family_id, f.family_name_" . $this->lang . " as family_name, s.subfamily_id, "
               . "s.subfamily_name_" . $this->lang . " as subfamily_name "
               . "from tb_families f "
               . "join tb_subfamilies s on s.family_id_fk = f.family_id "
               . "where f.family_repository_id_fk = ".$this->repository_id." "
               . "order by f.family_name_" . $this->lang . " asc, s.subfamily_name_" . $this->lang . " ";
       return $this->getDetailsFromQuery('Family', $query);
    }
    
        
    public function getAllFamilies(){
       $query = "select f.family_id, f.family_name_en, f.family_name_fr, s.subfamily_id, "
               . "s.subfamily_name_en, s.subfamily_name_fr "
               . "from tb_families as f "
               . "join tb_subfamilies as s on s.family_id_fk = f.family_id "
               . "where f.family_repository_id_fk = ".$this->repository_id." "
               . "order by f.family_name_fr asc, s.subfamily_name_fr";
       return $this->getDetailsFromQuery('Family', $query);
    }
    
    public function getRepositoryContext(){
       $query = "select context_item_id, context_item_name_" . $this->lang . " as contxt, "
               . "context_item_name_en, context_item_name_fr, "
               . "context_item_mandatory, context_item_type from tb_contexts_items "
               . "where context_item_status = 'ACT' and context_item_repository_id_fk = ".$this->repository_id." order by context_item_id asc";
       return $this->getDetailsFromQuery('Context', $query);
    }
    public function getRepositoryContextValues(){
       $query = "SELECT c.context_item_id, cv.context_item_value_id, cv.context_item_value_" . $this->lang . " AS context_item_value, "
               . "context_item_value_en, context_item_value_fr "
               . "FROM tb_contexts_items AS c "
               . "JOIN tb_contexts_items_values AS cv ON c.context_item_id = cv.context_item_id_fk "
               . "WHERE c.context_item_status = 'ACT' AND cv.context_item_value_status = 'ACT' "
               . "AND c.context_item_repository_id_fk = ".$this->repository_id." order by context_item_id asc";
       return $this->getDetailsFromQuery('ContextValues', $query);
    }
    
    public function getRepositoryTypologies(){
       $query = "select ty.typology_id, ty.typology_name_" . $this->lang . " as typology from tb_typologies ty where 
           ty.typology_status = 'ACT' and ty.typology_repository_id_fk =  ".$this->repository_id." order by typology asc;";
       return $this->getDetailsFromQuery('typologies', $query);
    }
    
    public function getGesperDataGroup() {
        $query = "SELECT qType.question_type_id AS typeId, qType.name_language_" . $this->lang . " AS type "
                . "FROM tb_typology_question_types as qType "
                . "ORDER BY qType.question_type_id ASC";
        return $this->getDetailsFromQuery('gesper_data_group', $query);
    }
    
    public function getRepositoryVersionMiles($repositoryVersionId) {
         $query = "select  rm.milestone_name_".$this->lang." as milestone ,
            rm.milestone_title_".$this->lang." as milestone_title,rm.milestone_definition_".$this->lang." as milestone_definition,
            rm.milestone_expectation_".$this->lang." as milestone_expectation,rm.milestone_aer_reference, rm.milestone_rpif_reference, 
           rm.repository_milestone_id,rm.milestone_order
           from tb_repositories_milestones rm where rm.repository_revision_id_fk = $repositoryVersionId order by rm.milestone_order asc";
        return $this->getDetailsFromQueryArray('repMilestones', $query);
    }
    
    public function getGesperData() {
        $query = "SELECT ques.question_id, ques.name_language_" . $this->lang . " AS name, "
                . "ques.description_language_" . $this->lang . " AS questionDesc,"
                . "qType.question_type_id AS questionTypeID, qType.name_language_" . $this->lang . " AS questionType "
                . "FROM tb_typology_questions AS ques "
                . "JOIN tb_typology_question_types as qType ON qType.question_type_id = ques.question_type_id_fk "
                . "ORDER BY qType.question_type_id ASC";
        return $this->getDetailsFromQuery('gesper_data', $query);
    }
    public function getRepositoryresultdatas($repositoryVersionId) {
        $query = "select rr.repository_milestone_id_fk,rr.result_name_".$this->lang." as result, 
            rr.repository_result_id,ra.repository_activity_id,
           ra.name_".$this->lang." as activity,rr.result_order,ra.activity_order
            from tb_repositories_results rr  
             join tb_repositories_activities ra on ra.repository_result_id_fk = rr.repository_result_id
        and ra.repository_revision_id_fk = rr.repository_revision_id_fk
        where rr.repository_revision_id_fk = $repositoryVersionId order by  rr.result_order, ra.activity_order";
        return $this->getDetailsFromQueryArray('repositoryMilestonesResultDatas', $query);
    }
     public function getRepositoryMileinfo($repository_milestone_id) {
         $query = "select * from tb_repositories_milestones rm where rm.repository_milestone_id = ".$repository_milestone_id." order by rm.milestone_order";
        return $this->getDetailsFromQuery('repMilestoneData', $query,true);
    }
    public function getRepositoryactivites($activityIds){
       $query = "select rr.repository_milestone_id_fk,rr.result_name_".$this->lang." as result, 
            rr.repository_result_id,ra.repository_activity_id,
           ra.name_".$this->lang." as activity,rr.result_order,ra.activity_order from tb_repositories_activities ra
join tb_repositories_results rr on rr.repository_result_id = ra.repository_result_id_fk and rr.repository_revision_id_fk = ra.repository_revision_id_fk
where ra.repository_activity_id in (".join(',',$activityIds).")";
        return $this->getDetailsFromQueryArray('repositoryActivitySelectedDatas', $query);
    }
    public function getRepositoryFullInfo(){
       $query = "select r.repository_id, r.repository_name_fr, r.repository_name_en, r.`file`, r.universe_id_fk from tb_repositories r 
           where r.repository_id = ".$this->repository_id;
       return $this->getDetailsFromQuery('repository', $query, true);
    }
    public function getRepositoryTdbs(){
        $query ="Select inst.instance_id  from tb_instances inst, tb_repositories_versions ver 
        where inst.repository_revision_id_fk = ver.repository_revision_id and inst.is_deleted <> 1 and  
        inst.is_updating in (1,2) and ver.repository_id_fk=".$this->repository_id;
        return $this->getDetailsFromQueryArray('repositoryTdb', $query, true);
    }
    
}
