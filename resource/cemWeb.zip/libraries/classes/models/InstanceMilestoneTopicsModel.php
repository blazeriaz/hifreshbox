<?php
class InstanceMilestoneTopicsModel extends coreModel {    
    protected $instanceMilestone;
    
    public function __construct() {
        parent::__construct();
    }
    
    public function setInstanceMilestone($instanceMilestone) {
        $this->instanceMilestone = $instanceMilestone;
        $this->setInstanceId($instanceMilestone->getInstanceId());
        $this->setMilestoneId($instanceMilestone->getMilestoneId());
    }

    public function getAllTopics() {
        $query = "SELECT CONVERT(rr.result_name_".$_SESSION['language']."  USING utf8) as name, "
                . "ra.repository_result_id_fk as id, "
                . "rr.result_order, "
                . "COUNT(ra.repository_result_id_fk) as total_count, "
                . "COUNT(DISTINCT ra.repository_activity_id) as count_activities, "
                . "SUM(CASE WHEN ia.GREY = 100 THEN 0 ELSE ia.GREEN END) AS green, "
                . "SUM(CASE WHEN ia.GREY = 100 THEN 0 ELSE ia.RED END) AS red, "
                . "SUM(CASE WHEN ia.GREY = 100 THEN 0 ELSE ia.ORANGE END) AS orange, "
                . "SUM(CASE WHEN ia.GREY = 100 THEN 0 ELSE ia.WHITE END) AS white, "
                . "SUM(ia.GREY) AS grey, "
                . "SUM(CASE WHEN ia.GREY = 100 THEN 0 "
                    . "WHEN ai.item_radar_force = 1 THEN (ia.RED + ia.ORANGE) "
                    . "WHEN ai.item_radar_force is NULL THEN (ia.RED) "
                    . "ELSE 0 END) AS red1, "
                . "SUM(CASE WHEN ia.GREY = 100 THEN 0 "
                    . "WHEN ai.item_radar_force is NULL THEN (ia.ORANGE) "
                    . "WHEN ai.item_radar_force = 1 THEN 0 "
                    . "ELSE (ia.RED + ia.ORANGE) END) AS orange1, "
                . "SUM(CASE WHEN ia.GREY > 0 THEN 1 ELSE 0 END) AS greyCount " 
                . "FROM tb_instances_activities AS ia "
                . "JOIN tb_repositories_activities AS ra ON ra.repository_activity_id = ia.repository_activity_id_fk "
                . "JOIN tb_repositories_results AS rr ON rr.repository_result_id = ra.repository_result_id_fk "
                . "JOIN tb_instances_results AS ir ON rr.repository_result_id = ir.repository_result_id_fk AND ia.instance_id_fk = ir.instance_id_fk "
                . "LEFT JOIN tb_assessments_items as ai ON ai.item_id = ia.activity_assessment_id_fk AND ai.item_radar_force = 1 "
                . "WHERE ia.instance_id_fk = ".$this->instance_id." AND ir.repository_milestone_id_fk = ".$this->milestone_id." "
                . "GROUP BY ra.repository_result_id_fk ORDER BY rr.result_order ASC";
        return $this->getDetailsFromQuery('topics', $query);
    }
    
    public function getBacklogTopicActivities($filters = array(), $need_joins = array(), $where = '', $eval_type) {
        $prevClosedMilestoneOrder = $this->instanceMilestone->getPreviousClosedMilestoneOrder();
        if(!$prevClosedMilestoneOrder) {
            return false;
        }
        
        $query = "SELECT ra.repository_result_id_fk as topic_id, ra.repository_activity_id as activity_id, ra.activity_order, "
                . "CONVERT(rr.result_name_".$_SESSION['language']."  USING utf8) as topic_name, rr.result_order as topic_order, "
                . "CONVERT(ra.name_".$_SESSION['language']."  USING utf8) as activity_name, "
                . "ia.activity_assessment_id_fk as assessment_id,"
                . "ia.activity_comment, ia.date_update, "
                . "CONVERT(rm.milestone_name_".$_SESSION['language']."  USING utf8) as milestone_name, "
                . "ia.GREEN AS green, ia.RED AS red, ia.ORANGE AS orange, ia.WHITE AS white, ia.GREY AS grey "
                . "FROM tb_instances_activities AS ia "
                . "JOIN tb_repositories_activities AS ra ON ra.repository_activity_id = ia.repository_activity_id_fk "
                . "JOIN tb_repositories_results AS rr ON rr.repository_result_id = ra.repository_result_id_fk "
                . "JOIN tb_instances_results AS ir ON rr.repository_result_id = ir.repository_result_id_fk AND ir.instance_id_fk= ia.instance_id_fk "
                . "JOIN tb_repositories_milestones AS rm ON rm.repository_milestone_id = ir.repository_milestone_id_fk "
                . "LEFT JOIN tb_assessments_items AS ai ON ai.item_id = ia.activity_assessment_id_fk AND ai.item_radar_force = 1 ";
        
        if(in_array('roles', $need_joins)) {
            $query .= "LEFT JOIN tb_repositories_activities_stakeholder_roles as ras ON "
                    . "ras.repository_activity_id_fk = ra.repository_activity_id "
                    . "AND ras.repository_revision_id_fk = ra.repository_revision_id_fk ";
            $query .= "LEFT JOIN tb_instances_milestones_assignments as ima ON "
                    . "ima.role_id_fk = ras.role_id_fk AND ia.instance_id_fk = ima.instance_id_fk "
                    . "AND ima.repository_milestone_id_fk = ir.repository_milestone_id_fk ";
            $query .= "LEFT JOIN tb_roles ON tb_roles.role_id = ras.role_id_fk ";
            $query .= "LEFT JOIN tb_departments ON tb_departments.department_id = tb_roles.role_department_id_fk ";
        }
        
        if(in_array('action_plans', $need_joins)) {
            $query .= "LEFT JOIN tb_instances_activities_action_plans as action_plans ON action_plans.activity_id_fk = ia.repository_activity_id_fk ";
        }
        
        $query .= "WHERE ia.instance_id_fk = ".$this->instance_id." ";
        if($eval_type != 4) {
            $query .= "AND ((ia.RED!=0 OR ia.ORANGE!=0 OR ia.WHITE!=0) OR (ia.GREEN!=0 OR ia.GREY!=0) AND ia.backlog_keep_visible=1) ";
        } else {
            $query .= "AND ((ia.RED!=0 OR ia.ORANGE!=0) OR ia.GREEN!=0 AND ia.backlog_keep_visible=0) ";
        }
        $query .= "AND ir.repository_milestone_id_fk IN ("
                    . "SELECT repository_milestone_id_fk FROM tb_instances_milestones WHERE instance_id_fk= ".$this->instance_id." AND milestone_status='CLO') "
                . "AND rm.milestone_order <= ".$prevClosedMilestoneOrder." ";
        
        foreach($filters as $key => $value) {
            if(is_array($value)) {
                $query .= "AND " . $key . " IN (" . join(", ", $value) . ") ";
            } else {
                $query .= "AND " . $key . " = '" . $value ."' ";
            }
        }
        
        if($where != '') {
            $query .= $where;
        }
        
        $query .= "GROUP BY ra.repository_result_id_fk, ra.repository_activity_id "
                . "ORDER BY rm.milestone_order ASC, rr.result_order ASC, ra.activity_order ASC";
        return $this->getDetailsFromQuery('', $query);
    }

    public function getAllActivities($filters = array(), $need_joins = array(), $where = '') {
        $query = "SELECT ra.repository_result_id_fk as topic_id, ra.repository_activity_id as activity_id, ra.activity_order, "
                . "CONVERT(rr.result_name_".$_SESSION['language']."  USING utf8) as topic_name, rr.result_order as topic_order, "
                . "CONVERT(ra.name_".$_SESSION['language']."  USING utf8) as activity_name, "
                . "ia.activity_assessment_id_fk as assessment_id,"
                . "ia.activity_comment, ia.date_update, "
                . "ia.GREEN AS green, ia.RED AS red, ia.ORANGE AS orange, ia.WHITE AS white, ia.GREY AS grey "
                . "FROM tb_instances_activities AS ia "
                . "JOIN tb_repositories_activities AS ra ON ra.repository_activity_id = ia.repository_activity_id_fk "
                . "JOIN tb_repositories_results AS rr ON rr.repository_result_id = ra.repository_result_id_fk "
                . "JOIN tb_instances_results AS ir ON rr.repository_result_id = ir.repository_result_id_fk AND ia.instance_id_fk = ir.instance_id_fk ";
        
        if(in_array('roles', $need_joins)) {
            $query .= "LEFT JOIN tb_repositories_activities_stakeholder_roles as ras ON "
                    . "ras.repository_activity_id_fk = ra.repository_activity_id "
                    . "AND ras.repository_revision_id_fk = ra.repository_revision_id_fk ";
            $query .= "LEFT JOIN tb_instances_milestones_assignments as ima ON "
                    . "ima.role_id_fk = ras.role_id_fk AND ia.instance_id_fk = ima.instance_id_fk "
                    . "AND ima.repository_milestone_id_fk = ir.repository_milestone_id_fk ";
            $query .= "LEFT JOIN tb_roles ON tb_roles.role_id = ras.role_id_fk ";
            $query .= "LEFT JOIN tb_departments ON tb_departments.department_id = tb_roles.role_department_id_fk ";
        }
        
        if(in_array('action_plans', $need_joins)) {
            $query .= "LEFT JOIN tb_instances_activities_action_plans as action_plans ON action_plans.activity_id_fk = ia.repository_activity_id_fk ";
        }

        $query .= "WHERE ia.instance_id_fk = ".$this->instance_id." AND ir.repository_milestone_id_fk = ".$this->milestone_id." ";
        
        foreach($filters as $key => $value) {
            if(is_array($value)) {
                $query .= "AND " . $key . " IN (" . join(", ", $value) . ") ";
            } else {
                $query .= "AND " . $key . " = '" . $value ."' ";
            }
        }
        
        if($where != '') {
            $query .= $where;
        }
        
        $query .= "GROUP BY ra.repository_activity_id ORDER BY rr.result_order ASC, rr.repository_result_id DESC, ra.activity_order ASC";
        return $this->getDetailsFromQuery('', $query);
    }

    public function getAcitvityExternalProofs($activity_id, $evaluation_id = '') {
        $query = "SELECT activity_external_link FROM tb_instances_activities_external_link "
                . "WHERE instance_id_fk = ".$this->instance_id." "
                . "AND repository_activity_id_fk = ".$activity_id." ";
        if($evaluation_id) {
            $query .= "AND activity_evaluation_id_fk = ".$evaluation_id." ";
        }
        
        $query .= "ORDER BY activity_external_link_id DESC";
        return $this->getDetailsFromQuery('', $query);
    }
}