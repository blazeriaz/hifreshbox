<?php
/**
* File fichier.php
*
* Definition of a class for the functions related to files
*
* @package   PHPLIBS
* @author    Laurent BARBOT <>
* @version   1.0.1	06/05/2000		Initial revision code
* @copyright Etablissement VSF - RENAULT
* @filesource
*/

/**
* Define constants
*/
//require_once "config_generique.php";

/**
* Class cl_fichier
*
* class constructor
*
* @package   PHPLIBS
* @author    Laurent BARBOT <>
* @version   1.0.1	06/05/2000		Initial revision code
* @copyright Etablissement VSF - RENAULT
*/
class cl_fichier
{
	/**
         * ATTRIBUTE : Information File
         */
        /**
         * path and file name
         */
	var $Fichier;		
        /**
         * Nom du fichier
         */
	var $NomFichier;	
        /**
         * file path (if it is a secure file, it does not contain /home/idvu/document/)
         */
	var $Chemin;		
        /**
         * equals 1 if the file exists
         */
	var $Existe;		
        /**
         * size in bytes
         */
	var $Taille;		
        /**
         * extension (sample : '.xls','.doc') always written in lower case
         */
	var $Extension;		
        /**
         * mime type of the file
         */
	var $TypeMime;		
        /**
         * equals 1 if the file is protected
         */
	var $Protege;		
        /**
         * equals 1 if the file is an image
         */
	var $Image;			
        /**
         * directory of protected files
         */
	var $RepertoireDocument;	
        /**
         * string defining the href to display the file
         */
	var $HrefFichier;	
	
        /**
        * fonction cl_fichier
        * 
        * Class constructor
        *
        * @author    Laurent BARBOT <>
        * @version   1.0.1	09/07/2000		Initial revision code
        * @copyright Etablissement VSF - RENAULT
        *
        * @param     string	$Fichier    file name
        * @param     string	$Protege    flag is 1 if the file is protected, If this flag is 0, the file will manage as a normal file
        * @return    void
        */
	function cl_fichier($Fichier,$Protege=1)
	{
                /**
                 * contains the mime type, icons, fileImage ...
                 */
		include "Icon_File.php";						
		
		/**
                 * fill attributes of the class with the values ​​of the file
                 */
		$this->Fichier=$Fichier;
		$this->NomFichier=basename($Fichier);
		$this->Chemin=dirname($Fichier);
		$this->Protege=$Protege;
		
		if(!$Protege)
		{ 
			$this->Existe=file_exists($Fichier);
			if($this->Existe) $this->Taille=filesize($Fichier);
			$this->HrefFichier=$Fichier;
		}
		else
		{
			$this->RepertoireDocument =  _REPERTOIRE_DOCUMENT ;
			$this->Existe=file_exists($this->RepertoireDocument.$Fichier);
			if($this->Existe) $this->Taille=filesize($this->RepertoireDocument.$Fichier);
			$this->HrefFichier="sendDocument.php?parNomFichier=$Fichier";
		}
		if(strstr($Fichier,".")) $this->Extension=strtolower(substr($Fichier,strrpos($Fichier,".")));
		$this->TypeMime=(($ContentType[$this->Extension]=="")?"application/x-unknown":$ContentType[$this->Extension]);
		if(isset($FichiersImage["$this->Extension"]))
			$this->Image=$FichiersImage["$this->Extension"];
		else
			$this->Image="";
	}
        /**
        * fonction Debug
        * 
        * Display the attributes of the class
        *
        * @author    Laurent BARBOT <>
        * @version   1.0.1	09/07/2000		Initial revision code
        * @copyright Etablissement VSF - RENAULT
        *
        * @param     void
        * @return    void
        */
	function Debug()
	{
		print (">===============   DEBUG DE LA CLASSE FICHIER   ==========<<BR>\n");
		print (">this->Fichier					=>$this->Fichier<<BR>\n");
		print (">this->NomFichier				=>$this->NomFichier<<BR>\n");
		print (">this->Chemin					=>$this->Chemin<<BR>\n");
		print (">this->Existe					=>$this->Existe<<BR>\n");
		print (">this->Taille					=>$this->Taille<<BR>\n");
		print (">this->Extension				=>$this->Extension<<BR>\n");
		print (">this->TypeMime					=>$this->TypeMime<<BR>\n");
		print (">this->Image					=>$this->Image<<BR>\n");
		
		print (">this->RepertoireDocument		=>$this->RepertoireDocument<<BR>\n");
		print (">===============    fin debug     ========================<<BR>\n");
	}
        /**
        * fonction is_Url
        * 
        * Define if the file is a url
        *
        * @author    Laurent BARBOT <>
        * @version   1.0.1	09/07/2000		Initial revision code
        * @copyright Etablissement VSF - RENAULT
        *
        * @param     void
        * @return    void
        */
	function is_Url()
	{
		$Tab_url=parse_url($this->Fichier);
		if(isset($Tab_url["scheme"])) return 1;
		else return 0;
	}
        /**
        * fonction supprimer
        * 
        * delete file
        *
        * @author    Laurent BARBOT <>
        * @version   1.0.1	09/07/2000		Initial revision code
        * @copyright Etablissement VSF - RENAULT
        *
        * @param     void
        * @return    void
        */
	function supprimer()
	{
		if ($this->Existe)
		{
			if(unlink($this->RepertoireDocument.$this->Fichier))
					return true;
		}
		return false;
	}
        /**
        * fonction copy
        * 
        * copy file
        *
        * @author    Laurent BARBOT <>
        * @version   1.0.1	09/07/2000		Initial revision code
        * @copyright Etablissement VSF - RENAULT
        *
        * @param     string $Cible target file
        * @return    void 
        */
	function copy($Cible)
	{
		if ($this->Existe)
		{
			if(!file_exists(dirname($Cible))) return false;
			if(copy($this->RepertoireDocument.$this->Fichier,$Cible))
					return true;
		}
		return false;
	}
        /**
        * fonction getDimension
        * 
        * return image size
        *
        * @author    Laurent BARBOT <>
        * @version   1.0.1	09/07/2000		Initial revision code
        * @copyright Etablissement VSF - RENAULT
        *
        * @param     string $X image x dimension
        * @param     string $Y image y dimension
        * @return    void 
        */
	function getDimension(&$X,&$Y)
	{
		if($this->Image)
		{
			$image_file=getimagesize($this->RepertoireDocument.$this->Fichier);
			$X=$image_file[0];
			$Y=$image_file[1];
		}
	}
        /**
        * fonction AfficheImage
        * 
        * Display the file if it is an image
        *
        * @author    Laurent BARBOT <>
        * @version   1.0.1	09/07/2000		Initial revision code
        * @copyright Etablissement VSF - RENAULT
        *
        * @param     string $width  image attribut
        * @param     string $height image attribut
        * @param     string $Alt    image attribut
        * @param     string $href image attribut
        * @param     string $target image attribut
        * @param     string $align image attribut
        * @param     string $hspace image attribut
        * @param     string $vspace image attribut
        * @param     string $returnHtml image attribut
        * @return    void 
        */
	function AfficheImage($width="",$height="",$Alt="",$href="",$target="",$align="",$hspace=10,$vspace=10, $returnHtml=0)
	{
		if(!$this->Existe) return 0;
				
		if($this->Image)
		{
			$html =  $this->GetTagImage($width, $height, $Alt, $href, $target, $align, $hspace, $vspace);
		}
		
	    if(!$returnHtml)
 		{
 		    echo $html;
 		}
 		else
 		{
 		    return $html;
 		}
	}
        /**
        * fonction GetTagImage
        * 
        * Display the file if it is an image
        *
        * @author    Laurent BARBOT <>
        * @version   1.0.1	09/07/2000		Initial revision code
        * @copyright Etablissement VSF - RENAULT
        *
        * @param     string $width  image attribut
        * @param     string $height image attribut
        * @param     string $Alt    image attribut
        * @param     string $href image attribut
        * @param     string $target image attribut
        * @param     string $align image attribut
        * @param     string $hspace image attribut
        * @param     string $vspace image attribut
        * @param     string $returnHtml image attribut
        * @return    void 
        */
	function GetTagImage($width="",$height="",$Alt="",$href="",$target="",$align="",$hspace=10,$vspace=10)
	{
		$str = "";
				
		if($this->Image && $this->Existe)
		{
			/**
                         * resize the image proportionally, reduce the image size but we can enlarge it:
                         */
			$image_file=getimagesize($this->RepertoireDocument.$this->Fichier);
			
			if($width) 	$coefx = $width  / $image_file[0];  else $coefx=1;
			if($height) $coefy = $height / $image_file[1];  else $coefy=1;
			$coef=min(1,$coefx,$coefy);
			$width =$image_file[0]*$coef;
			$height=$image_file[1]*$coef;
			
			/**
                         * add href balise
                         */
			if($href)
			{
				$str = "<A HREF=\"$href\" TARGET=\"$target\">";
			}
			
			/**
                         * add image
                         */
			$str .= "<IMG SRC=\"$href\" ALT=\"$Alt\" WIDTH='$width' HEIGHT='$height' ALIGN='$align' BORDER=0 HSPACE='$hspace' VSPACE='$vspace'>";
			
			/**
                         * add '/a' balise
                         */
			if($href)
			{
				$str .= "</A>";
			}
		}
		return $str;
	}
        /**
        * fonction DrawIconeHref
        * 
        * draw the icon file with a link on the icon to launch the file
        *
        * @author    Laurent BARBOT <>
        * @version   1.0.1	09/07/2000		Initial revision code
        * @copyright Etablissement VSF - RENAULT
        *
        * @param     string $IconSize  image attribut
        * @param     string $Alt image attribut
        * @param     string $Target    image attribut
        * @param     string $Text image attribut
        * @param     string $returnHtml image attribut
        * @return    void 
        */
	function DrawIconeHref($IconSize="32",$Alt="",$Target="",$Text="", $returnHtml=0)
	{
		include "Icon_File.php";
		
		/**
                 * display the icon with link to open the file
                 */
		
		/**
                 * If the file opens in the browser, a target is defined
                 */
		if($Target=="") 
		{
				$Target=(isset($FichierLisisblesParNavagateur["$this->Extension"])?"visualiser_fichier":"");
		}
			
		/**
                 * if the table icon does not know the extension, there is an extension by default
                 */
		if ($Icons["$this->Extension"]=="") $Icone=$Icons[""];
		else  $Icone=$Icons["$this->Extension"];		
		
		/**
                 * if the file is a URL, define the icon for the url and the target
                 */
		if($this->is_Url())
		{
			$Icone="url_html.gif";
			$Target="visualiser_fichier";
		}
		/**
                 * if the size of the icon is too small, change the image
                 */
		if($IconSize<25)
		{
			$Icone="small_".$Icone;
			$IconSize=16;
		}
		/**
                 * display link and icon
                 * the link path is the sendDocument which verifies that the user can access the file
                 */
 		$html = "<a href=\""._ADRESSE_HTTP."/comp_gen/document/".$this->HrefFichier."\" target=\"_blank\"><img src=\"".$Path_icones."/".$Icone."\" alt=\"$Alt\" width=\"$IconSize\" height=\"$IconSize\" hspace=\"2\" border=\"0\" align=\"top\">$Text</a>\n";
 		
 		if(!$returnHtml)
 		{
 		    echo $html;
 		}
 		else
 		{
 		    return $html;
 		}
	}
        /**
        * fonction getIconeHref
        * 
        * returns a character string in the design of the icon with link to the file (use for sending Email)
        *
        * @author    Laurent BARBOT <>
        * @version   1.0.1	09/07/2000		Initial revision code
        * @copyright Etablissement VSF - RENAULT
        *
        * @param     string $IconSize  image attribut
        * @param     string $IconSize image attribut
        * @param     string $Href    image attribut
        * @param     string $HrefImage image attribut
        * @return    void 
        */
	function getIconeHref($IconSize="",$IconSize="",$Href="",$HrefImage="")
	{
		include "Icon_File.php";
		
		/**
                 * display the icon with link to open the file
                 */
		
		/**
                 * If the file opens in the browser, a target is defined
                 */
		$Target=(($FichierLisisblesParNavagateur[$this->Extension])?"visu":"");
			
		/**
                 * If the icon does not know the extension table, there is an extension by default
                 */
		if ($Icons[$this->Extension]=="") $Icone=$Icons[""];
		else  $Icone=$Icons[$this->Extension];		

		
		/**
                 * display the icon and link
                 * If the file is protected, you call the script 'sendDocument.php3'
                 * the link path is the sendDocument which verifies that the user can accder file
                 */
		if($Href){
			if($HrefImage)
				return " <A HREF=\"$Href\" TARGET='$Target'><IMG SRC='".$HrefImage."/".$Path_icones."/".$Icone."' ALT='$Alt' WIDTH='$IconSize' height='$IconSize' BORDER=0></A>\n";
			else	
				return " <A HREF=\"$Href\" TARGET='$Target'><IMG SRC='".$Path_icones."/".$Icone."' ALT=\"$Alt\" WIDTH='$IconSize' height='$IconSize' BORDER=0></A>\n";			
		}
 		else
		{
			return " <A HREF=\"$this->HrefFichier\" TARGET='$Target'><IMG SRC='".$Path_icones."/".$Icone."' ALT='$Alt' WIDTH='$IconSize' height='$IconSize' BORDER=0></A>\n";
		}
	}
}
?>
