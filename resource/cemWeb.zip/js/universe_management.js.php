<?php
session_start();
require_once("../messages/".$_SESSION['language']."/alertes_js.msg");
?>
// JavaScript Document
function ControleSaisie()
{ 
//------ Controle saisie -------
 	if (document.form_universe.name.value=="")
        return(alert("<?php echo $js_alert_saisie_universe;?>"));
document.form_universe.submit();
}
