var app = angular.module('agCem', []);
app.controller('tdbCreateController', function($scope, $filter, $http, $window, $httpParamSerializerJQLike) {
    $scope.step = 1;
    $scope.currentStep = $scope.step;    
    $scope.header_color_code = ['#FF0000','#008081','#993365'];
    
    $scope.style = {
        align : {
            left : {'text-align' : 'left'},
            right : {'text-align' : 'right'},
            center : {'text-align' : 'center'},
        }
    };

    $scope.resetData = function(){
        $scope.submit = false;
        $scope.templates =[];
        $scope.AllTypologies =[];
        $scope.typologies =[];
        $scope.gesperData =[];
        $scope.gesperDataGroup =[];
        $scope.typology = null;
        $scope.projects =[];
        $scope.PjtContexts =[];
        $scope.families =[];
        $scope.selectedpjts = [];
        $scope.sfamilies = [];
        $scope.nav_style = "";
        $scope.pjtFilter='';
        $scope.selectedPjtFilter='';
        $scope.familyFilter = '';
        $scope.selectedFamFilter = '';
        $scope.gesper = null;
        $scope.duplicate = {};
        $scope.proposedClass = null;
        $scope.gsper_text_comment = null;
        $scope.proposedTypology = null;
        $scope.selectedTypology = null;
    }
    
    $scope.resetData();
    
    $scope.pjtContextOrder = function(pjtContext) {
        if(pjtContext.context_item_type == 'TEXT') return 0;
        else if(pjtContext.context_item_type == 'LIST') return 1;
        else if(pjtContext.context_item_type == 'MULTI') return 2;
        else return 3;
    }
      
    $scope.nextStep = function() {        
        var form_name = 'step'+$scope.step+'Form';
        if($scope.step == 4 || $scope.step == 6) {
            $scope[form_name].$invalid = false;
        }
        if($scope.step == 4 && $scope.selectedpjts.length == 0) {
            $scope[form_name].$invalid = true;
        }
        if($scope.step == 5) {
            var prjContextRequired = $filter("filter")($scope.PjtContexts,{'context_item_mandatory':1});
            $scope[form_name].$invalid = false;
            if(prjContextRequired.length > 0) {
                for(i=0;i<prjContextRequired.length;i++) {
                    if(prjContextRequired[i].context_item_type == 'TEXT' 
                            && (!prjContextRequired[i].context_value || prjContextRequired[i].context_value.trim() == "")) {
                        $scope[form_name].$invalid = true;
                    }
                    if(prjContextRequired[i].context_item_type == 'LIST' && 
                            (!prjContextRequired[i].context_value || $filter("isEmptyObject")(prjContextRequired[i].context_value))) {
                        $scope[form_name].$invalid = true;
                    }
                    if(prjContextRequired[i].context_item_type == 'MULTI' && 
                            (!prjContextRequired[i].context_value || prjContextRequired[i].context_value.length == 0)) {
                        $scope[form_name].$invalid = true;
                    }
                }
            }
        }
        if($scope.step == 6 && $scope.sfamilies.length == 0) {
            $scope[form_name].$invalid = true;
        }
        
        if($scope[form_name].$invalid) {
            $scope[form_name].$submitted = true;
            return;
        }

        if($scope.step == 1) {
            var req = {
                method: 'POST',
                url: '../xmlhttprequest/ajax_tdb_create.php',
                headers: {
                    'Content-Type': undefined
                },
                data: {
                    rep_id:  $scope.repository
                }
            }
            if($scope.templates.length == 0) {
                $http(req).then(function(response){
                    $scope.templates = response.data.templates?response.data.templates:[];
                    $scope.AllTypologies = [];
                    if(response.data.repository.gesper_status == 1) {
                        $scope.AllTypologies = response.data.typologies?response.data.typologies:[];
                        for(i=0;i<$scope.AllTypologies.length;i++) {
                            $scope.AllTypologies[i].description = $window.typo_definition[$scope.AllTypologies[i].typology];
                        }
                    }
                    if($scope.templates.length == 1){
                        $scope.template = $scope.templates[0];
                        $scope.step++;
                        if(!$scope.typologies.length){
                            $scope.step++;
                        }
                    }

                    $scope.projects = response.data.projects?response.data.projects:[];
                    $scope.PjtContexts = response.data.PjtContext?response.data.PjtContext:[];
                    var PjtContextsValues = response.data.PjtContextValues?response.data.PjtContextValues:[];
                    for(i=0; i<$scope.PjtContexts.length;i++) {
                        $scope.PjtContexts[i].values = $filter('filter')(PjtContextsValues,{context_item_id: $scope.PjtContexts[i].context_item_id});
                    }
                    $scope.families = response.data.families?response.data.families:[];
                    $scope.gesperData = response.data.gesper_data?response.data.gesper_data:[];
                    $scope.gesperDataGroup = response.data.gesper_data_group?response.data.gesper_data_group:[];
                    $scope.nav_style = "nav-justified";
                }, function(){

                });
            }
        } else if($scope.step == 2) {
            if($scope.template.is_enable_gesper == 0 || !$scope.AllTypologies.length) {  
                $scope.typologies = [];
                $scope.step++;
                if(!$scope.families.length && !$scope.PjtContexts.length) {
                    $scope.submit=true;
                }
            } else {
                $scope.typologies = $scope.AllTypologies;
            }
        } else if($scope.step==3) {
            if(!$scope.families.length && !$scope.PjtContexts.length) {
                $scope.submit=true;
            }
        } else if($scope.step == 4){
            if(!$scope.PjtContexts.length) {
                $scope.step++; 
                $scope.submit=true;
            }
        } else if($scope.step == 5){
            $scope.submit=true;
        }
        $scope.step++;
        $scope.currentStep = $scope.step;         
    }
    
    $scope.prevStep = function() {
        $scope.step--;
        $scope.submit=false;
        if($scope.step == 3){
            if($scope.template.is_enable_gesper == 0 || !$scope.typologies.length){
                $scope.step--;
            }
            if($scope.templates.length == 1){
                $scope.step--;
            }
        }
        if($scope.step == 2){
            if($scope.templates.length == 1){
                $scope.step--;
            }
        }
        if($scope.step == 5){
            if(!$scope.PjtContexts.length){
                $scope.step--;
            }
        }
        $scope.currentStep = $scope.step;
    }
    
    $scope.tdbAlertClose = function(){
        jQuery('#dialog_dashboard_alert').dialog( "close" );
    };
    
    $scope.Tdbcheck = function() {
        var form_name = 'step'+$scope.step+'Form';
        if($scope[form_name].$invalid) {
            $scope[form_name].$submitted = true;
            return;
        }
        $scope.chkDuplicate = {
            rep_id : $scope.repository,
            projects : [],
            families : []
        };
        for (var i = 0; i < $scope.selectedpjts.length; i++) {
            $scope.chkDuplicate.projects.push($scope.selectedpjts[i]['project_id']);
        }
        for (var i = 0; i < $scope.sfamilies.length; i++) {
            $scope.chkDuplicate.families.push($scope.sfamilies[i]['subfamily_id']);
        }
        var req = {
             method: 'POST',
             url: '../xmlhttprequest/ajax_check_duplicate.php',
             headers: {
               'Content-Type': undefined
             },
             data: $scope.chkDuplicate
        }
         
        $scope.duplicate = {};
        $http(req).then(function(response){
            var res = response.data;
            if(res['tdb'].length == 0) {
                $scope.TdbCreate();
            } else {
                $scope.duplicate = {
                    repository_name : res['rep'],
                    project_name : res['prj'],
                    family_name : res['family']?res['family']:'',
                    subfamily_name : res['subfamily']?res['subfamily']:'',
                    dashboards : res['tdb']
                };
                jQuery('#dialog_dashboard_alert').dialog( "open" );
            } 
        }, function(){

        });
    } 
    
    $scope.TdbCreate = function(){
        var propo_type = $scope.proposedTypology;
        var typo = propo_type;
        if($scope.selectedTypology) {
            typo = $scope.selectedTypology;
        }
        $scope.submitDashboard = {
            rep_id : $scope.repository,
            template_id : $scope.template.template_id,
            propo_typo_id : propo_type?propo_type.typology_id:'',
            typo_id: typo?typo.typology_id:'',
            propo_class: $scope.proposedClass,
            gsper_text_comment: $scope.gsper_text_comment,
            all_ques_answ : [],
            projects : [],
            families : [],
            pjt_contexts : []
        };
        for (var i = 0; i < $scope.gesperData.length; i++) {
            $scope.submitDashboard.all_ques_answ.push($scope.gesperData[i]['value']);
        }
        for (var i = 0; i < $scope.selectedpjts.length; i++) {
            $scope.submitDashboard.projects.push($scope.selectedpjts[i]['project_id']);
        }
        for (var i = 0; i < $scope.sfamilies.length; i++) {
            $scope.submitDashboard.families.push($scope.sfamilies[i]['subfamily_id']);
        }
        
        for (var i = 0; i < $scope.PjtContexts.length; i++) {
            $scope.submitDashboard.pjt_contexts[i] = {
                context_item_id : $scope.PjtContexts[i]['context_item_id'],
                context_value : $scope.PjtContexts[i]['context_value'],
            };
        }
        
        var req = {
             method: 'POST',
             url: '../xmlhttprequest/ajax_dashboard_create.php',
             headers: {
               'Content-Type': undefined
             },
             data: $scope.submitDashboard
        }
         
        $http(req).then(function(response){
            var res = response.data;
            if(res['success'] == 1) {
              $window.location = "dashboard.php?action=init_session&create_new=1&menu_n1=home&menu_n2=1&dashboard_id=" + res['dashboard']+"#!/view/" + res['dashboard'];
            } 
        }, function(){

        });
    }
});

app.filter('notInArray', function($filter) {
    return function(list, arrayFilter) {
        if(arrayFilter.length > 0) {
            return $filter("filter")(list, function(listItem) {
                return arrayFilter.indexOf(listItem) == -1;
            });
        } else {
            return list;
        }
    };
});
app.filter('isEmptyObject', function () {
    var bar;
    return function (obj) {
        for (bar in obj) {
            if (obj.hasOwnProperty(bar)) {
                return false;
            }
        }
        return true;
    };
});

app.controller('typoController', function($scope, $filter, $window){
    
    $scope.resetData = function() {
        $scope.level1_total = 0;
        $scope.level2_total = 0;
        $scope.level3_total = 0;

        $scope.level1_icon = null;
        $scope.level2_icon = null;
        $scope.level3_icon = null;

        $scope.level_values = [];
        
        $scope.$parent.proposedClass = null;
        $scope.$parent.proposedTypology = null;
        $scope.$parent.selectedTypology = null;
    }
    
    $scope.$watch('$parent.gesperData[0].value', function(n, o){
        if(typeof n == 'undefined') {
            $scope.resetData();
        }
    });
    
    $scope.resetData();
        
    $scope.validateTypo = function() {
        jQuery('#modifyTypology').dialog("close");
        $scope.$parent.nextStep();
    }
    
    $scope.modifyTypo = function() {
        $('#modifyTypology').dialog({
            autoOpen: true,
            modal: true,
            position: 'center',
            draggable: false,
            width: '350px',
            buttons: {},
            open: function(event, ui) { 
                $(this).parent().children().children('.ui-dialog-titlebar-close').remove();
            }
        });
    }
    
    $scope.closeModifyTypo = function() {
        jQuery('#modifyTypology').dialog("close");
        $scope.$parent.selectedTypology = null;
    }
    
    $scope.gesperChange = function(){    
        var level_totals = [];
        var level_counts = [];
        $scope.resetData();
        for(i=0;i<$scope.$parent.gesperDataGroup.length;i++) {
            var gesperGroup = $scope.$parent.gesperDataGroup[i];
            level_totals[i] = 0;
            var gesperDatas = $filter('filter')($scope.$parent.gesperData, {questionType:gesperGroup.type});
            level_counts[i] = 0;
            $scope.level_values[i] = [];
            for(j=0;j<gesperDatas.length;j++) {
                var value = (gesperDatas[j].value)?parseInt(gesperDatas[j].value):0;
                $scope.level_values[i][j] = value;
                level_totals[i] += value;
                if(value != 0) {
                    level_counts[i]++;
                }
            }
        }
        
        $scope.level1_total = level_totals[0];
        $scope.level2_total = level_totals[1] + level_totals[2];
        $scope.level3_total = level_totals[0] + level_totals[1] + level_totals[2];
        
        if(level_counts[0] == 7 && (level_counts[1] + level_counts[2]) !=7) {
            $scope.iconActionForLvlOneandTwo($scope.level1_total,'level1_icon');
            $scope.iconActionForLvlOneandTwo($scope.level2_total,'level2_icon');
            $scope.iconActionForLvlThree($scope.level3_total,'level3_icon');
        } else if(level_counts[0] != 7 && (level_counts[1] + level_counts[2]) == 7) {
            $scope.iconActionForLvlOneandTwo($scope.level1_total,'level1_icon');
            $scope.iconActionForLvlOneandTwo($scope.level2_total,'level2_icon');
            $scope.iconActionForLvlThree($scope.level3_total,'level3_icon');
        } else if(level_counts[0] == 7 && (level_counts[1] + level_counts[2]) == 7) {
            $scope.iconActionForLvlOneandTwo($scope.level1_total,'level1_icon');
            $scope.iconActionForLvlOneandTwo($scope.level2_total,'level2_icon');
            $scope.iconActionForLvlThree($scope.level3_total,'level3_icon');
            $scope.calTypoDefinition();
        } else if(level_counts[0] != 7 && (level_counts[1] + level_counts[2]) != 7) {
            $scope.iconActionForLvlOneandTwo($scope.level1_total,'level1_icon');
            $scope.iconActionForLvlOneandTwo($scope.level2_total,'level2_icon');
            $scope.iconActionForLvlThree($scope.level3_total,'level3_icon');
        } else {
            $scope.iconActionForLvlOneandTwo($scope.level1_total,'level1_icon');
            $scope.iconActionForLvlOneandTwo($scope.level2_total,'level2_icon');
            $scope.iconActionForLvlThree($scope.level3_total,'level3_icon');
        }
    }
    
    $scope.iconActionForLvlOneandTwo = function(lvlValue,lvlIconName) {
        var marginStart = 0;
        var marginStyle = 0;
        $scope[lvlIconName] = null;
        if(lvlValue >= 7 && lvlValue <= 10) {
            marginStart = 7;
            marginStyle = (lvlValue - marginStart)*11;            
        } else if(lvlValue >= 11 && lvlValue <= 16) {
            marginStart = 11;
            var defaultMargin = 51;
            if(lvlValue == 11){
                marginStyle = defaultMargin;
            } else if(lvlValue == 16) {
                marginStyle = 84;
            } else {
                marginStyle = defaultMargin+((lvlValue - marginStart)*7);
            }
	} else if(lvlValue >= 17 && lvlValue <= 35) {
            marginStart = 17;
            var defaultMargin = 101;
            if(lvlValue == 17) {
                marginStyle = defaultMargin;
            } else if(lvlValue == 35) {
                marginStyle = 236;
            } else {
                marginStyle = defaultMargin+((lvlValue - marginStart)*8);
            }
	}
        
        if(marginStyle > 0) {
            $scope[lvlIconName] = {
                style : {'margin-left' : marginStyle + 'px'},
                text : lvlValue
            };
        }
    }
    
    $scope.iconActionForLvlThree = function(lvlValue,lvlIconName) {
        var marginStart = 0;
        var marginStyle = 0;
        var proposed_typo = null;
        $scope.$parent.proposedClass = null;
        $scope[lvlIconName] = null;
	if(lvlValue >= 14 && lvlValue <= 20) {
            marginStart = 14;
            marginStyle = (lvlValue - marginStart)*5.67;
            proposed_typo = 'D';
	} else if(lvlValue >= 21 && lvlValue <= 30) {
            marginStart = 21;
            var defaultMargin = 51;
            if(lvlValue == 21){
                marginStyle = defaultMargin;
            } else if(lvlValue == 30) {
                marginStyle = 84;
            } else {
                marginStyle = defaultMargin+((lvlValue - marginStart)*3.5);
            }
            proposed_typo = 'C';
	} else if(lvlValue >= 31 && lvlValue <= 40) {
            marginStart = 31;
            var defaultMargin = 101;
            if(lvlValue == 31){
                marginStyle = defaultMargin;
            } else if(lvlValue == 40) {
                marginStyle = 134;
            } else {
                marginStyle = defaultMargin+((lvlValue - marginStart)*3.5);
            }
            proposed_typo = 'B';
	} else if(lvlValue >= 40 && lvlValue <= 70) {
            marginStart = 40;
            var defaultMargin = 151;
            if(lvlValue == 40){
                marginStyle = defaultMargin;
            } else if(lvlValue == 70) {
                marginStyle = 236;
            } else {
                marginStyle = defaultMargin+((lvlValue - marginStart)*2.84);
            }
            proposed_typo = 'A';
	}
        
        if(marginStyle > 0) {
            $scope.$parent.proposedClass = proposed_typo;
            $scope.proposedDesc = $window.gesperClassData[proposed_typo];
            $scope[lvlIconName] = {
                style : {'margin-left' : marginStyle + 'px'},
                text : lvlValue
            };
        }
    }
    
    $scope.calTypoDefinition = function(){	
	var total2_12 = $scope.level_values[1][0] * $scope.level_values[1][1];
	var total2_34 = $scope.level_values[1][2] * $scope.level_values[1][3];
	var total3_12 = $scope.level_values[2][0] * $scope.level_values[2][1];
	
	if(total2_12 > 2) { var cpl1 = true; } else { var cpl1 = false; }
	if(total2_34 > 2) { var cpl2 = true; } else { var cpl2 = false; }
	if(total3_12 > 2) { var cpl3 = true; } else { var cpl3 = false; }
	
	if(cpl1 && cpl2 && cpl3) {
            $scope.propo_typo = 'T1';
	} else if(cpl1 && cpl2 && !cpl3) {
            $scope.propo_typo = 'T2';
	} else if(cpl1 && !cpl2 && !cpl3) {
            $scope.propo_typo = 'T3';
	} else if(!cpl1 && cpl2 && !cpl3) {
            $scope.propo_typo = 'T4';
	} else if(!cpl1 && !cpl2 && cpl3) {
            $scope.propo_typo = 'T5';
	} else {
            $scope.propo_typo = 'T6';
	}
        
        $scope.$parent.proposedTypology = $filter('filter')($scope.typologies, {typology:$scope.propo_typo})[0];
    }
});

app.component('multiselect', {
    templateUrl: '../../js/angular/components/multiselect/template.html',   
    bindings: {
        leftitems: '=',
        model: '=',
        size: '@',
        optionid: '@',
        optionvalue: '@',
        optiongroup: '@',
    },
    controllerAs: "vm",
    controller: function(){
        var vm = this;
        vm.boxStyle = {};        
        vm.rightitems = [];
        
        vm.$onInit = function(){
            if(!vm.size) {
                vm.size = 18;
            }
            if(vm.size > 15) {
                vm.boxStyle = {'margin-top':'110px'};
            }
        }
        
        vm.moveRight = function($event){
            if(typeof $event != 'undefined' && $event.type == 'dblclick' && $event.target.nodeName.toLowerCase() == 'optgroup') {
                //vm.sfamilies = $filter('filter')(vm.families, vm.pjtFilter, function(families){});
            }          
            for (var i = 0; i < vm.leftBox.length; i++) {
                vm.rightitems.push(vm.leftBox[i]);
            }
            vm.model = vm.rightitems;
            vm.leftBox = [];
        }
        
        vm.moveLeft = function($event){
            if(typeof $event != 'undefined' && $event.type == 'dblclick' && $event.target.nodeName.toLowerCase() == 'optgroup') {
                //vm.sfamilies = $filter('filter')(vm.families, vm.pjtFilter, function(families){});
            }
            for (var i = 0; i < vm.rightBox.length; i++) {
                var removeIndex = vm.rightitems.map(function(item) { return item[vm.optionid]; })
                           .indexOf(vm.rightBox[i][vm.optionid]);
                if(removeIndex == -1) {
                    continue;
                }
                vm.rightitems.splice(removeIndex, 1);
            }
            vm.model = vm.rightitems;
            vm.rightBox = [];
        }
        vm.moveRightAll = function() {
            vm.rightitems = [];
            for (var i = 0; i < vm.leftitems.length; i++) {
                vm.rightitems.push(vm.leftitems[i]);
            }
            vm.model = vm.rightitems;
            vm.leftBox = [];
            vm.rightBox = [];
            vm.leftFilter = '';
            vm.rightFilter = '';
        }
        vm.moveLeftAll = function() {
            vm.rightitems = [];
            vm.leftBox = [];
            vm.rightBox = [];
            vm.leftFilter = '';
            vm.rightFilter = '';
            vm.model = vm.rightitems;
        }
    }
});
