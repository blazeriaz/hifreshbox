<?php
session_start();
require_once("../messages/".$_SESSION['language']."/standard.msg");
require_once("../messages/".$_SESSION['language']."/alertes_js.msg");
$base_path = "http://".$_SERVER['HTTP_HOST']."/";
?>
  // JavaScript Document

  coche = new Image(); coche.src = "../../images/pictos/bt_radio_bouton_on.gif";
  decoche = new Image(); decoche.src = "../../images/pictos/bt_radio_bouton_off.gif";
 
  NAcheck = new Image(); NAcheck.src = "../../images/pictos/checked.png";
  NAuncheck = new Image(); NAuncheck.src = "../../images/pictos/unchecked.png";
  

function select_exgform_checkbox(fieldName,id)
{
	   alert(fieldName);
       alert(id);
}

function exgDeSelectValues(id)
{
    $('#status_NC_'+id).val(0);
    $('#status_NA_'+id).val(0);
    $('#coche_radiobox_NC_'+id).attr("src",decoche.src);
	$('#coche_radiobox_NA_'+id).attr("src",decoche.src);
}

function exgCheckForPercentage(id,obj)
{
    var sum = 0;
    var colors = ["EC","ER","TR"];
    for(var i in colors)
    {
        sum = sum + parseInt($('#status_'+colors[i]+'_'+id).val());
        if(sum>100)
        {
          alert('<?php echo $msg_greater_than_99;?>');
          document.getElementById(obj.id).value=0;
          
          setTimeout(function(){document.getElementById(obj.id).focus();}, 0);
          return false;
        }
    }
}

function select_exgform_radiobox(gridType, fieldName, id)
{
	if(gridType == 2) {
	   if(fieldName == 'NC') {
            $('#status_TR_'+id+', #status_ER_'+id+', #status_EC_'+id+', #status_NA_'+id).val(0);
            $('#status_NC_'+id).val(1);
            $('#coche_radiobox_NC_'+id).attr("src",coche.src);
            $('#coche_radiobox_NA_'+id).attr("src",decoche.src);
       }
       if(fieldName == 'NA') {
            $('#status_TR_'+id+', #status_ER_'+id+', #status_EC_'+id+', #status_NC_'+id).val(0);
            $('#status_NA_'+id).val(1);
            $('#coche_radiobox_NA_'+id).attr("src",coche.src);
            $('#coche_radiobox_NC_'+id).attr("src",decoche.src);
       }
    }
    if(gridType == 1) {
    	var colors = ["EC","ER","TR","NC","NA"];
    	for(var i in colors)
        {
        	if(colors[i]==fieldName)
            {
            	$('#status_'+fieldName+'_'+id).val(1);
                $('#coche_radiobox_'+fieldName+'_'+id).attr("src",coche.src);
            } else {
            	$('#status_'+colors[i]+'_'+id).val(0);
            	$('#coche_radiobox_'+colors[i]+'_'+id).attr("src",decoche.src);
            }
        }
    } 
}
$(function(){
    $(document).on("focus",".jsdate",function(){
        var fieldName = $(this).attr('id');
           $("#"+fieldName).datepicker({                      
                                dateFormat:"dd/mm/yy",
                                changeMonth: true,
                                changeYear: true
                            });
    });
});


$( document ).ready(function() { 
    dialog = $( "#refuse_dialog" ).dialog({
      autoOpen: false,
      height: 270,
      width: 400,
      modal: true,
      buttons: {
        submit: function() {
          if($('#refuselreason').val().trim() == ''){
                alert('please enter value');
                return false;
          }else{
            dialog.dialog( "close" );
            $('form#refuselexgForm').submit();
          }
        },
        Cancel: function() {
          dialog.dialog( "close" );
        }
      }
    });
	$(".legal_readonly_date").datepicker({ dateFormat:"dd/mm/yy", changeMonth: true, changeYear: true});
        $('#validate_selection').click(function(){
              $('form#exg_activity_form input#form_action').val('validate');
              $('form#exg_activity_form').submit();
        });
          $('#refuse_all').click(function(){
             dialog.dialog( "open" );
        });
        
});

function add_exgform_evaluation_grid(path_base,nom_form)
{
	var activity_id = $('.tr_clicked').data('id');
    var exgform_activity_id = $('.tr_clicked').data('exg_act_id');
    
    if(activity_id !='') {
    
    	var grid_type = $('#grid_type').val();
        var exgform_id = $('#current_exgform_id').val();
    	
        saveExchangeFormActivity(path_base, grid_type, exgform_id, 'Edit', '');
        
        open(path_base+"xmlhttprequest/exgform_evaluation_grid.php?action=create&evaluation_activity="+activity_id+"&exgform_activity_id="+exgform_activity_id, "target_modify", "toolbar=0, directories=0, status=1, menubar=0, width=1000, height=600, scrollbars=1, location=0, resizable=1")
    } else {
    	return false;
    }
}

function saveExchangeFormActivity(path_base, grid_type, exgform_id, action_type, form_action) {
	
    var currentTab = $("#tabs").tabs('option', 'active');
    if((action_type == 'Edit' || action_type == 'LeaderValidateView') && currentTab == '1') {
        $.ajax({url: path_base+'xmlhttprequest/ajax_exchange_form.php?action=saveActivity&grid_type='+grid_type+'&exgform_id='+exgform_id+'&action_type='+action_type+'&form_action='+form_action,
            type: "POST",
            data: $("#exg_activity_form").serialize(),
            success: function(output) {
                if(grid_type == '4') {
                    if(output.trim()) {
                        var div = $('<div></div>').addClass('graph_css2');
                        var actData = JSON.parse(output);
                        $.each( actData['color_values'], function( key, value ) {
                          var span = $('<span></span>').addClass('bar intpercent').css({ 'background-color' : "#"+key, 'width' : value+"%" });
                          div.append(span);
                        });
                        $('#'+actData['activity_id']).html(div);
                        if(actData['form_action'] == 'save_draft') {
                        	alert('<?php echo $text_exgform_save_draft_message;?>');
                            return false;
                        }
                    	if(actData['form_action'] == 'send_answer') {
                        	alert('<?php echo $text_exgform_send_answer_message;?>');
                        	 <?php if(!empty($_SESSION['enable_exgform'])) { ?>
                                    window.location.href = "<?php echo $base_path;?>cem/scripts/index.php";
                                <?php } else { ?>
                                    window.location.href = "<?php echo $base_path;?>cem/scripts/scripts_dashboard/dashboard_exchange_form.php?&menu_n1=home&menu_n2=6&action=list_exchange_form";
                                <?php } ?>
                            return false;
                        }
                    }
                } else {
                	if(output.trim()) {
                    	var actData = JSON.parse(output);
                        if(actData['form_action'] == 'save_draft') {
                        	alert('<?php echo $text_exgform_save_draft_message;?>');
                            return false;
                        }
                    	if(actData['form_action'] == 'send_answer') {
                        	alert('<?php echo $text_exgform_send_answer_message;?>');
                                <?php if(!empty($_SESSION['enable_exgform'])) { ?>
                        	window.location.href = "<?php echo $base_path;?>cem/scripts/index.php";
                                <?php } else { ?>
                                window.location.href = "<?php echo $base_path;?>cem/scripts/scripts_dashboard/dashboard_exchange_form.php?&menu_n1=home&menu_n2=6&action=list_exchange_form";
                                <?php } ?>
                            return false;
                        }
                    }
                }
            }
        });
    }
}



function CheckExchangeFormEvaluationGrid(id)
{

	if($('#status_TR_'+id).val()==""){
        $('#status_TR_'+id).val('0');
    }
    if($('#status_ER_'+id).val()==""){
        $('#status_ER_'+id).val('0');
    }
    if($('#status_EC_'+id).val()==""){
        $('#status_EC_'+id).val('0');
    }
    if($('#status_NC_'+id).val()==""){
        $('#status_NC_'+id).val('0');
    }
    if (($('#status_TR_'+id).val()==0 && $('#status_ER_'+id).val()==0 && $('#status_EC_'+id).val()==0 && $('#status_NC_'+id).val()==0) || (($('#status_TR_'+id).val()=="" || $('#status_ER_'+id).val()=="" || $('#status_EC_'+id).val()=="" || $('#status_NC_'+id).val()=="")) || $('#deviation_text_'+id).val()=="")
    {
    	alert("<?php echo $js_alert_evaluation_grid;?>");
        return false;
    }
    /*if(($('#skill_entity_'+id).val().trim()!="") && ($('#skill_entity_'+id).val().trim().length>255))
    {
    	alert("<?php echo $js_alert_skill_entity;?>");
        return false;
    }
    if(($('#deviation_text_'+id).val().trim()!="") && ($('#deviation_text_'+id).val().trim().length>255))
    {
    	alert("<?php echo $js_alert_deviation;?>");
        return false;
    }*/
    
}


function beforeSelectValidateForm(grid_type) {
    if(grid_type == '4') {
        var exg_act_ids = $('#exgform_activity_ids').val();
        if(exg_act_ids !== undefined) {
            var exg_act_data = exg_act_ids.split(';');
            var totalError = 0;
            $.each(exg_act_data,function(key, values){
                var error_status = CheckExchangeFormEvaluationGrid(values);
                if(error_status == false) {
                     totalError = key+1;
                }
            });
            if(totalError == 0) {
                $(this).toggleClass('tr_clicked');
                $(this).siblings().removeClass('tr_clicked');
                return true;
            } else {
                return false;
            }
        } else {
            $(this).toggleClass('tr_clicked');
            $(this).siblings().removeClass('tr_clicked');
            return true;
        }
    } else {
        $(this).toggleClass('tr_clicked');
        $(this).siblings().removeClass('tr_clicked');
        return true;
    }
}

