<?php
session_start();
require_once('../messages/'.$_SESSION['language'].'/alertes_js.msg');
?>

// JavaScript Document
function CheckFormRepository()
{ 
	if (document.form_typology.Flibelle_fr.value.trim()=="")
        return(alert("<?php echo $js_alert_saisie_name_fr;?>"));
        if(document.form_typology.Flibelle_fr.value.length >45 )
        return(alert("<?php echo $js_alert_more_characters_fr;?>"));
 	if (document.form_typology.Flibelle_en.value.trim()=="")
        return(alert("<?php echo $js_alert_saisie_name_en;?>"));
        if(document.form_typology.Flibelle_en.value.length >45 )
        return(alert("<?php echo $js_alert_more_characters_en;?>"));
  document.form_typology.submit();
}
