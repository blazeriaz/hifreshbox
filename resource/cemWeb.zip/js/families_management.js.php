<?php
session_start();
require_once('../messages/'.$_SESSION['language'].'/alertes_js.msg');
?>
// JavaScript Document
function CheckFormFamily()
{ 
  if (document.form_manage_family.FFamily_name_fr.value.trim()=="")
    return(alert("<?php echo $js_alert_name_family_fr;?>"));
  if (document.form_manage_family.FFamily_name_en.value.trim()=="")
    return(alert("<?php echo $js_alert_name_family_en;?>"));
        
document.form_manage_family.submit();
}

function CheckFormSubfamily()
{ 
  if (document.form_manage_subfamily.FSubfamily_name_fr.value.trim()=="")
    return(alert("<?php echo $js_alert_name_subfamily_fr;?>"));
  if (document.form_manage_subfamily.FSubfamily_name_en.value.trim()=="")
    return(alert("<?php echo $js_alert_name_subfamily_en;?>"));
document.form_manage_subfamily.submit();
}


