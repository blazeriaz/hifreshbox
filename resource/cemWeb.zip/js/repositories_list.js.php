<?php
session_start();
require_once('../messages/'.$_SESSION['language'].'/alertes_js.msg');
?>
// JavaScript Document
function CheckFormRepository()
{ 
        if(document.form_repository.Funiverse.value==0 || document.form_repository.Funiverse.value ==''){
            return(alert("<?php echo $js_alert_universe_select;?>"));
        }        
	if (document.form_repository.Flibelle_fr.value==""){
        return(alert("<?php echo $js_alert_saisie_name_fr;?>"));
        }
 	if (document.form_repository.Flibelle_en.value=="")
        return(alert("<?php echo $js_alert_saisie_name_en;?>"));
        
  document.form_repository.submit();
}
