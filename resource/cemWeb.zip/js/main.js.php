<?php
session_start();
require_once("../messages/".$_SESSION['language']."/standard.msg");
require_once("../messages/".$_SESSION['language']."/alertes_js.msg");
$base_path = "http://".$_SERVER['HTTP_HOST']."/";
$delayMsg=1500;
// default path to root
  
  $pathBase='../'; 


  $pathRoot='../../'; 


  $pathPictures='../../images/';

?>
$(document).ready(function(){
$('#dialog_arca_search').dialog({
    autoOpen: false,
    modal: true,
    position: 'center',
    draggable: false,
    width: function(){
        if ($(window).width() < 700) {
            return "95%";
        }
        return "700px";
    },
    buttons: false
});

$('#dialog_activty_update_alert').dialog({
    autoOpen: false,
    modal: true,
    position: 'center',
    draggable: false,
    width: function(){
        return "300px";
    },
    buttons: false
});


$('.js_dialog_arca_search_close', $('#dialog_arca_search')).click(function() {
    $('#dialog_arca_search').dialog("close");
});

$('#dialog_arca_search_fav').dialog({
    autoOpen: false,
    modal: true,
    position: 'center',
    draggable: false,
    width: function(){
        if ($(window).width() < 700) {
            return "95%";
        }
        return "700px";
    },
    buttons: false
});

$('.js_dialog_arca_search_close', $('#dialog_arca_search_fav')).click(function() {
    $('#dialog_arca_search_fav').dialog("close");
});

});
function OpenCenter(pageURL, title,w,h) {
    var left = (screen.width/2)-(w/2);
    var top = (screen.height/2)-(h/2);
    var targetWin = window.open (pageURL, title, 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width='+w+', height='+h+', top='+top+', left='+left);
    return targetWin;
} 

function ControleSaisie_transfert(nom_form)
{ 
//------ Controle saisie -------
  	if (document.forms[nom_form].Fipn_arca_cache.value=="")
        return(alert("<?php echo $js_alert_saisie_arca;?>"));
document.forms[nom_form].submit();
}

function getHTTPObject() {
  var xhr_object;
	if(window.XMLHttpRequest) // Firefox 
	   xhr_object = new XMLHttpRequest(); 
	else if(window.ActiveXObject) // Internet Explorer 
	   xhr_object = new ActiveXObject("Microsoft.XMLHTTP"); 
	else { // XMLHttpRequest non support� par le navigateur 
	   alert("Votre navigateur ne supporte pas les objets XMLHTTPRequest...");
		 return; 
	     }
			 
	  return xhr_object;		  
  }

 var http = getHTTPObject();
 
  if(typeof String.prototype.trim !== 'function') {
            String.prototype.trim = function() {
              return this.replace(/^\s+|\s+$/g, ''); 
            }
          }

function swipeDefault(el, d, e) {
    if(e == "blur" && el.value == "") {
        el.value = d;
    }
    if(e == "focus" && el.value == d) {
        el.value = '';
    }
}
var arca_search_table = null;
var arca_search_fav_table = null;
var form_arca_search_id = "";
function handleHttpResponse_arca_search() {
    if (http.readyState == 4) {
        var results = JSON.parse(http.responseText);
        
        var request = results.request;
        var resData = results.data;
        
        if(results.total >= 300) {
            alert("<?php echo $msg_too_much_lines;?>");
            return;
        }
        
        if(resData.length == 0) {
            alert("No data found!");
            return;
        }
        
        var suffix = "";
        if(request.id) {
          suffix = "_" + request.id;
        }
        form_arca_search_id = request.id;
        
        var dataSet = [];
        for(var i=0;i < resData.length;i++) {
            dataSet[i] = new Array(); 
            dataSet[i][0] = resData[i].nom;
            dataSet[i][1] = resData[i].ipn;
            dataSet[i][2] = resData[i].mail;
            if(suffix == "_fav") {
                dataSet[i][3] = "";
            } else {
                if(resData[i].fav == 1) {
                    dataSet[i][3] = "<div align=\"center\" id=\"dialog_arca_search_fav_"+resData[i].ipn+"\">" +
                            "<a href=\"javascript:deleteARCAFavouriteFromSearch('"+resData[i].ipn+"');\" class=\"info_img_left\">"+
                                "<img src=\"<?php echo $pathPictures; ?>pictos/fav_start_active.png\"><span><?php echo $removeARCAFav; ?></span></a></div>";
                } else {
                    dataSet[i][3] = "<div align=\"center\" id=\"dialog_arca_search_fav_"+resData[i].ipn+"\">" +
                            "<a href=\"javascript:addARCAFavouriteFromSearch('"+resData[i].ipn+"');\" class=\"info_img_left\">"+
                            "<img src=\"<?php echo $pathPictures; ?>pictos/fav_start.png\"><span><?php echo $addARCAFav; ?></span></a></div>";
                }
            }
        }
        
        if(dataSet.length == 1) {
            var data = dataSet[0];
            $("#Fipn_arca_cache" + suffix).val(data[1]);
            $("#Fipn_arca" + suffix).val(data[1]);
            $("#Fnom_arca" + suffix).val(data[0]);
            updateDashboardProgressLinks();
            return;
        }
        
        if($('#dialog_arca_search_fav').dialog("isOpen")) {
            $('#dialog_arca_search_fav').dialog("close");
        }
        
        if(suffix == "_fav") {
            $(".arca_fav_link").hide();
        } else {
            $(".arca_fav_link").show();
        }
        
        if(arca_search_table != null) {
            arca_search_table.destroy();
        }
        arca_search_table = $('.arca_search_table', $('#dialog_arca_search')).DataTable({
            data: dataSet,
            dom : 'fit',
            paging : true,
            pagingType : "simple",
            pageLength : 10, 
            ordering : true, 
            info : false,            
            drawCallback : RnoTableDatadrawCallbackArca,
            language : {
                zeroRecords: "<?php echo $text_no_records_found; ?>",
                emptyTable: "<?php echo $text_no_records_found; ?>"
            }
        } );
        $('#dialog_arca_search').dialog("open");
        
        $('.arca_search_table tbody', $('#dialog_arca_search')).off('click', 'tr');
        $('.arca_search_table tbody', $('#dialog_arca_search')).on('click', 'tr', function (e) {
            if($(e.target).is('a') || $(e.target).parents('a').size() > 0) {
                return;
            }
            var data = arca_search_table.row( this ).data();
            $("#Fipn_arca_cache" + suffix).val(data[1]);
            $("#Fipn_arca" + suffix).val(data[1]);
            $("#Fnom_arca" + suffix).val(data[0]);
            $('#dialog_arca_search').dialog("close");
            if(suffix == "_fav") {
                $('#dialog_arca_search_fav').dialog("open");
            } else {
                updateDashboardProgressLinks();
            }
        });
    }
}

var asf_error_msg_clear = null;
function handleHttpResponse_arca_search_fav() {
    if (http.readyState == 4) {
        var results = JSON.parse(http.responseText);
        
        var request = results.request;
        var resData = results.data;
        
        var suffix = "";
        if(request.id) {
          suffix = "_" + request.id;
        }
        
        if(asf_error_msg_clear !== null) {
            clearTimeout(asf_error_msg_clear);
        }
        
        if(results.success == 1) {
            document.getElementById('Fipn_arca_fav').value='<?php echo $form_arca_ipn; ?>';
            document.getElementById('Fnom_arca_fav').value='<?php echo $form_arca_nom; ?>';
            document.getElementById('Fipn_arca_cache_fav').value='';
            var $div = $('<div class="RnoMessageBox RnoCheckOKMessageBox"></div>');
        } else {
            var $div = $('<div class="RnoMessageBox RnoWarningMessageBox"></div>');
        }
        
        $("#asf_error_msg").html("");
        if(results.message != "") {
            $div.html(results.message);
            $("#asf_error_msg").html($div).show();
        }
        
        asf_error_msg_clear = setTimeout(function(){
            $("#asf_error_msg").fadeOut(function(){
                $(this).html("");
            });
        }, 5000);
        
        var dataSet = [];
        for(var i=0;i < resData.length;i++) {
            dataSet[i] = new Array(); 
            dataSet[i][0] = resData[i].nom;
            dataSet[i][1] = resData[i].ipn;
            dataSet[i][2] = resData[i].mail;
            dataSet[i][3] = "<div align=\"center\">" +
                            "<a href=\"javascript:deleteARCAFavourite('"+resData[i].ipn+"');\" class=\"info_img_left\">"+
                            "<img src=\"<?php echo $pathPictures; ?>pictos/trash.png\"><span><?php echo $removeARCAFav; ?></span></a></div>";
        }
        
        if(arca_search_fav_table != null) {
            arca_search_fav_table.destroy();
        }
               
        arca_search_fav_table = $('.arca_search_table', $('#dialog_arca_search_fav')).DataTable({
            data: dataSet,
            dom : 'fit',
            paging : true,
            pagingType : "simple",
            pageLength : 10, 
            ordering : true, 
            info : false,            
            drawCallback : RnoTableDatadrawCallbackArca,
            language : {
                search:"<?php echo $text_search; ?>&nbsp;:&nbsp;",
                emptyTable: "<?php echo $text_no_records_found; ?>",
                zeroRecords: "<?php echo $text_no_records_found; ?>"
            }
        } );
        $('#dialog_arca_search_fav').dialog("open");
        
        $('.arca_search_table tbody', $('#dialog_arca_search_fav')).off('click', 'tr');
        $('.arca_search_table tbody', $('#dialog_arca_search_fav')).on('click', 'tr', function (e) {        
            if($(e.target).is('a') || $(e.target).parents('a').size() > 0) {
                return;
            }
            var data = arca_search_fav_table.row( this ).data();
            $("#Fipn_arca_cache" + suffix).val(data[1]);
            $("#Fipn_arca" + suffix).val(data[1]);
            $("#Fnom_arca" + suffix).val(data[0]);
            $('#dialog_arca_search_fav').dialog("close");
            updateDashboardProgressLinks();
        });
    }
}

jQuery(document).ready(function($){
    $(".js-link-first", $('#dialog_arca_search')).click(function(){
        arca_search_table.page( 'first' ).draw( 'page' );
    });
    $(".js-link-previous", $('#dialog_arca_search')).click(function(){
        arca_search_table.page( 'previous' ).draw( 'page' );
    });
    $(".js-link-next", $('#dialog_arca_search')).click(function(){
        arca_search_table.page( 'next' ).draw( 'page' );
    });
    /**$(document).keydown(function(e){
        if (arca_search_table != null && $('#dialog_arca_search').dialog('isOpen') === true) {        
            var isNumber = (!e.shiftKey && e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 96 && e.keyCode <= 105);
            var isAlpha = e.keyCode >= 65 && e.keyCode <= 90;
            if ($.inArray(e.keyCode, [46, 8, 32]) !== -1 || isNumber || isAlpha) {
                $('#dialog_arca_search').dialog("close");
            }
        }
    });**/
    
    $(".js-link-first", $('#dialog_arca_search_fav')).click(function(){
        arca_search_fav_table.page( 'first' ).draw( 'page' );
    });
    $(".js-link-previous", $('#dialog_arca_search_fav')).click(function(){
        arca_search_fav_table.page( 'previous' ).draw( 'page' );
    });
    $(".js-link-next", $('#dialog_arca_search_fav')).click(function(){
        arca_search_fav_table.page( 'next' ).draw( 'page' );
    });
});

function RnoTableDatadrawCallbackArca(setting) {
    var api = this.api();
    info = api.page.info();    
    var $parent = $(this.selector).parents(".js_content_block");
    $(".pagination_link", $parent).hide();
    if(info.pages > 1 && info.recordsTotal > 0) {
        if(info.page > 0) {
            $(".js-link-first", $parent).show();
            $(".js-link-previous", $parent).show();
        }
        if((info.page + 1) < info.pages) {
            $(".js-link-next", $parent).show();
        }
    }

    if(info.recordsDisplay == 0) {
        $(".pagination_info_arca", $parent).html("(<?php echo $text_no_element; ?>)");
    } else {
        $(".pagination_info_arca", $parent).html("(" + (info.start + 1) + " - " + info.end + " / " + info.recordsDisplay + ")");
    }
}

function controle_arca_new_search(path_base,form_nom,id) {
  setTimeout("",1000);
  var suffix = "";
  if(id) {
    suffix = "_"+id;
  }
  
  var Fipn_arca = document.getElementById("Fipn_arca"+suffix).value.trim();
  var Fnom_arca = document.getElementById("Fnom_arca"+suffix).value.trim();
  
  if(Fipn_arca == '<?php echo $form_arca_ipn; ?>') {
    Fipn_arca = "";
  }
  if(Fnom_arca == '<?php echo $form_arca_nom; ?>') {
    Fnom_arca = "";
  }  
  
  if(Fipn_arca == "" && Fnom_arca == "") {
    alert("<?php echo $js_alert_saisie_arca;?>");
    return;
  }
  
  if(!(Fipn_arca.length > 3 || Fnom_arca.length > 3)) {
    alert("<?php echo $msg_manque_caracteres; ?>");
    return;
  }
  
  http.open("POST", path_base+"xmlhttprequest/arca_new_search.php?form_nom=" + escape(form_nom)+"&Fipn=" 
                            + escape(Fipn_arca)+"&Fnom=" + escape(Fnom_arca)+"&id="+id, true);
  http.onreadystatechange = handleHttpResponse_arca_search;
  http.send(null);
}

function favourite_arca_search(path_base,form_nom,id) {    
    setTimeout("",1000);
    if($('#dialog_arca_search').dialog("isOpen")) {
        $('#dialog_arca_search').dialog("close");
    }
    if(typeof form_nom === undefined) {
        form_nom = '';
    }
    if(typeof id === undefined) {
        id = form_arca_search_id;
    }
    http.open("POST", path_base+"xmlhttprequest/arca_search_favourite.php?form_nom=" + escape(form_nom)+"&id="+id, true);
    http.onreadystatechange = handleHttpResponse_arca_search_fav;
    http.send(null);
}

var as_error_msg_clear = null;
function handleHttpResponse_arca_fav_add() {
    if (http.readyState == 4) {
        var results = JSON.parse(http.responseText);
        displayMessageArcaSearch(results);
        if(results.success == 1) {
            var html = "<a href=\"javascript:deleteARCAFavouriteFromSearch('"+results.request.new_ipn+"');\" class=\"info_img_left\">"+
                            "<img src=\"<?php echo $pathPictures; ?>pictos/fav_start_active.png\"><span><?php echo $removeARCAFav; ?></a></div>";
            $("#dialog_arca_search_fav_" + results.request.new_ipn).html(html);
        }
    }
}
function handleHttpResponse_arca_fav_delete() {
    if (http.readyState == 4) {
        var results = JSON.parse(http.responseText);
        displayMessageArcaSearch(results);
        if(results.success == 1) {
        var html = "<a href=\"javascript:addARCAFavouriteFromSearch('"+results.request.delete_ipn+"');\" class=\"info_img_left\">"+
                            "<img src=\"<?php echo $pathPictures; ?>pictos/fav_start.png\"><span><?php echo $addARCAFav; ?></a></div>";
            $("#dialog_arca_search_fav_" + results.request.delete_ipn).html(html);
        }
    }
}

function displayMessageArcaSearch(results) {                
    if(as_error_msg_clear !== null) {
        clearTimeout(as_error_msg_clear);
    }

    if(results.success == 1) {
        var $div = $('<div class="RnoMessageBox RnoCheckOKMessageBox"></div>');
    } else {
        var $div = $('<div class="RnoMessageBox RnoWarningMessageBox"></div>');
    }

    $("#as_error_msg").html("");
    if(results.message != "") {
        $div.html(results.message);
        $("#as_error_msg").html($div).show();
    }

    as_error_msg_clear = setTimeout(function(){
        $("#as_error_msg").fadeOut(function(){
            $(this).html("");
        });
    }, 5000);
}

function addARCAFavouriteFromSearch(Fipn_arca) {
    setTimeout("",1000);
    http.open("POST", "<?php echo $pathBase; ?>xmlhttprequest/arca_search_favourite.php?no_list=1&new_ipn="+escape(Fipn_arca), true);
    http.onreadystatechange = handleHttpResponse_arca_fav_add;
    http.send(null);
}

function deleteARCAFavouriteFromSearch(Fipn_arca) {
    setTimeout("",1000);
    http.open("POST", "<?php echo $pathBase; ?>xmlhttprequest/arca_search_favourite.php?no_list=1&delete_ipn="+escape(Fipn_arca), true);
    http.onreadystatechange = handleHttpResponse_arca_fav_delete;
    http.send(null);
}

function addARCAFavourite(path_base,form_nom,id) {
    setTimeout("",1000);
    var Fipn_arca = document.getElementById("Fipn_arca_cache_fav").value.trim();
    if(Fipn_arca == '<?php echo $form_arca_ipn; ?>') {
        Fipn_arca = "";
      }
    if(Fipn_arca == "") {
        $div = $('<div class="RnoMessageBox RnoWarningMessageBox"></div>');
        $div.html("<?php echo $js_alert_saisie_arca;?>");
        $("#asf_error_msg").append($div).show();
        return;
    }
    http.open("POST", "<?php echo $pathBase; ?>xmlhttprequest/arca_search_favourite.php?new_ipn="+escape(Fipn_arca)+"&id="+escape(id), true);
    http.onreadystatechange = handleHttpResponse_arca_search_fav;
    http.send(null);
}

function deleteARCAFavourite(delete_ipn) {
    setTimeout("",1000);
    http.open("POST", "<?php echo $pathBase; ?>xmlhttprequest/arca_search_favourite.php?delete_ipn="+escape(delete_ipn), true);
    http.onreadystatechange = handleHttpResponse_arca_search_fav;
    http.send(null);
}
 
function handleHttpResponse() {
  if (http.readyState == 4) {
    var results = http.responseText.split(',');
	if (results[0]=='OK')
    {
		document.getElementById('Fnom_arca').value = results[1];
		var ipn_arca=document.getElementById('Fipn_arca').value;
		document.getElementById('Fipn_arca_cache').value = trim(ipn_arca.toLowerCase());
			
	}
	else
	{
	  document.getElementById('Fnom_arca').value = '';
      if (results[0]=='KO')
	    document.getElementById('Fipn_arca').value = '<?php echo $js_alert_saisie_ipn_invalide;?>';
      else
	    document.getElementById('Fipn_arca').value = '<?php echo $js_alert_saisie_erreur;?>';
	}
  }
} 
 
function controle_arca(path_base) {
  setTimeout("",1000);
  var rechRapide = document.getElementById("Fipn_arca").value;
  http.open("POST", path_base+"xmlhttprequest/arca_check.php?recherche=" + escape(rechRapide), true);
  http.onreadystatechange = handleHttpResponse;
  http.send(null);
}
  
function recherche_arca(path_base,nom_form)
{
  open(path_base+"xmlhttprequest/arca_search.php?form_nom="+nom_form, "target_modify", "toolbar=0, directories=0, status=1, menubar=0, width=800, height=600, scrollbars=1, location=0, resizable=1")
}



function infos_arca(path_base,ipn)
{
  open(path_base+"common_scripts/arca_id_card.php?ipn="+ipn, "fiche_arca", "toolbar=0, directories=0, status=0, menubar=0, width=600, height=300, scrollbars=0, location=0, resizable=1")
}


/* Recherche par IPN dans un formulaire (liste de taches) */
function recherche_arca_champ(path_base,nom_form,id)
{
  open(path_base+"xmlhttprequest/arca_search.php?form_nom="+nom_form+"&id="+id, "target_modify", "toolbar=0, directories=0, status=1, menubar=0, width=800, height=600, scrollbars=1, location=0, resizable=1")
}

function arca_email_search(path_base,nom_form,id)
{
  open(path_base+"xmlhttprequest/arca_email_search.php?form_nom="+nom_form+"&id="+id, "target_modify", "toolbar=0, directories=0, status=1, menubar=0, width=800, height=600, scrollbars=1, location=0, resizable=1")
}  


function handleHttpResponse_champ() {
  if (http.readyState == 4) {
    var results = http.responseText.split(','); 
    var id_champ=results[2];
    if (results[0]=='OK')
    {
      document.getElementById('Fnom_arca_'+id_champ).value = results[1];
      var ipn_arca=document.getElementById('Fipn_arca_'+id_champ).value;
      document.getElementById('Fipn_arca_cache_'+id_champ).value = trim(ipn_arca.toLowerCase());
    }
    else
    {
      document.getElementById('Fnom_arca_'+id_champ).value = '';
      if (results[0]=='KO')
        document.getElementById('Fipn_arca_'+id_champ).value = '<?php echo $js_alert_saisie_ipn_invalide;?>';
      else
	document.getElementById('Fipn_arca_'+id_champ).value = '<?php echo $js_alert_saisie_erreur;?>';
    }
  }
} 
   
function controle_arca_champ(path_base,id) {
  setTimeout("",1000);
  var rechRapide = document.getElementById("Fipn_arca_"+id).value;
  http.open("POST", path_base+"xmlhttprequest/arca_check.php?recherche=" + escape(rechRapide)+"&id="+id, true);
  http.onreadystatechange = handleHttpResponse_champ;
  http.send(null);
  }
    

var http_checkpoint = getHTTPObject(); 

function handleHttpResponse_checkpoint() {
  if (http_checkpoint.readyState == 4) {
    var results = http_checkpoint.responseText.split(';');
	  if (results[0]!='OK')
	  {
	    alert("<?php echo $js_alert_tag_exists;?>");
	  }
	  document.form_checkpoint.submit();
  }
} 


function check_checkpoint_tag(path_base,template_id) {
  setTimeout("",1000);
  var rechRapide = document.getElementById("Ftag").value;
  var cp_id = document.getElementById("checkpoint_id").value;
  http_checkpoint.open("POST", path_base+"xmlhttprequest/xmlhttprequest_check_checkpoint_tag.php?cp_id="+escape(cp_id)+"&recherche=" + escape(rechRapide)+"&current_template_id="+escape(template_id), true);
  http_checkpoint.onreadystatechange = handleHttpResponse_checkpoint;
  http_checkpoint.send(null);
  }
  
  function submitFormAfterMilestoneFilter() {
  $('#activity_pagination').val(0);
    if($("#update_form_fileds").size() > 0 && $("#update_form_fileds").val() == 1){
        document.form_sauve_activite.dash_board_referrer.value='filter';
         $('#dialogg').dialog({
               autoOpen: true,
               modal: true,
               position: 'center',
               draggable: false,
               width: '30%',
               buttons: false,
               close: clearOnDialogClose
           });
           return false;
    }else{
        
        document.form_sauve_activite.submit();
    }
  }

  function advanced_filter(filterData) {
    document.form_sauve_activite.action.value='default';
    if($('#filter_topic').val() != 'all'){
        document.form_sauve_activite.selected_topic.value = $('#filter_topic').val();
    }
     if($('#filter_department').val()){
        document.form_sauve_activite.filter_department.value = $('#filter_department').val();
     }
     if($('#filter_stakeholder').val()){
        document.form_sauve_activite.filter_stakeholder.value = $('#filter_stakeholder').val();
     }
     if($('#filter_stakeholder_ipn').val()){
        document.form_sauve_activite.filter_stakeholder_ipn.value = $('#filter_stakeholder_ipn').val();
     }
     if($('#filter_action_plan_ipn').val()){
        document.form_sauve_activite.filter_action_plan_ipn.value = $('#filter_action_plan_ipn').val();
     }
     if(filterData == "Topic"){
        if($('#filter_department').val()){
            document.form_sauve_activite.filter_department.value = '';
        }
        if($('#filter_stakeholder').val()){
            document.form_sauve_activite.filter_stakeholder.value = '';
        }
        if($('#filter_stakeholder_ipn').val()){
            document.form_sauve_activite.filter_stakeholder_ipn.value = '';
        }
        if($('#filter_action_plan_ipn').val()){
            document.form_sauve_activite.filter_action_plan_ipn.value = '';
        }
     }
     
     
       submitFormAfterMilestoneFilter();
  }
  
  function clearOnDialogClose() {
        $('.js_dialog_block').removeClass('js_link_navi');
        $('.js_dialog_block').removeClass('js_link_topic');
        $('.js_link_active').removeClass('js_link_active');
        $(".js_actvity_pagination_link select[name='pageLimit']").val($('#activity_pagination_limit').val());
        document.form_sauve_activite.dash_board_referrer.value="";
    }
  
  function ClearFilterData(ClearData) { 
   if($('#filter_topic').val() != 'all'){
        document.form_sauve_activite.selected_topic.value = $('#filter_topic').val();
    }
    if($('#filter_department').val()){
       document.form_sauve_activite.filter_department.value = $('#filter_department').val();
    }
    if($('#filter_stakeholder').val()){
       document.form_sauve_activite.filter_stakeholder.value = $('#filter_stakeholder').val();
    }
    if($('#filter_stakeholder_ipn').val()){
       document.form_sauve_activite.filter_stakeholder_ipn.value = $('#filter_stakeholder_ipn').val();
    }
    if($('#filter_action_plan_ipn').val()){
       document.form_sauve_activite.filter_action_plan_ipn.value = $('#filter_action_plan_ipn').val();
    }
    if(ClearData == 'Department'){
        document.form_sauve_activite.filter_department.value = '';
    }else if(ClearData == 'Roles'){
        document.form_sauve_activite.filter_stakeholder.value = '';
    }else if(ClearData == 'Stakeholder'){
        document.form_sauve_activite.filter_stakeholder_ipn.value = '';
    }else if(ClearData == 'ActionPlan'){
        document.form_sauve_activite.filter_action_plan_ipn.value = '';
    }else if(ClearData == 'ROV'){
        $(".filter_check").prop('checked',false);
    }
    
     submitFormAfterMilestoneFilter();
  }
  
   function ResetData() { 
   if($('#filter_topic').val()){
        default_value = $('#filter_topic option:eq(1)').attr('value')
        $('#filter_topic').val(default_value);
        document.form_sauve_activite.selected_topic.value = default_value;
    }
    if($('#filter_department').val()){
       document.form_sauve_activite.filter_department.value = '';
    }
    if($('#filter_stakeholder').val()){
       document.form_sauve_activite.filter_stakeholder.value = '';
    }
    if($('#filter_stakeholder_ipn').val()){
       document.form_sauve_activite.filter_stakeholder_ipn.value = '';
    }
    if($('#filter_action_plan_ipn').val()){
       document.form_sauve_activite.filter_action_plan_ipn.value = '';
    }
    $(".filter_check").prop('checked',false);
    
     submitFormAfterMilestoneFilter();
  }
  function NoActionPlan(el) {
    if($(el).prop('checked') == true){
      document.form_sauve_activite.no_action_plan.value = 1;
    }else{
      document.form_sauve_activite.no_action_plan.value = 0;
    } 
    return false;
  }
  function WithProofs(el){
    if($(el).prop('checked') == true){
      document.form_sauve_activite.with_proofs.value = 1;
    }else{
      document.form_sauve_activite.with_proofs.value = 0;
    } 
    return false;
  }
  
  function CheckFormFeedback(){
    if (document.form_add_feedback.feedback_comment.value.trim()=="")
        return(alert("<?php echo $js_fill_feedback;?>"));
    document.form_add_feedback.submit();
  }
  
  function add_feedback(path_base,nom_form,activity_id){
    open(path_base+"xmlhttprequest/arca_search.php?form_name="+nom_form+"&activity_id="+activity_id, "target_modify", "toolbar=0, directories=0, status=1, menubar=0, width=800, height=600, scrollbars=1, location=0, resizable=1")
  }
  
$(document).ready(function(){
    var ajax_dashboard_submit = false;
    $('form.js_tdb_create').submit(function(e){
        if(ajax_dashboard_submit){
            return true;
        }
        var datastring = $(this).serialize();
        var urlData = getUrlVars();
        var repId = urlData['sel_rep_id'];
        var instid = 0;
        if((urlData['instance_id'])){
            var instid = urlData['instance_id'];
        }
        if(repId){
            $.ajax({
                type: "POST",
                url: $('#pathbase').html()+'xmlhttprequest/ajax_check_duplicate.php?rep_id='+repId+'&instid='+instid,
                data:datastring,
                success: function(output) {
                  var res = $.parseJSON(output);

                  if(res['tdb']){
                    $('span.js_repository_name').html(res['rep']);
                    $('span.js_project_name').html(res['prj']);
                    $('span.js_family_name').html(res['family']);
                    $('span.js_subfamily_name').html(res['subfamily']);
                    var len = res['count'];
                    $('span.js-dashboardid').html('');
                    $.each(res['tdb'], function(key,value){
                        var com =',';
                        if(key == parseInt(len)){
                            var com = '';
                        }
                        $("<a />", {
                            text: value+com,
                            href:"scripts_dashboard/dashboard.php?action=init_session&menu_n1=home&menu_n2=1&dashboard_id="+value+"#!/view/"+value,
                            target:"_blank"
                        }).appendTo(".js-dashboardid");
                    });
                    
                     $('#dialog_dashboard_alert').dialog( "open" );
                  }else{
                    ajax_dashboard_submit = true;
                    $('form.js_tdb_create').submit();
                  }
                  
                }
            });
        }
        e.preventDefault(e);
               
    });
    
    $('a#js_dashbard_create').click(function(){
            ajax_dashboard_submit = true;
            $('form.js_tdb_create').submit();
    });
    
    $('#dialog_dashboard_alert,#js_contributor_dialog').dialog({
        autoOpen: false,
        modal: true,
        position: 'center',
        draggable: false,
        width: '30%',
        buttons: false
    });
    
      $('a.js_porject').click(function() {
        var prjId = $(this).attr('id');
        var href = $(this).attr('href');
        $('#dashbard_create').attr('href',$(this).attr('href'));
        $.ajax({url: $('#pathbase').html()+'xmlhttprequest/ajax_get_dashboards.php?action=dashboard_prj_count&prj_id='+prjId,
               success: function(output) {
                  if(output > 0){
                     $('#dialog_dashboard_alert').dialog( "open" );
                     return false;
                  }else{
                    window.location.href  = href;
                  }
              }
            });
           return false;
    });
    
$('a.js_subfamily').click(function() {
      
        var famId = $(this).attr('id').split('_')[0];
        var prjId = $(this).attr('id').split('_')[1];
        var href = $(this).attr('href');
        $('#dashbard_create').attr('href',$(this).attr('href'));
        $.ajax({url: $('#pathbase').html()+'xmlhttprequest/ajax_get_dashboards.php?action=dashboard_count&prj_id='+prjId+'&subfamily_id='+famId,
               success: function(output) {
                  if(output > 0){
                     $('#dialog_dashboard_alert').dialog( "open" );
                     return false;
                  }else{
                    window.location.href  = href;
                  }
              }
            });
           return false;
    });
    
    $('#popup_cancel').click(function() {
        $('#dialog_dashboard_alert').dialog( "close" );
    });
    
    
    $(document.body).on('click','.js-link-gsper-alert',function() {  
    var target_url = $(this).attr("href");
    
    language_path = "<?php echo $base_path;?>";
    language_change_path = language_path+target_url;
    $( "#dialog_gsper_alert" ).dialog( "open" );
            return false;
        
    });
     $('#dialog_gsper_alert').dialog({
        autoOpen: false,
        modal: true,
        position: 'center',
        draggable: false,
        width: '30%',
        buttons: false
    });
    
    
    $('.js_dialog_gsper_ok').click(function() {
       
          window.location.assign(language_change_path);         
    
    });
    
    $('.js_dialog_gsper_close').click(function() {
         $('#dialog_gsper_alert').dialog("close");
    });
 

$.sessionTimeOut = false;
//checkActivity(120000, 60000, 0); // timeout = 30 minutes, interval = 1 minute.
//checkTimeOut();
 <?php if(!isset($_SESSION['liste_action_activity_id']))  { ?>
   /* This code is executed after the DOM has been completely loaded */
  $('#eraseDecision').click(function(){
   $('.screenshot_decision').prop('checked',false);     
  });  
    if($('#filtre_topic').length>1){
        $('#filtre_topic').html("");     
        $.ajax({url: $('#pathbase').html()+'xmlhttprequest/ajax_get_topics.php?action=loadtopic&selected_milestone_id=<?php echo (isset($_SESSION['filtre_milestone']) ? $_SESSION['filtre_milestone'] :'');?>&object_ref=<?php echo (isset($_SESSION['filtre_topic']) ? $_SESSION['filtre_topic'] :'');?>',
             success: function(output) {
                $('#filtre_topic').html(output);
                }
        });
    }
        
    $('#filtre_milestone').change(function() {
        var parent = $(this).val();
        $('#filtre_topic').html("");
        $.ajax({url: $('#pathbase').html()+'xmlhttprequest/ajax_get_topics.php?action=loadtopic&selected_milestone_id='+parent+'&object_ref=<?php echo (isset($_SESSION['filtre_topic']) ? $_SESSION['filtre_topic'] :'');?>',
             success: function(output) {
                $('#filtre_topic').html(output);
                }
          });
    }); 
    <?php /**
    Lot 1620 Changes
    Ajax get families while changing repository
    Modified By : Venkatesh Periyasamy
    **/ /** ?>
    $('#filtre_repository').change(function() {
        var repository = $(this).val();
        if($('#filtre_all_db_projects').size() > 0) {
            $('#filtre_all_db_projects').html("");
            $.ajax({
                url: $('#pathbase').html()+'xmlhttprequest/ajax_get_projects.php?action=loadprojects&selected_rep_id='+repository,
                success: function(output) {
                    $('#filtre_all_db_projects').html(output);
                }
            });
        }     
        if($('#filtre_all_db_families').size() > 0) {
            $('#filtre_all_db_families').html("");
            $.ajax({
                url: $('#pathbase').html()+'xmlhttprequest/ajax_get_families.php?action=loadfamilies&selected_rep_id='+repository,
                success: function(output) {
                    $('#filtre_all_db_families').html(output);
                }
            });
        }
    })
    <?php **/ /** END **/ ?>
 
    if($('#filtre_topic_feedback').length>1){
        $('#filtre_topic_feedback').html("");
        $.ajax({url: $('#pathbase').html()+'xmlhttprequest/ajax_get_topics.php?action=loadtopic&selected_milestone_id=<?php echo (isset($_SESSION['filtre_milestone_feedback']) ? $_SESSION['filtre_milestone_feedback'] :'');?>&object_ref=<?php echo (isset($_SESSION['filtre_topic_feedback']) ? $_SESSION['filtre_topic_feedback'] :'');?>',
             success: function(output) {
                $('#filtre_topic_feedback').html(output);
                }
        });
    }
        
    $('#filtre_milestone_feedback').change(function() {
        var parent = $(this).val();
        $('#filtre_topic_feedback').html("");
        $.ajax({url: $('#pathbase').html()+'xmlhttprequest/ajax_get_topics.php?action=loadtopic&selected_milestone_id='+parent+'&object_ref=<?php echo (isset($_SESSION['filtre_topic_feedback']) ? $_SESSION['filtre_topic_feedback'] :'');?>',
             success: function(output) {
                $('#filtre_topic_feedback').html(output);
                }
          });
    });
    if($('#filtre_topic_rep_feedback').length>1){
        $('#filtre_topic_rep_feedback').html("");
        $.ajax({url: $('#pathbase').html()+'xmlhttprequest/ajax_get_topics.php?action=loadtopic&selected_milestone_id=<?php echo (isset($_SESSION['filtre_milestone_rep_feedback']) ? $_SESSION['filtre_milestone_rep_feedback'] :'');?>&object_ref=<?php echo (isset($_SESSION['filtre_topic_rep_feedback']) ? $_SESSION['filtre_topic_rep_feedback'] :'');?>',
             success: function(output) {
                $('#filtre_topic_rep_feedback').html(output);
                }
        });
    }
    
    $('#filtre_milestone_rep_feedback').change(function() {
        var parent = $(this).val();
        $('#filtre_topic_rep_feedback').html("");
        $.ajax({url: $('#pathbase').html()+'xmlhttprequest/ajax_get_topics.php?action=loadtopic&selected_milestone_id='+parent+'&object_ref=<?php echo (isset($_SESSION['filtre_topic_rep_feedback']) ? $_SESSION['filtre_topic_rep_feedback'] :'');?>',
             success: function(output) {
                $('#filtre_topic_rep_feedback').html(output);
                }
          });
    });
    if($('#filtre_milestone_rep_feedback').length>1){
        $('#filtre_milestone_rep_feedback').html();
        $.ajax({url: $('#pathbase').html()+'xmlhttprequest/ajax_get_milestones.php?action=loadtopic&selected_revision_id=<?php echo (isset($_SESSION['filtre_rep_version']) ? $_SESSION['filtre_rep_version'] :'');?>',
            success: function(output) {
               $('#filtre_milestone_rep_feedback').html(output);
               }
        });
    }
    $('#filtre_rep_version').change(function() {
        var parent = $(this).val();
        $('#filtre_milestone_rep_feedback').html();
        $.ajax({url: $('#pathbase').html()+'xmlhttprequest/ajax_get_milestones.php?action=loadtopic&selected_revision_id='+parent,
             success: function(output) {
                $('#filtre_milestone_rep_feedback').html(output);
                }
          });
          
        $('#filtre_topic_rep_feedback').html("");
        $.ajax({url: $('#pathbase').html()+'xmlhttprequest/ajax_get_topics.php?action=loadtopic',
             success: function(output) {
                $('#filtre_topic_rep_feedback').html(output);
                }
          });
    });      
    $('a.repository_activate').click(function() {
        var $this = $(this);
        $this.parents(".SubmitButtonBlock").addClass("disabled");
        $('form#form_commit_rep_versiont #action').val('commit_repository');
        $.ajax({url: $('#pathbase').html()+'xmlhttprequest/ajax_check_dashboards.php?repository_id=10',
             async:false,
             success: function(output) {
                 if(output!=0){
                    var msg = '<?php echo $msg_confirm_dashboard_change;?>';
                    msg = msg.replace('#count',output);
                    if(confirm(msg))
                    {
                     $('form#form_commit_rep_versiont #action').val('confirm_dashboard_change');
                    }
                    document.form_commit_rep_versiont.submit();
                 }else{
                  document.form_commit_rep_versiont.submit();
                  
                 }
               }
          });
          return false;
    });      
    

 
    $('#filtre_my_db_rep').change(function() {
        var parent = $(this).val();
        $.ajax({url: $('#pathbase').html()+'xmlhttprequest/ajax_get_projects.php?action=loadprojects_home&selected_rep_id='+parent,
             success: function(output) {
                $('#filtre_my_db_projects').html(output);
                }
          });
    });
    
    $(".js_actvity_pagination_link select[name='pageLimit']").change(function(){
        var pageLimit = $(this).val();
        
        if($("#update_form_fileds").size() > 0 && $("#update_form_fileds").val() == 1) {
            $('.js_dialog_block').removeClass('js_link_topic').addClass('js_link_navi');
                $this = $(this);
                
                document.form_sauve_activite.dash_board_referrer.value= "dashboard_progress_review.php?milestone_dashboard_view_activities=0&milestone_dashboard_view_activities_limit="+pageLimit;
            $('#dialogg').dialog({
                autoOpen: true,
                modal: true,
                position: 'center',
                draggable: false,
                width: '30%',
                buttons: false,
                close: clearOnDialogClose
            });
            return false;
        } else {
            $('#activity_pagination').val(0);
            $('#activity_pagination_limit').val(parseInt(pageLimit));
            document.form_sauve_activite.submit();
            return false;
        }
    });
    
    $('.js_actvity_pagination_link a').click(function() {
      $this = $(this);
          document.form_sauve_activite.action.value='default';
    if($('#filter_topic').val() != 'all'){
        document.form_sauve_activite.selected_topic.value = $('#filter_topic').val();
    }
     if($('#filter_department').val()){
        document.form_sauve_activite.filter_department.value = $('#filter_department').val();
     }
     if($('#filter_stakeholder').val()){
        document.form_sauve_activite.filter_stakeholder.value = $('#filter_stakeholder').val();
     }
     if($('#filter_stakeholder_ipn').val()){
        document.form_sauve_activite.filter_stakeholder_ipn.value = $('#filter_stakeholder_ipn').val();
     }
     if($('#filter_action_plan_ipn').val()){
        document.form_sauve_activite.filter_action_plan_ipn.value = $('#filter_action_plan_ipn').val();
     }
     var perpage = parseInt($('#activity_pagination_limit').val()); 
        var page_value = parseInt($('#activity_pagination').val()); 
        if($(this).hasClass('js-link-previous')){
            if($(this).hasClass('js-first-page')){
                $('#activity_pagination').val(0); 
            }else{
               var pagination =  parseInt(page_value) - perpage;
               $('#activity_pagination').val(pagination); 
            }
        }
          document.form_sauve_activite.dash_board_referrer.value=$this.attr('href');
        if($(this).hasClass('js-link-next')){
            var pagination =  parseInt(page_value)+perpage;
            $('#activity_pagination').val(pagination); 
          
        }
        if($("#update_form_fileds").val() == 1){
            $('.js_dialog_block').removeClass('js_link_topic').addClass('js_link_navi');
            $this.addClass('js_link_active');
            document.form_sauve_activite.dash_board_referrer.value=$this.attr('href');
            $('#dialogg').dialog({
                   autoOpen: true,
                   modal: true,
                   position: 'center',
                   draggable: false,
                   width: '30%',
                   buttons: false
               });
               return false;
        }
  
     
     document.form_sauve_activite.submit();
     return false;
    });
    $("#sel_tpl_id").trigger('change');
		
 <?php }  ?>
});

function CheckFormItem()
{ 
 	if (document.form_item.Fname_fr.value=="")
        return(alert("<?php echo $js_alert_saisie_name_fr;?>"));
  	if (document.form_item.Fname_en.value=="")
        return(alert("<?php echo $js_alert_saisie_name_en;?>"));
        
document.form_item.submit();
}
function add_action_plan(path_base,nom_form,activity_id,eval_id,milestone_stat){
    if(eval_id)
    {
        open(path_base+"xmlhttprequest/action_plan.php?action=create_action_plan&liste_action_activity_id="+activity_id+"&evaluation_id="+eval_id+"&milestone_status="+milestone_stat, "target_modify", "toolbar=0, directories=0, status=1, menubar=0, width=800, height=600, scrollbars=1, location=0, resizable=1")
    }
    else
    {
        open(path_base+"xmlhttprequest/action_plan.php?action=create_action_plan&liste_action_activity_id="+activity_id, "target_modify", "toolbar=0, directories=0, status=1, menubar=0, width=800, height=600, scrollbars=1, location=0, resizable=1")
    }
  }
  
  function liste_action_plan(path_base,activity_id,status,eval_id){
    if(eval_id)
    {
        open(path_base+"xmlhttprequest/action_plan.php?action=liste_action_plan&liste_action_activity_id="+activity_id+"&milestone_status="+status+"&evaluation_id="+eval_id, "target_modify", "toolbar=0, directories=0, status=1, menubar=0, width=800, height=600, scrollbars=1, location=0, resizable=1")
    }
    else
    {
        open(path_base+"xmlhttprequest/action_plan.php?action=liste_action_plan&liste_action_activity_id="+activity_id+"&milestone_status="+status, "target_modify", "toolbar=0, directories=0, status=1, menubar=0, width=800, height=600, scrollbars=1, location=0, resizable=1")
    }
  }
  
function recherche_arca_action(path_base,nom_form)
{
  open(path_base+"xmlhttprequest/arca_search.php?form_nom="+nom_form, "_blank", "toolbar=0, directories=0, status=1, menubar=0, width=800, height=600, scrollbars=1, location=0, resizable=1")
}

function CheckFormActionPlan()
{
    if (document.form_sauve_action_plan.activity_action.value.trim()=="" && document.form_sauve_action_plan.Fnom_arca.value.trim()=="" && document.form_sauve_action_plan.activite_due_date.value.trim()=="")
    {
        return(alert("<?php echo $js_alert_saisie_fill_any;?>"));
    }
         
document.form_sauve_action_plan.submit();
}

function AjaxFormcreateActionPlan(path_base,count)
{
    var parentWindow = window.opener;
    $.ajax({
        url:path_base+"xmlhttprequest/ajax_action_plan.php?action=insertaction&count="+count+'&activity_id=<?php echo (isset($_SESSION['liste_action_activity_id']) ? $_SESSION['liste_action_activity_id'] :'');?>',
        sync:false,
        success: function(output) {
         if(output)
         {
              $messageArea = parentWindow.$('#hyperlink_<?php echo (isset($_SESSION['liste_action_activity_id']) ? $_SESSION['liste_action_activity_id'] :'');?>');
              $messageArea.html(output);
         }
        }
    });
    $('.RnoCheckOKMessageBox').delay(2000).slideUp("slow");
   
}

function AjaxActionplanupdate(path_base,action_id,action,count)
{
    var parentWindow = window.opener;
          $.ajax({
              url:path_base+'xmlhttprequest/ajax_action_plan.php?action='+action+'&action_id='+action_id+'&count='+count,
              success: function(output) {
               if(output)
               {
                    if(action_id=='')
                    {
                        $messageArea = parentWindow.$('#hyperlink_<?php echo (isset($_SESSION['liste_action_activity_id']) ? $_SESSION['liste_action_activity_id'] :'');?>');
                    }
                    else
                    {
                        $messageArea = parentWindow.$('#actionplan_<?php echo (isset($_SESSION['liste_action_activity_id']) ? $_SESSION['liste_action_activity_id'] :'');?>');
                    }
                    $messageArea.html(output);
               }
              }
          });
    $('.RnoCheckOKMessageBox').delay(<?php echo $delayMsg;?>).slideUp("2000");
    
    if(count==0 && action=='deleteaction')
    {
        setTimeout(function() {
        javascript:window.close();
        }, 2000);
    }
 /*   if(action == 'deleteaction')
    {
        url = document.URL;
        url = url.replace('delete_action_plan','');
        location.replace(url);
    }*/
}

function datepicker()
{
    $("#activite_due_date").datepicker({                      
                                dateFormat:"dd/mm/yy",
                                changeMonth: true,
                                changeYear: true
                            });
}

function save_activity_evaluation(target)
{
   var eval = $('#activity_eval').val();
   var choice = '';
   if(eval == 1)
   {
      choice = ' <?php echo $text_color;?>';
   }else if(eval == 2)
   {
      choice = ' <?php echo $text_percentage;?>';
   }else if(eval == 4)
   {
      choice = ' <?php echo $text_evaluation_grid;?>';
   }else if(eval == 3)
   {
      choice = ' <?php echo $text_integer;?>';
   }
   alert('<?php echo $msg_confirm_activity_evaluation;?>'+choice)
    var url = target;
    url = url +'&action=save&evaluation='+eval;
    location.replace(url);
}

function checkForPercentage(activity,obj)
{
    var sum = 0;
    var colors = ["EC","ER","TR"];
    for(var i in colors)
    {
        sum = sum + parseInt($('#status_'+colors[i]+'_'+activity).val());
        
        if(sum>100)
        {
          alert('<?php echo $msg_greater_than_99;?>');
          document.getElementById(obj.id).value=0;
          
          setTimeout(function(){document.getElementById(obj.id).focus();}, 0);
          return false;
        }
        
    }
}

function deselectStatusPercentage(activity)
{
    $('#status_NC_'+activity).val(0);
    $('#status_NA_'+activity).val(0);
    document.images['coche'+activity+'_NC'].src=decoche.src;
    document.images['coche'+activity+'_NA'].src=decoche.src;
}

function deselectStatusInteger(activity)
{
    $('#status_NA_'+activity).val(0);
    document.images['coche'+activity+'_NA'].src=decoche.src;
}

function confirm_Dashboard_Change(count,target)
{   
    var msg = '<?php echo $msg_confirm_dashboard_change;?>';
    msg = msg.replace('#count',count);
    var url = target;
    if(count==0)
    {
        url = url +'&action=commit_repository';
    }
    else
    {
        if(confirm(msg))
        {
            url = url +'&action=confirm_dashboard_change';
        }
        else
        {
            url = url +'&action=commit_repository';
        }
    }
    location.replace(url);

}

function save_activity_backlog(target)
{
   var backlog = $('#activity_backlog').val();
    var url = target;
    url = url +'&action=save_backlog&backlog='+backlog;
    location.replace(url);
}

function save_project_context_settings(target)
{
   var context_setting = $('#project_context_settings').val();
    var url = target;
    url = url +'&action=save_context_setting&contextstatus='+context_setting;    
    location.replace(url);
}

function validate_project_context()
{
   var res=0;
   var elems = document.getElementsByClassName('context_item_value');
   for (var i = 0; i < elems.length; ++i)
   {
     if(elems[i].value == '') { res = 1; }        
   }
   
   if(res == 1) { alert("<?php echo $js_alert_context_items_value;?>"); } else { document.FormContextitems.submit() }
   
}

function remove_ipn_role(role)
{
     $.ajax({url: $('#pathbase').html()+'xmlhttprequest/ajax_remove_ipn_role.php?role='+role,
             success: function(output) {
             }
             });
}

function save_gesper_settings(target)
{
	var url = target;
	var gesper_val = $('#gesper_settings').val();
    if(gesper_val == 1) {
        $.ajax({url: $('#pathbase').html()+'xmlhttprequest/ajax_gesper_settings.php?action=checkTypoCount',
             success: function(output) {
                if(output == 1) {
                    alert('<?php echo $text_gesper_count_alert;?>');
                    $("#gesper_settings").val(0);
                    return  false;
                } else {
                   url = url +'&action=save_gesper&gesper_value='+gesper_val;
                   location.replace(url);
                }
             }
        });
    } else {
    	url = url +'&action=save_gesper&gesper_value='+gesper_val;
        location.replace(url);
    }
    return  false;
}

function check_gesper_settings(tempID,repID)
{
      $.ajax({url: $('#pathbase').html()+'xmlhttprequest/ajax_gesper_settings.php?action=checkTempStatus&rep_id='+repID+'&temp_id='+tempID,
            success: function(output) {
                if(output == 'gesperEnabled') {
                    $("#temp_form").attr("action", "dashboard_generator.php?&action=choose_default_typology&sel_rep_id=" + repID);
                } else if(output == 'gesperDisabled') {
                    $("#temp_form").attr("action", "dashboard_generator.php?&action=choose_typology&sel_rep_id=" + repID);
                } else if(output == 'noTemplates') {
                    $("#temp_form").attr("action", "dashboard_generator.php?&action=choose_project&sel_rep_id=" + repID);
                } 
            }            
           
      });
      
      
}

function CheckFormEvaluationGrid()
{

    if(document.form_sauve_evaluation_grid.status_TR.value ==""){
        document.form_sauve_evaluation_grid.status_TR.value = 0;
    }
    if(document.form_sauve_evaluation_grid.status_ER.value ==""){
        document.form_sauve_evaluation_grid.status_ER.value = 0;
    }
    if(document.form_sauve_evaluation_grid.status_EC.value ==""){
        document.form_sauve_evaluation_grid.status_EC.value = 0;
    }
    if(document.form_sauve_evaluation_grid.status_NC.value ==""){
        document.form_sauve_evaluation_grid.status_NC.value = 0;
    }
    if (document.form_sauve_evaluation_grid.status_TR.value==0 && 
        document.form_sauve_evaluation_grid.status_ER.value==0 && 
        document.form_sauve_evaluation_grid.status_EC.value==0 &&
        document.form_sauve_evaluation_grid.status_NC.value==0)
    {
        return(alert("<?php echo $js_alert_evaluation_grid;?>"));
    }
    
    if(document.form_sauve_evaluation_grid.skill_entity.value.trim()==""){
        var a = 0;
        if(document.form_sauve_evaluation_grid.status_TR.value!=0 &&
        document.form_sauve_evaluation_grid.status_ER.value ==0 &&
        document.form_sauve_evaluation_grid.status_EC.value ==0 &&
         document.form_sauve_evaluation_grid.status_NC.value ==0)
        {
                a=1;
        }
       
        if(a==0){
            return(alert("<?php echo $js_alert_evaluation_grid;?>"));
        }
    }
    if(document.form_sauve_evaluation_grid.skill_entity.value.trim()!="" && document.form_sauve_evaluation_grid.skill_entity.value.length>255)
    {
        return(alert("<?php echo $js_alert_skill_entity;?>"));
    }
    if(document.form_sauve_evaluation_grid.activity_deviation.value.trim()!="" && document.form_sauve_evaluation_grid.activity_deviation.value.length>255)
    {
        return(alert("<?php echo $js_alert_deviation;?>"));
    }
        
document.form_sauve_evaluation_grid.submit();
}

function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}

function AjaxFormcreateEvaluation(path_base,count)
{
    var parentWindow = window.opener;
    $.ajax({
        url:path_base+"xmlhttprequest/ajax_evaluation_grid.php?action=insertaction&count="+count+'&activity_id=<?php echo (isset($_SESSION['evaluation_activity']) ? $_SESSION['evaluation_activity'] :'');?>',
        async:false,
        success: function(output) {
         if(output)
         {
            if(output!=' ')
            {
               output = jQuery.parseJSON(output);

                    parentWindow.$('#status_TR_'+output.ID).val(output.GREEN);
                    parentWindow.$('#status_ER_'+output.ID).val(output.RED);
                    parentWindow.$('#status_EC_'+output.ID).val(output.ORANGE);
                    parentWindow.$('#status_NC_'+output.ID).val(output.WHITE);
                    parentWindow.$('#status_hidden_TR_'+output.ID).val(output.GREEN);
                    parentWindow.$('#status_hidden_ER_'+output.ID).val(output.RED);
                    parentWindow.$('#status_hidden_EC_'+output.ID).val(output.ORANGE);
                    parentWindow.$('#status_hidden_NC_'+output.ID).val(output.WHITE);
                    $messageArea = parentWindow.$('#hyperlink_eval_'+output.ID);
                    $messageArea.html(output.LINK);
                    
                    $updateTextArea = parentWindow.$('#timestamp_activity_html_'+output.ID);
                    if($updateTextArea.size() > 0) {
                        $updateTextArea.html(output.update_text);
                    }
                    $updateDateInput = parentWindow.$("[name=\'timestamp_activity_'+output.ID+'\'']");
                    if($updateDateInput.size() > 0) {
                        $updateDateInput.val(output.date_update);
                    }
             }
             else
             {
                    parentWindow.$('#status_TR_<?php echo (isset($_SESSION['evaluation_activity']) ? $_SESSION['evaluation_activity'] :'');?>').val(0);
                    parentWindow.$('#status_ER_<?php echo (isset($_SESSION['evaluation_activity']) ? $_SESSION['evaluation_activity'] :'');?>').val(0);
                    parentWindow.$('#status_EC_<?php echo (isset($_SESSION['evaluation_activity']) ? $_SESSION['evaluation_activity'] :'');?>').val(0);
                    parentWindow.$('#status_NC_<?php echo (isset($_SESSION['evaluation_activity']) ? $_SESSION['evaluation_activity'] :'');?>').val(0);
                    parentWindow.$('#status_hidden_TR_<?php echo (isset($_SESSION['evaluation_activity']) ? $_SESSION['evaluation_activity'] :'');?>').val(0);
                    parentWindow.$('#status_hidden_ER_<?php echo (isset($_SESSION['evaluation_activity']) ? $_SESSION['evaluation_activity'] :'');?>').val(0);
                    parentWindow.$('#status_hidden_EC_<?php echo (isset($_SESSION['evaluation_activity']) ? $_SESSION['evaluation_activity'] :'');?>').val(0);
                    parentWindow.$('#status_hidden_NC_<?php echo (isset($_SESSION['evaluation_activity']) ? $_SESSION['evaluation_activity'] :'');?>').val(0);
                    $messageArea = parentWindow.$('#hyperlink_eval_<?php echo (isset($_SESSION['evaluation_activity']) ? $_SESSION['evaluation_activity'] :'');?>');
                    $messageArea.html('');
             }
         }
        }
    });
    $('.RnoCheckOKMessageBox').delay(2000).slideUp("slow");
   if(count<=0)
    window.close();
}

function liste_evaluation_grid(path_base,activity_id,status){
    open(path_base+"xmlhttprequest/evaluation_grid.php?action=liste_evaluation_grid&evaluation_activity="+activity_id+"&milestone_status="+status, "target_modify", "toolbar=0, directories=0, status=1, menubar=0, width=1000, height=600, scrollbars=1, location=0, resizable=1")
}

function checkActivity(timeout, interval, elapsed) {

    if (elapsed < timeout) {
        elapsed += interval;
        setTimeout(function() {
            checkActivity(timeout, interval, elapsed);
        }, interval);
    }else{
        if(!$.sessionTimeOut){
            checkTimeOut();
            elapsed += interval;
            setTimeout(function() {
                checkActivity(timeout, interval, elapsed);
            }, interval);
         }
    }
}


function checkTimeOut() {
    
     var url = "<?php echo $base_path;?>cem/scripts/timeout.php?timeout=1";
     
     $.get(url,function(data){       
        if(data=='alert'){
                $.sessionTimeOut = true; 
                alert("<?php echo $text_session_timeout; ?>");     
        }
        else{
            $.sessionTimeOut =false;
        }
       return false;
    });
    return false;
}


window.onload = init;
var interval;
function init()
{
	interval = setInterval(trackLogin,60000);
}
function trackLogin()
{
	var xmlReq = false;
	try {
	xmlReq = new ActiveXObject("Msxml2.XMLHTTP");
	} catch (e) {
	try {
	xmlReq = new ActiveXObject("Microsoft.XMLHTTP");
	} catch (e2) {
	xmlReq = false;
	}
	}
	if (!xmlReq && typeof XMLHttpRequest != 'undefined') {
	xmlReq = new XMLHttpRequest();
	}

	xmlReq.open('get', '<?php echo $base_path;?>cem/scripts/timeout.php?timeout=1', true);
	xmlReq.send(null);
	xmlReq.onreadystatechange = function(){
		if(xmlReq.readyState == 4 && xmlReq.status==200) {
			
                        if($("form[name='form_sauve_activite']").length && (xmlReq.responseText == 'save_alert' || xmlReq.responseText == 'save')){
                            if(xmlReq.responseText == 'save_alert')
                            {
                                $('#dialogSaveAlert').dialog({
                                    autoOpen: true,
                                    modal: true,
                                    position: 'center',
                                    draggable: false,
                                    width: '30%',
                                    buttons: {
                                        "Ok": function () {
                                            document.form_sauve_activite.action.value='save_activites';
                                            document.form_sauve_activite.submit();
                                            $(this).dialog("close");
                                        },
                                    }
                                });
                            }
                            
                            if(xmlReq.responseText == 'save')
                            {
                                document.form_sauve_activite.action.value='save_activites';
                                document.form_sauve_activite.submit();
                            }
                        }else{
                        if(xmlReq.responseText == 'alert')
			{
                        
                            $('#dialogAlert').dialog({
                                autoOpen: true,
                                modal: true,
                                position: 'center',
                                draggable: false,
                                width: '30%',
                                buttons: {

                                    "Ok": function () {
                                        $(this).dialog("close");
                                    }
                                }
                            });
			}
                        if(xmlReq.responseText == 'timeout')
			{
				clearInterval(interval);
                                $('#dialogAlert').close();
                                $('#dialogTimeout').dialog({
                                autoOpen: true,
                                modal: true,
                                position: 'center',
                                draggable: false,
                                width: '30%',
                                buttons: {
                                    "Ok": function () {
                                        $(this).dialog("close");
                                        document.location.href = "<?php echo $base_path;?>cem/scripts/index.php";
                                    }
                                }
                            });
                                
			}
                        }
		}
	}
}

function AjaxReloadExgform(path_base, activity_id, grid_type, exgform_id, action_type, color_values)
{
    var parentWindow = window.opener;
    $.ajax({
		url:path_base+'xmlhttprequest/ajax_exchange_form.php?action=getActivityPanels&activity_id='+activity_id+'&grid_type='+grid_type+'&exgform_id='+exgform_id+'&action_type='+action_type,
        sync:false,
        success: function(output) {
         if(output)
         {
              $messageArea = parentWindow.$('#grid_data');
              $messageArea.html(output);
              
                var divElement = $('<div></div>').addClass('graph_css2');
              	var colorvalues = JSON.parse(color_values);
                var i = 0;
                $.each( colorvalues, function( key, value ) {
                  var spanElement = $('<span></span>').addClass('bar intpercent').css({ 'background-color' : "#"+key, 'width' : value+"%" });
                  divElement.append(spanElement); 
                  parentWindow.$('span#'+activity_id+' div.graph_css2  span:eq('+i+')').width(value+'%');
                  i++;
                });
               // parentWindow.$('#'+activity_id).html(divElement);
         }
        }
    });
        $.ajax({
		url:path_base+'xmlhttprequest/ajax_exchange_form.php?action=getActivityPanelsData&activity_id='+activity_id+'&grid_type='+grid_type+'&exgform_id='+exgform_id+'&action_type='+action_type,
        sync:false,
        success: function(output) {
         if(output)
         {

              
              var div = $('<div></div>').addClass('graph_css2');
              	var colorvalues = JSON.parse(output);
                $.each( colorvalues, function( key, value ) {
                  var span = $('<span></span>').addClass('bar intpercent').css({ 'background-color' : "#"+key, 'width' : value+"%" });
                  div.append(span);
                });
                console.log(div);
                parentWindow.$('#'+activity_id).html(div);
         }
        }
    });
    $('.RnoCheckOKMessageBox').delay(2000).slideUp("slow");
}


function copy_ipn(id) {
    var suffix = "";
    if(id != "") {
        suffix = "_" + id;
    }
    var ipn = document.getElementById('Fipn_arca_cache'+suffix).value;
    var name = document.getElementById('Fnom_arca'+suffix).value;
    if(ipn.trim().length <= 0 || name.trim().length <= 0 ) {
        return;
    }
    sessionStorage.setItem("copied_ipn", ipn);
    sessionStorage.setItem("copied_ipn_name", name);
}
function paste_ipn(id) {
    if(sessionStorage.getItem("copied_ipn") == null) {
        return;
    }
    
    var suffix = "";
    if(id != "") {
        suffix = "_" + id;
    }
    
    document.getElementById('Fipn_arca_cache'+suffix).value = sessionStorage.getItem("copied_ipn");
    document.getElementById('Fipn_arca'+suffix).value = sessionStorage.getItem("copied_ipn");
    document.getElementById('Fnom_arca'+suffix).value = sessionStorage.getItem("copied_ipn_name");
    
    if(sessionStorage.getItem("copied_ipn") != null) {
        
    }
}

function updateDashboardProgressLinks() {
    if($("#update_form_fileds").size() <= 0) {
        return;
    }
    $("#update_form_fileds").val(1);
    $("#RnoNav1Top,#RnoNav2Top,#flags,.RnoConnexion").find('a').addClass('js-link-navigate');
    $(".RnoLinks").find('a:first').addClass('js-link-navigate');
    $(".RnoButtonsLeft").find('span.RnoCreateButtons').find('a:first').next().addClass('js-link-navigate');
    $(".RnoTableData_dashboard_header").find('a.js-milestone-link').addClass('js-link-navigate-milestone-topic');
    $(".RnoTableData_dashboard_activity tr").each(function(i, data){
        if(i>0){
            $(this).find('td:eq(0) a').addClass('js-link-navigate-milestone-topic');
        }
    });
}
  
  (function( $ ) {
    $.widget( "custom.combobox", {
      _create: function() {
        this.wrapper = $( "<span>" )
          .addClass( "custom-combobox" )
          .insertAfter( this.element );
 
        this.element.hide();
        this._createAutocomplete();
        this._createShowAllButton();
      },
 
      _createAutocomplete: function() {
        var selected = this.element.children( ":selected" ),
          value = selected.val() ? selected.text() : "";
          value = value.trim();
 
        this.input = $( "<input>" )
          .appendTo( this.wrapper )
          .val( value )
          .attr( "title", "" )
          .addClass( "custom-combobox-input ui-widget ui-widget-content ui-state-default ui-corner-left" )
          .autocomplete({
            delay: 0,
            minLength: 0,
            source: $.proxy( this, "_source" )
          })
          .tooltip({
            tooltipClass: "ui-state-highlight"
          });
 
        this._on( this.input, {
          autocompleteselect: function( event, ui ) {
            ui.item.option.selected = true;
            this._trigger( "select", event, {
              item: ui.item.option
            });
          },
 
          autocompletechange: "_removeIfInvalid"
        });
      },
 
      _createShowAllButton: function() {
        var input = this.input,
          wasOpen = false,
          element = this.element,
          object = this;
 
        $( "<a>" )
          .attr( "tabIndex", -1 )
          .attr( "title", "Show All Items" )
          .tooltip()
          .appendTo( this.wrapper )
          .button({
            icons: {
              primary: "ui-icon-triangle-1-s"
            },
            text: false
          })
          .removeClass( "ui-corner-all" )
          .addClass( "custom-combobox-toggle ui-corner-right" )
          .mousedown(function() {
            wasOpen = input.autocomplete( "widget" ).is( ":visible" );
          })
          .click(function() {
            input.focus();
 
            // Close if already visible
            if ( wasOpen ) {
              return;
            }
            
            if(element.children( "option" ).size() == 1) {
                input.val( "" )
                    ;/**.attr( "title", "No items" )
                    .tooltip( "open" );**/
                element.val( "" );
                /**object._delay(function() {
                    input.tooltip( "close" ).attr( "title", "" );
                }, 2500 );**/
                input.autocomplete( "instance" ).term = "";
            }
 
            // Pass empty string as value to search for, displaying all results
            input.autocomplete( "search", "" );
          });
      },
 
      _source: function( request, response ) {
        var matcher = new RegExp( $.ui.autocomplete.escapeRegex(request.term), "i" );
        response( this.element.children( "option" ).map(function() {
          var text = $( this ).text();
          if ( this.value && ( !request.term || matcher.test(text) ) )
            return {
              label: text,
              value: text,
              option: this
            };
        }) );
      },
 
      _removeIfInvalid: function( event, ui ) {
 
        // Selected an item, nothing to do
        if ( ui.item ) {
          return;
        }
 
        // Search for a match (case-insensitive)
        var value = this.input.val(),
          valueLowerCase = value.toLowerCase(),
          valid = false;
        this.element.children( "option" ).each(function() {
          if ( $( this ).text().toLowerCase() === valueLowerCase ) {
            this.selected = valid = true;
            return false;
          }
        });
 
        // Found a match, nothing to do
        if ( valid ) {
          return;
        }
 
        // Remove invalid value
        this.input
          .val( "" )
          ;/**.attr( "title", value + " didn't match any item" )
          .tooltip( "open" );**/
        this.element.val( "" );
        /**this._delay(function() {
          this.input.tooltip( "close" ).attr( "title", "" );
        }, 2500 );**/
        this.input.autocomplete( "instance" ).term = "";
      },
 
      _destroy: function() {
        this.wrapper.remove();
        this.element.show();
      }
    });
    

    
  })( jQuery );
 
  $(function() {
    $( "#filtre_all_db_projects,#filtre_my_db_projects,#filtre_all_db_families" ).combobox({
        select: function (event, ui) {
            $this = $(this);
            $this.val($this.find("option:selected").val());
            setTimeout(function(){
                $this.trigger("change");
            }, 100);            
        }
    });

  });   
  
  function glossary(path_base)
{
  open(path_base+"xmlhttprequest/glossary.php", "target_modify", "toolbar=0, directories=0, status=1, menubar=0, width=500, height=400, scrollbars=1, location=0, resizable=1")
}
  function getUrlVars()
{
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for(var i = 0; i < hashes.length; i++)
    {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

