<?php
session_start();
require_once('../messages/'.$_SESSION['language'].'/alertes_js.msg');
?>





