<?php
session_start();
require_once("../messages/".$_SESSION['language']."/alertes_js.msg");
?>
function CheckFormItem()
{ 
    if (document.department.department_name_fr.value.trim()=="")
        return(alert("<?php echo $js_alert_saisie_name_fr;?>"));
        if(document.department.department_name_fr.value.length >45 )
        return(alert("<?php echo $js_alert_more_characters_fr;?>"));
 	if (document.department.department_name_en.value.trim()=="")
        return(alert("<?php echo $js_alert_saisie_name_en;?>"));
        if(document.department.department_name_en.value.length >45 )
        return(alert("<?php echo $js_alert_more_characters_en;?>"));
  document.department.submit();
 	
}
