<?php
session_start();
require_once("../messages/".$_SESSION['language']."/alertes_js.msg");
?>
// JavaScript Document
function ControleSaisie()
{ 
//------ Controle saisie -------
  	if (document.form_process.Ftag.value=="")
        return(alert("<?php echo $js_alert_saisie_tag;?>"));
  	if (document.form_process.Fname_fr.value=="")
        return(alert("<?php echo $js_alert_saisie_nom_processus_fr;?>"));
  	if (document.form_process.Fname_en.value=="")
        return(alert("<?php echo $js_alert_saisie_nom_processus_en;?>"));
document.form_process.submit();
//self.close();
}
