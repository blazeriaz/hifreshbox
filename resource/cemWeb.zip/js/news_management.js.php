<?php
session_start();
require_once("../messages/".$_SESSION['language']."/alertes_js.msg");
?>
// JavaScript Document
function ControleSaisie()
{ 
//------ Controle saisie -------
 	if (document.form_news.Ftexte_fr.value=="")
        return(alert("<?php echo $js_alert_saisie_texte_fr;?>"));
 	if (document.form_news.Ftexte_en.value==-1)
        return(alert("<?php echo $js_alert_saisie_texte_en;?>"));
 	if (document.form_news.Fdate.value=="")
        return(alert("<?php echo $js_alert_saisie_date;?>"));		
document.form_news.submit();
}
