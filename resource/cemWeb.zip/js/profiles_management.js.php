<?php
session_start();
require_once("../messages/".$_SESSION['language']."/alertes_js.msg");
?>
// JavaScript Document
function ControleSaisie() { 
    //------ Controle saisie -------
    if (document.form_ajout_profil.acl_profile_group_id_fk.value=="") {
        return(alert("<?php echo "Group empty";?>"));
    }
    if (document.form_ajout_profil.name_fr.value=="") {
        return(alert("<?php echo $js_alert_saisie_nom_profil_fr;?>"));
    }
    if (document.form_ajout_profil.name_en.value=="") {
        return(alert("<?php echo $js_alert_saisie_nom_profil_en;?>"));
    }
    document.form_ajout_profil.submit();
}

coche = new Image(); coche.src = "../../images/coche.png";
decoche = new Image(); decoche.src = "../../images/coche_ko.png";


function coche_decoche(id) {
    if (document.form_ajout_profil.elements['Fda'+id].checked==true) {
        document.images['coche'+id].src=decoche.src;
        document.form_ajout_profil.elements['Fda'+id].checked=false;
    } else {
        document.images['coche'+id].src=coche.src;
        document.form_ajout_profil.elements['Fda'+id].checked=true;
    }
}