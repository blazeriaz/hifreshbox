<?php
session_start();
require_once("../messages/".$_SESSION['language']."/alertes_js.msg");
?>
// JavaScript Document
function ControleSaisie()
{ 
//------ Controle saisie -------
  	if (document.form_ajout_controle.Fmarqueur.value=="")
        return(alert("<?php echo $js_alert_saisie_marqueur;?>"));
  	if (document.form_ajout_controle.Fcontrole_fr.value=="")
        return(alert("<?php echo $js_alert_saisie_nom_controle_fr;?>"));
  	if (document.form_ajout_controle.Fcontrole_en.value=="")
        return(alert("<?php echo $js_alert_saisie_nom_controle_en;?>"));
document.form_ajout_controle.submit();
//self.close();
}