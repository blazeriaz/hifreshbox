<?php
session_start();
require_once('../messages/'.$_SESSION['language'].'/alertes_js.msg');
?>
// JavaScript Document
function CheckFormMilestone()
{ 
	if (document.form_milestone.Flibelle_fr.value=="")
        return(alert("<?php echo $js_alert_saisie_name_fr;?>"));
 	if (document.form_milestone.Flibelle_en.value=="")
        return(alert("<?php echo $js_alert_saisie_name_en;?>"));
  document.form_milestone.submit();
}

