<?php
session_start();
require_once('../messages/'.$_SESSION['language'].'/alertes_js.msg');
$delayMsg=1500;
?>
// JavaScript Document
function CheckFormResult()
{ 
	if (document.form_result.Fname_fr.value=="")
        return(alert("<?php echo $js_alert_saisie_name_fr;?>"));
 	if (document.form_result.Fname_en.value=="")
        return(alert("<?php echo $js_alert_saisie_name_en;?>"));

  document.form_result.submit();
}

function CheckFormActivity(cible,stakeholder_id)
{ 
	if (document.form_activity.Fname_fr.value=="")
        return(alert("<?php echo $js_alert_saisie_name_fr;?>"));
 	if (document.form_activity.Fname_en.value=="")
        return(alert("<?php echo $js_alert_saisie_name_en;?>"));
 	if (document.form_activity.Fleader.value=="")
        return(alert("<?php echo $js_alert_choix_responsable;?>"));
        if(cible == 'add_rpif_link' && document.form_activity.FrpifLink.value.trim()=="") {
            return;
        }
  if(cible == 'remove_stakeholder') {
  document.form_activity.stakeholder2remove_id.value=stakeholder_id;           
  }
  if(cible == 'remove_rpif_link') {
    document.form_activity.rpif_links2remove_id.value=stakeholder_id;           
  }
  document.form_activity.action.value=cible;      
  document.form_activity.submit();
}

function CheckFormCheckpoint(path_base,template_id)
{
	if (document.form_checkpoint.Ftag.value=="")
        return(alert("<?php echo $js_alert_saisie_tag;?>")); 
	if (document.form_checkpoint.Fname_fr.value=="")
        return(alert("<?php echo $js_alert_saisie_name_fr;?>"));
 	if (document.form_checkpoint.Fname_en.value=="")
        return(alert("<?php echo $js_alert_saisie_name_en;?>"));
  
  check_checkpoint_tag(path_base,template_id);
}

function add_To_Template_Typology(pathbase,cible,activity_id,milestone_id,activity_list,checkpoint_list)
{
    if(cible=="duplicate_result")
    {
        window.open(pathbase+"xmlhttprequest/template_typology.php?action="+cible+"&activity_id="+activity_id+"&typology_activity="+JSON.stringify(milestone_id), "target_modify", "toolbar=0, directories=0, status=1, menubar=0, width=800, height=600, scrollbars=1, location=0, resizable=1");
    }
    else
    {
        window.open(pathbase+"xmlhttprequest/template_typology.php?action="+cible+"&activity_id="+activity_id+"&milestone_id="+milestone_id, "target_modify", "toolbar=0, directories=0, status=1, menubar=0, width=800, height=600, scrollbars=1, location=0, resizable=1");
    }
    $('.RnoCheckOKMessageBox').delay(<?php echo $delayMsg;?>).slideUp("2000");
}