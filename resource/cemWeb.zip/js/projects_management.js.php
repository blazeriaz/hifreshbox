<?php
session_start();
require_once("../messages/".$_SESSION['language']."/alertes_js.msg");
?>
// JavaScript Document
function CheckFormProject()
{ 
  	if (document.form_project.Fcode.value=="")
        return(alert("<?php echo $js_alert_saisie_code;?>"));
  	if (document.form_project.Fname.value=="")
        return(alert("<?php echo $js_alert_saisie_name;?>"));
document.form_project.submit();
}
