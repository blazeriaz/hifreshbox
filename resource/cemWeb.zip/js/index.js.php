<?php
session_start();
require_once("../messages/".$_SESSION['language']."/alertes_js.msg");
?>
function ControleSaisie(){ 
  	if (document.form_logon.Fipn.value=='')
        return(alert("<?php echo $js_alert_saisie_ipn;?>"));
  	if (document.form_logon.Fpass.value=='')
        return(alert("<?php echo $js_alert_saisie_pass;?>"));		
document.form_logon.submit();
}

$(document).ready(function(){
    $('span.js_universe').click(function(){
        $(this).parent().hide();
        $(this).parent().next().show();
    });
});