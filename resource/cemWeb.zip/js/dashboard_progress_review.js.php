<?php
session_start();
require_once("../messages/".$_SESSION['language']."/alertes_js.msg");
?>
// JavaScript Document


  coche = new Image(); coche.src = "../../images/pictos/bt_radio_bouton_on.gif";
  decoche = new Image(); decoche.src = "../../images/pictos/bt_radio_bouton_off.gif";
 
  NAcheck =new Image(); NAcheck.src = "../../images/pictos/checked.png";
  NAuncheck =new Image(); NAuncheck.src = "../../images/pictos/unchecked.png";
  
  function openExternalLink(path_base, activity_id, status) {
    open(path_base+"xmlhttprequest/external_links.php?activity_id="+activity_id+"&status="+status, "target_modify", "toolbar=0, directories=0, status=1, menubar=0, width=900, height=600, scrollbars=1, location=0, resizable=1");
  }
  function select_statut_checkbox(id)
  {
       if($('#status_NA_'+id).val()==0)
       {
            document.images['coche_checkbox'+id].src=NAcheck.src;
            $('#evaluation_grid_'+id+' a').hide();
            $('#hyperlink_eval_'+id).hide();
            $('#status_TR_'+id).val(0);
            $('#status_ER_'+id).val(0);
            $('#status_EC_'+id).val(0);
            $('#status_NC_'+id).val(0);
            $('#status_NA_'+id).val(100);
            $('#activity_comment_'+id).removeClass('arca_search').addClass('legal');
            $('#activity_comment_'+id).removeAttr('readonly');
       }
       else
       {
            document.images['coche_checkbox'+id].src=NAuncheck.src;
            $('#evaluation_grid_'+id+' a').show();
            $('#hyperlink_eval_'+id).show();
            $('#status_TR_'+id).val($('#status_hidden_TR_'+id).val());
            $('#status_ER_'+id).val($('#status_hidden_ER_'+id).val());
            $('#status_EC_'+id).val($('#status_hidden_EC_'+id).val());
            $('#status_NC_'+id).val($('#status_hidden_NC_'+id).val());
            $('#status_NA_'+id).val(0);
            $('#activity_comment_'+id).removeClass('legal').addClass('arca_search');
            $('#activity_comment_'+id).attr('readonly','readonly');
       }
  }
  
  function select_statut(id,eval)
  {
    liv_id=id.split('_');
    if(eval!=3)
    {
        document.images['coche'+liv_id[0]+'_NC'].src=decoche.src;
    }
    document.images['coche'+liv_id[0]+'_NA'].src=decoche.src;
    if(eval==1)
    {
        document.images['coche'+liv_id[0]+'_TR'].src=decoche.src;
        if (document.images['coche'+liv_id[0]+'_ER'])
        {
          document.images['coche'+liv_id[0]+'_ER'].src=decoche.src;
        }
        if (document.images['coche'+liv_id[0]+'_EC'])
        {  
         document.images['coche'+liv_id[0]+'_EC'].src=decoche.src;
        } 
        var colors = ["EC","ER","TR","NC","NA"];
        for(var i in colors)
        {
            if(colors[i]==liv_id[1])
            {
                $('#status_'+colors[i]+'_'+liv_id[0]).val(1);
            }
            else
            {
                 $('#status_'+colors[i]+'_'+liv_id[0]).val(0);
            }
        }
    }
    else if(eval==2)
    {
        $('#status_'+liv_id[1]+'_'+liv_id[0]).val(100);
        if(liv_id[1]=='NC')
        {
            $('#status_NA_'+liv_id[0]).val(0);
        }
        else
        {
            $('#status_NC_'+liv_id[0]).val(0);
        }
        var colors = ["EC","ER","TR"];
        for(var i in colors)
        {
            $('#status_'+colors[i]+'_'+liv_id[0]).val(0);
        }
     }
     else
     {
        $('#status_'+liv_id[1]+'_'+liv_id[0]).val(1);
        var colors = ["EC","ER","TR","NC"];
        for(var i in colors)
        {
            $('#status_'+colors[i]+'_'+liv_id[0]).val(0);
        }
     }
     document.images['coche'+id].src=coche.src;
  //  document.form_sauve_activite.elements['activite_statut_'+liv_id[0]].value=liv_id[1];
  }  
  var save = false;
  function check_dashboard_change(path_base,ids,selected_topic,target_milestone_id,target)
  {
    save = true;
    $.ajax({
        url:path_base+'xmlhttprequest/ajax_check_repository_update.php?updating='+$('#updating').val(),
        async:false,
        success: function(output) {
              if(output=='1')
              {
              
                if(confirm("<?php echo $msg_confirm_current_dashboard_change;?>"))
                {
                  location.reload();
                }
               return false;
              }
              else
              {
                  check_comments(ids,selected_topic,target_milestone_id,target);  
              }
              
         }
         });
  }
  
  function check_comments(ids,selected_topic,target_milestone_id,target)
  {
    if (ids!='')
    {
      $('#activity_pagination').val(0);
      liv_id=ids.split('_');
      popup=false;
      for (i=0;i<liv_id.length;i++)
      {
        if($('#status_EC_'+liv_id[i]).length > 0){
            if($('#status_EC_'+liv_id[i]).val() == ''){
                var EC =0;
             }else{
               var EC = parseInt($('#status_EC_'+liv_id[i]).val());
             }
             if($('#status_ER_'+liv_id[i]).val() == ''){
                var ER =0;
             }else{
               var ER = parseInt($('#status_ER_'+liv_id[i]).val());
             }
              if($('#status_TR_'+liv_id[i]).val() == ''){
                var TR =0;
             }else{
               var TR = parseInt($('#status_TR_'+liv_id[i]).val());
             }

                total = EC+ER+TR+ parseInt($('#status_NC_'+liv_id[i]).val())+ parseInt($('#status_NA_'+liv_id[i]).val());

            if(total == 0)
            {
                var activityName = $('#status_EC_'+liv_id[i]).parents('.js_activity').find('span.js_activity_name').text().trim();
                return(alert("<?php echo $js_alert_missing_status;?> "+activityName));
            }
            if(parseInt($('#status_NA_'+liv_id[i]).val()) != 0 )
            {
                if (!$('textarea[name="activity_comment_'+liv_id[i]+'"]').hasClass('hide') && $('textarea[name="activity_comment_'+liv_id[i]+'"]').val().trim().length == 0)
                {
                    popup=true;
                }
            }
         }
      }
      if (popup==false)
      {
            document.form_sauve_activite.milestone_id.value=target_milestone_id;    
            document.form_sauve_activite.selected_topic.value=selected_topic;
            document.form_sauve_activite.action.value='save_activites';            
            if(save==false){
                document.form_sauve_activite.filter_topic.value=selected_topic;
            }
            if(document.form_sauve_activite.dash_board_referrer.value=='') {
          document.form_sauve_activite.dash_board_referrer.value='filter';
          }
            document.form_sauve_activite.submit();
      }
      else
      {
        return(alert("<?php echo $js_alert_missing_comment_on_na;?>"));	
      }
      
    }
    else
    {
         document.form_sauve_activite.milestone_id.value=target_milestone_id;    
         document.form_sauve_activite.selected_topic.value=selected_topic;
         if(save==false){
            document.form_sauve_activite.filter_topic.value=selected_topic;
          }
          document.form_sauve_activite.action.value='save_activites';
          if(document.form_sauve_activite.dash_board_referrer.value=='') {
          document.form_sauve_activite.dash_board_referrer.value='filter';
          }
        document.form_sauve_activite.submit();
    }    
  }
  
  
  
  function erase_leader(id)
  {
    document.getElementById('Fipn_arca_cache_'+id).value='';
    document.getElementById('Fnom_arca_'+id).value='';
  }
  
  
  
  
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}

function add_evaluation_grid(path_base,nom_form,activity_id)
{
    open(path_base+"xmlhttprequest/evaluation_grid.php?action=create&evaluation_activity="+activity_id, "target_modify", "toolbar=0, directories=0, status=1, menubar=0, width=1000, height=600, scrollbars=1, location=0, resizable=1")
}
<?php
        /**
         * 1520 - US 25 - Modified By selvaraj
         * Add functionality for US 25
         */
?>
$(function() {
   $( "form#js-dash-board-detail input[type='text'],form#js-dash-board-detail input[type='radio'],form#js-dash-board-detail textarea,.js-check-point-field").change(function() {
        $this = $(this);
        if($("#update_form_fileds").val() < 1){
             
                $("#update_form_fileds").val(1);
                $("#RnoNav1Top,#RnoNav2Top,#flags,.RnoConnexion").find('a').addClass('js-link-navigate');
				$(".RnoLinks").find('a:first').addClass('js-link-navigate');
				$(".RnoButtonsLeft").find('span.RnoCreateButtons').find('a:first').next().addClass('js-link-navigate');
                $(".RnoTableData_dashboard_header").find('a.js-milestone-link').addClass('js-link-navigate-milestone-topic');
                $(".RnoTableData_dashboard_activity tr").each(function(i, data){
                   if(i>0){
                     $(this).find('td:eq(0) a').addClass('js-link-navigate-milestone-topic');
                   }
                });
             
        }
    });

	$(".activite_check a,.js-remove-checked").click(function() {
		$this = $(this);
        if($("#update_form_fileds").val() < 1){
                $("#update_form_fileds").val(1);
                $("#RnoNav1Top,#RnoNav2Top,#flags,.RnoConnexion").find('a').addClass('js-link-navigate');
				$(".RnoLinks").find('a:first').addClass('js-link-navigate');
				$(".RnoButtonsLeft").find('span.RnoCreateButtons').find('a:first').next().addClass('js-link-navigate');
                $(".RnoTableData_dashboard_header").find('a.js-milestone-link').addClass('js-link-navigate-milestone-topic');
                $(".RnoTableData_dashboard_activity tr").each(function(i, data){
                   if(i>0){
                     $(this).find('td:eq(0) a').addClass('js-link-navigate-milestone-topic');
                   }
                });
             
        }
    });
});


$(function() {
    
    $('.js_dialog_close').click(function(){
        $('#dialogg').dialog("close");
    });
    
    
    function clearOnDialogClose() {
        $('.js_dialog_block').removeClass('js_link_navi');
        $('.js_dialog_block').removeClass('js_link_topic');
        $('.js_link_active').removeClass('js_link_active');
        $(".js_actvity_pagination_link select[name='pageLimit']").val($('#activity_pagination_limit').val());
        $("[name='dash_board_referrer']").val("");
    }
    
    clearOnDialogClose();
    
    $('.js_dialog_yes').click(function(){
            $this = $(this);
            var miles_tone_id = '<?php echo (isset($_SESSION['milestone_id']) ? $_SESSION['milestone_id'] :'');?>';
            var select_topic = '<?php echo (isset($_SESSION['selected_topic']) ? $_SESSION['selected_topic'] :'');?>';
            var $parent = $this.parents('.js_dialog_block').filter(':first');
            var list_of_activity = document.form_sauve_activite.dash_board_activities.value.trim();           
            
            check_dashboard_change('../',list_of_activity,select_topic,miles_tone_id,'dashboard_progress_review.php?');
      
        return false;
    });
    
    $('.js_dialog_no').click(function(){
        var    $this = $(this);
      var $parent = $this.parents('.js_dialog_block').filter(':first');
      var href = document.form_sauve_activite.dash_board_referrer.value.trim();
        if(href != "" && href != "filter" && href != "change-milestone"){ 
            document.location.href = href;
        } else {
            document.form_sauve_activite.milestone_id.value=document.form_sauve_activite.dash_board_target_milestone.value;    
            document.form_sauve_activite.selected_topic.value=document.form_sauve_activite.dash_board_target_topic.value; 
            document.form_sauve_activite.action.value='default';
            document.form_sauve_activite.dash_board_target_topic.value ='';
            document.form_sauve_activite.dash_board_target_milestone.value ='';
            document.form_sauve_activite.submit();
        }
        return false;
                                
    });
    
    $(document.body).on('click', '.js-link-navigate' ,function(){   
            $('.js_dialog_block').removeClass('js_link_topic').addClass('js_link_navi');
            $this = $(this);
            $this.addClass('js_link_active');
            document.form_sauve_activite.dash_board_referrer.value=$this.attr('href');
        $('#dialogg').dialog({
            autoOpen: true,
            modal: true,
            position: 'center',
            draggable: false,
            width: '30%',
            buttons: false,
            close : clearOnDialogClose
        });
        return false;

    });  
 
      $(document.body).on('click', '.js-milestone-navigate a' ,function(){
                $this = $(this);
            if($("#update_form_fileds").val() == 1){
            $('.js_dialog_block').removeClass('js_link_topic').addClass('js_link_navi');
            $this.addClass('js_link_active');
                document.form_sauve_activite.dash_board_referrer.value=$this.attr('href');
                $('#dialogg').dialog({
                    autoOpen: true,
                    modal: true,
                    position: 'center',
                    draggable: false,
                    width: '30%',
                    buttons: false,
                    close : clearOnDialogClose
                });
                return false;
        }else{
            return true;
        }

    });  
    
    $(document.body).on('click', '.js-link-navigate-milestone-topic' ,function(){
            $this = $(this);
            $('.js_dialog_block').removeClass('js_link_navi').addClass('js_link_topic');            
            var miles_tone_id = '<?php echo (isset($_SESSION['milestone_id']) ? $_SESSION['milestone_id'] :'');?>';
            var select_topic = '<?php echo (isset($_SESSION['selected_topic']) ? $_SESSION['selected_topic'] :'');?>';
            var list_of_activity = document.form_sauve_activite.dash_board_activities.value.trim();
            var target_milestone = $this.prev().attr("data-milestone");
            var target_topic = $this.prev().attr("data-topic");
            document.form_sauve_activite.dash_board_target_milestone.value = target_milestone;    
            document.form_sauve_activite.dash_board_target_topic.value = target_topic;   
            document.form_sauve_activite.dash_board_referrer.value='change-milestone';
     
            $('#dialogg').dialog({
                autoOpen: true,
                modal: true,
                position: 'center',
                draggable: false,
                width: '30%',
                buttons: false,
                close : clearOnDialogClose
            });
      
        return false;
        
    });  
});

