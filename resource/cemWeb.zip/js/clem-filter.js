var clemFilter = angular.module('clem.filters', []);

clemFilter.filter('placeholder', [function () {
    return function (text, placeholder) {
        // If we're dealing with a function, get the value
        if(!text) text ='';
        if (angular.isFunction(text)) text = text();
        
        // Trim any whitespace and show placeholder if no content
        return text.trim() || placeholder;
    };
}]);