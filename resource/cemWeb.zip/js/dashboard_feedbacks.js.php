<?php
session_start();
require_once('../messages/'.$_SESSION['language'].'/alertes_js.msg');
?>
// JavaScript Document
function CheckFormFeedback()
{ 
	if (document.form_feedback.feedback_comment.value.trim()=="")
        return(alert("<?php echo $js_fill_feedback;?>"));
  document.form_feedback.submit();
}
 