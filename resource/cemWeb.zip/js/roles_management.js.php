<?php
session_start();
require_once("../messages/".$_SESSION['language']."/alertes_js.msg");
?>
// JavaScript Document
function ControleSaisie()
{ 
//------ Controle saisie -------
  	if (document.form_resp.Fresponsabilite_name_fr.value.trim()=="")
        return(alert("<?php echo $js_alert_saisie_responsabilite_fr;?>"));
  	if (document.form_resp.Fresponsabilite_name_en.value.trim()=="")
        return(alert("<?php echo $js_alert_saisie_responsabilite_en;?>"));
        if (document.form_resp.Fdepart.value=="")
        return(alert("<?php echo $js_alert_saisie_department;?>"));
document.form_resp.submit();
}

