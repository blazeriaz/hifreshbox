<?php
session_start();
require_once("../messages/".$_SESSION['language']."/alertes_js.msg");
?>
function CheckFormSubject()
{ 
  	if (document.form_subject.Ftag.value=="")
        return(alert("<?php echo $js_alert_saisie_tag;?>"));
  	if (document.form_subject.Fname_fr.value=="")
        return(alert("<?php echo $js_alert_saisie_name_fr;?>"));
  	if (document.form_subject.Fname_en.value=="")
        return(alert("<?php echo $js_alert_saisie_name_en;?>"));
document.form_subject.submit();
}
