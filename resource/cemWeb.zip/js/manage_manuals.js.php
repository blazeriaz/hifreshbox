<?php
session_start();
require_once("../messages/".$_SESSION['language']."/alertes_js.msg");
?>
// JavaScript Document
function CheckFormManual()
{ 
//------ Controle saisie -------
 	if (document.form_manual.Ftitle.value=="")
        return(alert("<?php echo $js_alert_choice_title;?>"));
 	if (document.form_manual.Fdescription.value=="")
        return(alert("<?php echo $js_alert_choice_description;?>"));
 	if (document.form_manual.Flanguage.value==-1)
        return(alert("<?php echo $js_alert_choice_language;?>"));		
document.form_manual.submit();
}
