<?php
session_start();
require_once("../messages/".$_SESSION['language']."/alertes_js.msg");
?>
// JavaScript Document
function ControleSaisie(step) { 
    //------ Controle saisie -------
    if(step == 1) {    
        if (document.form_ajout_admin.Fipn_arca_cache.value=="") {
            return(alert("<?php echo $js_alert_saisie_arca;?>"));
        }
        document.form_ajout_admin.submit();
    }
    if(step == 2) {
        document.form_ajout_admin.submit();
    }
}

jQuery(document).ready(function($){
    $("[name='acl_profiles[]']").each(function(){
        if(this.checked) {
            var profile_id = this.value;
            if($("[name='acl_profile_universe["+profile_id+"][]'][value='0']:checked").size() > 0) {
                $("[name='acl_profile_universe["+profile_id+"][]'][value!='0']").prop("checked", true);
            } else {
                var c1 = $("[name='acl_profile_universe["+profile_id+"][]'][value!='0']").not(".no_rights").size();
                var c2 = $("[name='acl_profile_universe["+profile_id+"][]'][value!='0']:checked").not(".no_rights").size();            
                if(c1 == c2 && c1 != 0) {
                    $("[name='acl_profile_universe["+profile_id+"][]'][value='0']").prop("checked", true);
                }
            }
        }
    });
});

function selectUniverse(el, profile_id) {
    if(el.value == 0) {
        if(el.checked) {
            jQuery("[name='acl_profile_universe["+profile_id+"][]']").not(el).not("[disabled]").prop("checked", true);
        } else {
            jQuery("[name='acl_profile_universe["+profile_id+"][]']").not(el).not("[disabled]").removeAttr("checked");
        }
    } else {
        if(!el.checked) {
            jQuery("[name='acl_profile_universe["+profile_id+"][]'][value='0']").removeAttr("checked");
        } else {
            var c1 = jQuery("[name='acl_profile_universe["+profile_id+"][]'][value!='0']").not(".no_rights").size();
            var c2 = jQuery("[name='acl_profile_universe["+profile_id+"][]'][value!='0']:checked").not(".no_rights").size();            
            if(c1 == c2) {
                jQuery("[name='acl_profile_universe["+profile_id+"][]'][value='0']").prop("checked", true);
            }            
        }
    }
    
    if(jQuery("[name='acl_profile_universe["+profile_id+"][]']:checked").size() > 0) {
        jQuery("[name='acl_profiles[]'][value="+profile_id+"]").prop("checked", true);
    } else {
        jQuery("[name='acl_profiles[]'][value="+profile_id+"]").prop("checked", false);
    }
}



coche = new Image(); coche.src = "../../images/coche.png";
decoche = new Image(); decoche.src = "../../images/coche_ko.png";


function coche_decoche_new(id)
{
 if (document.form_ajout_admin.elements['activite_num'+id].checked==true)
 {
   document.images['coche'+id].src=decoche.src;
   document.form_ajout_admin.elements['activite_num'+id].checked=false;
 }  
else
 {
   document.images['coche'+id].src=coche.src;
   document.form_ajout_admin.elements['activite_num'+id].checked=true;
 }  

}

function coche_decoche_modif(id)
{
 if (document.form_modif_admin.elements['activite_num'+id].checked==true)
 {
   document.images['coche'+id].src=decoche.src;
   document.form_modif_admin.elements['activite_num'+id].checked=false;
 }  
else
 {
   document.images['coche'+id].src=coche.src;
   document.form_modif_admin.elements['activite_num'+id].checked=true;
 }  

}

function gere_acces(acces)
{
  if (acces)
  {
          document.getElementById('droits_modeles').style.visibility='visible';
      document.getElementById('droits_modeles').style.display='block';		  
  }
  else
  {
          document.getElementById('droits_modeles').style.visibility='hidden';
      document.getElementById('droits_modeles').style.display='none';
  }	   
}

function maj_droits(tab_profils)
{
  var acces=false;
  for (i=0;i<tab_profils.length;i++)
  {
          if (document.form_ajout_admin.Fprofil.value==tab_profils[i])
          {
                  acces=true;
          }
  }
  gere_acces(acces);
}

function maj_droits_modif(tab_profils)
{
  var acces=false;
  for (i=0;i<tab_profils.length;i++)
  {
          if (document.form_modif_admin.Fprofil.value==tab_profils[i])
          {
                  acces=true;
          }
  }
  gere_acces(acces);
}   